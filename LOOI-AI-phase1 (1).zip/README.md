# Yasmin AI 3.0 — Native Android JARVIS Personal AI Assistant & Coding Studio

Yasmin AI 3.0 is a JARVIS-inspired native Android AI voice assistant, phone automation controller, multimodal AI Vision analyzer, Smart Memory 3.0 & Personal Hub, and dual-sandbox Python + HTML/CSS/JS coding studio built with **Kotlin**, **XML Views**, **MVVM + Repository**, **Room (v3 with non-destructive migrations)**, **DataStore**, **Android Keystore AES-256-GCM**, **Chaquopy 17.2.0**, and **GitHub Actions Cloud CI**.

Built so you can upload and compile the APK **100% in the cloud via GitHub Actions** directly from an Android phone — no Android Studio or local Android SDK required.

---

## Architecture & Upgrades in Yasmin AI 3.0

- **Language & UI**: Kotlin `2.0.21`, Native Android XML Layouts, Material 3 Dark JARVIS Glass Theme, custom Canvas `JarvisVisualizerView` with dual-ring & live acoustic RMS waveform animation, plus real-time **Online AI vs Offline Local Mode** status indicator.
- **Non-Destructive Database & Architecture**: MVVM + Repository (`ViewModel`, `StateFlow`, `Room 2.6.1`, `DataStore 1.1.1`)
  - **Room v3 Non-Destructive Migrations**: Removed `.fallbackToDestructiveMigration()` and implemented explicit `MIGRATION_1_2` and `MIGRATION_2_3` (`room.schemaLocation` exported via KSP) so user chats, memories, tasks, and voice command logs are never wiped across updates.
  - Eliminated main-thread `runBlocking` startup stall in `YasminRepository`.
- **Modular AI Brain (`GeminiBackendClient` & `/server.ts`)**:
  - **Primary Provider Selection**: Switch between **Gemini Backend Proxy** (`gemini-4-hydrogen`) and any **OpenAI-Compatible** endpoint (URL, model ID, encrypted Keystore API key).
  - **Automatic Fallback**: Automatically fails over between providers when enabled in Settings.
  - **SSE Streaming & Personalities**: Real-time token streaming for conversational queries + configurable AI personality presets (`JARVIS Formal`, `Concise Tactical`, `Friendly Companion`, `Coding Mentor`), Search Grounding, and multi-step tool planning (`/api/gemini/agent`).
- **True Offline Wake Word Engine (`OfflineWakeWordDetector` + `WakeWordEngine`)**:
  - Zero `SpeechRecognizer` calls during wake detection.
  - Stage 1: Low-power `AudioRecord` 16kHz PCM adaptive ambient noise floor + RMS/ZCR VAD ring buffer.
  - Stage 2: Pure-Kotlin **Radix-2 FFT + 20-band Mel filterbank + 13-dim MFCC + Cepstral Mean Normalization + Dynamic Time Warping (DTW)** matching against user-enrolled `"Hey Yasmin"` acoustic voiceprints (recorded in Settings), with a conservative multi-syllable acoustic cadence fallback when 0 templates are enrolled.
  - *Acoustic limitation note*: Personalized MFCC+DTW voiceprints (2–3 samples) provide speaker-specific offline matching, whereas full speaker-independent neural wake spotting would require shipping a trained `.tflite` keyword spotting model.
- **Natural Voice System (`VoiceAssistantManager`)**:
  - Explicit `AudioManager` `AudioFocusRequest` lifecycle management (acquire during speaking/listening, release cleanly on completion/error).
  - Selectable installed **TTS voice profiles**, English (`en-US`), Hindi (`hi-IN`), and Hinglish (`en-IN`), speed (`0.5x–2.0x`), pitch (`0.6x–1.8x`), instant stop button, and spoken `"stop listening"` / `"stop yasmin"` / `"band karo"` interruption.
- **Offline Local Intelligence (`OfflineAssistantEngine`)**:
  - When internet or backend is unavailable, clearly displays **OFFLINE MODE** and handles on-device arithmetic evaluation, offline reminder scheduling (`AlarmManager` + notification), local Room memory Q&A/search, pending task lists, calendar events, and device hardware controls without fabricating cloud AI replies.
- **Phone Automation, Calendar & Smart Reminders**:
  - Installed app launcher (`PackageManager`), YouTube search, flashlight (`CameraManager`), volume (`AudioManager`), brightness, system settings, alarms/timers (`AlarmClock`).
  - **Calendar Integration (`CalendarHelper`)**: Reads upcoming 7-day events (`READ_CALENDAR`) and launches Calendar event creation.
  - **Scheduled Reminders (`ReminderScheduler` + `ReminderBroadcastReceiver`)**: Schedules real local Android notifications via `AlarmManager.setAndAllowWhileIdle` (e.g. `"Remind me in 15 minutes to drink water"`).
  - Contacts lookup (`READ_CONTACTS`) + explicit user confirmation dialogs for calls, SMS drafts, WhatsApp drafts, and Accessibility UI actions (`YasminAccessibilityService`, `YasminNotificationListenerService`).
- **Smart Memory 3.0 (`MemoryEngine` + `MemoryPrivacyGuard`)**:
  - Semantic token + TF overlap + recency + importance + frequency ranking (`rankRelevantMemories`), duplicate merging, auto-extraction of safe facts, category filtering, live search, tap-to-edit dialogs, and strict secret/OTP/card rejection.
- **AI Vision System (`VisionFragment` + `ScreenCaptureManager`)**:
  - Deterministic `ImageReader.setOnImageAvailableListener` MediaProjection single-frame capture with `AtomicBoolean` & 2.5s watchdog (replacing fragile timer delays), Camera photo capture, and Gallery upload across 5 modes (General, OCR, Document Summary, UI Helper, Object Identifier).
- **Dual-Sandbox Coding Studio 3.0**:
  - **On-Device Python 3.11 (Chaquopy 17.2.0)**: AST validator + blocked imports + `4.0s` / `400k` step timeout + `32 KB` cap. *(In-process on Android without OS `fork` memory limits.)*
  - **Backend OS-Isolated Subprocess Python Sandbox (`/api/sandbox/python`)**: Toggleable mode executing Python inside a clean ephemeral temp directory with `-I -B` isolation, scrubbed environment variables (zero API keys/tokens), disabled `socket`, `RLIMIT_CPU`/`RLIMIT_AS`/`RLIMIT_FSIZE`, and hard `4.5s` `SIGKILL`.
  - **IDE Intelligence**: Tap-to-insert snippet completion chips (`def`, `for`, `try/except`, HTML/CSS/JS patterns), static local lint checker (`CodeIntelligenceHelper`), and **GitHub Gist** clipboard/web export alongside ZIP import/export.

---

## Required Android Permissions

| Permission / Service | Purpose | Required or Optional |
|---|---|---|
| `INTERNET`, `ACCESS_NETWORK_STATE` | Connect to Gemini Proxy / OpenAI-compatible AI & remote sandbox | Optional (Offline engine works locally) |
| `RECORD_AUDIO` | Voice commands, MFCC wake enrollment & `"Hey Yasmin"` offline engine | Required for voice |
| `FOREGROUND_SERVICE`, `FOREGROUND_SERVICE_MICROPHONE`, `POST_NOTIFICATIONS` | Active microphone, scheduled reminders & screen-capture notifications | Required for Wake / Reminders |
| `FOREGROUND_SERVICE_MEDIA_PROJECTION` | Explicit-consent single-frame Screen AI snapshot | Optional (Vision Screen AI) |
| `CAMERA` | Camera photo capture inside AI Vision | Optional (Camera Vision) |
| `READ_CONTACTS` | Lookup contact numbers for confirmed dial/SMS/WhatsApp drafts | Optional |
| `READ_CALENDAR` | Read upcoming events for Daily Briefings & schedule voice queries | Optional |
| `CALL_PHONE`, `SET_ALARM` | Launch dialer / set alarms & timers | Optional |
| `YasminNotificationListenerService` | Read active notifications on request | Optional (System Notification Access) |
| `YasminAccessibilityService` | On-demand `"Read my screen"` & user-approved gestures | Optional (System Accessibility) |

---

## 1. Configuring AI Providers & Secure Backend Proxy

Yasmin AI **never** stores any Gemini or OpenAI API key in Kotlin, XML, `BuildConfig`, or GitHub source files.

1. Deploy the included standalone Express proxy server in `backend/` (with `Dockerfile`, `package.json`, `server.ts`, `.env.example`, or root `/server.ts`) locally, on Google Cloud Run, Railway, or your preferred HTTPS host with:
   - `GEMINI_API_KEY` set in the server environment
   - Optional `YASMIN_PROXY_TOKEN` set on the server if you want Bearer-token protection
2. Open Yasmin AI on Android → **Settings** tab:
   - Choose your **Primary AI Provider** (`Gemini Backend Proxy` or `OpenAI-Compatible Endpoint`), **AI Personality Preset**, and optional **Automatic Fallback** toggle.
   - Enter your **Backend Proxy URL** (e.g. `https://your-service.example.com`) and optional **Proxy Bearer Token** / **OpenAI-Compatible API Key** (all encrypted in Android Keystore `SecureVault`).
   - Tap **Save & Test AI Providers**.

---

## 2. Mobile Upload & Cloud APK Build via GitHub Actions

1. Download `YasminAI.zip` from the web studio and extract it in your Android **Files** app.
2. Open Chrome on Android, switch to **Desktop site**, create a repo named `Yasmin-AI` on GitHub, and upload all extracted files preserving `app/`, `gradle/`, `build.gradle.kts`, `settings.gradle.kts`, `gradlew`, and `.github/workflows/android-build.yml`.
3. Open the **Actions** tab → **Yasmin AI Debug APK Build** → **Run workflow** (runs `./gradlew testDebugUnitTest compileDebugKotlin assembleDebug --stacktrace`).
4. Once green, download **`Yasmin-AI-APK`** under **Artifacts**, extract `app-debug.apk`, and install it on your Android device.

> **Verification Transparency**: Because Gradle and the Android SDK are not installed inside this web studio container, Android APK compilation and JUnit execution run on GitHub Actions (`ubuntu-latest` + Temurin JDK 17 + Python 3.11). Locally in this container, Python AST sandbox tests, Android XML/ViewBinding/Manifest static audits, TypeScript/React build + lint, and Express backend API smoke tests (including OS-isolated `/api/sandbox/python` and Gemini endpoints) are executed and verified directly.
