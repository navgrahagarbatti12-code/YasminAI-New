# Yasmin AI v4.0.0 — Native Android JARVIS Assistant & Ultimate YouTube AI Agent

Yasmin AI (`com.yasmin.ai`) is a JARVIS-inspired native Android AI personal voice assistant, device controller, Ultimate YouTube AI Agent, AI Vision workspace, and multi-language coding studio built with **Kotlin**, **XML Layouts**, **MVVM + Repository**, **Room (v5 with non-destructive migrations)**, **DataStore**, **Android Keystore AES-256-GCM**, **WorkManager**, **Storage Access Framework (SAF)**, **Chaquopy 17.2.0**, and **GitHub Actions Cloud CI**.

Built to be managed and compiled **100% in the cloud via GitHub Actions** (`ubuntu-latest`) with zero hardcoded API keys.

---

## Implemented Capabilities

### 1. Ultimate YouTube AI Agent (Parts 1–3)
- **Multilingual YouTube Voice Control (English, Hindi & Hinglish)**:
  - Open YouTube, Search videos/Shorts/tutorials/educational/latest/creator, Open channel, Open playlist, Watch Later shortcut, Play/Resume, Pause, Seek forward/backward 10s, Next/Previous video, Volume up/down, Enter/Exit Fullscreen, Close/Minimize video, Read YouTube screen, Summarize, Generate notes, Learning & Quiz.
  - Verifies actual playback & control results via Android Intents, `AudioManager.dispatchMediaKeyEvent`, and user-authorized `YasminAccessibilityService`; never claims unsupported actions succeeded.
- **Video Identification, Official Metadata & Public Captions (`YouTubeDataService`)**:
  - Supports YouTube Data API v3 (`search`, `videos`, `playlistItems`) via optional encrypted key in `SecureVault`, plus official YouTube **oEmbed** metadata fallback when no YouTube Data API key is entered.
  - Discovers creator-enabled public captions & TimedText XML/JSON3 tracks preserving `[MM:SS]` timestamps and language switching; chunks long transcripts cleanly; reports `NO CAPTIONS` or `RESTRICTED` honestly without scraping hacks or fabricated content.
- **AI Video Summarizer & Grounded Q&A (`YouTubeAiEngine`)**:
  - Styles: Short, Detailed, Complete Transcript (map-reduce chunked), Topic-Wise, Step-by-Step, Important Points, Practical Examples, and Chapter-Wise.
  - Languages: English, Hindi (Devanagari), and Hinglish.
  - Context-aware Video Q&A grounded strictly in transcript, chapters, metadata, and optional user-consented screen text.
- **Structured Notes Generator & TXT/PDF Export (`NoteExportManager`)**:
  - Generates Topic, Definitions, Bullet Points, Step-by-Step notes, and Important Timestamps.
  - Persists searchable notes in Room (`video_notes`), deletes with confirmation dialog, and exports `.txt` and multi-page native `PdfDocument` `.pdf` files via `FileProvider` + optional SAF sync.
- **Interactive Learning Mode & Quiz**:
  - Basic, Advanced Deep Dive, Practical Examples, and Interactive Teaching lessons.
  - Generates 5-question MCQ quizzes, evaluates answers with scores & explanations for incorrect choices, and tracks learning progress in Room (`learning_sessions`).
- **Accessibility & Consented Screen Vision**:
  - Reads visible YouTube title, channel, controls, search items, and descriptions/comments via user-enabled `YasminAccessibilityService`, plus one-shot `MediaProjection` screenshot analysis via Gemini Vision.

### 2. Dual Direct AI Brain (Groq + Google Gemini ONLY) & Automatic Fallback
- **Direct Groq Cloud API (`https://api.groq.com/openai/v1`)** (default primary) & **Direct Google Gemini REST (`v1beta`)** + optional self-hosted Gemini/Groq gateway.
- Timeout, bounded transient retry (`429`/`5xx`/`IOException`), ordered automatic fallback, dynamic model fetching, and zero OpenAI provider anywhere.
- **Zero Plaintext Secret Exposure**: All API keys and tokens are encrypted locally via **Android Keystore AES-256-GCM** (`SecureVault`).

### 3. Preserved Yasmin AI v3 Core Capabilities
- Voice-to-Voice assistant (`SpeechRecognizer` + female Android TTS + barge-in), MFCC+DTW offline `"Hey Yasmin"` wake engine, Safe Phone Automation, Chaquopy 3.11 Python sandbox, HTML/JS WebView IDE, Multi-Language AI Coding Agent (`WorkManager`), Memory & Tasks Hub, and 12-Section Settings screen.

---

## Key Dependencies & Versions

- **Gradle Wrapper**: `8.11.1` · **AGP**: `8.7.3` · **Kotlin**: `2.1.21` · **KSP**: `2.1.21-2.0.2`
- **Android SDK**: `minSdk 26`, `compileSdk 35`, `targetSdk 35`
- **Core Libraries**: `androidx.room:*:2.7.2` (Schema v5, `MIGRATION_1_2` -> `MIGRATION_4_5`), `androidx.work:work-runtime-ktx:2.10.1`, `androidx.documentfile:documentfile:1.0.1`, `androidx.datastore:datastore-preferences:1.1.1`, `androidx.navigation:navigation-*:2.8.4`, `okhttp3:4.12.0`, `gson:2.11.0`, `com.chaquo.python:17.2.0`

---

## GitHub Actions APK Build

1. Push the repository to GitHub (`main` or `master`) or trigger **Actions -> Yasmin AI Android CI -> Run workflow**.
2. `.github/workflows/android.yml` executes `./gradlew clean testDebugUnitTest lintDebug assembleDebug` and uploads `Yasmin-AI-Debug-APK`.
3. `.github/workflows/android-release.yml` builds signed release `.apk` / `.aab` using repository secrets (`ANDROID_KEYSTORE_BASE64`, `ANDROID_KEYSTORE_PASSWORD`, `ANDROID_KEY_ALIAS`, `ANDROID_KEY_PASSWORD`).

---

## Known Limitations & Platform Notes
- **Account-Specific Watch Later / Subscriptions**: Personal playlists (`WL`/`LL`) require signed-in YouTube OAuth or opening directly in the YouTube app (`ACTION_VIEW`), as Yasmin never extracts browser cookies or passwords.
- **Disabled / Restricted Captions**: If a creator disables captions or restricts playback, Yasmin marks transcript status `NO CAPTIONS` / `RESTRICTED` and grounds answers strictly in available metadata or user-consented screen text.
- **Accessibility Controls**: Exact `+10s`/`-10s` seek gestures and Fullscreen/Close UI actions inside the YouTube app require the user to enable `YasminAccessibilityService`.
- **Verification Environment**: The web workbench sandbox lacks JDK 17 / Gradle / Android SDK, so Gradle unit tests, Android Lint, and APK generation run inside GitHub Actions CI.
