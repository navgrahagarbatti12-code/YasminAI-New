# Yasmin AI v4.0.0 — Honest Testing & Verification Report

## Environment Constraints
In this sandboxed web build container:
- Installed tools: Node.js v22, Python 3, Vite/TypeScript.
- **Unavailable tools**: JDK (`java`/`javac`), `kotlinc`, Gradle daemon, Android SDK, and Android Emulator / physical ADB device.
- Accordingly, `./gradlew testDebugUnitTest lintDebug assembleDebug` could **not** execute locally and **must run in GitHub Actions CI** (`.github/workflows/android.yml`). We make zero false claims of local APK compilation or runtime instrumentation execution.

## 1. Automated Static Checks Executed Locally (PASS)
- **ViewBinding Audit**: Verified 68 `binding.*` references in `YouTubeAgentFragment.kt` and all binding references across `YouTubeSearchAdapter`, `SavedNoteAdapter`, `QuizQuestionAdapter`, and `LearningHistoryAdapter` match exact `@+id/*` definitions in XML layouts.
- **Room Schema v5 Alignment**: Verified `VideoNoteEntity` and `LearningSessionEntity` columns match `YasminDatabase.MIGRATION_4_5` SQL statements.
- **Provider Policy Audit**: Confirmed zero OpenAI provider support; only Groq (`https://api.groq.com/openai/v1`) and Google Gemini (`generativelanguage.googleapis.com` / optional proxy) exist.
- **Secrets Audit**: Confirmed zero hardcoded Gemini, Groq, or YouTube API keys in `src/main/`.

## 2. JUnit 4 Unit Tests Written for GitHub Actions CI
Run via `./gradlew testDebugUnitTest`:
- `YouTubeVoiceCommandTest.kt` — EN / Hindi Devanagari / Hinglish recognition for YouTube home, agent, search/shorts/tutorial filters, play/pause/resume, forward/backward 10s, next/prev, volume, fullscreen/exit, close, channel, playlist, watch later, Hindi/Hinglish summarize, notes, quiz, read screen, and non-YouTube negative test.
- `YouTubeTranscriptAndUrlTest.kt` — URL/Shorts/Live/`youtu.be`/ID/playlist extraction, ISO 8601 duration parsing, chapters parser, TimedText XML & JSON3 caption parsing with preserved timestamps, transcript chunking, filtered search queries.
- `YouTubeNotesAndQuizTest.kt` — Structured JSON notes parsing, filename sanitization, `.txt` export formatter, MCQ quiz JSON parsing, score evaluation, and incorrect-answer explanations.
- `YouTubeGroundingAndAiTest.kt` — Transcript unavailable/restricted honest flagging in AI grounding block and EN/HI/HINGLISH language directives.
- Preserved v3 suites: `ProviderPolicyTest`, `ProviderClientAndErrorTest`, `MemoryEngineTest`, `MemoryPrivacyGuardTest`, `ReminderSchedulerParserTest`, `OfflineWakeWordDetectorTest`, `ProjectFilePathSanitizerTest`, `AgentActionModelTest`, `GeminiModelsTest`.

## 3. Manual On-Device QA Matrix (After Installing GitHub Actions `app-debug.apk`)
1. Permission Denied Cases: Trigger Accessibility playback controls and Screen Vision without enabling permissions; confirm guided Setup dialogs appear cleanly without crashes.
2. Live Playback Controls: Test Play/Pause/Seek +10s/-10s/Fullscreen/Close while playing a video in the official YouTube Android app with `YasminAccessibilityService` enabled.
3. Unavailable Captions: Load a music/restricted/no-caption video and confirm `NO CAPTIONS` / `RESTRICTED` badge shows and summary does not invent spoken dialogue.
4. Notes Export: Generate structured notes, tap `Export TXT` and `Export PDF`, verify `FileProvider` share sheet opens a readable `.txt` and multi-page `.pdf`.
5. Learning & Quiz: Generate Lesson + 5-Q Quiz, answer mixed right/wrong, tap `Evaluate Answers`, confirm score & wrong-answer explanations appear and persist to History.
