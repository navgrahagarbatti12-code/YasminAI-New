# Yasmin AI — Android Studio & Cloud CI Setup Instructions

This guide covers setting up, configuring, building, and testing the **Yasmin AI Ultimate YouTube Agent** native Android (Kotlin) project in Android Studio or GitHub Actions.

---

## 1. Prerequisites
- **Android Studio**: Ladybug (2024.2.1) or newer
- **JDK**: Java 17 (required by AGP 8.7.3 & Kotlin 2.1.21)
- **Android SDK**: `compileSdk 35`, `minSdk 26`, `targetSdk 35`
- **Python Build Toolchain** *(for Chaquopy 17.2.0)*: Python 3.8–3.12 installed on your local machine when compiling locally (GitHub Actions installs this automatically)

---

## 2. Opening in Android Studio
1. Extract **`YASMIN_AI_ULTIMATE_YOUTUBE_AGENT.zip`**.
2. Open **Android Studio -> File -> Open** and select the extracted project root folder (the folder containing `settings.gradle.kts` and `build.gradle.kts`).
3. Allow Android Studio to download Gradle `8.11.1` (configured in `gradle/wrapper/gradle-wrapper.properties`) and sync dependencies.
   - Note: `gradle-wrapper.jar` is omitted from the lightweight archive; Android Studio's Gradle sync creates/uses the wrapper automatically, or you can run `gradle wrapper --gradle-version 8.11.1` from a local terminal with Gradle installed.
4. Confirm zero hardcoded secrets exist in `local.properties` or source files.

---

## 3. Configuring API Keys (Zero Hardcoded Secrets)
All API keys are configured inside the running app and encrypted via **Android Keystore AES-256-GCM** (`SecureVault`):

1. Launch Yasmin AI on your device or emulator.
2. Open the **Settings** tab (12-Section Settings UI).
3. Under **AI Providers (Groq + Gemini ONLY)**:
   - **Groq API Key**: Enter your key from `https://console.groq.com/keys` (used for ultra-fast summaries, Q&A, notes, quizzes, and chat).
   - **Gemini API Key**: Enter your key from Google AI Studio (used for long-context analysis, screen understanding, and vision fallback).
   - Optional: Choose your primary AI provider (`AUTO`, `GROQ`, `GEMINI`), preferred models, and automatic fallback.
4. Under **YouTube Data API v3 (Optional)**:
   - Enter a YouTube Data API v3 key to unlock rich search filtering (Tutorials, Educational, Latest, Shorts, Channels, Playlists) with duration & description metadata.
   - If left blank, Yasmin still supports official YouTube oEmbed metadata lookup, public TimedText caption parsing, voice playback controls, and Accessibility-assisted reading.

---

## 4. Enabling Permissions & Optional Services
- **Microphone (`RECORD_AUDIO`)**: Required for voice commands (English, Hindi, Hinglish) and offline `"Hey Yasmin"` wake detection.
- **Yasmin Accessibility Service** *(User-Controlled)*:
  - Open **Android Settings -> Accessibility -> Yasmin Accessibility Service** and toggle it on.
  - Unlocks exact in-app YouTube UI actions (`+10s` / `-10s` seek, Enter/Exit Fullscreen, Close video, reading currently visible video title, channel, controls, comments, and scrolling).
- **Screen Capture (`MediaProjection`)** *(Per-Session Explicit Consent)*:
  - Triggered only when you tap **Read Screen / Vision** and accept the Android system capture prompt.

---

## 5. Building Debug APK & Running Unit Tests Locally
From the project root (with JDK 17 + Android SDK configured):
```bash
chmod +x gradlew
./gradlew clean testDebugUnitTest lintDebug assembleDebug
```
- **Unit Test Reports**: `app/build/reports/tests/testDebugUnitTest/`
- **Debug APK Output**: `app/build/outputs/apk/debug/app-debug.apk`

---

## 6. Building Debug & Signed Release APKs on GitHub Actions
1. Push the extracted project root to a GitHub repository (`main` or `master`).
2. **Debug APK + Unit Tests + Lint (`.github/workflows/android.yml`)**:
   - Runs automatically on push/PR or manually via **Actions -> Yasmin AI Android CI -> Run workflow**.
   - Automatically provisions Gradle Wrapper `8.11.1`, Java 17, Android SDK, executes `testDebugUnitTest`, `lintDebug`, and `assembleDebug`, and publishes **`Yasmin-AI-Debug-APK`** as a downloadable build artifact.
3. **Signed Release APK / AAB (`.github/workflows/android-release.yml`)**:
   - Add GitHub Repository Secrets:
     - `ANDROID_KEYSTORE_BASE64`
     - `ANDROID_KEYSTORE_PASSWORD`
     - `ANDROID_KEY_ALIAS`
     - `ANDROID_KEY_PASSWORD`
   - Run **Actions -> Yasmin AI Signed Release** to generate a signed Play Store `.aab` and `.apk`.
