# Yasmin AI 3.0 ProGuard / R8 Rules

-keep class com.yasmin.ai.ai.** { *; }
-keep class com.yasmin.ai.data.local.** { *; }
-keep class com.yasmin.ai.data.preferences.** { *; }
-keep class com.yasmin.ai.ui.views.** { *; }
-keepattributes Signature
-keepattributes *Annotation*
-keepattributes InnerClasses

# DataStore Preferences & Protobuf
-keepclassmembers class * extends androidx.datastore.preferences.protobuf.GeneratedMessageLite {
    <fields>;
}

# Kotlin Coroutines
-dontwarn kotlinx.coroutines.**

# OkHttp & Gson
-dontwarn okhttp3.**
-dontwarn okio.**
-keep class com.google.gson.reflect.TypeToken { *; }
-keep class * extends com.google.gson.reflect.TypeToken
-keepclassmembers class * {
    @com.google.gson.annotations.SerializedName <fields>;
}

# Chaquopy
-keep class com.chaquo.python.** { *; }
