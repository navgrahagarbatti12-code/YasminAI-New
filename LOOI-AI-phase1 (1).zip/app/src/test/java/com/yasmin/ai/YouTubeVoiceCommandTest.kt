package com.yasmin.ai

import com.yasmin.ai.youtube.SummaryLanguage
import com.yasmin.ai.youtube.YouTubeSearchFilter
import com.yasmin.ai.youtube.YouTubeVoiceController
import com.yasmin.ai.youtube.YouTubeVoiceIntent
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class YouTubeVoiceCommandTest {

    @Test
    fun parsesOpenYouTubeAndAgentInEnglishHindiHinglish() {
        assertEquals(YouTubeVoiceIntent.OpenYouTube, YouTubeVoiceController.parseCommand("Open YouTube"))
        assertEquals(YouTubeVoiceIntent.OpenYouTube, YouTubeVoiceController.parseCommand("youtube kholo"))
        assertEquals(YouTubeVoiceIntent.OpenYouTube, YouTubeVoiceController.parseCommand("यूट्यूब खोलो"))
        assertEquals(YouTubeVoiceIntent.OpenYouTubeAgent, YouTubeVoiceController.parseCommand("Hey Yasmin open YouTube agent"))
        assertEquals(YouTubeVoiceIntent.OpenYouTubeAgent, YouTubeVoiceController.parseCommand("यूट्यूब एजेंट खोलो"))
    }

    @Test
    fun parsesSearchVideosWithFiltersInThreeLanguages() {
        val en = YouTubeVoiceController.parseCommand("Search YouTube for Kotlin coroutines tutorial")
        assertTrue(en is YouTubeVoiceIntent.SearchVideos)
        assertEquals(YouTubeSearchFilter.TUTORIAL, (en as YouTubeVoiceIntent.SearchVideos).filter)

        val shorts = YouTubeVoiceController.parseCommand("Search Python shorts on YouTube")
        assertTrue(shorts is YouTubeVoiceIntent.SearchVideos)
        assertEquals(YouTubeSearchFilter.SHORTS, (shorts as YouTubeVoiceIntent.SearchVideos).filter)

        val hinglish = YouTubeVoiceController.parseCommand("youtube pe Android Jetpack Compose search karo")
        assertTrue(hinglish is YouTubeVoiceIntent.SearchVideos)
        assertEquals("Android Jetpack Compose", (hinglish as YouTubeVoiceIntent.SearchVideos).query)

        val hindi = YouTubeVoiceController.parseCommand("यूट्यूब पर मशीन लर्निंग खोजो")
        assertTrue(hindi is YouTubeVoiceIntent.SearchVideos)
    }

    @Test
    fun parsesPlaybackControlsAndSeekInEnglishHindiHinglish() {
        assertEquals(YouTubeVoiceIntent.PlayOrResume, YouTubeVoiceController.parseCommand("Play video"))
        assertEquals(YouTubeVoiceIntent.PlayOrResume, YouTubeVoiceController.parseCommand("video chalao"))
        assertEquals(YouTubeVoiceIntent.PlayOrResume, YouTubeVoiceController.parseCommand("वीडियो चलाओ"))

        assertEquals(YouTubeVoiceIntent.Pause, YouTubeVoiceController.parseCommand("Pause video"))
        assertEquals(YouTubeVoiceIntent.Pause, YouTubeVoiceController.parseCommand("video roko"))
        assertEquals(YouTubeVoiceIntent.Pause, YouTubeVoiceController.parseCommand("वीडियो रोको"))

        assertEquals(YouTubeVoiceIntent.SeekForward(10), YouTubeVoiceController.parseCommand("Seek forward 10 seconds"))
        assertEquals(YouTubeVoiceIntent.SeekForward(10), YouTubeVoiceController.parseCommand("10 seconds forward"))
        assertEquals(YouTubeVoiceIntent.SeekForward(15), YouTubeVoiceController.parseCommand("15 second aage badhao"))
        assertEquals(YouTubeVoiceIntent.SeekBackward(10), YouTubeVoiceController.parseCommand("10 सेकंड पीछे करो"))
        assertEquals(YouTubeVoiceIntent.SeekBackward(10), YouTubeVoiceController.parseCommand("10 seconds back"))
        assertEquals(YouTubeVoiceIntent.PlayOrResume, YouTubeVoiceController.parseCommand("resume"))
        assertEquals(YouTubeVoiceIntent.CloseVideo, YouTubeVoiceController.parseCommand("close the video"))

        assertEquals(YouTubeVoiceIntent.NextVideo, YouTubeVoiceController.parseCommand("अगला वीडियो"))
        assertEquals(YouTubeVoiceIntent.PreviousVideo, YouTubeVoiceController.parseCommand("pichla video"))
        assertEquals(YouTubeVoiceIntent.VolumeUp, YouTubeVoiceController.parseCommand("awaaz badhao"))
        assertEquals(YouTubeVoiceIntent.VolumeDown, YouTubeVoiceController.parseCommand("आवाज़ कम करो"))
        assertEquals(YouTubeVoiceIntent.Fullscreen(true), YouTubeVoiceController.parseCommand("fullscreen mode"))
        assertEquals(YouTubeVoiceIntent.Fullscreen(false), YouTubeVoiceController.parseCommand("exit fullscreen"))
        assertEquals(YouTubeVoiceIntent.CloseVideo, YouTubeVoiceController.parseCommand("video band karo"))
    }

    @Test
    fun parsesChannelPlaylistWatchLaterSummaryNotesQuizAndScreenRead() {
        val ch = YouTubeVoiceController.parseCommand("Open channel Fireship")
        assertEquals(YouTubeVoiceIntent.OpenChannel("fireship"), ch)

        val pl = YouTubeVoiceController.parseCommand("Open playlist Android Architecture")
        assertEquals(YouTubeVoiceIntent.OpenPlaylist("android architecture", false), pl)

        val wl = YouTubeVoiceController.parseCommand("Open watch later")
        assertEquals(YouTubeVoiceIntent.OpenPlaylist("WL", true), wl)

        val sumHi = YouTubeVoiceController.parseCommand("Summarize this video in Hindi")
        assertEquals(YouTubeVoiceIntent.SummarizeCurrent(SummaryLanguage.HINDI), sumHi)

        val sumHinglish = YouTubeVoiceController.parseCommand("is video ka summary batao")
        assertEquals(YouTubeVoiceIntent.SummarizeCurrent(SummaryLanguage.HINGLISH), sumHinglish)

        val qa = YouTubeVoiceController.parseCommand("What is this video about?")
        assertTrue(qa is YouTubeVoiceIntent.AskAboutVideo)

        val qaChap = YouTubeVoiceController.parseCommand("Explain the second chapter")
        assertTrue(qaChap is YouTubeVoiceIntent.AskAboutVideo)

        val playSearch = YouTubeVoiceController.parseCommand("Play Jetpack Compose tutorial on YouTube")
        assertTrue(playSearch is YouTubeVoiceIntent.SearchVideos)

        assertEquals(YouTubeVoiceIntent.GenerateNotes, YouTubeVoiceController.parseCommand("Make notes for video"))
        assertEquals(YouTubeVoiceIntent.StartLearningOrQuiz, YouTubeVoiceController.parseCommand("Quiz me on this video"))
        assertEquals(YouTubeVoiceIntent.ReadYouTubeScreen, YouTubeVoiceController.parseCommand("What video is playing"))
    }

    @Test
    fun returnsNullForNonYouTubeUtterances() {
        assertNull(YouTubeVoiceController.parseCommand("Open Chrome"))
        assertNull(YouTubeVoiceController.parseCommand("Remind me in 10 minutes to call Alex"))
        assertNull(YouTubeVoiceController.parseCommand(""))
    }
}
