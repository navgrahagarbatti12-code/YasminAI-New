package com.yasmin.ai

import com.yasmin.ai.automation.DeviceControlManager
import com.yasmin.ai.coding.ProjectFileManager
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class ProjectFilePathSanitizerTest {

    @Test
    fun sanitizeProjectNameStripsUnsafeCharacters() {
        assertEquals("my_app_1", ProjectFileManager.sanitizeProjectName("my app/1!"))
        assertEquals("yasmin_project", ProjectFileManager.sanitizeProjectName("///"))
    }

    @Test
    fun sanitizeRelativePathRejectsTraversal() {
        assertNull(ProjectFileManager.sanitizeRelativePath("../secret.txt"))
        assertNull(ProjectFileManager.sanitizeRelativePath("src/../../evil.kt"))
        assertEquals("src/Main.kt", ProjectFileManager.sanitizeRelativePath("/src/Main.kt"))
    }

    @Test
    fun detectLanguageRecognizesCommonExtensions() {
        assertEquals("Kotlin", ProjectFileManager.detectLanguageForPath("app/MainActivity.kt"))
        assertEquals("Python", ProjectFileManager.detectLanguageForPath("bot/runner.py"))
        assertEquals("C++", ProjectFileManager.detectLanguageForPath("engine/core.cpp"))
        assertEquals("PHP", ProjectFileManager.detectLanguageForPath("api/index.php"))
    }

    @Test
    fun normalizeUrlPrependsHttpsWhenMissing() {
        assertEquals("https://github.com", DeviceControlManager.normalizeUrl("github.com"))
        assertEquals("http://localhost:8080", DeviceControlManager.normalizeUrl("http://localhost:8080"))
    }
}
