package com.yasmin.ai

import com.yasmin.ai.ai.GeminiBackendClient
import com.yasmin.ai.data.preferences.YasminUserPreferences
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Test

/** Guards the product rule: Groq (primary) + Gemini (fallback) are the only AI providers. */
class ProviderPolicyTest {

    @Test
    fun groqIsTheDefaultPrimaryProvider() {
        assertEquals(GeminiBackendClient.PROVIDER_GROQ, YasminUserPreferences().providerType)
    }

    @Test
    fun noOpenAiProviderLabelExists() {
        listOf(
            GeminiBackendClient.PROVIDER_GROQ,
            GeminiBackendClient.PROVIDER_GEMINI_DIRECT,
            GeminiBackendClient.PROVIDER_GEMINI_PROXY,
            "openai_compatible"
        ).forEach {
            assertFalse(GeminiBackendClient.providerDisplayLabel(it).contains("OpenAI", ignoreCase = true))
        }
    }
}
