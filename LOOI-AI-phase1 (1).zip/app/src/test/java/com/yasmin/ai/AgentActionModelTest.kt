package com.yasmin.ai

import com.yasmin.ai.ai.GeminiAgentAction
import com.yasmin.ai.ai.GeminiAgentResponse
import org.junit.Assert.assertEquals
import org.junit.Test

class AgentActionModelTest {

    @Test
    fun agentActionPreservesToolAndArguments() {
        val action = GeminiAgentAction(
            tool = "set_alarm",
            arg1 = "7",
            arg2 = "30",
            arg3 = "Morning Briefing"
        )
        val response = GeminiAgentResponse(
            reply = "Setting an alarm for 7:30 AM.",
            actions = listOf(action)
        )
        assertEquals(1, response.actions.size)
        assertEquals("set_alarm", response.actions.first().tool)
        assertEquals("7", response.actions.first().arg1)
        assertEquals("30", response.actions.first().arg2)
    }
}
