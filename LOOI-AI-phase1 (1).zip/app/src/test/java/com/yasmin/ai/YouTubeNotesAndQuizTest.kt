package com.yasmin.ai

import com.yasmin.ai.data.local.VideoNoteEntity
import com.yasmin.ai.youtube.NoteExportManager
import com.yasmin.ai.youtube.YouTubeAiEngine
import com.yasmin.ai.youtube.YouTubeVideoInfo
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class YouTubeNotesAndQuizTest {

    private val sampleVideo = YouTubeVideoInfo(
        videoId = "abc123XYZ89",
        title = "Kotlin Coroutines Deep Dive",
        channelTitle = "Android Dev Lab",
        durationFormatted = "18:40"
    )

    @Test
    fun parsesStructuredNotesJsonAndSanitizesFilenames() {
        val raw = """
            ```json
            {
              "topic": "Structured Concurrency",
              "definitions": "CoroutineScope: manages lifetime of child coroutines.",
              "bulletPoints": "• Use viewModelScope for UI state\n• Dispatchers.IO for blocking network/disk calls",
              "stepByStep": "1. Create scope\n2. Launch suspend block",
              "importantTimestamps": "[02:10] Dispatchers\n[08:45] SupervisorJob",
              "fullMarkdown": "# Structured Concurrency\nFull study guide."
            }
            ```
        """.trimIndent()

        val bundle = YouTubeAiEngine.parseNotesJson(raw, sampleVideo)
        assertEquals("Structured Concurrency", bundle.topic)
        assertTrue(bundle.definitions.contains("CoroutineScope"))
        assertTrue(bundle.importantTimestamps.contains("[08:45]"))

        val safeName = NoteExportManager.sanitizeFilename("Kotlin: Coroutines / Deep? Dive* 2026!")
        assertFalse(safeName.contains(":"))
        assertFalse(safeName.contains("/"))
        assertFalse(safeName.contains("*"))

        val entity = VideoNoteEntity(
            id = 7L,
            videoId = sampleVideo.videoId,
            videoTitle = sampleVideo.title,
            channelTitle = sampleVideo.channelTitle,
            topic = bundle.topic,
            markdownContent = bundle.fullMarkdown,
            definitionsText = bundle.definitions,
            bulletPointsText = bundle.bulletPoints,
            stepsText = bundle.stepByStep,
            timestampsText = bundle.importantTimestamps,
            language = "en"
        )
        val txt = NoteExportManager.buildPlainTextNote(entity)
        assertTrue(txt.contains("YASMIN AI — YOUTUBE VIDEO NOTES"))
        assertTrue(txt.contains("https://www.youtube.com/watch?v=abc123XYZ89"))
        assertTrue(txt.contains("Full study guide."))
    }

    @Test
    fun parsesQuizJsonAndEvaluatesCorrectAndWrongAnswersWithExplanations() {
        val quizJson = """
            {
              "questions": [
                {
                  "question": "Which dispatcher is best for disk and network I/O?",
                  "options": ["Dispatchers.Main", "Dispatchers.IO", "Dispatchers.Unconfined", "None"],
                  "correctIndex": 1,
                  "explanation": "Dispatchers.IO backs blocking I/O operations with an elastic thread pool.",
                  "topicTag": "Dispatchers"
                },
                {
                  "question": "What keeps sibling coroutines alive when one child fails?",
                  "options": ["SupervisorJob", "CancelToken", "MainScope Only", "Thread.sleep"],
                  "correctIndex": 0,
                  "explanation": "SupervisorJob isolates child failure propagation.",
                  "topicTag": "Error Handling"
                }
              ]
            }
        """.trimIndent()

        val questions = YouTubeAiEngine.parseQuizQuestionsJson(quizJson)
        assertEquals(2, questions.size)

        val evaluation = YouTubeAiEngine.evaluateQuiz(
            questions = questions,
            selectedAnswers = mapOf(1 to 1, 2 to 3)
        )
        assertEquals(2, evaluation.totalQuestions)
        assertEquals(1, evaluation.correctCount)
        assertEquals(50, evaluation.scorePercent)
        assertTrue(evaluation.feedback[0].isCorrect)
        assertFalse(evaluation.feedback[1].isCorrect)
        assertTrue(evaluation.feedback[1].explanation.contains("Correct answer: SupervisorJob"))
        assertTrue(evaluation.feedback[1].explanation.contains("SupervisorJob isolates child failure"))
    }
}
