package com.yasmin.ai

import com.yasmin.ai.youtube.SummaryLanguage
import com.yasmin.ai.youtube.TranscriptResult
import com.yasmin.ai.youtube.TranscriptStatus
import com.yasmin.ai.youtube.YouTubeAiEngine
import com.yasmin.ai.youtube.YouTubeVideoInfo
import org.junit.Assert.assertTrue
import org.junit.Test

class YouTubeGroundingAndAiTest {

    @Test
    fun groundingBlockFlagsUnavailableTranscriptHonestly() {
        val video = YouTubeVideoInfo(
            videoId = "xyz98765432",
            title = "Restricted Lecture",
            channelTitle = "Uni Channel",
            description = "Overview of distributed consensus"
        )
        val unavailable = TranscriptResult(
            videoId = video.videoId,
            status = TranscriptStatus.UNAVAILABLE,
            statusReason = "Creator-enabled captions/transcripts are unavailable for this video."
        )

        val block = YouTubeAiEngine.buildVideoGroundingBlock(
            video = video,
            transcript = unavailable,
            screenContextText = "Detected Title: Restricted Lecture"
        )
        assertTrue(block.contains("NO CAPTIONS"))
        assertTrue(block.contains("Creator-enabled captions/transcripts are unavailable"))
        assertTrue(block.contains("User-Consented Visible Screen Text"))
    }

    @Test
    fun languageDirectivesCoverEnglishHindiAndHinglish() {
        assertTrue(YouTubeAiEngine.languageDirective(SummaryLanguage.HINDI).contains("Devanagari"))
        assertTrue(YouTubeAiEngine.languageDirective(SummaryLanguage.HINGLISH).contains("Hinglish"))
        assertTrue(YouTubeAiEngine.languageDirective(SummaryLanguage.ENGLISH).contains("English"))
    }
}
