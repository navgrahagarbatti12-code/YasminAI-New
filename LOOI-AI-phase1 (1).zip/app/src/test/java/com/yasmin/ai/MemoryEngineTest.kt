package com.yasmin.ai

import com.yasmin.ai.data.local.MemoryEntity
import com.yasmin.ai.memory.MemoryEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class MemoryEngineTest {

    @Test
    fun ranksSemanticallyMatchingMemoriesHighest() {
        val now = System.currentTimeMillis()
        val items = listOf(
            MemoryEntity(
                id = 1,
                category = "preference",
                keyTitle = "Favorite Drink",
                content = "User likes green tea in the morning",
                importance = 2,
                createdAt = now - 10_000,
                updatedAt = now - 10_000
            ),
            MemoryEntity(
                id = 2,
                category = "project",
                keyTitle = "CNC Controller",
                content = "Building a Python G-code parser for CNC milling machine",
                importance = 4,
                createdAt = now - 5_000,
                updatedAt = now - 5_000
            )
        )

        val ranked = MemoryEngine.rankRelevantMemories("help with CNC python milling", items, limit = 2)
        assertEquals(2, ranked.size)
        assertEquals(2L, ranked.first().id)
    }

    @Test
    fun detectsDuplicateMemoryByTitleOrOverlap() {
        val existing = listOf(
            MemoryEntity(
                id = 10,
                category = "preference",
                keyTitle = "Preferred Language",
                content = "Always reply concisely in Hinglish"
            )
        )
        val match = MemoryEngine.findDuplicate("preferred language", "Reply in Hinglish", existing)
        assertNotNull(match)
        assertEquals(10L, match?.id)
    }

    @Test
    fun autoExtractsSafePreferenceAndRejectsSecrets() {
        val safe = MemoryEngine.extractSafeCandidate("Remember that I work as an embedded robotics engineer")
        assertNotNull(safe)
        assertEquals("fact", safe?.category)
        assertTrue(safe?.content?.contains("robotics") == true)

        val blocked = MemoryEngine.extractSafeCandidate("My bank otp is 492811 remember that")
        assertNull(blocked)
    }
}
