package com.yasmin.ai

import com.yasmin.ai.assistant.ReminderScheduler
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class ReminderSchedulerParserTest {

    @Test
    fun parsesSecondsMinutesAndHoursDelays() {
        assertEquals(30_000L, ReminderScheduler.parseRelativeDelayMs("Remind me in 30 seconds to check oven"))
        assertEquals(15 * 60_000L, ReminderScheduler.parseRelativeDelayMs("in 15 minutes"))
        assertEquals(2 * 3_600_000L, ReminderScheduler.parseRelativeDelayMs("Remind me in 2 hours about meeting"))
    }

    @Test
    fun returnsNullWhenNoRelativeDelayFound() {
        assertNull(ReminderScheduler.parseRelativeDelayMs("Buy groceries tomorrow"))
    }
}
