package com.yasmin.ai

import com.yasmin.ai.security.MemoryPrivacyGuard
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class MemoryPrivacyGuardTest {

    @Test
    fun allowsNormalPersonalPreferences() {
        val result = MemoryPrivacyGuard.sanitizeOrReject("Preferred Language: User prefers Hinglish responses")
        assertTrue(result.isSuccess)
    }

    @Test
    fun blocksPasswordsAndOtps() {
        assertTrue(MemoryPrivacyGuard.containsSensitiveData("My bank password is 12345"))
        assertTrue(MemoryPrivacyGuard.containsSensitiveData("OTP code is 492811"))
        assertTrue(MemoryPrivacyGuard.sanitizeOrReject("PIN number 4821").isFailure)
    }

    @Test
    fun blocksApiTokensAndCardNumbers() {
        assertTrue(MemoryPrivacyGuard.containsSensitiveData("AIzaSyDummyApiKeyTokenValue1234567890"))
        assertTrue(MemoryPrivacyGuard.containsSensitiveData("sk-projDummySecretKeyTokenValue1234567890"))
        assertTrue(MemoryPrivacyGuard.containsSensitiveData("4111 2222 3333 4444"))
        assertFalse(MemoryPrivacyGuard.containsSensitiveData("Meeting at 5 PM tomorrow"))
    }
}
