package com.yasmin.ai

import com.yasmin.ai.youtube.YouTubeDataService
import com.yasmin.ai.youtube.YouTubeSearchFilter
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class YouTubeTranscriptAndUrlTest {

    @Test
    fun extractsVideoIdFromAllStandardYouTubeUrlFormats() {
        assertEquals("dQw4w9WgXcQ", YouTubeDataService.extractVideoId("https://www.youtube.com/watch?v=dQw4w9WgXcQ"))
        assertEquals("dQw4w9WgXcQ", YouTubeDataService.extractVideoId("https://youtu.be/dQw4w9WgXcQ?t=42"))
        assertEquals("dQw4w9WgXcQ", YouTubeDataService.extractVideoId("https://youtube.com/shorts/dQw4w9WgXcQ"))
        assertEquals("dQw4w9WgXcQ", YouTubeDataService.extractVideoId("https://www.youtube.com/live/dQw4w9WgXcQ?feature=share"))
        assertEquals("dQw4w9WgXcQ", YouTubeDataService.extractVideoId("dQw4w9WgXcQ"))
        assertNull(YouTubeDataService.extractVideoId("not a valid id or url"))
    }

    @Test
    fun extractsPlaylistIdsAndFormatsDurations() {
        assertEquals(
            "PLrAXtmErZgOeiKm4sgNOknGvNjby9efdf",
            YouTubeDataService.extractPlaylistId("https://www.youtube.com/playlist?list=PLrAXtmErZgOeiKm4sgNOknGvNjby9efdf")
        )
        assertEquals(3723, YouTubeDataService.parseIsoDurationSeconds("PT1H2M3S"))
        assertEquals(75, YouTubeDataService.parseIsoDurationSeconds("PT1M15S"))
        assertEquals("1:02:03", YouTubeDataService.formatTimestampSeconds(3723))
        assertEquals("01:15", YouTubeDataService.formatTimestampSeconds(75))
    }

    @Test
    fun parsesChaptersAndTimedTextXmlAndJson3WithTimestamps() {
        val desc = """
            00:00 Introduction
            02:15 Architecture Overview
            1:01:05 Final Benchmark
        """.trimIndent()
        val chapters = YouTubeDataService.parseChaptersFromDescription(desc)
        assertEquals(3, chapters.size)
        assertEquals("02:15", chapters[1].timestampLabel)
        assertEquals("Architecture Overview", chapters[1].title)

        val xml = """
            <transcript>
              <text start="0.0" dur="3.5">Hello &amp; welcome</text>
              <text start="65.2" dur="4.0">Today we build a Kotlin app</text>
            </transcript>
        """.trimIndent()
        val xmlSegs = YouTubeDataService.parseTimedTextXml(xml)
        assertEquals(2, xmlSegs.size)
        assertEquals("00:00", xmlSegs[0].timestampLabel)
        assertEquals("Hello & welcome", xmlSegs[0].text)
        assertEquals("01:05", xmlSegs[1].timestampLabel)

        val json3 = """
            {
              "events": [
                {"tStartMs": 12000, "dDurationMs": 3000, "segs": [{"utf8": "Neural "}, {"utf8": "networks"}]}
              ]
            }
        """.trimIndent()
        val jsonSegs = YouTubeDataService.parseTimedTextJson3(json3)
        assertEquals(1, jsonSegs.size)
        assertEquals("00:12", jsonSegs[0].timestampLabel)
        assertEquals("Neural networks", jsonSegs[0].text)
    }

    @Test
    fun chunksLongTranscriptWithoutDroppingContent() {
        val longTranscript = (1..200).joinToString("\n") { i ->
            "[00:${String.format("%02d", i % 60)}] Line $i explaining distributed systems and Android architecture cleanly."
        }
        val chunks = YouTubeDataService.chunkTranscriptText(longTranscript, maxCharsPerChunk = 1200)
        assertTrue(chunks.size > 1)
        assertTrue(chunks.all { it.length <= 1200 })
        assertTrue(chunks.last().contains("Line 200"))
    }

    @Test
    fun buildsFilteredQueriesCorrectly() {
        assertEquals(
            "Fireship Jetpack Compose tutorial",
            YouTubeDataService.buildFilteredQuery("Jetpack Compose", YouTubeSearchFilter.TUTORIAL, "Fireship")
        )
        assertEquals(
            "Kotlin tips #shorts",
            YouTubeDataService.buildFilteredQuery("Kotlin tips", YouTubeSearchFilter.SHORTS)
        )
    }
}
