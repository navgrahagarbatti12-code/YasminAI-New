package com.yasmin.ai

import com.yasmin.ai.ai.GeminiBackendClient
import com.yasmin.ai.security.SecureVault
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ProviderClientAndErrorTest {

    @Test
    fun httpErrorsMapToActionableMessages() {
        val err401 = GeminiBackendClient.mapHttpErrorMessage("Gemini", 401, "")
        val err429 = GeminiBackendClient.mapHttpErrorMessage("Groq", 429, "")
        val err503 = GeminiBackendClient.mapHttpErrorMessage("Gemini", 503, "")

        assertTrue(err401.contains("401"))
        assertTrue(err429.contains("429"))
        assertTrue(err503.contains("503"))
    }

    @Test
    fun parseMultiFileResponseExtractsFilesAndBlocksTraversal() {
        val client = GeminiBackendClient()
        val json = """
            ```json
            {
              "projectName": "demo_calc",
              "summary": "Created calculator modules",
              "readmeMarkdown": "# Demo Calc",
              "files": [
                {"path": "src/main.py", "language": "Python", "content": "print(1 + 2)"},
                {"path": "../../etc/passwd", "language": "Text", "content": "bad"}
              ]
            }
            ```
        """.trimIndent()

        val parsed = client.parseMultiFileResponse(json, "fallback")
        assertEquals("demo_calc", parsed.projectName)
        assertEquals(1, parsed.files.size)
        assertEquals("src/main.py", parsed.files.first().path)
    }

    @Test
    fun secretMaskingNeverExposesFullKey() {
        val fakeKey = "AIzaSyExampleKeyValue987654321"
        val masked = SecureVault.maskSecret(fakeKey)
        assertTrue(masked.startsWith("AIz"))
        assertTrue(masked.endsWith("4321"))
        assertTrue(!masked.contains("ExampleKey"))
    }
}
