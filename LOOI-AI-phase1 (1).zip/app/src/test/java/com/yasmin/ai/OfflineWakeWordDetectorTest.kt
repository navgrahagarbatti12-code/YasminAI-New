package com.yasmin.ai

import com.yasmin.ai.voice.OfflineWakeWordDetector
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.PI
import kotlin.math.sin

class OfflineWakeWordDetectorTest {

    private fun synthesizeTwoSyllableTone(
        sampleRate: Int = 16000,
        f1: Double = 340.0,
        f2: Double = 620.0
    ): ShortArray {
        val totalSamples = (sampleRate * 0.9).toInt()
        val out = ShortArray(totalSamples)
        for (i in 0 until totalSamples) {
            val t = i.toDouble() / sampleRate
            // Two distinct voiced syllables with a brief valley at 0.35s..0.45s
            val env = when {
                t < 0.08 -> 0.0
                t < 0.33 -> 0.85
                t < 0.44 -> 0.12
                t < 0.78 -> 0.92
                else -> 0.0
            }
            val freq = if (t < 0.4) f1 else f2
            val wave = sin(2.0 * PI * freq * t) + 0.4 * sin(2.0 * PI * (freq * 2.1) * t)
            out[i] = (wave * env * 12000.0).toInt().coerceIn(-32767, 32767).toShort()
        }
        return out
    }

    @Test
    fun enrollsMfccTemplateAndMatchesMatchingSignal() {
        val detector = OfflineWakeWordDetector(storageFile = null)
        val templateAudio = synthesizeTwoSyllableTone(f1 = 320.0, f2 = 640.0)
        assertTrue(detector.enrollSample(templateAudio))
        assertEquals(1, detector.getEnrolledTemplateCount())

        val matchingCandidate = synthesizeTwoSyllableTone(f1 = 325.0, f2 = 645.0)
        val positive = detector.detect(matchingCandidate, sensitivityPercent = 65)
        assertEquals("mfcc_dtw", positive.mode)
        assertTrue("Expected MFCC+DTW to match enrolled signal, distance=${positive.distance}", positive.detected)

        val silence = ShortArray(16000)
        val silentResult = detector.detect(silence, sensitivityPercent = 80)
        assertFalse(silentResult.detected)
    }
}
