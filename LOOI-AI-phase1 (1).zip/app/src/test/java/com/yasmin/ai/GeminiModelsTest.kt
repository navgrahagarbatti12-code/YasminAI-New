package com.yasmin.ai

import com.yasmin.ai.ai.AiResult
import com.yasmin.ai.ai.GeminiChatRequest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class GeminiModelsTest {
    @Test
    fun chatRequestDefaultsAreValid() {
        val req = GeminiChatRequest(message = "Hey Yasmin", language = "hinglish")
        assertEquals("Hey Yasmin", req.message)
        assertEquals("hinglish", req.language)
        assertTrue(req.history.isEmpty())
    }

    @Test
    fun aiResultErrorCarriesMessage() {
        val err = AiResult.Error("Rate limit", 429)
        assertEquals("Rate limit", err.message)
        assertEquals(429, err.code)
    }
}
