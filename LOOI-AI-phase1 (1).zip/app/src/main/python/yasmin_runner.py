import ast
import contextlib
import io
import json
import sys
import time
import traceback

MAX_OUTPUT_CHARS = 32768
MAX_EXEC_SECONDS = 4.0
MAX_TRACE_STEPS = 400000

ALLOWED_MODULES = frozenset({
    "math",
    "cmath",
    "random",
    "statistics",
    "json",
    "datetime",
    "re",
    "itertools",
    "functools",
    "collections",
    "decimal",
    "fractions",
    "string",
    "hashlib",
    "base64",
    "time",
})

BLOCKED_ATTRS = frozenset({
    "__subclasses__",
    "__globals__",
    "__builtins__",
    "__class__",
    "__bases__",
    "__mro__",
    "__import__",
    "__code__",
    "__closure__",
    "__dict__",
    "__getattribute__",
    "gi_frame",
    "f_globals",
    "f_locals",
    "f_back",
    "format",
    "format_map",
})

BLOCKED_CALLS = frozenset({
    "open",
    "eval",
    "exec",
    "compile",
    "__import__",
    "input",
    "breakpoint",
    "globals",
    "locals",
    "vars",
    "dir",
    "getattr",
    "setattr",
    "delattr",
    "format",
    "format_map",
    "object",
})


class SandboxAstValidator(ast.NodeVisitor):
    def visit_Import(self, node: ast.Import):
        for alias in node.names:
            root_pkg = alias.name.split(".")[0]
            if root_pkg not in ALLOWED_MODULES:
                raise SecurityError(f"Import blocked by sandbox policy: '{alias.name}'")
        self.generic_visit(node)

    def visit_ImportFrom(self, node: ast.ImportFrom):
        mod = (node.module or "").split(".")[0]
        if mod not in ALLOWED_MODULES:
            raise SecurityError(f"Import blocked by sandbox policy: '{node.module}'")
        self.generic_visit(node)

    def visit_Attribute(self, node: ast.Attribute):
        if node.attr in BLOCKED_ATTRS or node.attr.startswith("_"):
            raise SecurityError(f"Restricted attribute access blocked: '{node.attr}'")
        self.generic_visit(node)

    def visit_Name(self, node: ast.Name):
        if node.id in BLOCKED_CALLS or node.id.startswith("__"):
            raise SecurityError(f"Restricted builtin blocked: '{node.id}'")
        self.generic_visit(node)

    def visit_Call(self, node: ast.Call):
        if isinstance(node.func, ast.Attribute) and node.func.attr in ("format", "format_map"):
            raise SecurityError("str.format/format_map is blocked in sandbox; use f-strings instead.")
        self.generic_visit(node)


class SecurityError(Exception):
    pass


def _safe_import(name, globals=None, locals=None, fromlist=(), level=0):
    root_pkg = str(name).split(".")[0]
    if root_pkg not in ALLOWED_MODULES:
        raise ImportError(f"Module '{name}' is not permitted in Yasmin isolated Python sandbox.")
    return __import__(name, globals, locals, fromlist, level)


SAFE_BUILTINS = {
    "print": print,
    "len": len,
    "range": range,
    "enumerate": enumerate,
    "zip": zip,
    "map": map,
    "filter": filter,
    "sum": sum,
    "min": min,
    "max": max,
    "abs": abs,
    "round": round,
    "pow": pow,
    "divmod": divmod,
    "sorted": sorted,
    "reversed": reversed,
    "any": any,
    "all": all,
    "int": int,
    "float": float,
    "str": str,
    "bool": bool,
    "list": list,
    "dict": dict,
    "set": set,
    "tuple": tuple,
    "frozenset": frozenset,
    "chr": chr,
    "ord": ord,
    "hex": hex,
    "bin": bin,
    "oct": oct,
    "repr": repr,
    "isinstance": isinstance,
    "issubclass": issubclass,
    "type": type,
    "Exception": Exception,
    "ValueError": ValueError,
    "TypeError": TypeError,
    "KeyError": KeyError,
    "IndexError": IndexError,
    "ZeroDivisionError": ZeroDivisionError,
    "RuntimeError": RuntimeError,
    "__import__": _safe_import,
}


def execute_python(code: str) -> str:
    """
    Executes user-approved Python code inside an AST-validated, restricted-builtins,
    time/step-limited sandbox. Captures stdout/stderr up to MAX_OUTPUT_CHARS.
    """
    stdout_buffer = io.StringIO()
    stderr_buffer = io.StringIO()

    success = True
    error_message = ""
    steps = 0
    start_time = time.monotonic()

    def trace_watchdog(frame, event, arg):
        nonlocal steps
        steps += 1
        if steps > MAX_TRACE_STEPS:
            raise TimeoutError(f"Execution aborted: exceeded {MAX_TRACE_STEPS} bytecode steps.")
        if (steps & 1023) == 0:
            if (time.monotonic() - start_time) > MAX_EXEC_SECONDS:
                raise TimeoutError(f"Execution aborted: exceeded {MAX_EXEC_SECONDS}s timeout.")
        return trace_watchdog

    try:
        tree = ast.parse(code, filename="<yasmin_sandbox.py>", mode="exec")
        SandboxAstValidator().visit(tree)
        compiled = compile(tree, "<yasmin_sandbox.py>", "exec")

        sandbox_globals = {
            "__builtins__": SAFE_BUILTINS,
            "__name__": "__main__",
        }

        old_trace = sys.gettrace()
        sys.settrace(trace_watchdog)
        try:
            with contextlib.redirect_stdout(stdout_buffer), contextlib.redirect_stderr(stderr_buffer):
                exec(compiled, sandbox_globals, sandbox_globals)
        finally:
            sys.settrace(old_trace)

    except SecurityError as sec_err:
        success = False
        error_message = f"Sandbox Security Policy Violation: {sec_err}"
    except TimeoutError as t_err:
        success = False
        error_message = f"Sandbox Resource Limit: {t_err}"
    except SyntaxError as syn_err:
        success = False
        error_message = f"SyntaxError at line {syn_err.lineno}: {syn_err.msg}"
    except Exception:
        success = False
        error_message = traceback.format_exc()

    stdout_val = stdout_buffer.getvalue()[:MAX_OUTPUT_CHARS]
    stderr_val = stderr_buffer.getvalue()[:MAX_OUTPUT_CHARS]
    if len(stdout_buffer.getvalue()) > MAX_OUTPUT_CHARS:
        stdout_val += "\n... [Output truncated at 32 KB sandbox limit]"

    return json.dumps({
        "success": success,
        "stdout": stdout_val,
        "stderr": stderr_val,
        "error": error_message,
        "elapsedMs": int((time.monotonic() - start_time) * 1000),
    })
