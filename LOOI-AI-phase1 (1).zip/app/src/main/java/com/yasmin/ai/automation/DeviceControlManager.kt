package com.yasmin.ai.automation

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.Settings
import androidx.core.content.ContextCompat
import com.yasmin.ai.utils.NetworkUtils
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class ContactMatch(val displayName: String, val phoneNumber: String)

class DeviceControlManager(private val context: Context) {

    private var flashlightOn = false

    fun toggleFlashlight(forceState: Boolean? = null): String {
        return try {
            val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val cameraId = cameraManager.cameraIdList.firstOrNull { id ->
                cameraManager.getCameraCharacteristics(id)
                    .get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: return "No camera flash hardware detected on this device."

            val target = forceState ?: !flashlightOn
            cameraManager.setTorchMode(cameraId, target)
            flashlightOn = target
            if (target) "Flashlight turned ON." else "Flashlight turned OFF."
        } catch (e: Exception) {
            "Could not control flashlight: ${e.localizedMessage ?: "Hardware busy"}"
        }
    }

    fun adjustVolume(direction: Int): String {
        val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        audioManager.adjustStreamVolume(
            AudioManager.STREAM_MUSIC,
            direction,
            AudioManager.FLAG_SHOW_UI
        )
        val current = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
        val max = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        return "Media volume set to $current / $max."
    }

    fun setScreenBrightnessPercent(percent: Int): String {
        if (!Settings.System.canWrite(context)) {
            return try {
                val intent = Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS).apply {
                    data = Uri.parse("package:${context.packageName}")
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
                "Opened 'Modify system settings' permission screen so you can allow brightness control."
            } catch (_: Exception) {
                "Please enable 'Modify system settings' manually in Android Settings for brightness control."
            }
        }
        val clamped = percent.coerceIn(5, 100)
        val value = (clamped * 255) / 100
        Settings.System.putInt(
            context.contentResolver,
            Settings.System.SCREEN_BRIGHTNESS_MODE,
            Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL
        )
        Settings.System.putInt(context.contentResolver, Settings.System.SCREEN_BRIGHTNESS, value)
        return "Screen brightness set to $clamped%."
    }

    fun openAppByName(queryName: String): String {
        val pm = context.packageManager
        val mainIntent = Intent(Intent.ACTION_MAIN, null).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }
        val apps = pm.queryIntentActivities(mainIntent, 0)
        val target = queryName.trim().lowercase(Locale.getDefault())

        val matched = apps.firstOrNull { info ->
            val label = info.loadLabel(pm).toString().lowercase(Locale.getDefault())
            label == target || label.contains(target)
        } ?: return "Could not find an installed app matching '$queryName'."

        val launchIntent = pm.getLaunchIntentForPackage(matched.activityInfo.packageName)
            ?: return "App '${matched.loadLabel(pm)}' has no launchable activity."

        launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            context.startActivity(launchIntent)
            "Opening ${matched.loadLabel(pm)}."
        } catch (_: Exception) {
            "Could not launch ${matched.loadLabel(pm)} on this device."
        }
    }

    fun searchInstalledApps(query: String): List<String> {
        val pm = context.packageManager
        val mainIntent = Intent(Intent.ACTION_MAIN, null).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }
        val target = query.trim().lowercase(Locale.getDefault())
        return pm.queryIntentActivities(mainIntent, 0)
            .map { it.loadLabel(pm).toString() }
            .filter { target.isEmpty() || it.lowercase(Locale.getDefault()).contains(target) }
            .distinct()
            .sorted()
            .take(15)
    }

    fun searchYouTube(query: String): String {
        val cleanQuery = query.trim()
        if (cleanQuery.isEmpty()) return openYouTubeHome()
        val ytIntent = Intent(Intent.ACTION_SEARCH).apply {
            setPackage("com.google.android.youtube")
            putExtra("query", cleanQuery)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return try {
            context.startActivity(ytIntent)
            "Searching YouTube for '$cleanQuery'."
        } catch (_: Exception) {
            val webUrl = "https://www.youtube.com/results?search_query=${Uri.encode(cleanQuery)}"
            val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse(webUrl)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(browserIntent)
            "YouTube app unavailable. Opened browser search for '$cleanQuery'."
        }
    }

    fun openYouTubeHome(): String {
        val pm = context.packageManager
        val ytLaunch = pm.getLaunchIntentForPackage("com.google.android.youtube")
        return if (ytLaunch != null) {
            ytLaunch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(ytLaunch)
            "Opening YouTube."
        } else {
            val webIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com")).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(webIntent)
            "Opened YouTube in browser."
        }
    }

    fun playMusic(): String {
        val musicIntent = Intent.makeMainSelectorActivity(
            Intent.ACTION_MAIN,
            Intent.CATEGORY_APP_MUSIC
        ).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return try {
            context.startActivity(musicIntent)
            "Opening your default music player."
        } catch (_: Exception) {
            "No dedicated music app found."
        }
    }

    fun openAndroidSettings(action: String = Settings.ACTION_SETTINGS): String {
        return try {
            val intent = Intent(action).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
            context.startActivity(intent)
            "Opened Android Settings."
        } catch (e: Exception) {
            "Unable to open requested settings screen: ${e.localizedMessage}"
        }
    }

    fun setAlarm(hour: Int, minute: Int, label: String): String {
        val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
            putExtra(AlarmClock.EXTRA_HOUR, hour.coerceIn(0, 23))
            putExtra(AlarmClock.EXTRA_MINUTES, minute.coerceIn(0, 59))
            putExtra(AlarmClock.EXTRA_MESSAGE, label.ifBlank { "Yasmin AI Alarm" })
            putExtra(AlarmClock.EXTRA_SKIP_UI, false)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return try {
            context.startActivity(intent)
            "Prepared alarm for %02d:%02d.".format(hour.coerceIn(0, 23), minute.coerceIn(0, 59))
        } catch (e: Exception) {
            "No compatible Clock app found: ${e.localizedMessage}"
        }
    }

    fun setTimer(seconds: Int, label: String): String {
        val intent = Intent(AlarmClock.ACTION_SET_TIMER).apply {
            putExtra(AlarmClock.EXTRA_LENGTH, seconds.coerceAtLeast(1))
            putExtra(AlarmClock.EXTRA_MESSAGE, label.ifBlank { "Yasmin AI Timer" })
            putExtra(AlarmClock.EXTRA_SKIP_UI, false)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return try {
            context.startActivity(intent)
            "Prepared timer for $seconds seconds."
        } catch (e: Exception) {
            "No compatible Clock app found: ${e.localizedMessage}"
        }
    }

    fun findContacts(query: String): List<ContactMatch> {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CONTACTS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            return emptyList()
        }
        val results = mutableListOf<ContactMatch>()
        val selection = "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?"
        val args = arrayOf("%${query.trim()}%")
        return try {
            context.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                    ContactsContract.CommonDataKinds.Phone.NUMBER
                ),
                selection,
                args,
                "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} ASC"
            )?.use { cursor ->
                val nameIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
                val numIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
                if (nameIdx >= 0 && numIdx >= 0) {
                    while (cursor.moveToNext() && results.size < 5) {
                        val name = cursor.getString(nameIdx).orEmpty().ifBlank { "Unknown" }
                        val num = cursor.getString(numIdx).orEmpty().trim()
                        if (num.isNotEmpty()) {
                            results.add(ContactMatch(name, num))
                        }
                    }
                }
            }
            results
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun openDialer(phoneNumber: String): String {
        val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${Uri.encode(phoneNumber)}")).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return try {
            context.startActivity(intent)
            "Opened phone dialer for $phoneNumber."
        } catch (_: Exception) {
            "No compatible Phone Dialer app found on this device."
        }
    }

    fun prepareSms(phoneNumber: String, body: String): String {
        val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:${Uri.encode(phoneNumber)}")).apply {
            putExtra("sms_body", body)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return try {
            context.startActivity(intent)
            "Prepared SMS draft to $phoneNumber. Review and tap Send in Messages."
        } catch (_: Exception) {
            "No compatible SMS messaging app found on this device."
        }
    }

    fun prepareWhatsAppMessage(phoneNumberOrEmpty: String, message: String): String {
        val digits = phoneNumberOrEmpty.replace("[^0-9+]".toRegex(), "")
        val url = if (digits.isNotEmpty()) {
            "https://wa.me/${digits.removePrefix("+")}?text=${Uri.encode(message)}"
        } else {
            "https://api.whatsapp.com/send?text=${Uri.encode(message)}"
        }
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return try {
            context.startActivity(intent)
            "Prepared WhatsApp draft. Review and tap Send in WhatsApp."
        } catch (_: Exception) {
            "Could not open WhatsApp."
        }
    }

    fun getCurrentDateTimeText(): String {
        val fmt = SimpleDateFormat("EEEE, dd MMM yyyy · hh:mm a", Locale.getDefault())
        return "Current time is ${fmt.format(Date())}."
    }

    fun getBatteryPercentage(): Int {
        val batteryIntent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = batteryIntent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = batteryIntent?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        return if (level >= 0 && scale > 0) (level * 100) / scale else -1
    }

    fun getTelemetrySummary(): String {
        val battery = getBatteryPercentage()
        val net = NetworkUtils.getNetworkStatusLabel(context)
        val batteryLabel = if (battery >= 0) "$battery%" else "--%"
        return "Battery: $batteryLabel · Network: $net"
    }
}
