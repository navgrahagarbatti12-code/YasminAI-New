package com.yasmin.ai.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [
        ChatMessageEntity::class,
        MemoryEntity::class,
        TaskEntity::class,
        VoiceHistoryEntity::class,
        CodingJobEntity::class,
        VideoNoteEntity::class,
        LearningSessionEntity::class
    ],
    version = 5,
    exportSchema = true
)
abstract class YasminDatabase : RoomDatabase() {
    abstract fun chatDao(): ChatDao
    abstract fun memoryDao(): MemoryDao
    abstract fun taskDao(): TaskDao
    abstract fun voiceHistoryDao(): VoiceHistoryDao
    abstract fun codingJobDao(): CodingJobDao
    abstract fun videoNoteDao(): VideoNoteDao
    abstract fun learningSessionDao(): LearningSessionDao

    companion object {
        @Volatile
        private var INSTANCE: YasminDatabase? = null

        /**
         * Preserves v1 chat_messages while adding memories, assistant_tasks, and voice_history tables.
         */
        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `memories` (
                        `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        `category` TEXT NOT NULL,
                        `keyTitle` TEXT NOT NULL,
                        `content` TEXT NOT NULL,
                        `createdAt` INTEGER NOT NULL,
                        `updatedAt` INTEGER NOT NULL
                    )
                    """.trimIndent()
                )
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `assistant_tasks` (
                        `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        `type` TEXT NOT NULL,
                        `title` TEXT NOT NULL,
                        `details` TEXT NOT NULL,
                        `dueLabel` TEXT NOT NULL,
                        `isCompleted` INTEGER NOT NULL,
                        `createdAt` INTEGER NOT NULL
                    )
                    """.trimIndent()
                )
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `voice_history` (
                        `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        `transcript` TEXT NOT NULL,
                        `source` TEXT NOT NULL,
                        `timestamp` INTEGER NOT NULL
                    )
                    """.trimIndent()
                )
            }
        }

        /**
         * Upgrades v2 -> v3 non-destructively, preserving all chats, memories, tasks, and voice logs.
         */
        val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE `memories` ADD COLUMN `importance` INTEGER NOT NULL DEFAULT 1")
                db.execSQL("ALTER TABLE `memories` ADD COLUMN `accessCount` INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE `memories` ADD COLUMN `isUserApproved` INTEGER NOT NULL DEFAULT 1")
                db.execSQL("ALTER TABLE `assistant_tasks` ADD COLUMN `reminderEpochMs` INTEGER NOT NULL DEFAULT 0")
            }
        }

        /**
         * Upgrades v3 -> v4 non-destructively, adding coding_jobs table for WorkManager persistence.
         */
        val MIGRATION_3_4 = object : Migration(3, 4) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `coding_jobs` (
                        `jobId` TEXT NOT NULL PRIMARY KEY,
                        `projectName` TEXT NOT NULL,
                        `language` TEXT NOT NULL,
                        `prompt` TEXT NOT NULL,
                        `status` TEXT NOT NULL,
                        `progress` INTEGER NOT NULL,
                        `statusMessage` TEXT NOT NULL,
                        `projectPath` TEXT NOT NULL,
                        `summaryText` TEXT NOT NULL,
                        `filesJson` TEXT NOT NULL,
                        `errorMessage` TEXT NOT NULL,
                        `createdAt` INTEGER NOT NULL,
                        `updatedAt` INTEGER NOT NULL
                    )
                    """.trimIndent()
                )
            }
        }

        /**
         * Upgrades v4 -> v5 non-destructively, adding video_notes and learning_sessions tables
         * for YouTube AI Agent notes history, TXT/PDF export metadata, and learning progress tracking.
         */
        val MIGRATION_4_5 = object : Migration(4, 5) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `video_notes` (
                        `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        `videoId` TEXT NOT NULL,
                        `videoTitle` TEXT NOT NULL,
                        `channelTitle` TEXT NOT NULL,
                        `topic` TEXT NOT NULL,
                        `markdownContent` TEXT NOT NULL,
                        `definitionsText` TEXT NOT NULL,
                        `bulletPointsText` TEXT NOT NULL,
                        `stepsText` TEXT NOT NULL,
                        `timestampsText` TEXT NOT NULL,
                        `language` TEXT NOT NULL,
                        `createdAt` INTEGER NOT NULL,
                        `updatedAt` INTEGER NOT NULL
                    )
                    """.trimIndent()
                )
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `learning_sessions` (
                        `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        `videoId` TEXT NOT NULL,
                        `videoTitle` TEXT NOT NULL,
                        `channelTitle` TEXT NOT NULL,
                        `topic` TEXT NOT NULL,
                        `difficultyLevel` TEXT NOT NULL,
                        `quizScore` INTEGER NOT NULL,
                        `totalQuestions` INTEGER NOT NULL,
                        `progressPercent` INTEGER NOT NULL,
                        `summaryExcerpt` TEXT NOT NULL,
                        `lastStudiedAt` INTEGER NOT NULL
                    )
                    """.trimIndent()
                )
            }
        }

        fun getInstance(context: Context): YasminDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    YasminDatabase::class.java,
                    "yasmin_ai_database"
                )
                    .addMigrations(MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4, MIGRATION_4_5)
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}
