package com.yasmin.ai.ui.coding

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.fragment.app.viewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.yasmin.ai.ai.GeneratedCodeFile
import com.yasmin.ai.coding.ExternalEditorHelper
import com.yasmin.ai.coding.OpenEditorResult
import com.yasmin.ai.coding.ProjectFileManager
import com.yasmin.ai.coding.SyntaxHighlighter
import com.yasmin.ai.databinding.FragmentCodingAgentBinding
import com.yasmin.ai.ui.home.YasminSharedViewModel
import kotlinx.coroutines.launch

class CodingAgentFragment : Fragment() {

    private var _binding: FragmentCodingAgentBinding? = null
    private val binding get() = _binding!!
    private val viewModel: CodingAgentViewModel by viewModels()
    private val sharedViewModel: YasminSharedViewModel by activityViewModels()

    private lateinit var fileManager: ProjectFileManager
    private lateinit var jobAdapter: CodingJobAdapter

    private val languages = listOf(
        "Kotlin", "Python", "HTML/CSS/JS", "Java", "JavaScript", "PHP", "C++", "C", "JSON/XML", "Multi-Language"
    )
    private var isProgrammaticEdit = false
    private var lastLoadedFiles: List<GeneratedCodeFile> = emptyList()

    private val importZipLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri == null) return@registerForActivityResult
        val nameHint = resolveDisplayName(uri)?.removeSuffix(".zip")
        viewModel.importFromZip(uri, nameHint)
    }

    private val pickExportFolderLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocumentTree()
    ) { treeUri ->
        if (treeUri == null) return@registerForActivityResult
        try {
            requireContext().contentResolver.takePersistableUriPermission(
                treeUri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
        } catch (_: Exception) {
        }
        viewModel.syncCurrentProjectToSaf(treeUri)
    }

    private val reopenFolderLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocumentTree()
    ) { treeUri ->
        if (treeUri == null) return@registerForActivityResult
        try {
            requireContext().contentResolver.takePersistableUriPermission(
                treeUri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
        } catch (_: Exception) {
        }
        viewModel.importFromSafFolder(treeUri)
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentCodingAgentBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        fileManager = ProjectFileManager(requireContext())

        setupSpinnersAndRecycler()
        setupListeners()
        observeState()

        val incomingPrompt = sharedViewModel.consumePendingCodingPrompt()
        if (incomingPrompt.isNotBlank()) {
            binding.etAgentPrompt.setText(incomingPrompt)
        }
    }

    private fun setupSpinnersAndRecycler() {
        binding.spinnerAgentLanguage.adapter = ArrayAdapter(
            requireContext(),
            android.R.layout.simple_spinner_dropdown_item,
            languages
        )

        binding.spinnerAgentFiles.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, v: View?, position: Int, id: Long) {
                viewModel.selectFileIndex(position)
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        jobAdapter = CodingJobAdapter(
            onLoadProject = { job -> viewModel.loadJobResult(job) },
            onCancelJob = { job -> viewModel.cancelJob(job.jobId) },
            onRetryJob = { job -> viewModel.retryJob(job) },
            onDeleteJob = { job -> viewModel.deleteJob(job.jobId) }
        )
        binding.rvCodingJobs.layoutManager = LinearLayoutManager(requireContext())
        binding.rvCodingJobs.adapter = jobAdapter
    }

    private fun setupListeners() {
        binding.etAgentFileEditor.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                if (s == null) return
                val lang = viewModel.projectFiles.value.getOrNull(viewModel.selectedFileIndex.value)?.language.orEmpty().lowercase()
                val mode = when {
                    lang.contains("python") -> "python"
                    lang.contains("html") || lang.contains("css") || lang.contains("javascript") -> "web"
                    else -> "python"
                }
                SyntaxHighlighter.highlight(requireContext(), s, mode)
                if (!isProgrammaticEdit) {
                    viewModel.updateSelectedFileContent(s.toString())
                }
            }
        })

        binding.btnAgentGenerate.setOnClickListener { triggerMode("generate") }
        binding.btnAgentUpdate.setOnClickListener { triggerMode("update") }
        binding.btnAgentDebug.setOnClickListener { triggerMode("debug") }
        binding.btnAgentExplain.setOnClickListener { triggerMode("explain") }

        binding.btnAgentSaveProject.setOnClickListener {
            syncProjectNameField()
            if (viewModel.projectFiles.value.isEmpty()) {
                Toast.makeText(requireContext(), "No files to save yet.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val dir = viewModel.saveWholeProjectToDisk()
            Toast.makeText(requireContext(), "Saved project '${dir.name}'", Toast.LENGTH_SHORT).show()
        }

        binding.btnAgentOpenSaved.setOnClickListener {
            val projects = fileManager.listMultiFileProjects()
            if (projects.isEmpty()) {
                Toast.makeText(requireContext(), "No saved multi-file projects yet.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val names = projects.map { it.name }.toTypedArray()
            MaterialAlertDialogBuilder(requireContext())
                .setTitle("Open Saved Project")
                .setItems(names) { _, which ->
                    viewModel.loadProjectDirectory(projects[which])
                }
                .show()
        }

        binding.btnAgentExportZip.setOnClickListener {
            exportAndShareZip()
        }

        binding.btnAgentSaveToFolder.setOnClickListener {
            syncProjectNameField()
            val savedTree = viewModel.preferences.value.storageTreeUri
            if (savedTree.isNotBlank()) {
                viewModel.syncCurrentProjectToSaf(Uri.parse(savedTree))
            } else {
                pickExportFolderLauncher.launch(null)
            }
        }

        binding.btnAgentReopenFolder.setOnClickListener {
            reopenFolderLauncher.launch(null)
        }

        binding.btnAgentImportZip.setOnClickListener {
            importZipLauncher.launch(arrayOf("application/zip", "application/x-zip-compressed", "*/*"))
        }

        binding.btnAgentOpenExternalEditor.setOnClickListener {
            syncProjectNameField()
            val savedFile = viewModel.saveCurrentFileToDisk()
            if (savedFile == null) {
                Toast.makeText(requireContext(), "Generate or load a project file first.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val preferredPkg = viewModel.preferences.value.externalEditorPackage
            when (val res = ExternalEditorHelper.openFileInExternalEditor(requireContext(), savedFile, preferredPkg)) {
                is OpenEditorResult.Launched -> {
                    Toast.makeText(requireContext(), "Opened ${savedFile.name} in ${res.targetLabel}. Use 'Reopen Folder' or 'Import ZIP' to bring updates back.", Toast.LENGTH_LONG).show()
                }
                is OpenEditorResult.NoEditorInstalled -> {
                    MaterialAlertDialogBuilder(requireContext())
                        .setTitle("No External Code Editor Found")
                        .setMessage("No compatible Android code/text editor app is installed to edit ${savedFile.name} directly. Would you like to export a ZIP or save to a device folder instead?")
                        .setPositiveButton("Export ZIP") { _, _ -> exportAndShareZip() }
                        .setNeutralButton("Save to Folder") { _, _ -> pickExportFolderLauncher.launch(null) }
                        .setNegativeButton("Close", null)
                        .show()
                }
                is OpenEditorResult.Failed -> {
                    Toast.makeText(requireContext(), res.message, Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun syncProjectNameField() {
        val raw = binding.etAgentProjectName.text?.toString().orEmpty()
        if (raw.isNotBlank()) viewModel.setProjectName(raw)
    }

    private fun triggerMode(mode: String) {
        syncProjectNameField()
        val prompt = binding.etAgentPrompt.text?.toString().orEmpty()
        val lang = languages.getOrElse(binding.spinnerAgentLanguage.selectedItemPosition) { "Kotlin" }
        val useBg = binding.switchAgentBackground.isChecked
        val docs = binding.switchAgentDocs.isChecked
        viewModel.runCodingTask(prompt, lang, mode, useBg, docs)
    }

    private fun exportAndShareZip() {
        syncProjectNameField()
        if (viewModel.projectFiles.value.isEmpty()) {
            Toast.makeText(requireContext(), "Generate or load a project first.", Toast.LENGTH_SHORT).show()
            return
        }
        val dir = viewModel.saveWholeProjectToDisk()
        val zipFile = fileManager.exportDirectoryAsZip(dir)
        val intent = fileManager.createShareFileIntent(zipFile, "application/zip")
        startActivity(Intent.createChooser(intent, "Share ${dir.name}.zip"))
    }

    private fun resolveDisplayName(uri: Uri): String? {
        return try {
            requireContext().contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (idx >= 0 && cursor.moveToFirst()) cursor.getString(idx) else null
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun observeState() {
        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch {
                    viewModel.preferences.collect { prefs ->
                        binding.switchAgentBackground.isChecked = prefs.codingUseBackgroundWorker
                        binding.switchAgentDocs.isChecked = prefs.codingAutoGenerateDocs
                        val langIdx = languages.indexOfFirst { it.equals(prefs.codingDefaultLanguage, ignoreCase = true) }
                        if (langIdx >= 0 && binding.spinnerAgentLanguage.selectedItemPosition != langIdx) {
                            binding.spinnerAgentLanguage.setSelection(langIdx)
                        }
                    }
                }
                launch {
                    viewModel.projectName.collect { name ->
                        if (!binding.etAgentProjectName.hasFocus() && binding.etAgentProjectName.text?.toString() != name) {
                            binding.etAgentProjectName.setText(name)
                        }
                    }
                }
                launch {
                    viewModel.projectFiles.collect { files ->
                        binding.tvAgentFilesHeader.text = "Project Files (${files.size})"
                        if (files.map { it.path } != lastLoadedFiles.map { it.path }) {
                            lastLoadedFiles = files
                            val labels = if (files.isEmpty()) listOf("(No files generated yet)") else files.map { "${it.path} (${it.language})" }
                            binding.spinnerAgentFiles.adapter = ArrayAdapter(
                                requireContext(),
                                android.R.layout.simple_spinner_dropdown_item,
                                labels
                            )
                        }
                        refreshEditorForSelectedFile(files, viewModel.selectedFileIndex.value)
                    }
                }
                launch {
                    viewModel.selectedFileIndex.collect { idx ->
                        refreshEditorForSelectedFile(viewModel.projectFiles.value, idx)
                    }
                }
                launch {
                    viewModel.summaryOutput.collect { summary ->
                        binding.tvAgentSummary.text = summary
                    }
                }
                launch {
                    viewModel.isLoading.collect { loading ->
                        binding.btnAgentGenerate.isEnabled = !loading
                        binding.btnAgentUpdate.isEnabled = !loading
                        binding.btnAgentDebug.isEnabled = !loading
                        binding.btnAgentExplain.isEnabled = !loading
                    }
                }
                launch {
                    viewModel.codingJobs.collect { jobs ->
                        jobAdapter.submitList(jobs)
                    }
                }
                launch {
                    viewModel.events.collect { msg ->
                        Toast.makeText(requireContext(), msg, Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }

    private fun refreshEditorForSelectedFile(files: List<GeneratedCodeFile>, idx: Int) {
        val text = files.getOrNull(idx)?.content.orEmpty()
        if (binding.etAgentFileEditor.text?.toString() != text) {
            isProgrammaticEdit = true
            binding.etAgentFileEditor.setText(text)
            isProgrammaticEdit = false
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
