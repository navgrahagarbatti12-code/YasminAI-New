package com.yasmin.ai.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "voice_history")
data class VoiceHistoryEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val transcript: String,
    val source: String, // "mic", "wake_word", "continuous"
    val timestamp: Long = System.currentTimeMillis()
)
