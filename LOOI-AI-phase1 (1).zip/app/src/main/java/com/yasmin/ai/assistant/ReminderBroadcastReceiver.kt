package com.yasmin.ai.assistant

import android.Manifest
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.yasmin.ai.MainActivity
import com.yasmin.ai.R
import com.yasmin.ai.YasminApplication

class ReminderBroadcastReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            return
        }

        val taskId = intent.getLongExtra(EXTRA_TASK_ID, System.currentTimeMillis())
        val title = intent.getStringExtra(EXTRA_TITLE).orEmpty().ifBlank { "Yasmin AI Reminder" }
        val details = intent.getStringExtra(EXTRA_DETAILS).orEmpty().ifBlank { "Scheduled reminder alert." }

        val openIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingOpen = PendingIntent.getActivity(
            context,
            taskId.toInt(),
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, YasminApplication.CHANNEL_REMINDERS)
            .setSmallIcon(R.drawable.ic_calendar)
            .setContentTitle("Reminder: $title")
            .setContentText(details)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(pendingOpen)
            .build()

        try {
            val nm = context.getSystemService(NotificationManager::class.java)
            nm?.notify((5000 + (taskId % 1000)).toInt(), notification)
        } catch (_: SecurityException) {
        }
    }

    companion object {
        const val EXTRA_TASK_ID = "extra_task_id"
        const val EXTRA_TITLE = "extra_title"
        const val EXTRA_DETAILS = "extra_details"
    }
}
