package com.yasmin.ai.automation

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class NotificationDigestItem(
    val appPackage: String,
    val title: String,
    val text: String,
    val postTime: Long
)

/**
 * Reads active notifications ONLY when the user explicitly enables Android
 * Notification Access in system settings and asks Yasmin to read notifications.
 */
class YasminNotificationListenerService : NotificationListenerService() {

    override fun onListenerConnected() {
        super.onListenerConnected()
        instance = this
        _isConnected.value = true
    }

    override fun onListenerDisconnected() {
        super.onListenerDisconnected()
        if (instance === this) instance = null
        _isConnected.value = false
    }

    fun getRecentNotificationSummaries(limit: Int = 8): List<NotificationDigestItem> {
        val active: Array<StatusBarNotification> = try {
            activeNotifications ?: emptyArray()
        } catch (_: Exception) {
            emptyArray()
        }

        return active
            .filter { !it.isOngoing && it.packageName != packageName }
            .sortedByDescending { it.postTime }
            .take(limit)
            .mapNotNull { sbn ->
                val extras = sbn.notification?.extras ?: return@mapNotNull null
                val title = extras.getCharSequence("android.title")?.toString()?.trim().orEmpty()
                val text = extras.getCharSequence("android.text")?.toString()?.trim().orEmpty()
                if (title.isEmpty() && text.isEmpty()) null
                else NotificationDigestItem(sbn.packageName, title, text, sbn.postTime)
            }
    }

    companion object {
        @Volatile
        var instance: YasminNotificationListenerService? = null
            private set

        private val _isConnected = MutableStateFlow(false)
        val isConnected: StateFlow<Boolean> = _isConnected.asStateFlow()
    }
}
