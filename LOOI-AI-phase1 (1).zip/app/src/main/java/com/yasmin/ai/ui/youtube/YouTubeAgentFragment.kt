package com.yasmin.ai.ui.youtube

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.fragment.app.viewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.yasmin.ai.MainActivity
import com.yasmin.ai.R
import com.yasmin.ai.data.local.VideoNoteEntity
import com.yasmin.ai.databinding.FragmentYoutubeAgentBinding
import com.yasmin.ai.ui.home.YasminSharedViewModel
import com.yasmin.ai.youtube.LearningDepth
import com.yasmin.ai.youtube.SummaryLanguage
import com.yasmin.ai.youtube.SummaryStyle
import com.yasmin.ai.youtube.TranscriptStatus
import com.yasmin.ai.youtube.YouTubeSearchFilter
import com.yasmin.ai.youtube.YouTubeVoiceIntent
import kotlinx.coroutines.launch

class YouTubeAgentFragment : Fragment() {

    private var _binding: FragmentYoutubeAgentBinding? = null
    private val binding get() = _binding!!
    private val viewModel: YouTubeAgentViewModel by viewModels()
    private val sharedViewModel: YasminSharedViewModel by activityViewModels()

    private lateinit var searchAdapter: YouTubeSearchAdapter
    private lateinit var savedNoteAdapter: SavedNoteAdapter
    private lateinit var quizAdapter: QuizQuestionAdapter
    private lateinit var historyAdapter: LearningHistoryAdapter

    private val searchFilters = YouTubeSearchFilter.values().toList()
    private val summaryStyles = SummaryStyle.values().toList()
    private val summaryLanguages = SummaryLanguage.values().toList()
    private val learningDepths = LearningDepth.values().toList()

    private var activeTabIndex = 0

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentYoutubeAgentBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupSpinnersAndAdapters()
        setupListeners()
        observeState()
        handlePendingVoiceDispatch()
    }

    private fun setupSpinnersAndAdapters() {
        binding.spinnerYtFilter.adapter = ArrayAdapter(
            requireContext(),
            android.R.layout.simple_spinner_dropdown_item,
            searchFilters.map { it.label }
        )
        binding.spinnerYtFilter.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                viewModel.setSearchFilter(searchFilters.getOrElse(pos) { YouTubeSearchFilter.VIDEO })
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        binding.spinnerSummaryStyle.adapter = ArrayAdapter(
            requireContext(),
            android.R.layout.simple_spinner_dropdown_item,
            summaryStyles.map { it.label }
        )
        binding.spinnerSummaryLang.adapter = ArrayAdapter(
            requireContext(),
            android.R.layout.simple_spinner_dropdown_item,
            summaryLanguages.map { it.label }
        )
        binding.spinnerLearningDepth.adapter = ArrayAdapter(
            requireContext(),
            android.R.layout.simple_spinner_dropdown_item,
            learningDepths.map { it.label }
        )

        searchAdapter = YouTubeSearchAdapter(
            onSelect = { item -> viewModel.selectVideoItem(item) },
            onOpenExternal = { item ->
                val url = item.sourceUrl.ifBlank { "https://www.youtube.com/watch?v=${item.videoId}" }
                viewModel.deviceControl.openYouTubeUrl(url)
            }
        )
        binding.rvYtSearchResults.layoutManager = LinearLayoutManager(requireContext())
        binding.rvYtSearchResults.adapter = searchAdapter

        savedNoteAdapter = SavedNoteAdapter(
            onView = { note ->
                binding.tvYtGeneratedNotesPreview.text = note.markdownContent.ifBlank { note.bulletPointsText }
                switchTab(1)
            },
            onExportTxt = { note -> viewModel.exportNoteAsTxt(note) },
            onExportPdf = { note -> viewModel.exportNoteAsPdf(note) },
            onDelete = { note ->
                MaterialAlertDialogBuilder(requireContext())
                    .setTitle("Delete Saved Notes?")
                    .setMessage("Delete study notes for \"${note.videoTitle.ifBlank { note.topic }}\" permanently?")
                    .setPositiveButton("Delete") { _, _ -> viewModel.deleteSavedNote(note) }
                    .setNegativeButton("Cancel", null)
                    .show()
            }
        )
        binding.rvYtSavedNotes.layoutManager = LinearLayoutManager(requireContext())
        binding.rvYtSavedNotes.adapter = savedNoteAdapter

        quizAdapter = QuizQuestionAdapter { questionIndex, optionIndex ->
            viewModel.selectQuizAnswer(questionIndex, optionIndex)
        }
        binding.rvYtQuizQuestions.layoutManager = LinearLayoutManager(requireContext())
        binding.rvYtQuizQuestions.adapter = quizAdapter

        historyAdapter = LearningHistoryAdapter(
            onResumeVideo = { session ->
                viewModel.reloadVideoFromHistory(session.videoId)
                switchTab(0)
            },
            onDeleteSession = { session -> viewModel.deleteLearningSession(session) }
        )
        binding.rvYtLearningHistory.layoutManager = LinearLayoutManager(requireContext())
        binding.rvYtLearningHistory.adapter = historyAdapter
    }

    private fun setupListeners() {
        binding.btnTabSummaryQa.setOnClickListener { switchTab(0) }
        binding.btnTabNotes.setOnClickListener { switchTab(1) }
        binding.btnTabLearnQuiz.setOnClickListener { switchTab(2) }
        binding.btnTabHistory.setOnClickListener { switchTab(3) }

        binding.btnYtDismissError.setOnClickListener { viewModel.clearError() }

        binding.btnYtVoiceCommand.setOnClickListener { triggerYouTubeVoiceCommand() }
        binding.btnYtReadScreen.setOnClickListener { viewModel.identifyFromAccessibilityScreen() }
        binding.btnYtScreenVision.setOnClickListener {
            MaterialAlertDialogBuilder(requireContext())
                .setTitle("Capture YouTube Screen for Gemini Vision?")
                .setMessage("Android will request consent to capture one screenshot of your current screen to identify visible video titles, controls, or slides.")
                .setPositiveButton("Continue") { _, _ ->
                    (activity as? MainActivity)?.requestScreenCapture { base64 ->
                        viewModel.attachScreenVisionBase64(base64)
                    }
                }
                .setNegativeButton("Cancel", null)
                .show()
        }

        binding.btnYtSearchGo.setOnClickListener { submitSearchOrUrl() }
        binding.etYtSearchOrUrl.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH || actionId == EditorInfo.IME_ACTION_GO) {
                submitSearchOrUrl()
                true
            } else {
                false
            }
        }
        binding.btnYtWatchLater.setOnClickListener {
            viewModel.executePlaybackControl(YouTubeVoiceIntent.OpenPlaylist("WL", isWatchLater = true))
        }
        binding.btnYtBrowserSearchFallback.setOnClickListener {
            val q = binding.etYtSearchOrUrl.text?.toString()?.trim().orEmpty().ifBlank {
                viewModel.currentVideo.value?.title ?: "educational tutorials"
            }
            viewModel.executePlaybackControl(YouTubeVoiceIntent.SearchVideos(q, viewModel.searchFilter.value))
        }

        binding.btnYtOpenExternal.setOnClickListener {
            val video = viewModel.currentVideo.value
            if (video == null) {
                viewModel.executePlaybackControl(YouTubeVoiceIntent.OpenYouTube)
            } else {
                viewModel.deviceControl.openYouTubeUrl(video.sourceUrl.ifBlank { "https://www.youtube.com/watch?v=${video.videoId}" })
            }
        }

        binding.btnYtSwitchCaptionLang.setOnClickListener {
            val langs = viewModel.transcriptResult.value?.availableLanguages.orEmpty()
            if (langs.isEmpty()) {
                Toast.makeText(requireContext(), "No alternate caption languages reported for this video.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val arr = langs.toTypedArray()
            MaterialAlertDialogBuilder(requireContext())
                .setTitle("Select Caption Language")
                .setItems(arr) { _, which ->
                    viewModel.switchTranscriptLanguage(arr[which])
                }
                .show()
        }

        binding.btnYtToggleTranscript.setOnClickListener {
            val isVisible = binding.tvYtTranscriptPreview.visibility == View.VISIBLE
            binding.tvYtTranscriptPreview.visibility = if (isVisible) View.GONE else View.VISIBLE
        }

        binding.btnYtRecommendations.setOnClickListener {
            if (viewModel.currentVideo.value == null) {
                Toast.makeText(requireContext(), "Load a video first to fetch recommendations.", Toast.LENGTH_SHORT).show()
            } else {
                viewModel.loadRecommendationsForCurrent()
            }
        }

        // Playback Controls
        binding.btnCtrlPlay.setOnClickListener { viewModel.executePlaybackControl(YouTubeVoiceIntent.PlayOrResume) }
        binding.btnCtrlPause.setOnClickListener { viewModel.executePlaybackControl(YouTubeVoiceIntent.Pause) }
        binding.btnCtrlBack10.setOnClickListener { viewModel.executePlaybackControl(YouTubeVoiceIntent.SeekBackward(10)) }
        binding.btnCtrlFwd10.setOnClickListener { viewModel.executePlaybackControl(YouTubeVoiceIntent.SeekForward(10)) }
        binding.btnCtrlPrev.setOnClickListener { viewModel.executePlaybackControl(YouTubeVoiceIntent.PreviousVideo) }
        binding.btnCtrlNext.setOnClickListener { viewModel.executePlaybackControl(YouTubeVoiceIntent.NextVideo) }
        binding.btnCtrlVolDown.setOnClickListener { viewModel.executePlaybackControl(YouTubeVoiceIntent.VolumeDown) }
        binding.btnCtrlVolUp.setOnClickListener { viewModel.executePlaybackControl(YouTubeVoiceIntent.VolumeUp) }
        binding.btnCtrlFullscreen.setOnClickListener { viewModel.executePlaybackControl(YouTubeVoiceIntent.Fullscreen(true)) }
        binding.btnCtrlExitFullscreen.setOnClickListener { viewModel.executePlaybackControl(YouTubeVoiceIntent.Fullscreen(false)) }
        binding.btnCtrlCloseVideo.setOnClickListener { viewModel.executePlaybackControl(YouTubeVoiceIntent.CloseVideo) }

        // Summary & Q&A
        binding.btnYtSummarize.setOnClickListener {
            viewModel.summarizeCurrentVideo(selectedStyle(), selectedLanguage())
        }
        binding.btnYtAsk.setOnClickListener { submitQuestion() }
        binding.etYtQuestion.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEND) {
                submitQuestion()
                true
            } else {
                false
            }
        }

        // Notes & Export
        binding.btnYtGenerateNotes.setOnClickListener {
            viewModel.generateNotesForCurrentVideo(selectedLanguage(), autoSave = true)
        }
        binding.btnYtSaveNotesCopy.setOnClickListener {
            if (viewModel.generatedNotes.value == null) {
                Toast.makeText(requireContext(), "Generate structured notes first.", Toast.LENGTH_SHORT).show()
            } else {
                viewModel.saveCurrentNotesToVault(selectedLanguage())
            }
        }
        binding.btnYtExportCurrentTxt.setOnClickListener {
            buildTemporaryNoteFromCurrent()?.let { viewModel.exportNoteAsTxt(it) }
                ?: Toast.makeText(requireContext(), "Generate notes for a video first.", Toast.LENGTH_SHORT).show()
        }
        binding.btnYtExportCurrentPdf.setOnClickListener {
            buildTemporaryNoteFromCurrent()?.let { viewModel.exportNoteAsPdf(it) }
                ?: Toast.makeText(requireContext(), "Generate notes for a video first.", Toast.LENGTH_SHORT).show()
        }
        binding.etYtSearchNotes.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                viewModel.setNoteSearchQuery(s?.toString().orEmpty())
            }
        })

        // Learning & Quiz
        binding.btnYtTeachMe.setOnClickListener {
            viewModel.startLearningLesson(selectedLearningDepth(), selectedLanguage())
        }
        binding.btnYtGenerateQuiz.setOnClickListener {
            viewModel.generateQuizForCurrentVideo(selectedLanguage())
        }
        binding.btnYtEvaluateQuiz.setOnClickListener {
            viewModel.evaluateActiveQuiz()
        }
        binding.btnYtClearHistory.setOnClickListener {
            MaterialAlertDialogBuilder(requireContext())
                .setTitle("Clear Learning History?")
                .setMessage("Remove all recorded learning sessions and quiz progress?")
                .setPositiveButton("Clear") { _, _ -> viewModel.clearLearningHistory() }
                .setNegativeButton("Cancel", null)
                .show()
        }
    }

    private fun triggerYouTubeVoiceCommand() {
        val hasMic = ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
        if (!hasMic) {
            (activity as? MainActivity)?.requestAudioPermission()
            return
        }
        sharedViewModel.voiceManager.startListening(
            languageMode = sharedViewModel.preferences.value.languageMode,
            onResult = { spoken ->
                val parsed = com.yasmin.ai.youtube.YouTubeVoiceController.parseCommand(spoken)
                if (parsed == null) {
                    binding.etYtSearchOrUrl.setText(spoken)
                    viewModel.performSearchOrLoadUrl(spoken)
                } else {
                    when (parsed) {
                        is YouTubeVoiceIntent.SearchVideos -> {
                            binding.etYtSearchOrUrl.setText(parsed.query)
                            viewModel.setSearchFilter(parsed.filter)
                            viewModel.performSearchOrLoadUrl(parsed.query)
                        }
                        is YouTubeVoiceIntent.SummarizeCurrent -> {
                            val lang = parsed.language ?: selectedLanguage()
                            if (parsed.language != null) selectLanguageSpinner(parsed.language)
                            switchTab(0)
                            viewModel.summarizeCurrentVideo(selectedStyle(), lang)
                        }
                        is YouTubeVoiceIntent.AskAboutVideo -> {
                            switchTab(0)
                            viewModel.askAboutVideo(parsed.question, selectedLanguage())
                        }
                        is YouTubeVoiceIntent.GenerateNotes -> {
                            switchTab(1)
                            viewModel.generateNotesForCurrentVideo(selectedLanguage(), autoSave = true)
                        }
                        is YouTubeVoiceIntent.StartLearningOrQuiz -> {
                            switchTab(2)
                            viewModel.startLearningLesson(selectedLearningDepth(), selectedLanguage())
                        }
                        is YouTubeVoiceIntent.ReadYouTubeScreen -> {
                            viewModel.identifyFromAccessibilityScreen()
                        }
                        else -> viewModel.executePlaybackControl(parsed)
                    }
                }
            },
            onError = { err ->
                Toast.makeText(requireContext(), err, Toast.LENGTH_SHORT).show()
            }
        )
    }

    private fun handlePendingVoiceDispatch() {
        val pending = sharedViewModel.consumePendingYouTubeAction()
        if (pending.isBlank()) return
        when {
            pending.startsWith("summarize") -> {
                val code = pending.substringAfter(":", "")
                val lang = SummaryLanguage.values().firstOrNull { it.code == code } ?: selectedLanguage()
                selectLanguageSpinner(lang)
                switchTab(0)
                if (viewModel.currentVideo.value != null) {
                    viewModel.summarizeCurrentVideo(selectedStyle(), lang)
                } else {
                    Toast.makeText(requireContext(), "Load or pick a video to summarize in ${lang.label}.", Toast.LENGTH_SHORT).show()
                }
            }
            pending.startsWith("ask:") -> {
                val question = pending.substringAfter("ask:").trim()
                switchTab(0)
                if (viewModel.currentVideo.value != null && question.isNotEmpty()) {
                    viewModel.askAboutVideo(question, selectedLanguage())
                } else if (question.isNotEmpty()) {
                    binding.etYtQuestion.setText(question)
                    Toast.makeText(requireContext(), "Load a video first, then tap Ask.", Toast.LENGTH_SHORT).show()
                }
            }
            pending == "notes" -> {
                switchTab(1)
                if (viewModel.currentVideo.value != null) {
                    viewModel.generateNotesForCurrentVideo(selectedLanguage())
                }
            }
            pending == "learn" -> {
                switchTab(2)
                if (viewModel.currentVideo.value != null) {
                    viewModel.startLearningLesson(selectedLearningDepth(), selectedLanguage())
                }
            }
            else -> {
                binding.etYtSearchOrUrl.setText(pending)
                viewModel.performSearchOrLoadUrl(pending)
            }
        }
    }

    private fun submitSearchOrUrl() {
        val query = binding.etYtSearchOrUrl.text?.toString().orEmpty()
        val creator = binding.etYtCreatorFilter.text?.toString().orEmpty()
        viewModel.performSearchOrLoadUrl(query, creator)
    }

    private fun submitQuestion() {
        val q = binding.etYtQuestion.text?.toString().orEmpty()
        if (q.isNotBlank()) {
            binding.etYtQuestion.text?.clear()
            viewModel.askAboutVideo(q, selectedLanguage())
        }
    }

    private fun buildTemporaryNoteFromCurrent(): VideoNoteEntity? {
        val video = viewModel.currentVideo.value ?: return null
        val bundle = viewModel.generatedNotes.value ?: return null
        return VideoNoteEntity(
            id = System.currentTimeMillis(),
            videoId = video.videoId,
            videoTitle = video.title,
            channelTitle = video.channelTitle,
            topic = bundle.topic,
            markdownContent = bundle.fullMarkdown,
            definitionsText = bundle.definitions,
            bulletPointsText = bundle.bulletPoints,
            stepsText = bundle.stepByStep,
            timestampsText = bundle.importantTimestamps,
            language = selectedLanguage().code
        )
    }

    private fun selectedStyle(): SummaryStyle =
        summaryStyles.getOrElse(binding.spinnerSummaryStyle.selectedItemPosition) { SummaryStyle.DETAILED }

    private fun selectedLanguage(): SummaryLanguage =
        summaryLanguages.getOrElse(binding.spinnerSummaryLang.selectedItemPosition) { SummaryLanguage.ENGLISH }

    private fun selectedLearningDepth(): LearningDepth =
        learningDepths.getOrElse(binding.spinnerLearningDepth.selectedItemPosition) { LearningDepth.BASIC }

    private fun selectLanguageSpinner(lang: SummaryLanguage) {
        val idx = summaryLanguages.indexOf(lang)
        if (idx >= 0) binding.spinnerSummaryLang.setSelection(idx)
    }

    private fun switchTab(idx: Int) {
        activeTabIndex = idx
        binding.panelSummaryQa.visibility = if (idx == 0) View.VISIBLE else View.GONE
        binding.panelNotes.visibility = if (idx == 1) View.VISIBLE else View.GONE
        binding.panelLearnQuiz.visibility = if (idx == 2) View.VISIBLE else View.GONE
        binding.panelHistory.visibility = if (idx == 3) View.VISIBLE else View.GONE

        val tabs = listOf(
            binding.btnTabSummaryQa,
            binding.btnTabNotes,
            binding.btnTabLearnQuiz,
            binding.btnTabHistory
        )
        val deep = ContextCompat.getColor(requireContext(), R.color.jarvis_bg_deep)
        val muted = ContextCompat.getColor(requireContext(), R.color.jarvis_text_secondary)
        tabs.forEachIndexed { index, button ->
            if (index == idx) {
                button.setBackgroundResource(R.drawable.bg_jarvis_button_primary)
                button.setTextColor(deep)
            } else {
                button.setBackgroundResource(R.drawable.bg_jarvis_panel)
                button.setTextColor(muted)
            }
        }
    }

    private fun observeState() {
        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch {
                    viewModel.isBusy.collect { busy ->
                        binding.progressYouTubeBusy.visibility = if (busy) View.VISIBLE else View.GONE
                        binding.btnYtSearchGo.isEnabled = !busy
                        binding.btnYtSummarize.isEnabled = !busy
                        binding.btnYtGenerateNotes.isEnabled = !busy
                        binding.btnYtTeachMe.isEnabled = !busy
                        binding.btnYtGenerateQuiz.isEnabled = !busy
                    }
                }
                launch {
                    viewModel.statusBanner.collect { banner ->
                        binding.tvYtStatusBanner.text = banner
                    }
                }
                launch {
                    viewModel.errorMessage.collect { err ->
                        if (err.isNullOrBlank()) {
                            binding.layoutYtError.visibility = View.GONE
                        } else {
                            binding.layoutYtError.visibility = View.VISIBLE
                            binding.tvYtErrorMessage.text = err
                        }
                    }
                }
                launch {
                    viewModel.searchResults.collect { items ->
                        searchAdapter.submitList(items)
                        val vis = if (items.isEmpty()) View.GONE else View.VISIBLE
                        binding.tvYtSearchResultsHeader.visibility = vis
                        binding.rvYtSearchResults.visibility = vis
                        binding.tvYtSearchResultsHeader.text = "Search / Playlist Results (${items.size})"
                    }
                }
                launch {
                    viewModel.currentVideo.collect { video ->
                        if (video == null) {
                            binding.tvYtCurrentTitle.text = "No YouTube video loaded yet"
                            binding.tvYtCurrentChannel.text = "Paste a video URL, search above, or tap Read Screen"
                            binding.tvYtDurationChip.text = "--:--"
                        } else {
                            binding.tvYtCurrentTitle.text = video.title
                            binding.tvYtCurrentChannel.text = "${video.channelTitle.ifBlank { "YouTube" }} ${if (video.viewCount.isNotBlank()) "· ${video.viewCount}" else ""}".trim()
                            binding.tvYtDurationChip.text = video.durationFormatted.ifBlank { "--:--" }
                        }
                    }
                }
                launch {
                    viewModel.thumbnailBitmap.collect { bmp ->
                        if (bmp != null) {
                            binding.ivYtThumbnail.setImageBitmap(bmp)
                        } else {
                            binding.ivYtThumbnail.setImageResource(R.drawable.ic_youtube)
                        }
                    }
                }
                launch {
                    viewModel.transcriptResult.collect { tr ->
                        if (tr == null) {
                            binding.tvYtTranscriptStatusChip.text = "NOT CHECKED"
                            binding.tvYtTranscriptDetail.text = "Transcript status will appear here once a video is loaded."
                            binding.tvYtTranscriptPreview.text = "Timestamped transcript will appear here when captions are loaded."
                        } else {
                            binding.tvYtTranscriptStatusChip.text = tr.status.badgeLabel
                            val colorRes = when (tr.status) {
                                TranscriptStatus.AVAILABLE -> R.color.jarvis_success
                                TranscriptStatus.UNAVAILABLE, TranscriptStatus.RESTRICTED, TranscriptStatus.ERROR -> R.color.jarvis_warning
                                else -> R.color.jarvis_cyan
                            }
                            binding.tvYtTranscriptStatusChip.setTextColor(ContextCompat.getColor(requireContext(), colorRes))
                            val chunkLabel = if (tr.isChunked) " · ${tr.chunkCount} chunks" else ""
                            val langLabel = if (tr.availableLanguages.isNotEmpty()) " · Languages: ${tr.availableLanguages.joinToString(", ")}" else ""
                            binding.tvYtTranscriptDetail.text = "${tr.statusReason}$chunkLabel$langLabel"
                            binding.tvYtTranscriptPreview.text = if (tr.rawTextWithTimestamps.isNotBlank()) {
                                tr.rawTextWithTimestamps.take(4500)
                            } else {
                                tr.statusReason
                            }
                        }
                    }
                }
                launch {
                    viewModel.summaryOutput.collect { summary ->
                        if (summary.isNotBlank()) {
                            binding.tvYtSummaryOutput.text = summary
                        }
                    }
                }
                launch {
                    viewModel.qaMessages.collect { msgs ->
                        if (msgs.isNotEmpty()) {
                            binding.tvYtQaHistory.text = msgs.joinToString("\n\n") { m ->
                                val speaker = if (m.role == "user") "You" else "Yasmin"
                                val tag = if (m.role == "assistant" && m.groundedInTranscript) " [Transcript-Grounded]" else ""
                                "$speaker$tag:\n${m.content}"
                            }
                        }
                    }
                }
                launch {
                    viewModel.generatedNotes.collect { bundle ->
                        if (bundle != null) {
                            binding.tvYtGeneratedNotesPreview.text = bundle.fullMarkdown
                        }
                    }
                }
                launch {
                    viewModel.savedNotes.collect { notes ->
                        savedNoteAdapter.submitList(notes)
                        binding.tvYtNotesEmpty.visibility = if (notes.isEmpty()) View.VISIBLE else View.GONE
                    }
                }
                launch {
                    viewModel.learningOutput.collect { lesson ->
                        if (lesson.isNotBlank()) {
                            binding.tvYtLearningOutput.text = lesson
                        }
                    }
                }
                launch {
                    viewModel.quizQuestions.collect { questions ->
                        quizAdapter.submitQuiz(
                            questions,
                            viewModel.selectedQuizAnswers.value,
                            viewModel.quizEvaluation.value
                        )
                        binding.btnYtEvaluateQuiz.visibility = if (questions.isEmpty()) View.GONE else View.VISIBLE
                    }
                }
                launch {
                    viewModel.selectedQuizAnswers.collect { selected ->
                        quizAdapter.submitQuiz(
                            viewModel.quizQuestions.value,
                            selected,
                            viewModel.quizEvaluation.value
                        )
                    }
                }
                launch {
                    viewModel.quizEvaluation.collect { eval ->
                        quizAdapter.submitQuiz(
                            viewModel.quizQuestions.value,
                            viewModel.selectedQuizAnswers.value,
                            eval
                        )
                        if (eval == null) {
                            binding.tvYtQuizEvaluation.visibility = View.GONE
                        } else {
                            binding.tvYtQuizEvaluation.visibility = View.VISIBLE
                            binding.tvYtQuizEvaluation.text = eval.summaryMessage
                            val colorRes = if (eval.scorePercent >= 60) R.color.jarvis_success else R.color.jarvis_warning
                            binding.tvYtQuizEvaluation.setTextColor(ContextCompat.getColor(requireContext(), colorRes))
                        }
                    }
                }
                launch {
                    viewModel.learningHistory.collect { history ->
                        historyAdapter.submitList(history)
                        binding.tvYtHistoryStats.text = "Learning Progress & History (${history.size} sessions)"
                        binding.tvYtHistoryEmpty.visibility = if (history.isEmpty()) View.VISIBLE else View.GONE
                    }
                }
                launch {
                    viewModel.uiEvents.collect { ev ->
                        when (ev) {
                            is YouTubeAgentViewModel.YouTubeUiEvent.ShowToast ->
                                Toast.makeText(requireContext(), ev.message, Toast.LENGTH_SHORT).show()
                            is YouTubeAgentViewModel.YouTubeUiEvent.ShareExportedFile -> {
                                runCatching { startActivity(ev.intent) }.onFailure {
                                    Toast.makeText(requireContext(), "Saved file, but no app handler opened the share sheet.", Toast.LENGTH_SHORT).show()
                                }
                            }
                            is YouTubeAgentViewModel.YouTubeUiEvent.RequestPermissionsScreen -> {
                                MaterialAlertDialogBuilder(requireContext())
                                    .setTitle("Accessibility Permission Required")
                                    .setMessage(ev.reason)
                                    .setPositiveButton("Open Setup") { _, _ ->
                                        findNavController().navigate(R.id.permissionsFragment)
                                    }
                                    .setNegativeButton("Cancel", null)
                                    .show()
                            }
                        }
                    }
                }
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
