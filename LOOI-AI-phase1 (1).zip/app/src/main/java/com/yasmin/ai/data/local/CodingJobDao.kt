package com.yasmin.ai.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface CodingJobDao {
    @Query("SELECT * FROM coding_jobs ORDER BY updatedAt DESC")
    fun observeAllJobs(): Flow<List<CodingJobEntity>>

    @Query("SELECT * FROM coding_jobs WHERE jobId = :jobId LIMIT 1")
    suspend fun getJobById(jobId: String): CodingJobEntity?

    @Query("SELECT * FROM coding_jobs WHERE status IN ('QUEUED', 'RUNNING') ORDER BY updatedAt DESC")
    suspend fun getNonTerminalJobs(): List<CodingJobEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertJob(job: CodingJobEntity)

    @Query("UPDATE coding_jobs SET status = :status, progress = :progress, statusMessage = :statusMessage, updatedAt = :updatedAt WHERE jobId = :jobId")
    suspend fun updateProgress(
        jobId: String,
        status: String,
        progress: Int,
        statusMessage: String,
        updatedAt: Long = System.currentTimeMillis()
    )

    @Query("DELETE FROM coding_jobs WHERE jobId = :jobId")
    suspend fun deleteJob(jobId: String)

    @Query("DELETE FROM coding_jobs")
    suspend fun clearAllJobs()
}
