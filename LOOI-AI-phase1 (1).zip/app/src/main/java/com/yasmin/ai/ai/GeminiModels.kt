package com.yasmin.ai.ai

data class ChatTurn(
    val role: String,
    val content: String
)

data class MemoryContextItem(
    val keyTitle: String,
    val content: String
)

data class GeminiChatRequest(
    val message: String,
    val language: String,
    val personality: String = "jarvis_formal",
    val history: List<ChatTurn> = emptyList(),
    val memories: List<MemoryContextItem> = emptyList(),
    val userName: String = "Commander",
    val enableWebSearch: Boolean = true
)

data class GeminiAgentRequest(
    val message: String,
    val language: String,
    val personality: String = "jarvis_formal",
    val memories: List<MemoryContextItem> = emptyList(),
    val pendingTasks: List<String> = emptyList(),
    val userName: String = "Commander"
)

data class PlannedAction(
    val tool: String = "",
    val arg1: String = "",
    val arg2: String = "",
    val arg3: String = ""
)

data class GeminiAgentResponse(
    val reply: String = "",
    val actions: List<PlannedAction> = emptyList(),
    val error: String? = null
)

data class GeminiCodeRequest(
    val prompt: String,
    val target: String, // "python" | "web" | "debug" | "explain"
    val existingCode: String = "",
    val errorOutput: String = ""
)

data class GeminiVisionRequest(
    val prompt: String,
    val imageBase64: String,
    val mimeType: String = "image/jpeg",
    val language: String = "hinglish",
    val mode: String = "general" // "general" | "ocr" | "document" | "ui" | "objects"
)

data class BriefingRequest(
    val cityOrContext: String = "",
    val pendingTasks: List<String> = emptyList(),
    val upcomingEvents: List<String> = emptyList(),
    val language: String = "hinglish",
    val personality: String = "jarvis_formal",
    val userName: String = "Commander"
)

data class PythonSandboxRequest(
    val code: String
)

data class PythonSandboxResponse(
    val success: Boolean = false,
    val stdout: String = "",
    val stderr: String = "",
    val error: String = "",
    val elapsedMs: Long = 0L,
    val isolation: String = "subprocess-rlimit-ast"
)

data class GroundingSource(
    val title: String = "",
    val uri: String = ""
)

data class GeminiResponse(
    val reply: String? = null,
    val code: String? = null,
    val html: String? = null,
    val css: String? = null,
    val js: String? = null,
    val explanation: String? = null,
    val sources: List<GroundingSource>? = null,
    val error: String? = null
)

sealed class AiResult<out T> {
    data class Success<T>(val data: T) : AiResult<T>()
    data class Error(val message: String, val code: Int? = null) : AiResult<Nothing>()
}
