package com.yasmin.ai.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface LearningSessionDao {
    @Query("SELECT * FROM learning_sessions ORDER BY lastStudiedAt DESC")
    fun observeAllSessions(): Flow<List<LearningSessionEntity>>

    @Query("SELECT * FROM learning_sessions WHERE videoId = :videoId LIMIT 1")
    suspend fun getByVideoId(videoId: String): LearningSessionEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertSession(session: LearningSessionEntity): Long

    @Delete
    suspend fun deleteSession(session: LearningSessionEntity)

    @Query("DELETE FROM learning_sessions")
    suspend fun clearHistory()
}
