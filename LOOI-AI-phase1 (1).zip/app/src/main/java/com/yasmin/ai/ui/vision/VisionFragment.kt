package com.yasmin.ai.ui.vision

import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.yasmin.ai.MainActivity
import com.yasmin.ai.databinding.FragmentVisionBinding
import kotlinx.coroutines.launch
import java.io.File

class VisionFragment : Fragment() {

    private var _binding: FragmentVisionBinding? = null
    private val binding get() = _binding!!
    private val viewModel: VisionViewModel by viewModels()

    private var pendingCameraUri: Uri? = null

    private val modeKeys = listOf("general", "objects", "ocr", "document", "ui")
    private val modeLabels = listOf(
        "General Image Q&A",
        "Camera Object Recognition",
        "OCR & Text Extraction",
        "Document Understanding",
        "Screenshot / UI Analysis"
    )

    private val galleryLauncher = registerForActivityResult(
        ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            viewModel.loadFromUri(uri) {
                Toast.makeText(requireContext(), "Failed to decode selected image.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private val cameraLauncher = registerForActivityResult(
        ActivityResultContracts.TakePicture()
    ) { success ->
        val uri = pendingCameraUri
        if (success && uri != null) {
            viewModel.loadFromUri(uri) {
                Toast.makeText(requireContext(), "Failed to decode camera image.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private val cameraPermLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) launchCamera()
        else Toast.makeText(requireContext(), "Camera permission denied.", Toast.LENGTH_SHORT).show()
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentVisionBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.spinnerVisionMode.adapter = ArrayAdapter(
            requireContext(),
            android.R.layout.simple_spinner_dropdown_item,
            modeLabels
        )
        binding.spinnerVisionMode.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, v: View?, position: Int, id: Long) {
                viewModel.setSelectedModeIndex(position)
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        binding.btnVisionCamera.setOnClickListener {
            if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.CAMERA)
                == PackageManager.PERMISSION_GRANTED
            ) {
                launchCamera()
            } else {
                cameraPermLauncher.launch(Manifest.permission.CAMERA)
            }
        }

        binding.btnVisionGallery.setOnClickListener {
            galleryLauncher.launch(
                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
            )
        }

        binding.btnVisionScreen.setOnClickListener {
            MaterialAlertDialogBuilder(requireContext())
                .setTitle("Capture One Screen Snapshot?")
                .setMessage("Android will prompt for permission to capture one frame for Vision analysis.")
                .setPositiveButton("Continue") { _, _ ->
                    (activity as? MainActivity)?.requestScreenCapture { base64 ->
                        viewModel.loadCapturedBase64(base64)
                    }
                }
                .setNegativeButton("Cancel", null)
                .show()
        }

        binding.btnVisionAnalyze.setOnClickListener {
            if (viewModel.imageBase64.value.isNullOrBlank()) {
                Toast.makeText(requireContext(), "Capture or pick an image first.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val safeIdx = binding.spinnerVisionMode.selectedItemPosition.coerceIn(0, modeKeys.lastIndex)
            val mode = modeKeys[safeIdx]
            val prompt = binding.etVisionPrompt.text?.toString()?.trim().orEmpty()
                .ifBlank { "Analyze this image thoroughly according to the selected mode." }

            viewModel.analyzeCurrentImage(prompt, mode)
        }

        observeViewModel()
    }

    private fun observeViewModel() {
        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch {
                    viewModel.previewBitmap.collect { bmp ->
                        if (bmp != null) {
                            binding.ivVisionPreview.setImageBitmap(bmp)
                        }
                    }
                }
                launch {
                    viewModel.selectedModeIndex.collect { idx ->
                        val clamped = idx.coerceIn(0, modeLabels.lastIndex)
                        if (binding.spinnerVisionMode.selectedItemPosition != clamped) {
                            binding.spinnerVisionMode.setSelection(clamped)
                        }
                    }
                }
                launch {
                    viewModel.resultText.collect { txt ->
                        binding.tvVisionResult.text = txt
                    }
                }
                launch {
                    viewModel.isLoading.collect { loading ->
                        binding.btnVisionAnalyze.isEnabled = !loading
                    }
                }
            }
        }
    }

    private fun launchCamera() {
        val camDir = File(requireContext().cacheDir, "camera").apply { mkdirs() }
        val photoFile = File(camDir, "vision_${System.currentTimeMillis()}.jpg")
        val uri = FileProvider.getUriForFile(
            requireContext(),
            "${requireContext().packageName}.fileprovider",
            photoFile
        )
        pendingCameraUri = uri
        cameraLauncher.launch(uri)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
