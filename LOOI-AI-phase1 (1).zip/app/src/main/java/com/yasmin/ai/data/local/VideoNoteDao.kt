package com.yasmin.ai.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface VideoNoteDao {
    @Query("SELECT * FROM video_notes ORDER BY updatedAt DESC")
    fun observeAllNotes(): Flow<List<VideoNoteEntity>>

    @Query(
        "SELECT * FROM video_notes " +
            "WHERE videoTitle LIKE '%' || :query || '%' " +
            "OR topic LIKE '%' || :query || '%' " +
            "OR markdownContent LIKE '%' || :query || '%' " +
            "OR channelTitle LIKE '%' || :query || '%' " +
            "ORDER BY updatedAt DESC"
    )
    fun observeSearchNotes(query: String): Flow<List<VideoNoteEntity>>

    @Query(
        "SELECT * FROM video_notes " +
            "WHERE videoTitle LIKE '%' || :query || '%' " +
            "OR topic LIKE '%' || :query || '%' " +
            "OR markdownContent LIKE '%' || :query || '%' " +
            "OR channelTitle LIKE '%' || :query || '%' " +
            "ORDER BY updatedAt DESC"
    )
    suspend fun searchNotesOnce(query: String): List<VideoNoteEntity>

    @Query("SELECT * FROM video_notes WHERE videoId = :videoId ORDER BY updatedAt DESC")
    suspend fun getNotesForVideo(videoId: String): List<VideoNoteEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNote(note: VideoNoteEntity): Long

    @Update
    suspend fun updateNote(note: VideoNoteEntity)

    @Delete
    suspend fun deleteNote(note: VideoNoteEntity)

    @Query("DELETE FROM video_notes WHERE id = :noteId")
    suspend fun deleteById(noteId: Long)
}
