package com.yasmin.ai.coding

import android.content.Context
import android.content.Intent
import androidx.core.content.FileProvider
import java.io.File

data class InstalledEditorApp(
    val packageName: String,
    val label: String
)

sealed class OpenEditorResult {
    data class Launched(val targetLabel: String) : OpenEditorResult()
    data class NoEditorInstalled(val file: File) : OpenEditorResult()
    data class Failed(val message: String) : OpenEditorResult()
}

object ExternalEditorHelper {

    fun findCompatibleEditors(context: Context): List<InstalledEditorApp> {
        val pm = context.packageManager
        val probeIntent = Intent(Intent.ACTION_EDIT).apply {
            type = "text/plain"
        }
        val matches = pm.queryIntentActivities(probeIntent, 0)
        return matches
            .filter { it.activityInfo.packageName != context.packageName }
            .map {
                InstalledEditorApp(
                    packageName = it.activityInfo.packageName,
                    label = it.loadLabel(pm).toString()
                )
            }
            .distinctBy { it.packageName }
            .sortedBy { it.label.lowercase() }
    }

    fun openFileInExternalEditor(
        context: Context,
        file: File,
        preferredPackage: String = ""
    ): OpenEditorResult {
        if (!file.exists()) {
            return OpenEditorResult.Failed("File does not exist yet: ${file.name}")
        }
        val uri = try {
            FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )
        } catch (e: Exception) {
            return OpenEditorResult.Failed("Could not prepare FileProvider URI: ${e.localizedMessage}")
        }

        val mime = ProjectFileManager.guessMimeTypeForPath(file.name)
        val grantFlags = Intent.FLAG_GRANT_READ_URI_PERMISSION or
            Intent.FLAG_GRANT_WRITE_URI_PERMISSION or
            Intent.FLAG_ACTIVITY_NEW_TASK

        if (preferredPackage.isNotBlank()) {
            val targeted = Intent(Intent.ACTION_EDIT).apply {
                setDataAndType(uri, mime)
                setPackage(preferredPackage)
                addFlags(grantFlags)
            }
            try {
                context.startActivity(targeted)
                return OpenEditorResult.Launched(preferredPackage)
            } catch (_: Exception) {
                // Fall through to general editor chooser if selected editor is unavailable
            }
        }

        val editIntent = Intent(Intent.ACTION_EDIT).apply {
            setDataAndType(uri, mime)
            addFlags(grantFlags)
        }
        val editors = context.packageManager.queryIntentActivities(editIntent, 0)
            .filter { it.activityInfo.packageName != context.packageName }
        if (editors.isNotEmpty()) {
            val chooser = Intent.createChooser(editIntent, "Open ${file.name} in Code Editor").apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            return try {
                context.startActivity(chooser)
                OpenEditorResult.Launched("External Editor")
            } catch (e: Exception) {
                OpenEditorResult.Failed("Could not launch external editor: ${e.localizedMessage}")
            }
        }

        // Secondary attempt with generic text/plain VIEW intent
        val viewIntent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "text/plain")
            addFlags(grantFlags)
        }
        val viewers = context.packageManager.queryIntentActivities(viewIntent, 0)
            .filter { it.activityInfo.packageName != context.packageName }
        if (viewers.isNotEmpty()) {
            val chooser = Intent.createChooser(viewIntent, "Open ${file.name} in Editor/Viewer").apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            return try {
                context.startActivity(chooser)
                OpenEditorResult.Launched("External Viewer")
            } catch (_: Exception) {
                OpenEditorResult.NoEditorInstalled(file)
            }
        }

        return OpenEditorResult.NoEditorInstalled(file)
    }
}
