package com.yasmin.ai.ui.views

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View
import android.view.animation.LinearInterpolator
import com.yasmin.ai.voice.AssistantVoiceState
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/**
 * Futuristic JARVIS circular arc reactor & real-time voice waveform visualizer.
 * Reduces redraw cost cleanly when detached or hidden.
 */
class JarvisVisualizerView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    private var currentState: AssistantVoiceState = AssistantVoiceState.IDLE
    private var audioLevel: Float = 0f
    private var smoothedLevel: Float = 0f
    private var phaseAngle: Float = 0f

    private val outerRingPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 4.5f
        color = Color.parseColor("#00E5FF")
    }

    private val middleArcPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 7f
        strokeCap = Paint.Cap.ROUND
        color = Color.parseColor("#2979FF")
    }

    private val innerArcPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 3.5f
        strokeCap = Paint.Cap.ROUND
        color = Color.parseColor("#8000E5FF")
    }

    private val coreGlowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.parseColor("#3300E5FF")
    }

    private val coreCenterPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.parseColor("#00E5FF")
    }

    private val tickPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 3f
        strokeCap = Paint.Cap.ROUND
        color = Color.parseColor("#8000E5FF")
    }

    private val wavePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 3f
        strokeCap = Paint.Cap.ROUND
        color = Color.parseColor("#AA00E5FF")
    }

    private val arcBounds = RectF()
    private val innerArcBounds = RectF()
    private val wavePath = Path()

    private val animator = ValueAnimator.ofFloat(0f, 360f).apply {
        duration = 4200L
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener {
            phaseAngle = it.animatedValue as Float
            smoothedLevel += (audioLevel - smoothedLevel) * 0.35f
            invalidate()
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (visibility == VISIBLE && !animator.isRunning) {
            animator.start()
        }
    }

    override fun onVisibilityChanged(changedView: View, visibility: Int) {
        super.onVisibilityChanged(changedView, visibility)
        if (visibility == VISIBLE && isAttachedToWindow) {
            if (!animator.isRunning) animator.start()
        } else {
            animator.pause()
        }
    }

    override fun onDetachedFromWindow() {
        animator.cancel()
        super.onDetachedFromWindow()
    }

    fun setAssistantState(state: AssistantVoiceState) {
        if (currentState != state) {
            currentState = state
            if (state != AssistantVoiceState.LISTENING) {
                audioLevel = 0f
            }
            invalidate()
        }
    }

    fun setAudioLevel(level: Float) {
        audioLevel = level.coerceIn(0f, 1f)
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f
        val cy = height / 2f
        val baseRadius = min(width, height) * 0.38f

        val pulseBoost = when (currentState) {
            AssistantVoiceState.IDLE -> sin(Math.toRadians(phaseAngle.toDouble())).toFloat() * 4f
            AssistantVoiceState.LISTENING -> 10f + smoothedLevel * 28f
            AssistantVoiceState.THINKING -> 8f + sin(Math.toRadians((phaseAngle * 3).toDouble())).toFloat() * 10f
            AssistantVoiceState.SPEAKING -> 12f + sin(Math.toRadians((phaseAngle * 4).toDouble())).toFloat() * 14f
        }

        coreGlowPaint.color = when (currentState) {
            AssistantVoiceState.IDLE -> Color.parseColor("#2400E5FF")
            AssistantVoiceState.LISTENING -> Color.parseColor("#4400E5FF")
            AssistantVoiceState.THINKING -> Color.parseColor("#442979FF")
            AssistantVoiceState.SPEAKING -> Color.parseColor("#4D00E676")
        }
        canvas.drawCircle(cx, cy, baseRadius * 0.68f + pulseBoost * 0.8f, coreGlowPaint)

        outerRingPaint.alpha = if (currentState == AssistantVoiceState.IDLE) 130 else 245
        canvas.drawCircle(cx, cy, baseRadius + pulseBoost * 0.4f, outerRingPaint)

        // Outer rotating segmented arcs
        val arcR = baseRadius * 0.84f
        arcBounds.set(cx - arcR, cy - arcR, cx + arcR, cy + arcR)
        val speedMultiplier = when (currentState) {
            AssistantVoiceState.IDLE -> 1f
            AssistantVoiceState.LISTENING -> 2.2f
            AssistantVoiceState.THINKING -> 3.6f
            AssistantVoiceState.SPEAKING -> 2.6f
        }
        val start = (phaseAngle * speedMultiplier) % 360f
        middleArcPaint.color = when (currentState) {
            AssistantVoiceState.SPEAKING -> Color.parseColor("#00E676")
            AssistantVoiceState.THINKING -> Color.parseColor("#40C4FF")
            else -> Color.parseColor("#2979FF")
        }
        canvas.drawArc(arcBounds, start, 95f, false, middleArcPaint)
        canvas.drawArc(arcBounds, start + 180f, 95f, false, middleArcPaint)

        // Counter-rotating inner technical arc
        val innerR = baseRadius * 0.56f
        innerArcBounds.set(cx - innerR, cy - innerR, cx + innerR, cy + innerR)
        val reverseStart = (360f - (phaseAngle * 1.6f) % 360f)
        canvas.drawArc(innerArcBounds, reverseStart, 65f, false, innerArcPaint)
        canvas.drawArc(innerArcBounds, reverseStart + 120f, 65f, false, innerArcPaint)
        canvas.drawArc(innerArcBounds, reverseStart + 240f, 65f, false, innerArcPaint)

        // Radial audio equalizer ticks
        val tickCount = 36
        val tickInner = baseRadius * 0.92f
        for (i in 0 until tickCount) {
            val angleDeg = i * (360f / tickCount) + (phaseAngle * 0.5f)
            val rad = Math.toRadians(angleDeg.toDouble())
            val wave = when (currentState) {
                AssistantVoiceState.LISTENING -> 6f + smoothedLevel * 24f * ((i % 3) + 1) / 3f
                AssistantVoiceState.SPEAKING -> 8f + abs(sin(rad * 4 + phaseAngle * 0.05f)).toFloat() * 18f
                AssistantVoiceState.THINKING -> 5f + ((i % 2) * 9f)
                AssistantVoiceState.IDLE -> 4f
            }
            val x1 = cx + (tickInner * cos(rad)).toFloat()
            val y1 = cy + (tickInner * sin(rad)).toFloat()
            val x2 = cx + ((tickInner + wave) * cos(rad)).toFloat()
            val y2 = cy + ((tickInner + wave) * sin(rad)).toFloat()
            canvas.drawLine(x1, y1, x2, y2, tickPaint)
        }

        // Real-time horizontal acoustic waveform across core when active
        if (currentState == AssistantVoiceState.LISTENING || currentState == AssistantVoiceState.SPEAKING) {
            wavePath.reset()
            val span = baseRadius * 0.72f
            val amp = if (currentState == AssistantVoiceState.LISTENING) {
                (6f + smoothedLevel * 22f)
            } else {
                14f
            }
            wavePaint.color = if (currentState == AssistantVoiceState.SPEAKING) {
                Color.parseColor("#CC00E676")
            } else {
                Color.parseColor("#CC00E5FF")
            }
            val steps = 28
            for (s in 0..steps) {
                val t = s / steps.toFloat()
                val x = (cx - span) + t * (span * 2f)
                val envelope = sin(Math.PI * t).toFloat()
                val y = cy + sin((t * 14f) + phaseAngle * 0.14f) * amp * envelope
                if (s == 0) wavePath.moveTo(x, y) else wavePath.lineTo(x, y)
            }
            canvas.drawPath(wavePath, wavePaint)
        }

        // Solid inner core orb
        coreCenterPaint.color = when (currentState) {
            AssistantVoiceState.SPEAKING -> Color.parseColor("#00E676")
            AssistantVoiceState.THINKING -> Color.parseColor("#2979FF")
            else -> Color.parseColor("#00E5FF")
        }
        canvas.drawCircle(cx, cy, baseRadius * 0.25f + pulseBoost * 0.22f, coreCenterPaint)
    }
}
