package com.yasmin.ai.accessibility

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Rect
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class YasminAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        _isConnected.value = true
        _automationStatus.value = "Accessibility Service Connected"
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Deliberately passive: screen content is ONLY read on explicit user command.
    }

    override fun onInterrupt() {
        _automationStatus.value = "Accessibility Service Interrupted"
    }

    override fun onDestroy() {
        super.onDestroy()
        if (instance === this) {
            instance = null
        }
        _isConnected.value = false
        _automationStatus.value = "Accessibility Service Disconnected"
    }

    fun readVisibleScreenText(): String {
        val root = rootInActiveWindow ?: return ""
        val builder = StringBuilder()
        collectNodeText(root, builder, depth = 0)
        return builder.toString().trim()
    }

    private fun collectNodeText(node: AccessibilityNodeInfo?, out: StringBuilder, depth: Int) {
        if (node == null || depth > 24) return
        // Never expose password fields to the AI or to logs.
        if (node.isPassword) {
            out.append("[password field hidden]").append('\n')
            return
        }
        val text = node.text?.toString()?.trim()
        val desc = node.contentDescription?.toString()?.trim()
        if (!text.isNullOrEmpty()) {
            out.append(text).append('\n')
        } else if (!desc.isNullOrEmpty()) {
            out.append(desc).append('\n')
        }
        for (i in 0 until node.childCount) {
            collectNodeText(node.getChild(i), out, depth + 1)
        }
    }

    fun performScrollDown(): Boolean {
        val root = rootInActiveWindow
        if (root != null && findAndScroll(root, AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)) {
            _automationStatus.value = "Scrolled down"
            return true
        }
        val metrics = resources.displayMetrics
        val cx = metrics.widthPixels / 2f
        val startY = metrics.heightPixels * 0.72f
        val endY = metrics.heightPixels * 0.28f
        return performSwipe(cx, startY, cx, endY, 320L).also {
            if (it) _automationStatus.value = "Swiped down"
        }
    }

    fun performScrollUp(): Boolean {
        val root = rootInActiveWindow
        if (root != null && findAndScroll(root, AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD)) {
            _automationStatus.value = "Scrolled up"
            return true
        }
        val metrics = resources.displayMetrics
        val cx = metrics.widthPixels / 2f
        val startY = metrics.heightPixels * 0.28f
        val endY = metrics.heightPixels * 0.72f
        return performSwipe(cx, startY, cx, endY, 320L).also {
            if (it) _automationStatus.value = "Swiped up"
        }
    }

    private fun findAndScroll(node: AccessibilityNodeInfo?, action: Int): Boolean {
        if (node == null) return false
        if (node.isScrollable && node.performAction(action)) return true
        for (i in 0 until node.childCount) {
            if (findAndScroll(node.getChild(i), action)) return true
        }
        return false
    }

    /** One visible UI element, as exposed through AccessibilityNodeInfo. */
    data class UiElement(
        val label: String,
        val className: String,
        val clickable: Boolean,
        val editable: Boolean,
        val bounds: Rect
    )

    /** Outcome of an action so callers never claim success without evidence. */
    sealed class ActionOutcome {
        data class Done(val message: String) : ActionOutcome()
        data class Failed(val reason: String) : ActionOutcome()
        data class Ambiguous(val candidates: List<String>) : ActionOutcome()
    }

    /** Collects labelled, interactive or text-bearing nodes with their on-screen bounds. */
    fun snapshotUiElements(limit: Int = 80): List<UiElement> {
        val root = rootInActiveWindow ?: return emptyList()
        val result = mutableListOf<UiElement>()
        collectElements(root, result, 0, limit)
        return result
    }

    private fun collectElements(node: AccessibilityNodeInfo?, out: MutableList<UiElement>, depth: Int, limit: Int) {
        if (node == null || depth > 24 || out.size >= limit) return
        if (node.isPassword) return
        if (node.isVisibleToUser) {
            val label = (node.text?.toString() ?: node.contentDescription?.toString() ?: node.hintText?.toString())
                ?.trim().orEmpty()
            val interactive = node.isClickable || node.isEditable || node.isCheckable
            if (label.isNotEmpty() || interactive) {
                val rect = Rect()
                node.getBoundsInScreen(rect)
                out.add(
                    UiElement(
                        label = label.take(80),
                        className = node.className?.toString()?.substringAfterLast('.').orEmpty(),
                        clickable = node.isClickable,
                        editable = node.isEditable,
                        bounds = rect
                    )
                )
            }
        }
        for (i in 0 until node.childCount) collectElements(node.getChild(i), out, depth + 1, limit)
    }

    /** Text block describing visible UI elements; this is the context sent to Groq/Gemini. */
    fun describeScreenStructured(): String {
        val elements = snapshotUiElements()
        if (elements.isEmpty()) return ""
        return elements.joinToString("\n") { e ->
            val kind = when {
                e.editable -> "input"
                e.clickable -> "button"
                else -> "text"
            }
            "[$kind] ${e.label.ifEmpty { "(no label)" }} @(${e.bounds.left},${e.bounds.top},${e.bounds.right},${e.bounds.bottom})"
        }
    }

    /** Labels of clickable elements matching [targetText] (case-insensitive, de-duplicated). */
    fun findClickableCandidates(targetText: String): List<String> {
        val needle = targetText.trim().lowercase()
        if (needle.isEmpty()) return emptyList()
        return snapshotUiElements(200)
            .filter { it.clickable && it.label.lowercase().contains(needle) }
            .map { it.label }
            .distinct()
    }

    /**
     * Validates the target first (refuses ambiguous matches), clicks, then reports
     * whether the screen content actually changed afterwards.
     */
    fun clickNodeValidated(targetText: String): ActionOutcome {
        val root = rootInActiveWindow ?: return ActionOutcome.Failed("No active window is readable.")
        val candidates = findClickableCandidates(targetText)
        if (candidates.size > 1) return ActionOutcome.Ambiguous(candidates.take(6))
        val before = readVisibleScreenText()
        val matches = root.findAccessibilityNodeInfosByText(targetText)
        for (node in matches) {
            if (node.isPassword) continue
            var current: AccessibilityNodeInfo? = node
            while (current != null) {
                if (current.isClickable && current.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                    _automationStatus.value = "Clicked '$targetText'"
                    Thread.sleep(500L) // let the target screen settle before verifying
                    val changed = readVisibleScreenText() != before
                    return ActionOutcome.Done(
                        if (changed) "Clicked '$targetText'; the screen changed."
                        else "Click on '$targetText' was sent, but the screen did not visibly change."
                    )
                }
                current = current.parent
            }
        }
        return ActionOutcome.Failed("Could not find a clickable element '$targetText'.")
    }

    /** Backwards-compatible boolean wrapper. */
    fun clickNodeByText(targetText: String): Boolean = clickNodeValidated(targetText) is ActionOutcome.Done

    /** Types into the focused editable field. Never touches password fields. */
    fun typeIntoFocusedField(text: String): ActionOutcome {
        val root = rootInActiveWindow ?: return ActionOutcome.Failed("No active window is readable.")
        val field = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
            ?: return ActionOutcome.Failed("No text field is focused. Tap a text field first.")
        if (field.isPassword) return ActionOutcome.Failed("Refusing to type into a password field.")
        if (!field.isEditable) return ActionOutcome.Failed("The focused element is not editable.")
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        val ok = field.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
        if (!ok) return ActionOutcome.Failed("The app rejected the text input.")
        field.refresh()
        val applied = field.text?.toString() == text
        _automationStatus.value = "Typed text"
        return if (applied) ActionOutcome.Done("Typed the text into the focused field.")
        else ActionOutcome.Failed("Text input was sent but the field does not show the new text.")
    }

    fun performTap(x: Float, y: Float): Boolean {
        val path = Path().apply { moveTo(x, y) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0L, 60L))
            .build()
        _automationStatus.value = "Performed tap at (${x.toInt()}, ${y.toInt()})"
        return dispatchGesture(gesture, null, null)
    }

    fun performSwipe(
        startX: Float,
        startY: Float,
        endX: Float,
        endY: Float,
        durationMs: Long = 350L
    ): Boolean {
        val path = Path().apply {
            moveTo(startX, startY)
            lineTo(endX, endY)
        }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0L, durationMs))
            .build()
        return dispatchGesture(gesture, null, null)
    }

    fun performBackNavigation(): Boolean {
        _automationStatus.value = "Navigated Back"
        return performGlobalAction(GLOBAL_ACTION_BACK)
    }

    fun isYouTubeActive(): Boolean {
        val pkg = rootInActiveWindow?.packageName?.toString().orEmpty()
        return pkg == YOUTUBE_PACKAGE || pkg == YOUTUBE_MUSIC_PACKAGE
    }

    /**
     * Extracts structured YouTube context (title, channel, visible controls, search results,
     * and description/comments) ONLY when Accessibility Service is enabled and user triggers it.
     */
    fun parseYouTubeScreen(): com.yasmin.ai.youtube.YouTubeScreenContext {
        val root = rootInActiveWindow
            ?: return com.yasmin.ai.youtube.YouTubeScreenContext(isYouTubeForeground = false)
        val isYt = isYouTubeActive()
        val elements = snapshotUiElements(160)
        val controlKeywords = listOf(
            "play", "pause", "next", "previous", "fullscreen", "exit fullscreen",
            "minimize", "close", "subscribe", "like", "dislike", "share", "comments",
            "captions", "skip", "seek"
        )

        val visibleControls = mutableListOf<String>()
        val searchResults = mutableListOf<String>()
        val descOrComments = mutableListOf<String>()
        var detectedTitle = ""
        var detectedChannel = ""

        for (el in elements) {
            val lbl = el.label.trim()
            if (lbl.isBlank()) continue
            val low = lbl.lowercase()

            if (el.clickable && controlKeywords.any { low.contains(it) }) {
                if (!visibleControls.contains(lbl)) visibleControls.add(lbl)
            }

            if (lbl.contains("views") || lbl.contains("ago") || lbl.contains("minute") || lbl.contains("hour")) {
                if (detectedTitle.isEmpty() && lbl.length in 10..140) {
                    detectedTitle = lbl
                } else if (!searchResults.contains(lbl)) {
                    searchResults.add(lbl)
                }
            } else if (detectedTitle.isEmpty() && !el.editable && lbl.length in 15..120 && !controlKeywords.any { low == it }) {
                detectedTitle = lbl
            } else if (detectedChannel.isEmpty() && lbl.startsWith("@") || (lbl.contains("subscribers", ignoreCase = true))) {
                detectedChannel = lbl.substringBefore("·").trim()
            } else if (!el.clickable && lbl.length > 45) {
                descOrComments.add(lbl)
            }
        }

        val playbackState = when {
            visibleControls.any { it.contains("Pause", ignoreCase = true) } -> "Pause button visible (likely playing)"
            visibleControls.any { it.contains("Play", ignoreCase = true) } -> "Play button visible (likely paused)"
            else -> ""
        }
        val fullscreenLikely = visibleControls.any { it.contains("Exit fullscreen", ignoreCase = true) }

        return com.yasmin.ai.youtube.YouTubeScreenContext(
            isYouTubeForeground = isYt,
            videoTitle = detectedTitle,
            channelName = detectedChannel,
            playbackControlVisible = playbackState,
            isFullscreenLikely = fullscreenLikely,
            visibleControls = visibleControls.distinct().take(12),
            searchResults = searchResults.distinct().take(12),
            descriptionOrComments = descOrComments.distinct().take(10),
            rawSnapshot = describeScreenStructured()
        )
    }

    /** Finds a matching YouTube player/UI control by label/contentDescription, clicks it, and verifies state change. */
    fun performYouTubeControlAction(targetAction: String): ActionOutcome {
        val root = rootInActiveWindow ?: return ActionOutcome.Failed("Accessibility window unavailable.")
        if (!isYouTubeActive()) {
            return ActionOutcome.Failed("YouTube is not currently the active foreground app.")
        }
        val aliases = when (targetAction.lowercase()) {
            "play" -> listOf("Play video", "Play")
            "pause" -> listOf("Pause video", "Pause")
            "next video", "next" -> listOf("Next video", "Next")
            "previous video", "previous" -> listOf("Previous video", "Previous")
            "enter fullscreen", "fullscreen" -> listOf("Enter fullscreen", "Full screen")
            "exit fullscreen" -> listOf("Exit fullscreen", "Exit full screen")
            "minimize" -> listOf("Minimize", "Miniplayer")
            "close player", "close" -> listOf("Close", "Close player", "Dismiss")
            else -> listOf(targetAction)
        }

        for (alias in aliases) {
            val matches = findNodesByTextOrContentDesc(root, alias)
            for (node in matches) {
                var current: AccessibilityNodeInfo? = node
                while (current != null) {
                    if (current.isClickable) {
                        val before = describeScreenStructured()
                        val clicked = current.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                        if (clicked) {
                            _automationStatus.value = "YouTube action: $alias"
                            Thread.sleep(380L)
                            val changed = describeScreenStructured() != before
                            return ActionOutcome.Done(
                                if (changed) "Executed and verified '$alias' in YouTube."
                                else "Tapped '$alias' in YouTube."
                            )
                        }
                    }
                    current = current.parent
                }
            }
        }
        return ActionOutcome.Failed(
            "Control '$targetAction' was not found on the current YouTube screen. Tap the video briefly to reveal player controls and retry."
        )
    }

    /** Performs a +10s / -10s seek inside the active YouTube window using SeekBar forward/backward or double-tap zone. */
    fun seekYouTubeRelative(forward: Boolean, seconds: Int = 10): ActionOutcome {
        val root = rootInActiveWindow ?: return ActionOutcome.Failed("Accessibility window unavailable.")
        if (!isYouTubeActive()) {
            return ActionOutcome.Failed("YouTube is not currently open in the foreground.")
        }
        val seekNode = findFirstSeekBar(root)
        if (seekNode != null) {
            val action = if (forward) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
            if (seekNode.performAction(action)) {
                _automationStatus.value = if (forward) "Seeked forward in YouTube" else "Seeked backward in YouTube"
                return ActionOutcome.Done(
                    if (forward) "Seeked forward via YouTube player SeekBar."
                    else "Seeked backward via YouTube player SeekBar."
                )
            }
        }
        // Fallback: double-tap left/right player region when video player area is visible
        val metrics = resources.displayMetrics
        val x = if (forward) metrics.widthPixels * 0.80f else metrics.widthPixels * 0.20f
        val y = metrics.heightPixels * 0.22f
        val firstTap = performTap(x, y)
        if (!firstTap) return ActionOutcome.Failed("Gesture dispatch rejected by Android.")
        Thread.sleep(110L)
        val secondTap = performTap(x, y)
        return if (secondTap) {
            ActionOutcome.Done(
                if (forward) "Performed YouTube player right-side double-tap (+${seconds}s)."
                else "Performed YouTube player left-side double-tap (-${seconds}s)."
            )
        } else {
            ActionOutcome.Failed("Could not complete double-tap seek gesture on YouTube player.")
        }
    }

    private fun findNodesByTextOrContentDesc(node: AccessibilityNodeInfo?, query: String, depth: Int = 0): List<AccessibilityNodeInfo> {
        if (node == null || depth > 24 || node.isPassword) return emptyList()
        val out = mutableListOf<AccessibilityNodeInfo>()
        val t = node.text?.toString()?.trim().orEmpty()
        val d = node.contentDescription?.toString()?.trim().orEmpty()
        if (t.equals(query, ignoreCase = true) || d.equals(query, ignoreCase = true) ||
            t.contains(query, ignoreCase = true) || d.contains(query, ignoreCase = true)
        ) {
            out.add(node)
        }
        for (i in 0 until node.childCount) {
            out.addAll(findNodesByTextOrContentDesc(node.getChild(i), query, depth + 1))
        }
        return out
    }

    private fun findFirstSeekBar(node: AccessibilityNodeInfo?, depth: Int = 0): AccessibilityNodeInfo? {
        if (node == null || depth > 24) return null
        val cls = node.className?.toString().orEmpty()
        if (cls.contains("SeekBar", ignoreCase = true) && node.isVisibleToUser) return node
        for (i in 0 until node.childCount) {
            val found = findFirstSeekBar(node.getChild(i), depth + 1)
            if (found != null) return found
        }
        return null
    }

    companion object {
        const val YOUTUBE_PACKAGE = "com.google.android.youtube"
        const val YOUTUBE_MUSIC_PACKAGE = "com.google.android.apps.youtube.music"

        @Volatile
        var instance: YasminAccessibilityService? = null
            private set

        private val _isConnected = MutableStateFlow(false)
        val isConnected: StateFlow<Boolean> = _isConnected.asStateFlow()

        private val _automationStatus = MutableStateFlow("Accessibility Idle")
        val automationStatus: StateFlow<String> = _automationStatus.asStateFlow()
    }
}
