package com.yasmin.ai.accessibility

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class YasminAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        _isConnected.value = true
        _automationStatus.value = "Accessibility Service Connected"
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Deliberately passive: screen content is ONLY read on explicit user command.
    }

    override fun onInterrupt() {
        _automationStatus.value = "Accessibility Service Interrupted"
    }

    override fun onDestroy() {
        super.onDestroy()
        if (instance === this) {
            instance = null
        }
        _isConnected.value = false
        _automationStatus.value = "Accessibility Service Disconnected"
    }

    fun readVisibleScreenText(): String {
        val root = rootInActiveWindow ?: return ""
        val builder = StringBuilder()
        collectNodeText(root, builder, depth = 0)
        return builder.toString().trim()
    }

    private fun collectNodeText(node: AccessibilityNodeInfo?, out: StringBuilder, depth: Int) {
        if (node == null || depth > 24) return
        val text = node.text?.toString()?.trim()
        val desc = node.contentDescription?.toString()?.trim()
        if (!text.isNullOrEmpty()) {
            out.append(text).append('\n')
        } else if (!desc.isNullOrEmpty()) {
            out.append(desc).append('\n')
        }
        for (i in 0 until node.childCount) {
            collectNodeText(node.getChild(i), out, depth + 1)
        }
    }

    fun performScrollDown(): Boolean {
        val root = rootInActiveWindow
        if (root != null && findAndScroll(root, AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)) {
            _automationStatus.value = "Scrolled down"
            return true
        }
        val metrics = resources.displayMetrics
        val cx = metrics.widthPixels / 2f
        val startY = metrics.heightPixels * 0.72f
        val endY = metrics.heightPixels * 0.28f
        return performSwipe(cx, startY, cx, endY, 320L).also {
            if (it) _automationStatus.value = "Swiped down"
        }
    }

    fun performScrollUp(): Boolean {
        val root = rootInActiveWindow
        if (root != null && findAndScroll(root, AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD)) {
            _automationStatus.value = "Scrolled up"
            return true
        }
        val metrics = resources.displayMetrics
        val cx = metrics.widthPixels / 2f
        val startY = metrics.heightPixels * 0.28f
        val endY = metrics.heightPixels * 0.72f
        return performSwipe(cx, startY, cx, endY, 320L).also {
            if (it) _automationStatus.value = "Swiped up"
        }
    }

    private fun findAndScroll(node: AccessibilityNodeInfo?, action: Int): Boolean {
        if (node == null) return false
        if (node.isScrollable && node.performAction(action)) return true
        for (i in 0 until node.childCount) {
            if (findAndScroll(node.getChild(i), action)) return true
        }
        return false
    }

    fun clickNodeByText(targetText: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val matches = root.findAccessibilityNodeInfosByText(targetText)
        for (node in matches) {
            var current: AccessibilityNodeInfo? = node
            while (current != null) {
                if (current.isClickable && current.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                    _automationStatus.value = "Clicked '$targetText'"
                    return true
                }
                current = current.parent
            }
        }
        return false
    }

    fun performTap(x: Float, y: Float): Boolean {
        val path = Path().apply { moveTo(x, y) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0L, 60L))
            .build()
        _automationStatus.value = "Performed tap at (${x.toInt()}, ${y.toInt()})"
        return dispatchGesture(gesture, null, null)
    }

    fun performSwipe(
        startX: Float,
        startY: Float,
        endX: Float,
        endY: Float,
        durationMs: Long = 350L
    ): Boolean {
        val path = Path().apply {
            moveTo(startX, startY)
            lineTo(endX, endY)
        }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0L, durationMs))
            .build()
        return dispatchGesture(gesture, null, null)
    }

    fun performBackNavigation(): Boolean {
        _automationStatus.value = "Navigated Back"
        return performGlobalAction(GLOBAL_ACTION_BACK)
    }

    companion object {
        @Volatile
        var instance: YasminAccessibilityService? = null
            private set

        private val _isConnected = MutableStateFlow(false)
        val isConnected: StateFlow<Boolean> = _isConnected.asStateFlow()

        private val _automationStatus = MutableStateFlow("Accessibility Idle")
        val automationStatus: StateFlow<String> = _automationStatus.asStateFlow()
    }
}
