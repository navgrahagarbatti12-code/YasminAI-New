package com.yasmin.ai.ui.youtube

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.yasmin.ai.data.local.VideoNoteEntity
import com.yasmin.ai.databinding.ItemSavedNoteBinding
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class SavedNoteAdapter(
    private val onView: (VideoNoteEntity) -> Unit,
    private val onExportTxt: (VideoNoteEntity) -> Unit,
    private val onExportPdf: (VideoNoteEntity) -> Unit,
    private val onDelete: (VideoNoteEntity) -> Unit
) : ListAdapter<VideoNoteEntity, SavedNoteAdapter.NoteViewHolder>(Diff) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): NoteViewHolder {
        val binding = ItemSavedNoteBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return NoteViewHolder(binding)
    }

    override fun onBindViewHolder(holder: NoteViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class NoteViewHolder(private val binding: ItemSavedNoteBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(note: VideoNoteEntity) {
            val dateStr = SimpleDateFormat("dd MMM · HH:mm", Locale.US).format(Date(note.updatedAt))
            binding.tvNoteTitle.text = note.videoTitle.ifBlank { note.topic }
            binding.tvNoteMeta.text = "${note.channelTitle.ifBlank { "YouTube" }} · ${note.topic} · ${note.language.uppercase()} · $dateStr"
            binding.tvNotePreview.text = note.markdownContent.ifBlank { note.bulletPointsText }.take(180)
            binding.btnNoteView.setOnClickListener { onView(note) }
            binding.btnNoteTxt.setOnClickListener { onExportTxt(note) }
            binding.btnNotePdf.setOnClickListener { onExportPdf(note) }
            binding.btnNoteDelete.setOnClickListener { onDelete(note) }
        }
    }

    private object Diff : DiffUtil.ItemCallback<VideoNoteEntity>() {
        override fun areItemsTheSame(oldItem: VideoNoteEntity, newItem: VideoNoteEntity): Boolean =
            oldItem.id == newItem.id

        override fun areContentsTheSame(oldItem: VideoNoteEntity, newItem: VideoNoteEntity): Boolean =
            oldItem == newItem
    }
}
