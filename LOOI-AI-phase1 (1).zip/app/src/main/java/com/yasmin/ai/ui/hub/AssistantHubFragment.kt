package com.yasmin.ai.ui.hub

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.navigation.fragment.findNavController
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.yasmin.ai.R
import com.yasmin.ai.YasminApplication
import com.yasmin.ai.ai.AiResult
import com.yasmin.ai.assistant.CalendarHelper
import com.yasmin.ai.assistant.ReminderScheduler
import com.yasmin.ai.automation.DeviceControlManager
import com.yasmin.ai.data.local.MemoryEntity
import com.yasmin.ai.data.local.TaskEntity
import com.yasmin.ai.data.local.VoiceHistoryEntity
import com.yasmin.ai.databinding.FragmentAssistantHubBinding
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class AssistantHubFragment : Fragment() {

    private var _binding: FragmentAssistantHubBinding? = null
    private val binding get() = _binding!!

    private val taskTypes = listOf("todo", "reminder", "note")
    private val memoryCategories = listOf("preference", "instruction", "fact", "project", "person")
    private var allMemories: List<MemoryEntity> = emptyList()
    private var memorySearchQuery = ""

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentAssistantHubBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val repo = (requireActivity().application as YasminApplication).repository
        val deviceControl = DeviceControlManager(requireContext())
        val calendarHelper = CalendarHelper(requireContext())
        val reminderScheduler = ReminderScheduler(requireContext())

        binding.spinnerTaskType.adapter = ArrayAdapter(
            requireContext(),
            android.R.layout.simple_spinner_dropdown_item,
            listOf("To-Do", "Reminder", "Quick Note")
        )
        binding.spinnerMemoryCategory.adapter = ArrayAdapter(
            requireContext(),
            android.R.layout.simple_spinner_dropdown_item,
            memoryCategories.map { it.replaceFirstChar(Char::titlecase) }
        )

        refreshCalendarCard(calendarHelper)

        binding.btnCalendarAction.setOnClickListener {
            if (!calendarHelper.hasCalendarPermission()) {
                findNavController().navigate(R.id.permissionsFragment)
            } else {
                val input = EditText(requireContext()).apply { hint = "Event title (e.g. Project Review)" }
                MaterialAlertDialogBuilder(requireContext())
                    .setTitle("New Calendar Event")
                    .setView(input)
                    .setPositiveButton("Open Calendar") { _, _ ->
                        val title = input.text?.toString()?.trim().orEmpty().ifBlank { "Yasmin AI Event" }
                        val msg = calendarHelper.openAddCalendarEventIntent(title)
                        Toast.makeText(requireContext(), msg, Toast.LENGTH_SHORT).show()
                    }
                    .setNegativeButton("Cancel", null)
                    .show()
            }
        }

        binding.btnRunBriefing.setOnClickListener {
            binding.btnRunBriefing.isEnabled = false
            binding.tvBriefingOutput.text = "Compiling live daily briefing (weather, news, calendar, telemetry)…"
            viewLifecycleOwner.lifecycleScope.launch {
                val city = binding.etBriefingCity.text?.toString()?.trim().orEmpty()
                val timeAndTelemetry = "${deviceControl.getCurrentDateTimeText()} ${deviceControl.getTelemetrySummary()}"
                val calendarLines = if (calendarHelper.hasCalendarPermission()) {
                    calendarHelper.getUpcomingEvents(5).map { evt ->
                        val t = SimpleDateFormat("EEE hh:mm a", Locale.getDefault()).format(Date(evt.startMs))
                        "${evt.title} ($t)"
                    }
                } else emptyList()

                when (val res = repo.fetchDailyBriefing(city, calendarLines)) {
                    is AiResult.Success -> {
                        val sources = res.data.sources
                            ?.takeIf { it.isNotEmpty() }
                            ?.joinToString("\n") { "• ${it.title}: ${it.uri}" }
                            ?.let { "\n\nSources:\n$it" }
                            .orEmpty()
                        binding.tvBriefingOutput.text = "$timeAndTelemetry\n\n${res.data.reply.orEmpty()}$sources"
                    }
                    is AiResult.Error -> {
                        val calText = if (calendarLines.isNotEmpty()) "\n\nUpcoming Calendar:\n${calendarLines.joinToString("\n") { "• $it" }}" else ""
                        binding.tvBriefingOutput.text = "$timeAndTelemetry$calText\n\n(Online weather/news offline: ${res.message})"
                    }
                }
                binding.btnRunBriefing.isEnabled = true
            }
        }

        binding.btnAddTask.setOnClickListener {
            val title = binding.etTaskTitle.text?.toString()?.trim().orEmpty()
            if (title.isEmpty()) return@setOnClickListener
            val type = taskTypes.getOrElse(binding.spinnerTaskType.selectedItemPosition) { "todo" }
            val delayInput = binding.etTaskDelay.text?.toString()?.trim().orEmpty()
            val parsedDelay = if (delayInput.isNotBlank()) {
                ReminderScheduler.parseRelativeDelayMs(if (delayInput.startsWith("in ")) delayInput else "in $delayInput")
            } else {
                ReminderScheduler.parseRelativeDelayMs(title)
            }
            val triggerAt = if (parsedDelay != null) System.currentTimeMillis() + parsedDelay else 0L
            val dueLabel = if (triggerAt > 0L) ReminderScheduler.formatDueLabel(triggerAt) else delayInput

            binding.etTaskTitle.text?.clear()
            binding.etTaskDelay.text?.clear()
            viewLifecycleOwner.lifecycleScope.launch {
                val id = repo.addTask(
                    type = type,
                    title = title,
                    dueLabel = dueLabel,
                    reminderEpochMs = triggerAt
                )
                if (triggerAt > 0L) {
                    reminderScheduler.scheduleReminder(id, title, dueLabel, triggerAt)
                    Toast.makeText(requireContext(), "Alarm scheduled for $dueLabel", Toast.LENGTH_SHORT).show()
                }
            }
        }

        binding.btnSaveMemory.setOnClickListener {
            val cat = memoryCategories.getOrElse(binding.spinnerMemoryCategory.selectedItemPosition) { "preference" }
            val key = binding.etMemoryKey.text?.toString()?.trim().orEmpty()
            val content = binding.etMemoryContent.text?.toString()?.trim().orEmpty()
            if (key.isEmpty() || content.isEmpty()) {
                Toast.makeText(requireContext(), "Enter both label and memory detail.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            viewLifecycleOwner.lifecycleScope.launch {
                val res = repo.savePersonalMemory(cat, key, content, importance = 3, isUserApproved = true)
                if (res.isSuccess) {
                    binding.etMemoryKey.text?.clear()
                    binding.etMemoryContent.text?.clear()
                    Toast.makeText(requireContext(), "Memory saved securely.", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(
                        requireContext(),
                        res.exceptionOrNull()?.message ?: "Blocked by privacy guard.",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
        }

        binding.etMemorySearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                memorySearchQuery = s?.toString()?.trim().orEmpty()
                renderMemories(allMemories, repo)
            }
        })

        binding.btnClearMemories.setOnClickListener {
            MaterialAlertDialogBuilder(requireContext())
                .setTitle("Clear All Stored Memories?")
                .setMessage("Deletes all personal instructions and preferences saved in Yasmin AI.")
                .setPositiveButton("Delete All") { _, _ ->
                    viewLifecycleOwner.lifecycleScope.launch { repo.clearAllMemories() }
                }
                .setNegativeButton("Cancel", null)
                .show()
        }

        binding.btnClearVoiceHistory.setOnClickListener {
            viewLifecycleOwner.lifecycleScope.launch { repo.clearVoiceHistory() }
        }

        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch {
                    repo.tasksFlow.collect { tasks -> renderTasks(tasks, repo, reminderScheduler) }
                }
                launch {
                    repo.memoriesFlow.collect { memories ->
                        allMemories = memories
                        renderMemories(memories, repo)
                    }
                }
                launch {
                    repo.voiceHistoryFlow.collect { history -> renderVoiceHistory(history) }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        refreshCalendarCard(CalendarHelper(requireContext()))
    }

    private fun refreshCalendarCard(calendarHelper: CalendarHelper) {
        if (!calendarHelper.hasCalendarPermission()) {
            binding.btnCalendarAction.text = "Grant Access"
            binding.tvCalendarEvents.text = "Calendar permission not granted yet. Tap Grant Access to view upcoming events."
        } else {
            binding.btnCalendarAction.text = "Add Event"
            binding.tvCalendarEvents.text = calendarHelper.formatUpcomingEventsText(5)
        }
    }

    private fun renderTasks(
        tasks: List<TaskEntity>,
        repo: com.yasmin.ai.repository.YasminRepository,
        reminderScheduler: ReminderScheduler
    ) {
        binding.tasksContainer.removeAllViews()
        if (tasks.isEmpty()) {
            val empty = TextView(requireContext()).apply {
                text = "No tasks, notes, or reminders yet."
                setTextColor(ContextCompat.getColor(requireContext(), R.color.jarvis_text_secondary))
                textSize = 12f
            }
            binding.tasksContainer.addView(empty)
            return
        }
        tasks.forEach { task ->
            val row = LinearLayout(requireContext()).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(0, 6, 0, 6)
            }
            val dueSuffix = if (task.dueLabel.isNotBlank()) " · ${task.dueLabel}" else ""
            val cb = CheckBox(requireContext()).apply {
                text = "[${task.type.uppercase()}] ${task.title}$dueSuffix"
                isChecked = task.isCompleted
                setTextColor(ContextCompat.getColor(requireContext(), R.color.jarvis_text_primary))
                textSize = 12f
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                setOnCheckedChangeListener { buttonView, _ ->
                    if (buttonView.isPressed) {
                        viewLifecycleOwner.lifecycleScope.launch { repo.toggleTaskCompleted(task) }
                    }
                }
            }
            val delBtn = Button(requireContext()).apply {
                text = "Del"
                setTextColor(ContextCompat.getColor(requireContext(), R.color.jarvis_error))
                setBackgroundColor(android.graphics.Color.TRANSPARENT)
                setOnClickListener {
                    reminderScheduler.cancelReminder(task.id)
                    viewLifecycleOwner.lifecycleScope.launch { repo.deleteTask(task) }
                }
            }
            row.addView(cb)
            row.addView(delBtn)
            binding.tasksContainer.addView(row)
        }
    }

    private fun renderMemories(memories: List<MemoryEntity>, repo: com.yasmin.ai.repository.YasminRepository) {
        binding.memoriesContainer.removeAllViews()
        val filtered = if (memorySearchQuery.isBlank()) {
            memories
        } else {
            val q = memorySearchQuery.lowercase()
            memories.filter {
                it.keyTitle.lowercase().contains(q) ||
                    it.content.lowercase().contains(q) ||
                    it.category.lowercase().contains(q)
            }
        }

        if (filtered.isEmpty()) {
            val empty = TextView(requireContext()).apply {
                text = if (memories.isEmpty()) "No personal memories saved." else "No memories matched '$memorySearchQuery'."
                setTextColor(ContextCompat.getColor(requireContext(), R.color.jarvis_text_secondary))
                textSize = 12f
            }
            binding.memoriesContainer.addView(empty)
            return
        }

        filtered.forEach { mem ->
            val row = LinearLayout(requireContext()).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(0, 8, 0, 8)
            }
            val sourceTag = if (mem.isUserApproved) "Verified" else "Auto"
            val label = TextView(requireContext()).apply {
                text = "[${mem.category} · $sourceTag] ${mem.keyTitle}: ${mem.content}"
                setTextColor(ContextCompat.getColor(requireContext(), R.color.jarvis_text_primary))
                textSize = 12f
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                setOnClickListener { showEditMemoryDialog(mem, repo) }
            }
            val delBtn = Button(requireContext()).apply {
                text = "Delete"
                setTextColor(ContextCompat.getColor(requireContext(), R.color.jarvis_error))
                setBackgroundColor(android.graphics.Color.TRANSPARENT)
                setOnClickListener {
                    viewLifecycleOwner.lifecycleScope.launch { repo.deleteMemory(mem) }
                }
            }
            row.addView(label)
            row.addView(delBtn)
            binding.memoriesContainer.addView(row)
        }
    }

    private fun showEditMemoryDialog(mem: MemoryEntity, repo: com.yasmin.ai.repository.YasminRepository) {
        val layout = LinearLayout(requireContext()).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 24, 40, 8)
        }
        val titleInput = EditText(requireContext()).apply {
            setText(mem.keyTitle)
            hint = "Label"
        }
        val contentInput = EditText(requireContext()).apply {
            setText(mem.content)
            hint = "Detail"
        }
        layout.addView(titleInput)
        layout.addView(contentInput)

        MaterialAlertDialogBuilder(requireContext())
            .setTitle("Edit Memory (${mem.category})")
            .setView(layout)
            .setPositiveButton("Update") { _, _ ->
                val newTitle = titleInput.text?.toString()?.trim().orEmpty()
                val newContent = contentInput.text?.toString()?.trim().orEmpty()
                if (newTitle.isNotBlank() && newContent.isNotBlank()) {
                    viewLifecycleOwner.lifecycleScope.launch {
                        val res = repo.updateExistingMemory(mem, mem.category, newTitle, newContent)
                        Toast.makeText(
                            requireContext(),
                            if (res.isSuccess) "Memory updated." else res.exceptionOrNull()?.message ?: "Blocked by privacy guard.",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun renderVoiceHistory(items: List<VoiceHistoryEntity>) {
        binding.voiceHistoryContainer.removeAllViews()
        if (items.isEmpty()) {
            val empty = TextView(requireContext()).apply {
                text = "No voice commands logged yet."
                setTextColor(ContextCompat.getColor(requireContext(), R.color.jarvis_text_secondary))
                textSize = 12f
            }
            binding.voiceHistoryContainer.addView(empty)
            return
        }
        val fmt = SimpleDateFormat("dd MMM HH:mm", Locale.getDefault())
        items.take(15).forEach { entry ->
            val tv = TextView(requireContext()).apply {
                text = "• [${entry.source}] ${entry.transcript} (${fmt.format(Date(entry.timestamp))})"
                setTextColor(ContextCompat.getColor(requireContext(), R.color.jarvis_text_secondary))
                textSize = 11.5f
                setPadding(0, 4, 0, 4)
            }
            binding.voiceHistoryContainer.addView(tv)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
