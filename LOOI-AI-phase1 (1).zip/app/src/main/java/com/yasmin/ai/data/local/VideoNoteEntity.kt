package com.yasmin.ai.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "video_notes")
data class VideoNoteEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val videoId: String,
    val videoTitle: String,
    val channelTitle: String,
    val topic: String,
    val markdownContent: String,
    val definitionsText: String = "",
    val bulletPointsText: String = "",
    val stepsText: String = "",
    val timestampsText: String = "",
    val language: String = "en",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)
