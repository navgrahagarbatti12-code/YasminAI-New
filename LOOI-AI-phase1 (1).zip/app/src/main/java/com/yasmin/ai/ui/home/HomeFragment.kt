package com.yasmin.ai.ui.home

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.GridLayoutManager
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.yasmin.ai.MainActivity
import com.yasmin.ai.R
import com.yasmin.ai.accessibility.YasminAccessibilityService
import com.yasmin.ai.databinding.FragmentHomeBinding
import com.yasmin.ai.voice.AssistantVoiceState
import com.yasmin.ai.voice.OfflineWakeWordDetector
import com.yasmin.ai.voice.WakeEngineState
import com.yasmin.ai.voice.WakeWordEngine
import com.yasmin.ai.voice.WakeWordForegroundService
import kotlinx.coroutines.launch

class HomeFragment : Fragment() {

    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!
    private val sharedViewModel: YasminSharedViewModel by activityViewModels()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupQuickCommands()
        setupListeners()
        observeState()
        refreshTelemetry()
        sharedViewModel.refreshConnectionHealth()
    }

    override fun onResume() {
        super.onResume()
        refreshTelemetry()
    }

    private fun refreshTelemetry() {
        binding.tvDeviceTelemetry.text = sharedViewModel.deviceControl.getTelemetrySummary()
    }

    private fun setupQuickCommands() {
        val quickCommands = listOf(
            "Open Chrome",
            "Read calendar",
            "Remind me in 15 minutes to drink water",
            "Play music",
            "Read my screen",
            "Read notifications",
            "Write Python code",
            "Create HTML website"
        )
        binding.rvQuickCommands.layoutManager = GridLayoutManager(requireContext(), 2)
        binding.rvQuickCommands.adapter = QuickCommandAdapter(quickCommands) { cmd ->
            sharedViewModel.handleUserInput(cmd)
        }
    }

    private fun setupListeners() {
        binding.btnMicToggle.setOnClickListener {
            val hasMic = ContextCompat.checkSelfPermission(
                requireContext(),
                Manifest.permission.RECORD_AUDIO
            ) == PackageManager.PERMISSION_GRANTED

            if (!hasMic) {
                (activity as? MainActivity)?.requestAudioPermission()
                return@setOnClickListener
            }

            if (sharedViewModel.voiceState.value == AssistantVoiceState.LISTENING) {
                sharedViewModel.voiceManager.stopListening()
            } else {
                sharedViewModel.startVoiceCapture("mic") {
                    (activity as? MainActivity)?.requestAudioPermission()
                }
            }
        }

        binding.btnStopSpeaking.setOnClickListener {
            sharedViewModel.stopSpeaking()
            sharedViewModel.voiceManager.stopListening()
        }
        binding.btnOpenTextChat.setOnClickListener { findNavController().navigate(R.id.chatFragment) }
        binding.tvViewAllChats.setOnClickListener { findNavController().navigate(R.id.chatFragment) }
        binding.btnHomeSettings.setOnClickListener { findNavController().navigate(R.id.settingsFragment) }
        binding.btnOpenVisionHub.setOnClickListener { findNavController().navigate(R.id.visionFragment) }

        binding.btnFlashlight.setOnClickListener {
            val msg = sharedViewModel.deviceControl.toggleFlashlight()
            Toast.makeText(requireContext(), msg, Toast.LENGTH_SHORT).show()
        }

        binding.btnReadScreen.setOnClickListener {
            if (YasminAccessibilityService.instance == null) {
                MaterialAlertDialogBuilder(requireContext())
                    .setTitle("Accessibility Permission Needed")
                    .setMessage("Enable Yasmin AI Accessibility Service so it can read on-screen text when you request it.")
                    .setPositiveButton("Open Setup") { _, _ ->
                        findNavController().navigate(R.id.permissionsFragment)
                    }
                    .setNegativeButton("Cancel", null)
                    .show()
            } else {
                sharedViewModel.handleUserInput("Read my screen")
            }
        }

        binding.btnCaptureExplain.setOnClickListener {
            MaterialAlertDialogBuilder(requireContext())
                .setTitle("Share Screen Snapshot with Gemini?")
                .setMessage("Android will ask your permission to capture one frame of your screen and send it to Gemini Vision. Capture stops immediately after one frame.")
                .setPositiveButton("Continue") { _, _ ->
                    (activity as? MainActivity)?.requestScreenCapture()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }

        binding.switchWakeSession.setOnCheckedChangeListener { buttonView, isChecked ->
            if (!buttonView.isPressed) return@setOnCheckedChangeListener
            if (isChecked) {
                val hasMic = ContextCompat.checkSelfPermission(
                    requireContext(),
                    Manifest.permission.RECORD_AUDIO
                ) == PackageManager.PERMISSION_GRANTED
                if (!hasMic) {
                    buttonView.isChecked = false
                    (activity as? MainActivity)?.requestAudioPermission()
                    return@setOnCheckedChangeListener
                }
                WakeWordForegroundService.start(requireContext())
            } else {
                WakeWordForegroundService.stop(requireContext())
            }
            sharedViewModel.setWakeSessionEnabled(isChecked)
        }

        binding.switchContinuousVoice.setOnCheckedChangeListener { buttonView, isChecked ->
            if (buttonView.isPressed) {
                sharedViewModel.setContinuousConversation(isChecked)
            }
        }

        binding.btnQuickSend.setOnClickListener { sendTypedCommand() }
        binding.etQuickInput.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEND) {
                sendTypedCommand()
                true
            } else {
                false
            }
        }
    }

    private fun sendTypedCommand() {
        val text = binding.etQuickInput.text?.toString()?.trim().orEmpty()
        if (text.isNotEmpty()) {
            binding.etQuickInput.text?.clear()
            sharedViewModel.handleUserInput(text)
        }
    }

    private fun observeState() {
        val enrolledCount = OfflineWakeWordDetector(WakeWordEngine.templateFile(requireContext()))
            .getEnrolledTemplateCount()

        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch {
                    sharedViewModel.voiceState.collect { state ->
                        binding.jarvisVisualizer.setAssistantState(state)
                        binding.tvVoiceState.text = when (state) {
                            AssistantVoiceState.IDLE -> getString(R.string.status_idle)
                            AssistantVoiceState.LISTENING -> getString(R.string.status_listening)
                            AssistantVoiceState.THINKING -> getString(R.string.status_thinking)
                            AssistantVoiceState.SPEAKING -> getString(R.string.status_speaking)
                        }
                    }
                }
                launch {
                    sharedViewModel.rmsLevel.collect { rms ->
                        binding.jarvisVisualizer.setAudioLevel(rms)
                    }
                }
                launch {
                    sharedViewModel.transcriptText.collect { text ->
                        binding.tvTranscript.text = text
                    }
                }
                launch {
                    sharedViewModel.aiConnectionStatus.collect { status ->
                        binding.tvAiConnectionStatus.text = status
                    }
                }
                launch {
                    sharedViewModel.isOnlineAiAvailable.collect { online ->
                        val colorRes = if (online) R.color.jarvis_cyan else R.color.jarvis_warning
                        binding.tvAiConnectionStatus.setTextColor(ContextCompat.getColor(requireContext(), colorRes))
                    }
                }
                launch {
                    WakeWordForegroundService.wakeStatus.collect { engineState ->
                        val modeLabel = if (enrolledCount > 0) "MFCC+DTW ($enrolledCount voiceprints)" else "Offline VAD+Cadence"
                        binding.tvWakeEngineStatus.text = when (engineState) {
                            WakeEngineState.STOPPED -> "Stopped · $modeLabel"
                            WakeEngineState.CALIBRATING -> "Calibrating ambient room noise…"
                            WakeEngineState.MONITORING_VAD -> "Active · $modeLabel listening for \"Hey Yasmin\""
                            WakeEngineState.VERIFYING_WAKE_PHRASE -> "Scoring offline speech burst…"
                            WakeEngineState.COOLDOWN -> "Cooldown · Resuming offline wake monitoring…"
                        }
                    }
                }
                launch {
                    sharedViewModel.messages.collect { list ->
                        val preview = list.takeLast(3).joinToString("\n") { msg ->
                            val prefix = if (msg.role == "user") "You" else "Yasmin"
                            "$prefix: ${msg.content.replace('\n', ' ').take(90)}"
                        }
                        binding.tvRecentConversations.text =
                            preview.ifBlank { "No conversations recorded yet." }
                    }
                }
                launch {
                    sharedViewModel.preferences.collect { prefs ->
                        binding.tvLanguageIndicator.text = prefs.languageMode.uppercase()
                        if (binding.switchWakeSession.isChecked != prefs.wakeSessionEnabled) {
                            binding.switchWakeSession.isChecked = prefs.wakeSessionEnabled
                        }
                        if (binding.switchContinuousVoice.isChecked != prefs.continuousConversation) {
                            binding.switchContinuousVoice.isChecked = prefs.continuousConversation
                        }
                    }
                }
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
