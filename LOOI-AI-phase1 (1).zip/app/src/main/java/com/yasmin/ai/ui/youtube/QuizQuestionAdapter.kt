package com.yasmin.ai.ui.youtube

import android.content.res.ColorStateList
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.RadioButton
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.yasmin.ai.R
import com.yasmin.ai.databinding.ItemQuizQuestionBinding
import com.yasmin.ai.youtube.QuizEvaluation
import com.yasmin.ai.youtube.QuizQuestion

class QuizQuestionAdapter(
    private val onSelectOption: (questionIndex: Int, optionIndex: Int) -> Unit
) : RecyclerView.Adapter<QuizQuestionAdapter.QuizViewHolder>() {

    private var questions: List<QuizQuestion> = emptyList()
    private var selectedMap: Map<Int, Int> = emptyMap()
    private var evaluation: QuizEvaluation? = null

    fun submitQuiz(
        items: List<QuizQuestion>,
        selected: Map<Int, Int>,
        eval: QuizEvaluation?
    ) {
        questions = items
        selectedMap = selected
        evaluation = eval
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): QuizViewHolder {
        val binding = ItemQuizQuestionBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return QuizViewHolder(binding)
    }

    override fun onBindViewHolder(holder: QuizViewHolder, position: Int) {
        holder.bind(questions[position])
    }

    override fun getItemCount(): Int = questions.size

    inner class QuizViewHolder(private val binding: ItemQuizQuestionBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(q: QuizQuestion) {
            val ctx = binding.root.context
            binding.tvQuizQuestion.text = "Q${q.index}. ${q.question}"
            binding.rgQuizOptions.setOnCheckedChangeListener(null)
            binding.rgQuizOptions.removeAllViews()

            val chosenIdx = selectedMap[q.index] ?: -1
            val cyan = ContextCompat.getColor(ctx, R.color.jarvis_cyan)
            val textPrimary = ContextCompat.getColor(ctx, R.color.jarvis_text_primary)

            q.options.forEachIndexed { idx, optText ->
                val rb = RadioButton(ctx).apply {
                    id = View.generateViewId()
                    text = optText
                    setTextColor(textPrimary)
                    textSize = 12f
                    buttonTintList = ColorStateList.valueOf(cyan)
                    isChecked = idx == chosenIdx
                    setOnClickListener {
                        onSelectOption(q.index, idx)
                    }
                }
                binding.rgQuizOptions.addView(rb)
            }

            val fb = evaluation?.feedback?.firstOrNull { it.index == q.index }
            if (fb != null) {
                binding.tvQuizFeedback.visibility = View.VISIBLE
                binding.tvQuizFeedback.text = fb.explanation
                val color = ContextCompat.getColor(
                    ctx,
                    if (fb.isCorrect) R.color.jarvis_success else R.color.jarvis_warning
                )
                binding.tvQuizFeedback.setTextColor(color)
            } else {
                binding.tvQuizFeedback.visibility = View.GONE
            }
        }
    }
}
