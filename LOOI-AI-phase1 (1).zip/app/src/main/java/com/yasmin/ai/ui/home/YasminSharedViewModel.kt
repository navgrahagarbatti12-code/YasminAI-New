package com.yasmin.ai.ui.home

import android.app.Application
import android.media.AudioManager
import android.provider.Settings
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.yasmin.ai.YasminApplication
import com.yasmin.ai.accessibility.YasminAccessibilityService
import com.yasmin.ai.ai.AiResult
import com.yasmin.ai.ai.GeminiBackendClient
import com.yasmin.ai.ai.GeminiChatRequest
import com.yasmin.ai.ai.PlannedAction
import com.yasmin.ai.assistant.CalendarHelper
import com.yasmin.ai.assistant.ReminderScheduler
import com.yasmin.ai.automation.CommandActionResult
import com.yasmin.ai.automation.CommandRouter
import com.yasmin.ai.automation.DeviceControlManager
import com.yasmin.ai.automation.OfflineAssistantEngine
import com.yasmin.ai.automation.YasminNotificationListenerService
import com.yasmin.ai.data.local.ChatMessageEntity
import com.yasmin.ai.data.preferences.YasminUserPreferences
import com.yasmin.ai.voice.AssistantVoiceState
import com.yasmin.ai.voice.VoiceAssistantManager
import com.yasmin.ai.voice.WakeWordForegroundService
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed class NavigationEvent {
    data class OpenPython(val prompt: String) : NavigationEvent()
    data class OpenHtml(val prompt: String) : NavigationEvent()
    data class OpenCodingAgent(val prompt: String) : NavigationEvent()
    data object OpenVision : NavigationEvent()
    data object OpenDailyHub : NavigationEvent()
    data object OpenYouTubeAgent : NavigationEvent()
    data object OpenPermissions : NavigationEvent()
    data class ConfirmAutomation(
        val title: String,
        val description: String,
        val onConfirmed: () -> String
    ) : NavigationEvent()
}

class YasminSharedViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = (application as YasminApplication).repository
    val deviceControl = DeviceControlManager(application)
    val calendarHelper = CalendarHelper(application)
    val reminderScheduler = ReminderScheduler(application)
    val youTubeVoiceController = com.yasmin.ai.youtube.YouTubeVoiceController(application, deviceControl)
    private val commandRouter = CommandRouter(deviceControl, calendarHelper, youTubeVoiceController)
    private val offlineEngine = OfflineAssistantEngine(
        context = application,
        repository = repository,
        deviceControl = deviceControl,
        calendarHelper = calendarHelper,
        reminderScheduler = reminderScheduler
    )
    val voiceManager = VoiceAssistantManager(application)

    val preferences: StateFlow<YasminUserPreferences> = repository.preferencesFlow.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        YasminUserPreferences()
    )

    val messages: StateFlow<List<ChatMessageEntity>> = repository.messagesFlow.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        emptyList()
    )

    private val _transcriptText = MutableStateFlow("Tap microphone or say \"Hey Yasmin\" when wake engine is enabled")
    val transcriptText: StateFlow<String> = _transcriptText.asStateFlow()

    private val _aiConnectionStatus = MutableStateFlow("AI CORE: Checking…")
    val aiConnectionStatus: StateFlow<String> = _aiConnectionStatus.asStateFlow()

    private val _isOnlineAiAvailable = MutableStateFlow(false)
    val isOnlineAiAvailable: StateFlow<Boolean> = _isOnlineAiAvailable.asStateFlow()

    private val _isBusy = MutableStateFlow(false)
    val isBusy: StateFlow<Boolean> = _isBusy.asStateFlow()

    private val _navigationEvents = MutableSharedFlow<NavigationEvent>()
    val navigationEvents: SharedFlow<NavigationEvent> = _navigationEvents.asSharedFlow()

    private val _pendingCodingPrompt = MutableStateFlow("")
    val pendingCodingPrompt: StateFlow<String> = _pendingCodingPrompt.asStateFlow()

    private val _pendingYouTubeAction = MutableStateFlow("")
    val pendingYouTubeAction: StateFlow<String> = _pendingYouTubeAction.asStateFlow()

    val voiceState: StateFlow<AssistantVoiceState> = voiceManager.voiceState
    val rmsLevel: StateFlow<Float> = voiceManager.rmsLevel

    private var onPermissionNeededForContinuous: (() -> Unit)? = null

    init {
        viewModelScope.launch {
            preferences.collect { prefs ->
                voiceManager.applyVoiceSettings(
                    languageMode = prefs.languageMode,
                    speechRate = prefs.speechRate,
                    speechPitch = prefs.speechPitch,
                    timeoutSec = prefs.conversationTimeoutSec,
                    voiceName = prefs.ttsVoiceName,
                    bargeIn = prefs.bargeInEnabled
                )
            }
        }
        viewModelScope.launch {
            voiceManager.partialTranscript.collect { partial ->
                if (partial.isNotBlank()) {
                    _transcriptText.value = partial
                }
            }
        }
        viewModelScope.launch {
            voiceState.collect { state ->
                when (state) {
                    AssistantVoiceState.LISTENING -> {
                        WakeWordForegroundService.pauseEngine(getApplication())
                    }
                    AssistantVoiceState.IDLE -> {
                        if (preferences.value.wakeSessionEnabled && WakeWordForegroundService.isRunning.value) {
                            WakeWordForegroundService.resumeEngine(getApplication())
                        }
                    }
                    else -> Unit
                }
            }
        }
        voiceManager.setOnSpeechCompletedListener {
            if (preferences.value.continuousConversation && !_isBusy.value) {
                onPermissionNeededForContinuous?.let { permCb ->
                    startVoiceCapture(source = "continuous", onPermissionRequired = permCb)
                }
            }
        }
        voiceManager.setOnBargeInDetectedListener {
            onPermissionNeededForContinuous?.let { permCb ->
                startVoiceCapture(source = "barge_in", onPermissionRequired = permCb)
            }
        }
        refreshConnectionHealth()
    }

    fun refreshConnectionHealth() {
        viewModelScope.launch {
            val prefs = repository.getPreferencesSnapshot()
            if (!offlineEngine.hasNetworkConnection()) {
                _isOnlineAiAvailable.value = false
                _aiConnectionStatus.value = "OFFLINE MODE: Local Engine Active"
                return@launch
            }
            if (!repository.hasAnyAiConfigured(prefs)) {
                _isOnlineAiAvailable.value = false
                _aiConnectionStatus.value = "OFFLINE MODE: Add Gemini or Groq API Key in Settings"
                return@launch
            }
            _aiConnectionStatus.value = "AI CORE: Connecting…"
            val label = GeminiBackendClient.providerDisplayLabel(prefs.providerType)
            when (val res = repository.aiProvider.checkHealth()) {
                is AiResult.Success -> {
                    _isOnlineAiAvailable.value = true
                    _aiConnectionStatus.value = "AI CORE ($label): Connected"
                }
                is AiResult.Error -> {
                    // Check if fallback provider is ready
                    val fallbackReady = prefs.autoFallbackEnabled &&
                        ((prefs.providerType != GeminiBackendClient.PROVIDER_GROQ && repository.hasGroqApiKey()) ||
                            (prefs.providerType != GeminiBackendClient.PROVIDER_GEMINI_DIRECT && repository.hasGeminiApiKey()))
                    if (fallbackReady) {
                        _isOnlineAiAvailable.value = true
                        _aiConnectionStatus.value = "AI CORE ($label Issue · Fallback Ready)"
                    } else {
                        _isOnlineAiAvailable.value = false
                        _aiConnectionStatus.value = "OFFLINE FALLBACK: ${res.message}"
                    }
                }
            }
        }
    }

    fun consumePendingCodingPrompt(): String {
        val current = _pendingCodingPrompt.value
        _pendingCodingPrompt.value = ""
        return current
    }

    fun consumePendingYouTubeAction(): String {
        val current = _pendingYouTubeAction.value
        _pendingYouTubeAction.value = ""
        return current
    }

    fun startVoiceCapture(source: String = "mic", onPermissionRequired: () -> Unit) {
        onPermissionNeededForContinuous = onPermissionRequired
        WakeWordForegroundService.pauseEngine(getApplication())
        val lang = preferences.value.languageMode
        voiceManager.startListening(
            languageMode = lang,
            onResult = { spokenText ->
                _transcriptText.value = spokenText
                viewModelScope.launch { repository.recordVoiceCommand(spokenText, source) }
                handleUserInput(spokenText)
            },
            onError = { errorMsg ->
                _transcriptText.value = errorMsg
                if (errorMsg.contains("Microphone permission")) {
                    onPermissionRequired()
                }
            }
        )
    }

    fun stopSpeaking() {
        voiceManager.stopSpeaking()
    }

    fun handleUserInput(input: String) {
        val trimmed = input.trim()
        if (trimmed.isEmpty()) return

        viewModelScope.launch {
            _isBusy.value = true
            voiceManager.setThinkingState()

            when (val routed = commandRouter.routeLocalFirst(trimmed)) {
                is CommandActionResult.StopVoiceSession -> {
                    voiceManager.stopListening()
                    voiceManager.stopSpeaking()
                    setContinuousConversation(false)
                    val msg = "Listening stopped. Tap the mic anytime or say Hey Yasmin when wake mode is active."
                    repository.saveUserMessage(trimmed, preferences.value.languageMode)
                    repository.saveAssistantMessage(msg, preferences.value.languageMode)
                    _transcriptText.value = msg
                    voiceManager.setIdleState()
                }

                is CommandActionResult.CreateReminder -> {
                    val triggerAt = System.currentTimeMillis() + routed.delayMs
                    val dueLabel = ReminderScheduler.formatDueLabel(triggerAt)
                    val taskId = repository.addTask(
                        type = "reminder",
                        title = routed.title,
                        dueLabel = dueLabel,
                        reminderEpochMs = triggerAt
                    )
                    reminderScheduler.scheduleReminder(taskId, routed.title, dueLabel, triggerAt)
                    val msg = "Reminder scheduled for $dueLabel: \"${routed.title}\""
                    repository.saveUserMessage(trimmed, preferences.value.languageMode)
                    repository.saveAssistantMessage(msg, preferences.value.languageMode)
                    presentAssistantReply(msg)
                }

                is CommandActionResult.Handled -> {
                    repository.saveUserMessage(trimmed, preferences.value.languageMode)
                    repository.saveAssistantMessage(routed.responseText, preferences.value.languageMode)
                    presentAssistantReply(routed.responseText)
                }

                is CommandActionResult.ReadScreenWithAi -> {
                    if (!offlineEngine.hasNetworkConnection()) {
                        presentAssistantReply("[Offline Screen Reader]\n${routed.screenText}")
                    } else {
                        when (val aiResult = repository.explainScreenText(routed.screenText)) {
                            is AiResult.Success -> presentAssistantReply(aiResult.data)
                            is AiResult.Error -> presentAssistantReply(aiResult.message)
                        }
                    }
                }

                is CommandActionResult.OpenPythonWorkspace -> {
                    _pendingCodingPrompt.value = routed.prompt
                    _navigationEvents.emit(NavigationEvent.OpenPython(routed.prompt))
                    presentAssistantReply("Opening Python workspace for your request.")
                }

                is CommandActionResult.OpenHtmlWorkspace -> {
                    _pendingCodingPrompt.value = routed.prompt
                    _navigationEvents.emit(NavigationEvent.OpenHtml(routed.prompt))
                    presentAssistantReply("Opening Web IDE workspace for your project.")
                }

                is CommandActionResult.OpenCodingAgent -> {
                    _pendingCodingPrompt.value = routed.prompt
                    _navigationEvents.emit(NavigationEvent.OpenCodingAgent(routed.prompt))
                    presentAssistantReply("Opening Yasmin AI Multi-Language Coding Agent.")
                }

                is CommandActionResult.OpenVisionWorkspace -> {
                    _navigationEvents.emit(NavigationEvent.OpenVision)
                    presentAssistantReply("Opening Yasmin AI Vision.")
                }

                is CommandActionResult.OpenDailyHub -> {
                    _navigationEvents.emit(NavigationEvent.OpenDailyHub)
                    presentAssistantReply("Opening Daily Assistant & Smart Memory.")
                }

                is CommandActionResult.OpenYouTubeAgent -> {
                    _pendingYouTubeAction.value = routed.autoMode.ifBlank { routed.initialQuery }
                    _navigationEvents.emit(NavigationEvent.OpenYouTubeAgent)
                    presentAssistantReply("Opening Yasmin YouTube AI Agent.")
                }

                is CommandActionResult.RequestPermissionsSetup -> {
                    val msg = "Please enable the required Accessibility or Notification permission in Permission Setup."
                    presentAssistantReply(msg)
                    _navigationEvents.emit(NavigationEvent.OpenPermissions)
                }

                is CommandActionResult.RequiresConfirmation -> {
                    voiceManager.setIdleState()
                    _navigationEvents.emit(
                        NavigationEvent.ConfirmAutomation(
                            title = routed.actionTitle,
                            description = routed.description,
                            onConfirmed = routed.onConfirmed
                        )
                    )
                }

                is CommandActionResult.UseAiPlanner -> {
                    handleWithAiPlanner(trimmed)
                }
            }
            _isBusy.value = false
        }
    }

    private suspend fun handleWithAiPlanner(userText: String) {
        val prefs = repository.getPreferencesSnapshot()
        repository.saveUserMessage(userText, prefs.languageMode)
        repository.tryAutoExtractMemory(userText)

        val hasProviderConfigured = repository.hasAnyAiConfigured(prefs)
        if (!offlineEngine.hasNetworkConnection() || !hasProviderConfigured) {
            _isOnlineAiAvailable.value = false
            _aiConnectionStatus.value = if (!offlineEngine.hasNetworkConnection()) {
                "OFFLINE MODE: Local Engine Active"
            } else {
                "OFFLINE MODE: Add Gemini or Groq API Key in Settings"
            }
            val offlineReply = offlineEngine.handleOfflineQuery(userText)
            repository.saveAssistantMessage(offlineReply, prefs.languageMode)
            presentAssistantReply(offlineReply)
            return
        }

        when (val planRes = repository.planNaturalIntent(userText)) {
            is AiResult.Success -> {
                _isOnlineAiAvailable.value = true
                val actions = planRes.data.actions
                if (actions.isEmpty()) {
                    val historyTurns = repository.getRecentHistoryTurns(10)
                    val relevantMemories = repository.getSemanticMemoriesForQuery(userText, limit = 8)
                    val assembled = StringBuilder()
                    var streamedMsgId: Long? = null
                    var streamFailed = false

                    repository.streamChatReply(userText, historyTurns, relevantMemories)
                        .catch { streamFailed = true }
                        .collect { delta ->
                            assembled.append(delta)
                            val partialText = assembled.toString()
                            _transcriptText.value = partialText
                            streamedMsgId = repository.updateOrInsertAssistantMessage(
                                streamedMsgId,
                                partialText,
                                prefs.languageMode
                            )
                        }

                    val streamedText = assembled.toString().trim()
                    if (!streamFailed && streamedText.isNotBlank()) {
                        presentAssistantReply(streamedText)
                        return
                    }

                    when (
                        val chatRes = repository.aiProvider.chat(
                            GeminiChatRequest(
                                message = userText,
                                language = prefs.languageMode,
                                personality = prefs.aiPersonality,
                                history = historyTurns,
                                memories = relevantMemories,
                                userName = prefs.userName,
                                enableWebSearch = true
                            )
                        )
                    ) {
                        is AiResult.Success -> {
                            val reply = chatRes.data.reply?.takeIf { it.isNotBlank() } ?: planRes.data.reply
                            val sourcesSuffix = chatRes.data.sources
                                ?.takeIf { it.isNotEmpty() }
                                ?.joinToString("\n") { "• ${it.title}: ${it.uri}" }
                                ?.let { "\n\nSources:\n$it" }
                                .orEmpty()
                            val full = reply + sourcesSuffix
                            repository.updateOrInsertAssistantMessage(streamedMsgId, full, prefs.languageMode)
                            presentAssistantReply(full)
                        }
                        is AiResult.Error -> {
                            val fallback = planRes.data.reply.ifBlank { chatRes.message }
                            repository.updateOrInsertAssistantMessage(streamedMsgId, fallback, prefs.languageMode)
                            presentAssistantReply(fallback)
                        }
                    }
                } else {
                    val toolNotes = mutableListOf<String>()
                    for (action in actions) {
                        val note = executePlannedAction(action)
                        if (note.isNotBlank()) toolNotes.add(note)
                    }
                    val combined = buildString {
                        if (planRes.data.reply.isNotBlank()) append(planRes.data.reply)
                        if (toolNotes.isNotEmpty()) {
                            if (isNotEmpty()) append("\n\n")
                            append(toolNotes.joinToString("\n"))
                        }
                    }.ifBlank { "Action completed." }
                    repository.saveAssistantMessage(combined, prefs.languageMode)
                    presentAssistantReply(combined)
                }
            }
            is AiResult.Error -> {
                _isOnlineAiAvailable.value = false
                val offlineReply = offlineEngine.handleOfflineQuery(userText)
                val fullReply = "Cloud AI unavailable (${planRes.message}).\n\n$offlineReply"
                repository.saveAssistantMessage(fullReply, prefs.languageMode)
                presentAssistantReply(fullReply)
            }
        }
    }

    private suspend fun executePlannedAction(action: PlannedAction): String {
        return when (action.tool) {
            "open_app" -> deviceControl.openAppByName(action.arg1)
            "open_chrome" -> deviceControl.openChrome(action.arg1)
            "open_calculator" -> deviceControl.openCalculator()
            "open_url" -> deviceControl.openUrl(action.arg1)
            "web_search" -> deviceControl.searchWeb(action.arg1)
            "youtube_search" -> deviceControl.searchYouTube(action.arg1)
            "show_notification" -> deviceControl.showLocalNotification(action.arg1, action.arg2)
            "toggle_flashlight" -> {
                val state = when (action.arg1.lowercase()) {
                    "on" -> true
                    "off" -> false
                    else -> null
                }
                deviceControl.toggleFlashlight(state)
            }
            "adjust_volume" -> deviceControl.adjustVolume(
                if (action.arg1 == "down") AudioManager.ADJUST_LOWER else AudioManager.ADJUST_RAISE
            )
            "set_alarm" -> deviceControl.setAlarm(
                action.arg1.toIntOrNull() ?: 7,
                action.arg2.toIntOrNull() ?: 0,
                action.arg3
            )
            "set_timer" -> deviceControl.setTimer(action.arg1.toIntOrNull() ?: 60, action.arg2)
            "create_task" -> {
                val type = action.arg1.ifBlank { "todo" }
                val title = action.arg2.ifBlank { "Task" }
                val due = action.arg3
                val delayMs = ReminderScheduler.parseRelativeDelayMs(due) ?: ReminderScheduler.parseRelativeDelayMs(title)
                val triggerAt = if (delayMs != null) System.currentTimeMillis() + delayMs else 0L
                val id = repository.addTask(
                    type = type,
                    title = title,
                    dueLabel = due.ifBlank { ReminderScheduler.formatDueLabel(triggerAt) },
                    reminderEpochMs = triggerAt
                )
                if (triggerAt > 0L) {
                    reminderScheduler.scheduleReminder(id, title, due, triggerAt)
                }
                "Saved $type: $title"
            }
            "create_calendar_event" -> calendarHelper.openAddCalendarEventIntent(action.arg1.ifBlank { "Yasmin AI Event" })
            "save_memory" -> {
                val saved = repository.savePersonalMemory(
                    category = action.arg1.ifBlank { "fact" },
                    keyTitle = action.arg2.ifBlank { "Note" },
                    content = action.arg3,
                    importance = 3,
                    isUserApproved = true
                )
                if (saved.isSuccess) "Remembered: ${action.arg2}" else "Skipped memory for privacy safety."
            }
            "prepare_call" -> {
                val matches = deviceControl.findContacts(action.arg1)
                val phone = matches.firstOrNull()?.phoneNumber ?: action.arg1
                _navigationEvents.emit(
                    NavigationEvent.ConfirmAutomation(
                        title = "Confirm Phone Call",
                        description = "Open phone dialer for ${matches.firstOrNull()?.displayName ?: phone} ($phone)?"
                    ) { deviceControl.openDialer(phone) }
                )
                "Waiting for your confirmation to dial $phone."
            }
            "prepare_sms" -> {
                val matches = deviceControl.findContacts(action.arg1)
                val phone = matches.firstOrNull()?.phoneNumber ?: action.arg1
                _navigationEvents.emit(
                    NavigationEvent.ConfirmAutomation(
                        title = "Confirm SMS Draft",
                        description = "Prepare SMS to ${matches.firstOrNull()?.displayName ?: phone}:\n\"${action.arg2}\""
                    ) { deviceControl.prepareSms(phone, action.arg2) }
                )
                "Waiting for your confirmation to prepare SMS draft."
            }
            "prepare_whatsapp" -> {
                val matches = deviceControl.findContacts(action.arg1)
                val phone = matches.firstOrNull()?.phoneNumber.orEmpty()
                _navigationEvents.emit(
                    NavigationEvent.ConfirmAutomation(
                        title = "Confirm WhatsApp Draft",
                        description = "Prepare WhatsApp message for ${action.arg1}:\n\"${action.arg2}\""
                    ) { deviceControl.prepareWhatsAppMessage(phone, action.arg2) }
                )
                "Waiting for your confirmation to prepare WhatsApp draft."
            }
            "read_notifications" -> {
                val listener = YasminNotificationListenerService.instance
                    ?: return "Enable Notification Access in Permissions to read notifications."
                val items = listener.getRecentNotificationSummaries()
                if (items.isEmpty()) "No active notifications." else items.joinToString("\n") { "• ${it.title}: ${it.text}" }
            }
            "read_calendar" -> calendarHelper.formatUpcomingEventsText()
            "open_settings" -> {
                val target = when (action.arg1.lowercase()) {
                    "wifi" -> Settings.ACTION_WIFI_SETTINGS
                    "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
                    "display" -> Settings.ACTION_DISPLAY_SETTINGS
                    "sound" -> Settings.ACTION_SOUND_SETTINGS
                    "battery" -> Settings.ACTION_BATTERY_SAVER_SETTINGS
                    "location" -> Settings.ACTION_LOCATION_SOURCE_SETTINGS
                    "apps" -> Settings.ACTION_APPLICATION_SETTINGS
                    else -> Settings.ACTION_SETTINGS
                }
                deviceControl.openAndroidSettings(target)
            }
            "read_screen" -> {
                val svc = YasminAccessibilityService.instance
                    ?: return "Enable Accessibility Service in Permissions to read your screen."
                val text = svc.readVisibleScreenText()
                if (text.isBlank()) "Screen has no readable text." else "Screen text captured (${text.length} chars)."
            }
            "scroll" -> {
                val svc = YasminAccessibilityService.instance
                    ?: return "Enable Accessibility Service in Permissions to scroll."
                val ok = if (action.arg1 == "up") svc.performScrollUp() else svc.performScrollDown()
                if (ok) "Scrolled ${action.arg1}." else "Nothing scrollable."
            }
            "open_python" -> {
                _pendingCodingPrompt.value = action.arg1
                _navigationEvents.emit(NavigationEvent.OpenPython(action.arg1))
                "Opened Python IDE."
            }
            "open_web_ide" -> {
                _pendingCodingPrompt.value = action.arg1
                _navigationEvents.emit(NavigationEvent.OpenHtml(action.arg1))
                "Opened Web IDE."
            }
            "open_coding_agent" -> {
                _pendingCodingPrompt.value = action.arg1
                _navigationEvents.emit(NavigationEvent.OpenCodingAgent(action.arg1))
                "Opened Multi-Language AI Coding Agent."
            }
            "daily_briefing" -> {
                _navigationEvents.emit(NavigationEvent.OpenDailyHub)
                deviceControl.getCurrentDateTimeText() + "\n" + calendarHelper.formatUpcomingEventsText(3)
            }
            else -> ""
        }
    }

    fun executeConfirmedAction(action: () -> String) {
        viewModelScope.launch {
            val outcome = action()
            repository.saveAssistantMessage(outcome, preferences.value.languageMode)
            presentAssistantReply(outcome)
        }
    }

    fun analyzeScreenshotBase64(base64Jpeg: String) {
        viewModelScope.launch {
            _isBusy.value = true
            voiceManager.setThinkingState()
            _transcriptText.value = "Analyzing approved screenshot with Gemini Vision…"
            when (val res = repository.analyzeVisionImage(base64Jpeg, "Explain what is visible on this screen and suggest next actions.", "ui")) {
                is AiResult.Success -> presentAssistantReply(res.data)
                is AiResult.Error -> presentAssistantReply(res.message)
            }
            _isBusy.value = false
        }
    }

    fun speakText(text: String) = voiceManager.speak(text)

    fun clearChatHistory() {
        viewModelScope.launch {
            repository.clearChatHistory()
            repository.clearVoiceHistory()
        }
    }

    fun setWakeSessionEnabled(enabled: Boolean) {
        viewModelScope.launch { repository.updateWakeSession(enabled) }
    }

    fun setContinuousConversation(enabled: Boolean) {
        viewModelScope.launch { repository.updateContinuousConversation(enabled) }
    }

    private fun presentAssistantReply(reply: String) {
        _transcriptText.value = reply
        if (preferences.value.autoSpeakResponses) {
            voiceManager.speak(reply)
        } else {
            voiceManager.setIdleState()
        }
    }

    override fun onCleared() {
        voiceManager.release()
        super.onCleared()
    }
}
