package com.yasmin.ai.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "memories")
data class MemoryEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val category: String, // "preference", "instruction", "fact", "project", "person"
    val keyTitle: String,
    val content: String,
    val importance: Int = 1, // 1..5
    val accessCount: Int = 0,
    val isUserApproved: Boolean = true,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)
