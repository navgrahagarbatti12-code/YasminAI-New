package com.yasmin.ai.ui.vision

import android.app.Application
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Base64
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.yasmin.ai.YasminApplication
import com.yasmin.ai.ai.AiResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream

class VisionViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = (application as YasminApplication).repository

    private val _imageBase64 = MutableStateFlow<String?>(null)
    val imageBase64: StateFlow<String?> = _imageBase64.asStateFlow()

    private val _previewBitmap = MutableStateFlow<Bitmap?>(null)
    val previewBitmap: StateFlow<Bitmap?> = _previewBitmap.asStateFlow()

    private val _selectedModeIndex = MutableStateFlow(0)
    val selectedModeIndex: StateFlow<Int> = _selectedModeIndex.asStateFlow()

    private val _resultText = MutableStateFlow(
        "Select or capture an image, choose a mode (Objects, OCR, Document, UI), and tap Analyze."
    )
    val resultText: StateFlow<String> = _resultText.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    fun setSelectedModeIndex(index: Int) {
        _selectedModeIndex.value = index.coerceAtLeast(0)
    }

    fun loadFromUri(uri: Uri, onFailed: () -> Unit) {
        viewModelScope.launch {
            val loaded = withContext(Dispatchers.IO) {
                try {
                    getApplication<Application>().contentResolver.openInputStream(uri)?.use { stream ->
                        val original = BitmapFactory.decodeStream(stream) ?: return@withContext null
                        val maxDim = 1024f
                        val scale = minOf(maxDim / original.width, maxDim / original.height, 1f)
                        val w = (original.width * scale).toInt().coerceAtLeast(1)
                        val h = (original.height * scale).toInt().coerceAtLeast(1)
                        val resized = Bitmap.createScaledBitmap(original, w, h, true)
                        if (resized != original) original.recycle()

                        val baos = ByteArrayOutputStream()
                        resized.compress(Bitmap.CompressFormat.JPEG, 82, baos)
                        val b64 = Base64.encodeToString(baos.toByteArray(), Base64.NO_WRAP)
                        Pair(resized, b64)
                    }
                } catch (_: Exception) {
                    null
                }
            }
            if (loaded != null) {
                _previewBitmap.value = loaded.first
                _imageBase64.value = loaded.second
                _resultText.value = "Image loaded. Choose analysis mode and tap Analyze."
            } else {
                onFailed()
            }
        }
    }

    fun loadCapturedBase64(base64: String) {
        viewModelScope.launch {
            val bmp = withContext(Dispatchers.IO) {
                try {
                    val bytes = Base64.decode(base64, Base64.DEFAULT)
                    BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                } catch (_: Exception) {
                    null
                }
            }
            _imageBase64.value = base64
            if (bmp != null) _previewBitmap.value = bmp
            _selectedModeIndex.value = 4 // UI Analysis
            _resultText.value = "Screen snapshot ready. Tap 'Analyze With Gemini Vision'."
        }
    }

    fun analyzeCurrentImage(prompt: String, mode: String) {
        val base64 = _imageBase64.value ?: return
        viewModelScope.launch {
            _isLoading.value = true
            _resultText.value = "Analyzing image with Gemini Vision ($mode)…"
            when (val res = repository.analyzeVisionImage(base64, prompt, mode)) {
                is AiResult.Success -> _resultText.value = res.data
                is AiResult.Error -> _resultText.value = "Vision Error: ${res.message}"
            }
            _isLoading.value = false
        }
    }
}
