package com.yasmin.ai.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "learning_sessions")
data class LearningSessionEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val videoId: String,
    val videoTitle: String,
    val channelTitle: String,
    val topic: String,
    val difficultyLevel: String,
    val quizScore: Int = 0,
    val totalQuestions: Int = 0,
    val progressPercent: Int = 0,
    val summaryExcerpt: String = "",
    val lastStudiedAt: Long = System.currentTimeMillis()
)
