package com.yasmin.ai.assistant

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ReminderScheduler(private val context: Context) {

    fun scheduleReminder(taskId: Long, title: String, details: String, triggerAtMs: Long): Boolean {
        if (triggerAtMs <= System.currentTimeMillis()) return false
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, ReminderBroadcastReceiver::class.java).apply {
            putExtra(ReminderBroadcastReceiver.EXTRA_TASK_ID, taskId)
            putExtra(ReminderBroadcastReceiver.EXTRA_TITLE, title)
            putExtra(ReminderBroadcastReceiver.EXTRA_DETAILS, details)
        }
        val pending = PendingIntent.getBroadcast(
            context,
            taskId.toInt(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMs, pending)
        return true
    }

    fun cancelReminder(taskId: Long) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, ReminderBroadcastReceiver::class.java)
        val pending = PendingIntent.getBroadcast(
            context,
            taskId.toInt(),
            intent,
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        )
        if (pending != null) {
            alarmManager.cancel(pending)
        }
    }

    companion object {
        /**
         * Parses simple delay expressions such as "in 10 minutes", "in 2 hours", "in 30 seconds".
         */
        fun parseRelativeDelayMs(text: String): Long? {
            val lower = text.lowercase(Locale.getDefault())
            val match = Regex("in\\s+(\\d{1,4})\\s*(sec|secs|second|seconds|min|mins|minute|minutes|hr|hrs|hour|hours)")
                .find(lower) ?: return null
            val amount = match.groupValues[1].toLongOrNull() ?: return null
            val unit = match.groupValues[2]
            val multiplier = when {
                unit.startsWith("sec") -> 1_000L
                unit.startsWith("min") -> 60_000L
                else -> 3_600_000L
            }
            return amount * multiplier
        }

        fun formatDueLabel(epochMs: Long): String {
            if (epochMs <= 0L) return ""
            return SimpleDateFormat("dd MMM · hh:mm a", Locale.getDefault()).format(Date(epochMs))
        }
    }
}
