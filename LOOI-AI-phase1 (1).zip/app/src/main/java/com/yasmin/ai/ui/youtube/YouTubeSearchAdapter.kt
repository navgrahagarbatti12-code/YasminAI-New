package com.yasmin.ai.ui.youtube

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.yasmin.ai.databinding.ItemYoutubeResultBinding
import com.yasmin.ai.youtube.YouTubeItemType
import com.yasmin.ai.youtube.YouTubeVideoInfo

class YouTubeSearchAdapter(
    private val onSelect: (YouTubeVideoInfo) -> Unit,
    private val onOpenExternal: (YouTubeVideoInfo) -> Unit
) : ListAdapter<YouTubeVideoInfo, YouTubeSearchAdapter.ResultViewHolder>(Diff) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ResultViewHolder {
        val binding = ItemYoutubeResultBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ResultViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ResultViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class ResultViewHolder(private val binding: ItemYoutubeResultBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(item: YouTubeVideoInfo) {
            binding.tvItemType.text = when {
                item.itemType == YouTubeItemType.CHANNEL -> "CHANNEL"
                item.itemType == YouTubeItemType.PLAYLIST -> "PLAYLIST"
                item.isShort -> "SHORT"
                else -> "VIDEO"
            }
            binding.tvItemDuration.text = item.durationFormatted.ifBlank { "" }
            binding.tvItemDuration.visibility = if (item.durationFormatted.isNotBlank()) View.VISIBLE else View.GONE
            binding.tvItemViews.text = item.viewCount
            binding.tvItemTitle.text = item.title
            binding.tvItemChannel.text = item.channelTitle.ifBlank { "YouTube" }
            binding.tvItemDescription.text = item.description.ifBlank { item.sourceUrl }

            binding.btnItemAnalyze.text = when (item.itemType) {
                YouTubeItemType.PLAYLIST -> "Load Playlist"
                YouTubeItemType.CHANNEL -> "Channel Videos"
                YouTubeItemType.VIDEO -> "Load in Agent"
            }
            binding.btnItemAnalyze.setOnClickListener { onSelect(item) }
            binding.root.setOnClickListener { onSelect(item) }
            binding.btnItemOpenExternal.setOnClickListener { onOpenExternal(item) }
        }
    }

    private object Diff : DiffUtil.ItemCallback<YouTubeVideoInfo>() {
        override fun areItemsTheSame(oldItem: YouTubeVideoInfo, newItem: YouTubeVideoInfo): Boolean =
            oldItem.videoId == newItem.videoId && oldItem.itemType == newItem.itemType

        override fun areContentsTheSame(oldItem: YouTubeVideoInfo, newItem: YouTubeVideoInfo): Boolean =
            oldItem == newItem
    }
}
