package com.yasmin.ai.ui.youtube

import android.app.Application
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.yasmin.ai.YasminApplication
import com.yasmin.ai.accessibility.YasminAccessibilityService
import com.yasmin.ai.ai.AiResult
import com.yasmin.ai.automation.DeviceControlManager
import com.yasmin.ai.data.local.LearningSessionEntity
import com.yasmin.ai.data.local.VideoNoteEntity
import com.yasmin.ai.youtube.GeneratedNotesBundle
import com.yasmin.ai.youtube.LearningDepth
import com.yasmin.ai.youtube.NoteExportManager
import com.yasmin.ai.youtube.QuizEvaluation
import com.yasmin.ai.youtube.QuizQuestion
import com.yasmin.ai.youtube.SummaryLanguage
import com.yasmin.ai.youtube.SummaryStyle
import com.yasmin.ai.youtube.TranscriptResult
import com.yasmin.ai.youtube.TranscriptStatus
import com.yasmin.ai.youtube.YouTubeActionVerification
import com.yasmin.ai.youtube.YouTubeAiEngine
import com.yasmin.ai.youtube.YouTubeChatMessage
import com.yasmin.ai.youtube.YouTubeDataService
import com.yasmin.ai.youtube.YouTubeItemType
import com.yasmin.ai.youtube.YouTubeSearchFilter
import com.yasmin.ai.youtube.YouTubeVideoInfo
import com.yasmin.ai.youtube.YouTubeVoiceController
import com.yasmin.ai.youtube.YouTubeVoiceIntent
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

@OptIn(ExperimentalCoroutinesApi::class)
class YouTubeAgentViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = (application as YasminApplication).repository
    val deviceControl = DeviceControlManager(application)
    val voiceController = YouTubeVoiceController(application, deviceControl)
    private val dataService = YouTubeDataService { repository.getYouTubeApiKey() }
    private val aiEngine = YouTubeAiEngine(repository.aiProvider)
    private val exportManager = NoteExportManager(application)
    private val imageHttpClient = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    private val _currentVideo = MutableStateFlow<YouTubeVideoInfo?>(null)
    val currentVideo: StateFlow<YouTubeVideoInfo?> = _currentVideo.asStateFlow()

    private val _thumbnailBitmap = MutableStateFlow<Bitmap?>(null)
    val thumbnailBitmap: StateFlow<Bitmap?> = _thumbnailBitmap.asStateFlow()

    private val _transcriptResult = MutableStateFlow<TranscriptResult?>(null)
    val transcriptResult: StateFlow<TranscriptResult?> = _transcriptResult.asStateFlow()

    private val _searchResults = MutableStateFlow<List<YouTubeVideoInfo>>(emptyList())
    val searchResults: StateFlow<List<YouTubeVideoInfo>> = _searchResults.asStateFlow()

    private val _searchFilter = MutableStateFlow(YouTubeSearchFilter.VIDEO)
    val searchFilter: StateFlow<YouTubeSearchFilter> = _searchFilter.asStateFlow()

    private val _summaryOutput = MutableStateFlow("")
    val summaryOutput: StateFlow<String> = _summaryOutput.asStateFlow()

    private val _qaMessages = MutableStateFlow<List<YouTubeChatMessage>>(emptyList())
    val qaMessages: StateFlow<List<YouTubeChatMessage>> = _qaMessages.asStateFlow()

    private val _generatedNotes = MutableStateFlow<GeneratedNotesBundle?>(null)
    val generatedNotes: StateFlow<GeneratedNotesBundle?> = _generatedNotes.asStateFlow()

    private val _learningOutput = MutableStateFlow("")
    val learningOutput: StateFlow<String> = _learningOutput.asStateFlow()

    private val _quizQuestions = MutableStateFlow<List<QuizQuestion>>(emptyList())
    val quizQuestions: StateFlow<List<QuizQuestion>> = _quizQuestions.asStateFlow()

    private val _selectedQuizAnswers = MutableStateFlow<Map<Int, Int>>(emptyMap())
    val selectedQuizAnswers: StateFlow<Map<Int, Int>> = _selectedQuizAnswers.asStateFlow()

    private val _quizEvaluation = MutableStateFlow<QuizEvaluation?>(null)
    val quizEvaluation: StateFlow<QuizEvaluation?> = _quizEvaluation.asStateFlow()

    private val _screenContextText = MutableStateFlow("")
    val screenContextText: StateFlow<String> = _screenContextText.asStateFlow()

    private val _isBusy = MutableStateFlow(false)
    val isBusy: StateFlow<Boolean> = _isBusy.asStateFlow()

    private val _statusBanner = MutableStateFlow("Paste any YouTube URL, search, or read your active YouTube screen.")
    val statusBanner: StateFlow<String> = _statusBanner.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    private val _noteSearchQuery = MutableStateFlow("")
    val savedNotes: StateFlow<List<VideoNoteEntity>> = _noteSearchQuery
        .flatMapLatest { q -> repository.observeSearchVideoNotes(q) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val learningHistory: StateFlow<List<LearningSessionEntity>> = repository.learningSessionsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _uiEvents = MutableSharedFlow<YouTubeUiEvent>()
    val uiEvents: SharedFlow<YouTubeUiEvent> = _uiEvents.asSharedFlow()

    sealed class YouTubeUiEvent {
        data class ShowToast(val message: String) : YouTubeUiEvent()
        data class ShareExportedFile(val intent: android.content.Intent) : YouTubeUiEvent()
        data class RequestPermissionsScreen(val reason: String) : YouTubeUiEvent()
    }

    fun setSearchFilter(filter: YouTubeSearchFilter) {
        _searchFilter.value = filter
    }

    fun setNoteSearchQuery(query: String) {
        _noteSearchQuery.value = query
    }

    fun clearError() {
        _errorMessage.value = null
    }

    fun performSearchOrLoadUrl(rawInput: String, creatorFilter: String = "") {
        val clean = rawInput.trim()
        if (clean.isEmpty()) {
            _errorMessage.value = "Enter a YouTube URL, video ID, topic, channel, or playlist query."
            return
        }

        val extractedVideoId = YouTubeDataService.extractVideoId(clean)
        val extractedPlaylistId = YouTubeDataService.extractPlaylistId(clean)

        viewModelScope.launch {
            _isBusy.value = true
            _errorMessage.value = null

            when {
                extractedVideoId != null -> {
                    loadVideoAndTranscript(extractedVideoId)
                }
                extractedPlaylistId != null -> {
                    _statusBanner.value = "Loading playlist items for $extractedPlaylistId…"
                    when (val res = dataService.fetchPlaylistVideos(extractedPlaylistId)) {
                        is YouTubeDataService.DataResult.Success -> {
                            _searchResults.value = res.data
                            _statusBanner.value = "Loaded ${res.data.size} videos from playlist."
                            res.data.firstOrNull()?.let { selectVideoItem(it) }
                        }
                        is YouTubeDataService.DataResult.Error -> {
                            _errorMessage.value = res.message
                            _statusBanner.value = "Playlist load failed."
                        }
                    }
                }
                else -> {
                    val filter = _searchFilter.value
                    _statusBanner.value = "Searching YouTube (${filter.label}) for \"$clean\"…"
                    when (val res = dataService.search(clean, filter, creatorFilter)) {
                        is YouTubeDataService.DataResult.Success -> {
                            _searchResults.value = res.data
                            _statusBanner.value = if (res.data.isEmpty()) {
                                "No results returned for \"$clean\"."
                            } else {
                                "Found ${res.data.size} ${filter.label.lowercase()} for \"$clean\"."
                            }
                        }
                        is YouTubeDataService.DataResult.Error -> {
                            _errorMessage.value = res.message
                            _statusBanner.value = "YouTube API search unavailable — you can still open search in YouTube app/browser."
                        }
                    }
                }
            }
            _isBusy.value = false
        }
    }

    fun selectVideoItem(item: YouTubeVideoInfo) {
        viewModelScope.launch {
            _isBusy.value = true
            _errorMessage.value = null
            when (item.itemType) {
                YouTubeItemType.PLAYLIST -> {
                    val plId = item.playlistId.ifBlank { item.videoId }
                    when (val res = dataService.fetchPlaylistVideos(plId)) {
                        is YouTubeDataService.DataResult.Success -> {
                            _searchResults.value = res.data
                            _statusBanner.value = "Opened playlist \"${item.title}\" (${res.data.size} videos)."
                        }
                        is YouTubeDataService.DataResult.Error -> {
                            _errorMessage.value = res.message
                            deviceControl.openYouTubePlaylist(plId)
                        }
                    }
                }
                YouTubeItemType.CHANNEL -> {
                    val q = item.channelTitle.ifBlank { item.title }
                    _searchFilter.value = YouTubeSearchFilter.CREATOR
                    when (val res = dataService.search(q, YouTubeSearchFilter.CREATOR, creatorName = q)) {
                        is YouTubeDataService.DataResult.Success -> {
                            _searchResults.value = res.data
                            _statusBanner.value = "Loaded videos for channel $q."
                        }
                        is YouTubeDataService.DataResult.Error -> {
                            deviceControl.openYouTubeChannel(item.sourceUrl.ifBlank { item.channelId })
                        }
                    }
                }
                YouTubeItemType.VIDEO -> {
                    loadVideoAndTranscript(item.videoId, preloaded = item)
                }
            }
            _isBusy.value = false
        }
    }

    fun loadRecommendationsForCurrent() {
        val current = _currentVideo.value ?: return
        viewModelScope.launch {
            _isBusy.value = true
            _statusBanner.value = "Loading related recommendations for \"${current.title.take(40)}\"…"
            when (val res = dataService.fetchRelatedRecommendations(current)) {
                is YouTubeDataService.DataResult.Success -> {
                    _searchResults.value = res.data
                    _statusBanner.value = "Loaded ${res.data.size} recommended videos."
                }
                is YouTubeDataService.DataResult.Error -> {
                    _errorMessage.value = res.message
                }
            }
            _isBusy.value = false
        }
    }

    private suspend fun loadVideoAndTranscript(videoId: String, preloaded: YouTubeVideoInfo? = null) {
        _statusBanner.value = "Fetching video metadata & captions for $videoId…"
        val metaRes = dataService.fetchVideoMetadata(videoId)
        val resolvedVideo = when (metaRes) {
            is YouTubeDataService.DataResult.Success -> metaRes.data
            is YouTubeDataService.DataResult.Error -> {
                if (preloaded != null) {
                    preloaded
                } else {
                    _errorMessage.value = metaRes.message
                    _statusBanner.value = "Video metadata unavailable."
                    return
                }
            }
        }
        _currentVideo.value = resolvedVideo
        loadThumbnailAsync(resolvedVideo.thumbnailUrl)

        _transcriptResult.value = TranscriptResult(
            videoId = resolvedVideo.videoId,
            status = TranscriptStatus.LOADING,
            statusReason = "Checking authorized public captions…"
        )
        val prefsLang = repository.getPreferencesSnapshot().languageMode
        val preferredCaptionLang = if (prefsLang == "hi") "hi" else "en"
        val transcript = dataService.fetchTranscript(resolvedVideo.videoId, preferredCaptionLang)
        _transcriptResult.value = transcript

        _summaryOutput.value = ""
        _generatedNotes.value = null
        _quizQuestions.value = emptyList()
        _selectedQuizAnswers.value = emptyMap()
        _quizEvaluation.value = null
        _qaMessages.value = listOf(
            YouTubeChatMessage(
                role = "assistant",
                content = "Loaded \"${resolvedVideo.title}\". Caption status: ${transcript.status.badgeLabel}. ${transcript.statusReason}",
                groundedInTranscript = transcript.status == TranscriptStatus.AVAILABLE
            )
        )
        _statusBanner.value = "Ready: ${resolvedVideo.title} · ${transcript.status.badgeLabel}"
    }

    fun switchTranscriptLanguage(langCode: String) {
        val video = _currentVideo.value ?: return
        viewModelScope.launch {
            _isBusy.value = true
            val res = dataService.fetchTranscript(video.videoId, langCode)
            _transcriptResult.value = res
            _statusBanner.value = "Transcript ($langCode): ${res.statusReason}"
            _isBusy.value = false
        }
    }

    fun identifyFromAccessibilityScreen() {
        val svc = YasminAccessibilityService.instance
        if (svc == null) {
            viewModelScope.launch {
                _uiEvents.emit(
                    YouTubeUiEvent.RequestPermissionsScreen(
                        "Enable Yasmin AI Accessibility Service in Permission Setup to read active YouTube titles, controls, and comments."
                    )
                )
            }
            return
        }
        val ytCtx = svc.parseYouTubeScreen()
        if (ytCtx.rawSnapshot.isBlank()) {
            _errorMessage.value = "No readable elements detected on screen. Open a YouTube video first."
            return
        }
        val formattedScreen = buildString {
            if (ytCtx.videoTitle.isNotBlank()) appendLine("Detected Title: ${ytCtx.videoTitle}")
            if (ytCtx.channelName.isNotBlank()) appendLine("Detected Channel: ${ytCtx.channelName}")
            if (ytCtx.playbackControlVisible.isNotBlank()) appendLine("Player State: ${ytCtx.playbackControlVisible}")
            if (ytCtx.visibleControls.isNotEmpty()) appendLine("Visible Controls: ${ytCtx.visibleControls.joinToString(", ")}")
            if (ytCtx.searchResults.isNotEmpty()) appendLine("Visible Items: ${ytCtx.searchResults.joinToString(" | ")}")
            if (ytCtx.descriptionOrComments.isNotEmpty()) appendLine("Descriptions/Comments:\n${ytCtx.descriptionOrComments.joinToString("\n")}")
        }
        _screenContextText.value = formattedScreen

        if (ytCtx.videoTitle.isNotBlank() && _currentVideo.value == null) {
            _statusBanner.value = "Detected on screen: ${ytCtx.videoTitle}"
            // Optionally search via API if key is set, else hold screen context
            if (repository.hasYouTubeApiKey()) {
                performSearchOrLoadUrl(ytCtx.videoTitle)
                return
            }
        }
        viewModelScope.launch {
            _uiEvents.emit(
                YouTubeUiEvent.ShowToast(
                    "Captured YouTube screen context (${ytCtx.visibleControls.size} controls, ${ytCtx.descriptionOrComments.size} text blocks)."
                )
            )
        }
    }

    fun attachScreenVisionBase64(base64Jpeg: String) {
        viewModelScope.launch {
            _isBusy.value = true
            _statusBanner.value = "Analyzing YouTube screenshot with Gemini Vision…"
            when (
                val res = repository.analyzeVisionImage(
                    base64Jpeg = base64Jpeg,
                    prompt = "Extract the YouTube video title, channel name, visible timestamps, visible player state, and key educational content shown on this screen.",
                    mode = "ui"
                )
            ) {
                is AiResult.Success -> {
                    _screenContextText.value = res.data
                    _statusBanner.value = "Screen Vision context attached for summary & Q&A."
                }
                is AiResult.Error -> _errorMessage.value = res.message
            }
            _isBusy.value = false
        }
    }

    fun summarizeCurrentVideo(style: SummaryStyle, language: SummaryLanguage) {
        val video = _currentVideo.value
        if (video == null) {
            _errorMessage.value = "Load or select a YouTube video first."
            return
        }
        val transcript = _transcriptResult.value ?: TranscriptResult(video.videoId, TranscriptStatus.UNAVAILABLE)
        viewModelScope.launch {
            _isBusy.value = true
            _errorMessage.value = null
            _statusBanner.value = "Generating ${style.label} in ${language.label}…"
            when (val res = aiEngine.summarizeVideo(video, transcript, style, language, _screenContextText.value)) {
                is AiResult.Success -> {
                    _summaryOutput.value = res.data
                    _statusBanner.value = "${style.label} ready (${language.label})."
                    repository.recordLearningProgress(
                        videoId = video.videoId,
                        videoTitle = video.title,
                        channelTitle = video.channelTitle,
                        topic = video.title.take(60),
                        difficultyLevel = style.label,
                        progressIncrement = 20,
                        summaryExcerpt = res.data.take(220)
                    )
                }
                is AiResult.Error -> {
                    _errorMessage.value = res.message
                    _statusBanner.value = "Summary failed."
                }
            }
            _isBusy.value = false
        }
    }

    fun askAboutVideo(question: String, language: SummaryLanguage) {
        val cleanQ = question.trim()
        val video = _currentVideo.value
        if (video == null) {
            _errorMessage.value = "Load a YouTube video first before asking questions."
            return
        }
        if (cleanQ.isEmpty()) return

        val transcript = _transcriptResult.value ?: TranscriptResult(video.videoId, TranscriptStatus.UNAVAILABLE)
        val userMsg = YouTubeChatMessage(role = "user", content = cleanQ)
        _qaMessages.value = _qaMessages.value + userMsg

        viewModelScope.launch {
            _isBusy.value = true
            _errorMessage.value = null
            when (
                val res = aiEngine.answerVideoQuestion(
                    video = video,
                    transcript = transcript,
                    history = _qaMessages.value,
                    question = cleanQ,
                    language = language,
                    screenContextText = _screenContextText.value
                )
            ) {
                is AiResult.Success -> {
                    _qaMessages.value = _qaMessages.value + YouTubeChatMessage(
                        role = "assistant",
                        content = res.data,
                        groundedInTranscript = transcript.status == TranscriptStatus.AVAILABLE
                    )
                }
                is AiResult.Error -> {
                    _errorMessage.value = res.message
                }
            }
            _isBusy.value = false
        }
    }

    fun generateNotesForCurrentVideo(language: SummaryLanguage, autoSave: Boolean = true) {
        val video = _currentVideo.value
        if (video == null) {
            _errorMessage.value = "Load a YouTube video first to generate study notes."
            return
        }
        val transcript = _transcriptResult.value ?: TranscriptResult(video.videoId, TranscriptStatus.UNAVAILABLE)
        viewModelScope.launch {
            _isBusy.value = true
            _errorMessage.value = null
            _statusBanner.value = "Generating structured video notes…"
            when (val res = aiEngine.generateStructuredNotes(video, transcript, language, _screenContextText.value)) {
                is AiResult.Success -> {
                    _generatedNotes.value = res.data
                    _statusBanner.value = "Structured notes generated."
                    if (autoSave) {
                        saveCurrentNotesToVault(language)
                    }
                }
                is AiResult.Error -> _errorMessage.value = res.message
            }
            _isBusy.value = false
        }
    }

    fun saveCurrentNotesToVault(language: SummaryLanguage) {
        val video = _currentVideo.value ?: return
        val bundle = _generatedNotes.value ?: return
        viewModelScope.launch {
            val id = repository.saveVideoNote(
                VideoNoteEntity(
                    videoId = video.videoId,
                    videoTitle = video.title,
                    channelTitle = video.channelTitle,
                    topic = bundle.topic,
                    markdownContent = bundle.fullMarkdown,
                    definitionsText = bundle.definitions,
                    bulletPointsText = bundle.bulletPoints,
                    stepsText = bundle.stepByStep,
                    timestampsText = bundle.importantTimestamps,
                    language = language.code
                )
            )
            _uiEvents.emit(YouTubeUiEvent.ShowToast("Saved notes #$id to Room Vault."))
        }
    }

    fun deleteSavedNote(note: VideoNoteEntity) {
        viewModelScope.launch {
            repository.deleteVideoNote(note)
            _uiEvents.emit(YouTubeUiEvent.ShowToast("Deleted notes for \"${note.videoTitle.take(32)}\"."))
        }
    }

    fun exportNoteAsTxt(note: VideoNoteEntity) {
        viewModelScope.launch {
            val prefs = repository.getPreferencesSnapshot()
            val res = withContext(Dispatchers.IO) {
                exportManager.exportAsTxt(note, prefs.storageTreeUri)
            }
            res.onSuccess { exported ->
                val msg = if (exported.safSynced) "Exported TXT + synced to SAF folder." else "Exported TXT to ${exported.file.name}."
                _uiEvents.emit(YouTubeUiEvent.ShowToast(msg))
                _uiEvents.emit(YouTubeUiEvent.ShareExportedFile(exportManager.buildShareOrOpenIntent(exported, note.videoTitle)))
            }.onFailure { err ->
                _errorMessage.value = "TXT export failed: ${err.localizedMessage}"
            }
        }
    }

    fun exportNoteAsPdf(note: VideoNoteEntity) {
        viewModelScope.launch {
            val prefs = repository.getPreferencesSnapshot()
            val res = withContext(Dispatchers.IO) {
                exportManager.exportAsPdf(note, prefs.storageTreeUri)
            }
            res.onSuccess { exported ->
                val msg = if (exported.safSynced) "Exported PDF + synced to SAF folder." else "Exported PDF to ${exported.file.name}."
                _uiEvents.emit(YouTubeUiEvent.ShowToast(msg))
                _uiEvents.emit(YouTubeUiEvent.ShareExportedFile(exportManager.buildShareOrOpenIntent(exported, note.videoTitle)))
            }.onFailure { err ->
                _errorMessage.value = "PDF export failed: ${err.localizedMessage}"
            }
        }
    }

    fun startLearningLesson(depth: LearningDepth, language: SummaryLanguage) {
        val video = _currentVideo.value
        if (video == null) {
            _errorMessage.value = "Load a YouTube video first to start Learning Mode."
            return
        }
        val transcript = _transcriptResult.value ?: TranscriptResult(video.videoId, TranscriptStatus.UNAVAILABLE)
        viewModelScope.launch {
            _isBusy.value = true
            _errorMessage.value = null
            _statusBanner.value = "Preparing ${depth.label} lesson…"
            when (val res = aiEngine.generateLearningLesson(video, transcript, depth, language, _screenContextText.value)) {
                is AiResult.Success -> {
                    _learningOutput.value = res.data
                    _statusBanner.value = "Learning lesson ready (${depth.label})."
                    repository.recordLearningProgress(
                        videoId = video.videoId,
                        videoTitle = video.title,
                        channelTitle = video.channelTitle,
                        topic = video.title.take(60),
                        difficultyLevel = depth.label,
                        progressIncrement = 30,
                        summaryExcerpt = res.data.take(220)
                    )
                }
                is AiResult.Error -> _errorMessage.value = res.message
            }
            _isBusy.value = false
        }
    }

    fun generateQuizForCurrentVideo(language: SummaryLanguage) {
        val video = _currentVideo.value
        if (video == null) {
            _errorMessage.value = "Load a YouTube video first to generate a quiz."
            return
        }
        val transcript = _transcriptResult.value ?: TranscriptResult(video.videoId, TranscriptStatus.UNAVAILABLE)
        viewModelScope.launch {
            _isBusy.value = true
            _errorMessage.value = null
            _quizEvaluation.value = null
            _selectedQuizAnswers.value = emptyMap()
            _statusBanner.value = "Generating interactive MCQ quiz…"
            when (val res = aiEngine.generateQuiz(video, transcript, language, questionCount = 5, _screenContextText.value)) {
                is AiResult.Success -> {
                    _quizQuestions.value = res.data
                    _statusBanner.value = "Quiz ready (${res.data.size} questions)."
                }
                is AiResult.Error -> _errorMessage.value = res.message
            }
            _isBusy.value = false
        }
    }

    fun selectQuizAnswer(questionIndex: Int, optionIndex: Int) {
        val updated = _selectedQuizAnswers.value.toMutableMap()
        updated[questionIndex] = optionIndex
        _selectedQuizAnswers.value = updated
    }

    fun evaluateActiveQuiz() {
        val questions = _quizQuestions.value
        if (questions.isEmpty()) {
            _errorMessage.value = "Generate a quiz first."
            return
        }
        val eval = YouTubeAiEngine.evaluateQuiz(questions, _selectedQuizAnswers.value)
        _quizEvaluation.value = eval
        val video = _currentVideo.value ?: return
        viewModelScope.launch {
            repository.recordLearningProgress(
                videoId = video.videoId,
                videoTitle = video.title,
                channelTitle = video.channelTitle,
                topic = video.title.take(60),
                difficultyLevel = "Quiz Completed",
                quizScore = eval.correctCount,
                totalQuestions = eval.totalQuestions,
                progressIncrement = 40,
                summaryExcerpt = eval.summaryMessage
            )
            _uiEvents.emit(YouTubeUiEvent.ShowToast(eval.summaryMessage))
        }
    }

    fun executePlaybackControl(intent: YouTubeVoiceIntent) {
        viewModelScope.launch(Dispatchers.IO) {
            val outcome: YouTubeActionVerification = voiceController.executeVoiceIntent(intent)
            _statusBanner.value = "${outcome.actionName} (${outcome.methodUsed}): ${outcome.message}"
            if (outcome.requiresAccessibilitySetup && !outcome.verified) {
                _uiEvents.emit(YouTubeUiEvent.RequestPermissionsScreen(outcome.message))
            } else {
                _uiEvents.emit(YouTubeUiEvent.ShowToast(outcome.message))
            }
        }
    }

    fun deleteLearningSession(session: LearningSessionEntity) {
        viewModelScope.launch { repository.deleteLearningSession(session) }
    }

    fun clearLearningHistory() {
        viewModelScope.launch {
            repository.clearLearningHistory()
            _uiEvents.emit(YouTubeUiEvent.ShowToast("Cleared learning progress history."))
        }
    }

    fun reloadVideoFromHistory(videoId: String) {
        viewModelScope.launch {
            _isBusy.value = true
            loadVideoAndTranscript(videoId)
            _isBusy.value = false
        }
    }

    private fun loadThumbnailAsync(url: String) {
        if (url.isBlank()) {
            _thumbnailBitmap.value = null
            return
        }
        viewModelScope.launch(Dispatchers.IO) {
            val bmp = try {
                val req = Request.Builder().url(url).get().build()
                imageHttpClient.newCall(req).execute().use { resp ->
                    if (!resp.isSuccessful) null
                    else resp.body?.byteStream()?.use { stream -> BitmapFactory.decodeStream(stream) }
                }
            } catch (_: Exception) {
                null
            }
            _thumbnailBitmap.value = bmp
        }
    }
}
