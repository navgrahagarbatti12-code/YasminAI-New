package com.yasmin.ai.screen

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.Looper
import android.util.Base64
import kotlinx.coroutines.suspendCancellableCoroutine
import java.io.ByteArrayOutputStream
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.coroutines.resume

class ScreenCaptureManager(private val context: Context) {

    fun createConsentIntent(): Intent {
        val manager = context.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        return manager.createScreenCaptureIntent()
    }

    suspend fun captureSingleScreenshotBase64(resultCode: Int, data: Intent): String? =
        suspendCancellableCoroutine { continuation ->
            val manager =
                context.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val metrics = context.resources.displayMetrics
            val width = metrics.widthPixels
            val height = metrics.heightPixels
            val density = metrics.densityDpi

            var projection: MediaProjection? = null
            var virtualDisplay: VirtualDisplay? = null
            var imageReader: ImageReader? = null
            val completed = AtomicBoolean(false)
            val handler = Handler(Looper.getMainLooper())

            lateinit var timeoutRunnable: Runnable

            fun cleanup() {
                handler.removeCallbacks(timeoutRunnable)
                try {
                    imageReader?.setOnImageAvailableListener(null, null)
                } catch (_: Exception) {
                }
                try {
                    virtualDisplay?.release()
                    imageReader?.close()
                    projection?.stop()
                } catch (_: Exception) {
                } finally {
                    MediaProjectionService.stopForegroundProjection(context)
                }
            }

            fun finishWith(result: String?) {
                if (completed.compareAndSet(false, true)) {
                    cleanup()
                    if (continuation.isActive) {
                        continuation.resume(result)
                    }
                }
            }

            timeoutRunnable = Runnable {
                finishWith(null)
            }

            try {
                projection = manager.getMediaProjection(resultCode, data)
                if (projection == null) {
                    finishWith(null)
                    return@suspendCancellableCoroutine
                }

                imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)

                projection.registerCallback(object : MediaProjection.Callback() {
                    override fun onStop() {
                        finishWith(null)
                    }
                }, handler)

                imageReader.setOnImageAvailableListener({ reader ->
                    if (completed.get()) return@setOnImageAvailableListener
                    val image = try {
                        reader.acquireLatestImage()
                    } catch (_: Exception) {
                        null
                    } ?: return@setOnImageAvailableListener

                    try {
                        val planes = image.planes
                        val buffer = planes[0].buffer
                        val pixelStride = planes[0].pixelStride
                        val rowStride = planes[0].rowStride
                        val rowPadding = rowStride - pixelStride * width

                        val rawBitmap = Bitmap.createBitmap(
                            width + rowPadding / pixelStride,
                            height,
                            Bitmap.Config.ARGB_8888
                        )
                        rawBitmap.copyPixelsFromBuffer(buffer)
                        image.close()

                        val cropped = Bitmap.createBitmap(rawBitmap, 0, 0, width, height)
                        if (cropped != rawBitmap) rawBitmap.recycle()

                        val scaledWidth = 720
                        val scaledHeight = (height * (720f / width)).toInt().coerceAtLeast(1)
                        val scaled = Bitmap.createScaledBitmap(cropped, scaledWidth, scaledHeight, true)
                        if (scaled != cropped) cropped.recycle()

                        val out = ByteArrayOutputStream()
                        scaled.compress(Bitmap.CompressFormat.JPEG, 78, out)
                        scaled.recycle()

                        val base64 = Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
                        finishWith(base64)
                    } catch (_: Exception) {
                        try {
                            image.close()
                        } catch (_: Exception) {
                        }
                        finishWith(null)
                    }
                }, handler)

                handler.postDelayed(timeoutRunnable, 2500L)

                virtualDisplay = projection.createVirtualDisplay(
                    "YasminScreenCapture",
                    width,
                    height,
                    density,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                    imageReader.surface,
                    null,
                    handler
                )

                continuation.invokeOnCancellation {
                    finishWith(null)
                }
            } catch (_: Exception) {
                finishWith(null)
            }
        }
}
