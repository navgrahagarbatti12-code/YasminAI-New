package com.yasmin.ai

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import com.yasmin.ai.data.local.YasminDatabase
import com.yasmin.ai.data.preferences.UserPreferencesDataStore
import com.yasmin.ai.repository.YasminRepository
import com.yasmin.ai.security.SecureVault

class YasminApplication : Application() {

    lateinit var repository: YasminRepository
        private set

    override fun onCreate() {
        super.onCreate()
        createNotificationChannels()

        if (!Python.isStarted()) {
            Python.start(AndroidPlatform(this))
        }

        val database = YasminDatabase.getInstance(this)
        val prefs = UserPreferencesDataStore(this)
        val vault = SecureVault(this)
        repository = YasminRepository(
            chatDao = database.chatDao(),
            memoryDao = database.memoryDao(),
            taskDao = database.taskDao(),
            voiceHistoryDao = database.voiceHistoryDao(),
            codingJobDao = database.codingJobDao(),
            videoNoteDao = database.videoNoteDao(),
            learningSessionDao = database.learningSessionDao(),
            preferencesDataStore = prefs,
            secureVault = vault
        )
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java)
            val wakeChannel = NotificationChannel(
                CHANNEL_WAKE_SESSION,
                getString(R.string.notification_channel_wake_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = getString(R.string.notification_channel_wake_desc)
            }
            val projectionChannel = NotificationChannel(
                CHANNEL_MEDIA_PROJECTION,
                getString(R.string.notification_channel_projection_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = getString(R.string.notification_channel_projection_desc)
            }
            val reminderChannel = NotificationChannel(
                CHANNEL_REMINDERS,
                "Yasmin Smart Reminders",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Scheduled personal assistant reminders and alerts"
            }
            val codingChannel = NotificationChannel(
                CHANNEL_CODING_JOBS,
                getString(R.string.notification_channel_coding_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = getString(R.string.notification_channel_coding_desc)
            }
            nm.createNotificationChannel(wakeChannel)
            nm.createNotificationChannel(projectionChannel)
            nm.createNotificationChannel(reminderChannel)
            nm.createNotificationChannel(codingChannel)
        }
    }

    companion object {
        const val CHANNEL_WAKE_SESSION = "yasmin_wake_session"
        const val CHANNEL_MEDIA_PROJECTION = "yasmin_media_projection"
        const val CHANNEL_REMINDERS = "yasmin_reminders"
        const val CHANNEL_CODING_JOBS = "yasmin_coding_jobs"
    }
}
