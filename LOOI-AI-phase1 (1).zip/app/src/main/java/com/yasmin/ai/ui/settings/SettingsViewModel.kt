package com.yasmin.ai.ui.settings

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.yasmin.ai.YasminApplication
import com.yasmin.ai.ai.AiModelOption
import com.yasmin.ai.ai.AiResult
import com.yasmin.ai.ai.GeminiBackendClient
import com.yasmin.ai.data.preferences.YasminUserPreferences
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class ProviderConnectionUi(
    val connected: Boolean = false,
    val statusText: String = "Disconnected"
)

class SettingsViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = (application as YasminApplication).repository

    val preferences: StateFlow<YasminUserPreferences> = repository.preferencesFlow.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        YasminUserPreferences()
    )

    private val _hasSavedGeminiKey = MutableStateFlow(repository.hasGeminiApiKey())
    val hasSavedGeminiKey: StateFlow<Boolean> = _hasSavedGeminiKey.asStateFlow()

    private val _geminiKeyMasked = MutableStateFlow(repository.getGeminiKeyMasked())
    val geminiKeyMasked: StateFlow<String> = _geminiKeyMasked.asStateFlow()

    private val _hasSavedGroqKey = MutableStateFlow(repository.hasGroqApiKey())
    val hasSavedGroqKey: StateFlow<Boolean> = _hasSavedGroqKey.asStateFlow()

    private val _groqKeyMasked = MutableStateFlow(repository.getGroqKeyMasked())
    val groqKeyMasked: StateFlow<String> = _groqKeyMasked.asStateFlow()

    private val _hasSavedToken = MutableStateFlow(repository.hasProxyAuthToken())
    val hasSavedToken: StateFlow<Boolean> = _hasSavedToken.asStateFlow()

    private val _youTubeKeyMasked = MutableStateFlow(repository.getYouTubeKeyMasked())
    val youTubeKeyMasked: StateFlow<String> = _youTubeKeyMasked.asStateFlow()

    private val _geminiConnection = MutableStateFlow(
        ProviderConnectionUi(
            connected = false,
            statusText = if (repository.hasGeminiApiKey()) "Saved · Tap Test" else "Disconnected"
        )
    )
    val geminiConnection: StateFlow<ProviderConnectionUi> = _geminiConnection.asStateFlow()

    private val _groqConnection = MutableStateFlow(
        ProviderConnectionUi(
            connected = false,
            statusText = if (repository.hasGroqApiKey()) "Saved · Tap Test" else "Disconnected"
        )
    )
    val groqConnection: StateFlow<ProviderConnectionUi> = _groqConnection.asStateFlow()

    private val _geminiModels = MutableStateFlow(
        listOf(
            AiModelOption("gemini-2.5-flash", "gemini-2.5-flash", GeminiBackendClient.PROVIDER_GEMINI_DIRECT),
            AiModelOption("gemini-2.5-pro", "gemini-2.5-pro", GeminiBackendClient.PROVIDER_GEMINI_DIRECT),
            AiModelOption("gemini-2.0-flash", "gemini-2.0-flash", GeminiBackendClient.PROVIDER_GEMINI_DIRECT)
        )
    )
    val geminiModels: StateFlow<List<AiModelOption>> = _geminiModels.asStateFlow()

    private val _groqModels = MutableStateFlow(
        listOf(
            AiModelOption("llama-3.3-70b-versatile", "llama-3.3-70b-versatile", GeminiBackendClient.PROVIDER_GROQ),
            AiModelOption("llama-3.1-8b-instant", "llama-3.1-8b-instant", GeminiBackendClient.PROVIDER_GROQ),
            AiModelOption("qwen/qwen3-32b", "qwen/qwen3-32b", GeminiBackendClient.PROVIDER_GROQ)
        )
    )
    val groqModels: StateFlow<List<AiModelOption>> = _groqModels.asStateFlow()

    private val _toastMessage = MutableSharedFlow<String>()
    val toastMessage: SharedFlow<String> = _toastMessage.asSharedFlow()

    fun saveAndVerifyAllProviders(
        userName: String,
        providerType: String,
        newGeminiKey: String,
        geminiModel: String,
        newGroqKey: String,
        groqModel: String,
        proxyUrl: String,
        newProxyToken: String,
        autoFallback: Boolean
    ) {
        viewModelScope.launch {
            if (userName.isNotBlank()) repository.updateUserName(userName)

            if (newGeminiKey.isNotBlank()) {
                repository.saveGeminiApiKey(newGeminiKey.trim())
                _hasSavedGeminiKey.value = true
                _geminiKeyMasked.value = repository.getGeminiKeyMasked()
            }
            if (newGroqKey.isNotBlank()) {
                repository.saveGroqApiKey(newGroqKey.trim())
                _hasSavedGroqKey.value = true
                _groqKeyMasked.value = repository.getGroqKeyMasked()
            }
            if (newProxyToken.isNotBlank()) {
                repository.saveProxyAuthToken(newProxyToken.trim())
                _hasSavedToken.value = true
            }

            val cleanProxy = proxyUrl.trim().trimEnd('/')

            repository.updateProxyUrl(cleanProxy)
            repository.updateProviderConfig(
                type = providerType,
                geminiModel = geminiModel.ifBlank { GeminiBackendClient.DEFAULT_GEMINI_MODEL },
                groqModel = groqModel.ifBlank { GeminiBackendClient.DEFAULT_GROQ_MODEL },
                autoFallback = autoFallback
            )

            if (!repository.hasAnyAiConfigured()) {
                _toastMessage.emit("Settings saved. Add a Gemini or Groq API key to enable Cloud AI.")
                return@launch
            }
            when (val res = repository.aiProvider.checkHealth()) {
                is AiResult.Success -> _toastMessage.emit("AI providers verified & encrypted in SecureVault.")
                is AiResult.Error -> _toastMessage.emit("Settings saved; active provider check: ${res.message}")
            }
        }
    }

    fun testGeminiConnection(unsavedKeyInput: String) {
        viewModelScope.launch {
            val keyToUse = unsavedKeyInput.trim().ifBlank { null }
            if (keyToUse != null) {
                repository.saveGeminiApiKey(keyToUse)
                _hasSavedGeminiKey.value = true
                _geminiKeyMasked.value = repository.getGeminiKeyMasked()
            }
            _geminiConnection.value = ProviderConnectionUi(false, "Testing…")
            when (val res = repository.testGeminiConnection(keyToUse)) {
                is AiResult.Success -> {
                    _geminiConnection.value = ProviderConnectionUi(true, "Connected")
                    _toastMessage.emit(res.data)
                    fetchGeminiModels(keyToUse)
                }
                is AiResult.Error -> {
                    _geminiConnection.value = ProviderConnectionUi(false, "Disconnected")
                    _toastMessage.emit(res.message)
                }
            }
        }
    }

    fun testGroqConnection(unsavedKeyInput: String) {
        viewModelScope.launch {
            val keyToUse = unsavedKeyInput.trim().ifBlank { null }
            if (keyToUse != null) {
                repository.saveGroqApiKey(keyToUse)
                _hasSavedGroqKey.value = true
                _groqKeyMasked.value = repository.getGroqKeyMasked()
            }
            _groqConnection.value = ProviderConnectionUi(false, "Testing…")
            when (val res = repository.testGroqConnection(keyToUse)) {
                is AiResult.Success -> {
                    _groqConnection.value = ProviderConnectionUi(true, "Connected")
                    _toastMessage.emit(res.data)
                    fetchGroqModels(keyToUse)
                }
                is AiResult.Error -> {
                    _groqConnection.value = ProviderConnectionUi(false, "Disconnected")
                    _toastMessage.emit(res.message)
                }
            }
        }
    }

    fun fetchGeminiModels(unsavedKeyInput: String? = null) {
        viewModelScope.launch {
            val keyToUse = unsavedKeyInput?.trim()?.ifBlank { null }
            if (keyToUse != null) {
                repository.saveGeminiApiKey(keyToUse)
                _hasSavedGeminiKey.value = true
                _geminiKeyMasked.value = repository.getGeminiKeyMasked()
            }
            when (val res = repository.fetchGeminiModels(keyToUse)) {
                is AiResult.Success -> {
                    _geminiModels.value = res.data
                    _geminiConnection.value = ProviderConnectionUi(true, "Connected")
                    _toastMessage.emit("Loaded ${res.data.size} Gemini models.")
                }
                is AiResult.Error -> _toastMessage.emit(res.message)
            }
        }
    }

    fun fetchGroqModels(unsavedKeyInput: String? = null) {
        viewModelScope.launch {
            val keyToUse = unsavedKeyInput?.trim()?.ifBlank { null }
            if (keyToUse != null) {
                repository.saveGroqApiKey(keyToUse)
                _hasSavedGroqKey.value = true
                _groqKeyMasked.value = repository.getGroqKeyMasked()
            }
            when (val res = repository.fetchGroqModels(keyToUse)) {
                is AiResult.Success -> {
                    _groqModels.value = res.data
                    _groqConnection.value = ProviderConnectionUi(true, "Connected")
                    _toastMessage.emit("Loaded ${res.data.size} Groq models.")
                }
                is AiResult.Error -> _toastMessage.emit(res.message)
            }
        }
    }

    fun clearGeminiKey() {
        repository.clearGeminiApiKey()
        _hasSavedGeminiKey.value = false
        _geminiKeyMasked.value = ""
        _geminiConnection.value = ProviderConnectionUi(false, "Disconnected")
        viewModelScope.launch { _toastMessage.emit("Gemini API key removed from SecureVault.") }
    }

    fun clearGroqKey() {
        repository.clearGroqApiKey()
        _hasSavedGroqKey.value = false
        _groqKeyMasked.value = ""
        _groqConnection.value = ProviderConnectionUi(false, "Disconnected")
        viewModelScope.launch { _toastMessage.emit("Groq API key removed from SecureVault.") }
    }

    fun saveYouTubeApiKey(rawKey: String) {
        val trimmed = rawKey.trim()
        if (trimmed.isEmpty()) {
            viewModelScope.launch { _toastMessage.emit("Enter a YouTube Data API v3 key first.") }
            return
        }
        repository.saveYouTubeApiKey(trimmed)
        _youTubeKeyMasked.value = repository.getYouTubeKeyMasked()
        viewModelScope.launch { _toastMessage.emit("YouTube Data API v3 key encrypted in SecureVault.") }
    }

    fun clearYouTubeApiKey() {
        repository.clearYouTubeApiKey()
        _youTubeKeyMasked.value = ""
        viewModelScope.launch { _toastMessage.emit("YouTube Data API v3 key removed from SecureVault.") }
    }

    fun setPrimaryProvider(type: String) {
        viewModelScope.launch { repository.updatePrimaryProvider(type) }
    }

    fun setGeminiModel(modelId: String) {
        viewModelScope.launch { repository.updateGeminiModel(modelId) }
    }

    fun setGroqModel(modelId: String) {
        viewModelScope.launch { repository.updateGroqModel(modelId) }
    }

    fun setAutoFallback(enabled: Boolean) {
        viewModelScope.launch { repository.updateAutoFallback(enabled) }
    }

    fun setAiPersonality(personality: String) {
        viewModelScope.launch { repository.updateAiPersonality(personality) }
    }

    fun setTtsVoiceName(voiceName: String) {
        viewModelScope.launch { repository.updateTtsVoiceName(voiceName) }
    }

    fun setLanguageMode(mode: String) {
        viewModelScope.launch { repository.updateLanguageMode(mode) }
    }

    fun setAutoSpeak(enabled: Boolean) {
        viewModelScope.launch { repository.updateAutoSpeak(enabled) }
    }

    fun setContinuousMode(enabled: Boolean) {
        viewModelScope.launch { repository.updateContinuousConversation(enabled) }
    }

    fun setBargeInEnabled(enabled: Boolean) {
        viewModelScope.launch { repository.updateBargeInEnabled(enabled) }
    }

    fun setSpeechRate(rate: Float) {
        viewModelScope.launch { repository.updateSpeechRate(rate) }
    }

    fun setSpeechPitch(pitch: Float) {
        viewModelScope.launch { repository.updateSpeechPitch(pitch) }
    }

    fun setWakeSensitivity(sensitivity: Int) {
        viewModelScope.launch { repository.updateWakeSensitivity(sensitivity) }
    }

    fun setScreenConsent(allowed: Boolean) {
        viewModelScope.launch { repository.updateScreenConsent(allowed) }
    }

    fun setCodingSettings(defaultLang: String, autoDocs: Boolean, useBackgroundWorker: Boolean) {
        viewModelScope.launch { repository.updateCodingSettings(defaultLang, autoDocs, useBackgroundWorker) }
    }

    fun setExternalEditorPackage(pkg: String) {
        viewModelScope.launch { repository.updateExternalEditorPackage(pkg) }
    }

    fun setStorageTreeUri(uriString: String) {
        viewModelScope.launch { repository.updateStorageTreeUri(uriString) }
    }

    fun clearHistory() {
        viewModelScope.launch {
            repository.clearChatHistory()
            repository.clearVoiceHistory()
            _toastMessage.emit("Conversation and voice command history cleared.")
        }
    }

    fun resetPreferences() {
        viewModelScope.launch {
            repository.resetAllPreferences()
            _hasSavedGeminiKey.value = false
            _geminiKeyMasked.value = ""
            _hasSavedGroqKey.value = false
            _groqKeyMasked.value = ""
            _hasSavedToken.value = false
            _youTubeKeyMasked.value = ""
            _geminiConnection.value = ProviderConnectionUi(false, "Disconnected")
            _groqConnection.value = ProviderConnectionUi(false, "Disconnected")
            _toastMessage.emit("All saved preferences and encrypted SecureVault keys deleted.")
        }
    }
}
