package com.yasmin.ai.ui.settings

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.yasmin.ai.YasminApplication
import com.yasmin.ai.ai.AiResult
import com.yasmin.ai.data.preferences.YasminUserPreferences
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class SettingsViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = (application as YasminApplication).repository

    val preferences: StateFlow<YasminUserPreferences> = repository.preferencesFlow.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        YasminUserPreferences()
    )

    private val _hasSavedToken = MutableStateFlow(repository.hasProxyAuthToken())
    val hasSavedToken: StateFlow<Boolean> = _hasSavedToken.asStateFlow()

    private val _hasSavedCustomKey = MutableStateFlow(repository.hasCustomProviderKey())
    val hasSavedCustomKey: StateFlow<Boolean> = _hasSavedCustomKey.asStateFlow()

    private val _toastMessage = MutableSharedFlow<String>()
    val toastMessage: SharedFlow<String> = _toastMessage.asSharedFlow()

    fun saveAndTestProviders(
        userName: String,
        proxyUrl: String,
        newProxyToken: String,
        providerType: String,
        customUrl: String,
        customModel: String,
        newCustomKey: String,
        autoFallback: Boolean
    ) {
        viewModelScope.launch {
            if (userName.isNotBlank()) {
                repository.updateUserName(userName)
            }
            if (newProxyToken.isNotBlank()) {
                repository.saveProxyAuthToken(newProxyToken.trim())
                _hasSavedToken.value = true
            }
            if (newCustomKey.isNotBlank()) {
                repository.saveCustomProviderKey(newCustomKey.trim())
                _hasSavedCustomKey.value = true
            }

            val cleanProxy = proxyUrl.trim().trimEnd('/')
            val cleanCustomUrl = customUrl.trim().trimEnd('/')
            val cleanModel = customModel.trim().ifBlank { "gpt-4o-mini" }

            repository.updateProxyUrl(cleanProxy)
            repository.updateProviderConfig(
                type = providerType,
                customUrl = cleanCustomUrl,
                customModel = cleanModel,
                autoFallback = autoFallback
            )

            if (cleanProxy.isBlank() && cleanCustomUrl.isBlank()) {
                _toastMessage.emit("Personalization saved. Add a backend proxy or OpenAI-compatible URL to enable Cloud AI.")
                return@launch
            }
            when (val res = repository.aiProvider.checkHealth()) {
                is AiResult.Success -> _toastMessage.emit("AI providers connected & settings saved in SecureVault.")
                is AiResult.Error -> _toastMessage.emit("Saved settings, but connection check returned: ${res.message}")
            }
        }
    }

    fun setAiPersonality(personality: String) {
        viewModelScope.launch { repository.updateAiPersonality(personality) }
    }

    fun setTtsVoiceName(voiceName: String) {
        viewModelScope.launch { repository.updateTtsVoiceName(voiceName) }
    }

    fun setLanguageMode(mode: String) {
        viewModelScope.launch { repository.updateLanguageMode(mode) }
    }

    fun setAutoSpeak(enabled: Boolean) {
        viewModelScope.launch { repository.updateAutoSpeak(enabled) }
    }

    fun setContinuousMode(enabled: Boolean) {
        viewModelScope.launch { repository.updateContinuousConversation(enabled) }
    }

    fun setSpeechRate(rate: Float) {
        viewModelScope.launch { repository.updateSpeechRate(rate) }
    }

    fun setSpeechPitch(pitch: Float) {
        viewModelScope.launch { repository.updateSpeechPitch(pitch) }
    }

    fun setWakeSensitivity(sensitivity: Int) {
        viewModelScope.launch { repository.updateWakeSensitivity(sensitivity) }
    }

    fun setScreenConsent(allowed: Boolean) {
        viewModelScope.launch { repository.updateScreenConsent(allowed) }
    }

    fun clearHistory() {
        viewModelScope.launch {
            repository.clearChatHistory()
            repository.clearVoiceHistory()
            _toastMessage.emit("Conversation and voice command history cleared.")
        }
    }

    fun resetPreferences() {
        viewModelScope.launch {
            repository.resetAllPreferences()
            _hasSavedToken.value = false
            _hasSavedCustomKey.value = false
            _toastMessage.emit("All saved preferences and encrypted SecureVault tokens deleted.")
        }
    }
}
