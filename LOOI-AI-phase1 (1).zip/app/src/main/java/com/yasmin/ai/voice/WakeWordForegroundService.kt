package com.yasmin.ai.voice

import android.Manifest
import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.yasmin.ai.MainActivity
import com.yasmin.ai.R
import com.yasmin.ai.YasminApplication
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class WakeWordForegroundService : Service() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var wakeEngine: WakeWordEngine? = null
    private var sensitivity = 60
    private var isPausedForSpeech = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val repo = (application as YasminApplication).repository
        serviceScope.launch {
            repo.preferencesFlow.collect { prefs ->
                sensitivity = prefs.wakeSensitivity
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                shutdownService(syncPreference = true)
                return START_NOT_STICKY
            }
            ACTION_PAUSE -> {
                isPausedForSpeech = true
                wakeEngine?.stop()
                _wakeStatus.value = WakeEngineState.COOLDOWN
                val nm = getSystemService(NotificationManager::class.java)
                nm?.notify(NOTIFICATION_ID, buildNotification("Wake engine paused during voice input…"))
                return START_STICKY
            }
            ACTION_RESUME -> {
                isPausedForSpeech = false
                if (_isRunning.value) {
                    wakeEngine?.start(serviceScope)
                }
                return START_STICKY
            }
        }

        // Guard against Android 14+ SecurityException when microphone permission is missing
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED
        ) {
            shutdownService(syncPreference = true)
            return START_NOT_STICKY
        }

        isPausedForSpeech = false
        val notification = buildNotification("Listening for \"Hey Yasmin\" (Offline VAD active)…")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }

        if (wakeEngine == null) {
            wakeEngine = WakeWordEngine(
                context = this,
                sensitivityPercent = { sensitivity },
                onWakeDetected = {
                    sendBroadcast(Intent(ACTION_WAKE_TRIGGERED).setPackage(packageName))
                    val nm = getSystemService(NotificationManager::class.java)
                    nm?.notify(
                        NOTIFICATION_ID,
                        buildNotification("\"Hey Yasmin\" detected! Tap here to speak.")
                    )
                    try {
                        val launch = Intent(this, MainActivity::class.java).apply {
                            putExtra(EXTRA_TRIGGER_VOICE, true)
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                        }
                        startActivity(launch)
                    } catch (_: Exception) {
                        // Android 10+ may restrict background activity launch; notification intent remains ready
                    }
                }
            )
            serviceScope.launch {
                wakeEngine?.engineState?.collect { st ->
                    if (!isPausedForSpeech || st == WakeEngineState.STOPPED) {
                        _wakeStatus.value = st
                        val text = when (st) {
                            WakeEngineState.STOPPED -> if (isPausedForSpeech) "Paused for speech recognition…" else "Wake engine stopped"
                            WakeEngineState.CALIBRATING -> "Calibrating ambient noise floor…"
                            WakeEngineState.MONITORING_VAD -> "Monitoring voice activity for \"Hey Yasmin\""
                            WakeEngineState.VERIFYING_WAKE_PHRASE -> "Verifying wake phrase…"
                            WakeEngineState.COOLDOWN -> "Wake cooldown active…"
                        }
                        val nm = getSystemService(NotificationManager::class.java)
                        nm?.notify(NOTIFICATION_ID, buildNotification(text))
                    }
                }
            }
        }
        if (!isPausedForSpeech) {
            wakeEngine?.start(serviceScope)
        }
        _isRunning.value = true
        return START_STICKY
    }

    private fun shutdownService(syncPreference: Boolean) {
        isPausedForSpeech = false
        wakeEngine?.stop()
        wakeEngine = null
        _isRunning.value = false
        _wakeStatus.value = WakeEngineState.STOPPED
        if (syncPreference) {
            val repo = (application as YasminApplication).repository
            CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
                repo.updateWakeSession(false)
            }
        }
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        wakeEngine?.stop()
        serviceScope.cancel()
        _isRunning.value = false
        _wakeStatus.value = WakeEngineState.STOPPED
        super.onDestroy()
    }

    private fun buildNotification(statusText: String): Notification {
        val openIntent = Intent(this, MainActivity::class.java).apply {
            putExtra(EXTRA_TRIGGER_VOICE, true)
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val openPending = PendingIntent.getActivity(
            this,
            100,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = Intent(this, WakeWordForegroundService::class.java).apply {
            action = ACTION_STOP
        }
        val stopPending = PendingIntent.getService(
            this,
            101,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, YasminApplication.CHANNEL_WAKE_SESSION)
            .setSmallIcon(R.drawable.ic_mic)
            .setContentTitle("Yasmin AI Wake Word Engine")
            .setContentText(statusText)
            .setOngoing(true)
            .setContentIntent(openPending)
            .addAction(R.drawable.ic_stop, "Stop", stopPending)
            .build()
    }

    companion object {
        const val NOTIFICATION_ID = 4101
        const val ACTION_STOP = "com.yasmin.ai.ACTION_STOP_WAKE"
        const val ACTION_PAUSE = "com.yasmin.ai.ACTION_PAUSE_WAKE"
        const val ACTION_RESUME = "com.yasmin.ai.ACTION_RESUME_WAKE"
        const val ACTION_WAKE_TRIGGERED = "com.yasmin.ai.ACTION_WAKE_TRIGGERED"
        const val EXTRA_TRIGGER_VOICE = "extra_trigger_voice"

        private val _isRunning = MutableStateFlow(false)
        val isRunning: StateFlow<Boolean> = _isRunning.asStateFlow()

        private val _wakeStatus = MutableStateFlow(WakeEngineState.STOPPED)
        val wakeStatus: StateFlow<WakeEngineState> = _wakeStatus.asStateFlow()

        fun start(context: Context) {
            val intent = Intent(context, WakeWordForegroundService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun pauseEngine(context: Context) {
            if (!_isRunning.value) return
            val intent = Intent(context, WakeWordForegroundService::class.java).apply {
                action = ACTION_PAUSE
            }
            context.startService(intent)
        }

        fun resumeEngine(context: Context) {
            if (!_isRunning.value) return
            val intent = Intent(context, WakeWordForegroundService::class.java).apply {
                action = ACTION_RESUME
            }
            context.startService(intent)
        }

        fun stop(context: Context) {
            if (!_isRunning.value) return
            val intent = Intent(context, WakeWordForegroundService::class.java).apply {
                action = ACTION_STOP
            }
            context.startService(intent)
        }
    }
}
