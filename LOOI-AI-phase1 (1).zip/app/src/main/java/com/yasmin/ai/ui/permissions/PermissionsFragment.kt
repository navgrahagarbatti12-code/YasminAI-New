package com.yasmin.ai.ui.permissions

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.yasmin.ai.accessibility.YasminAccessibilityService
import com.yasmin.ai.automation.YasminNotificationListenerService
import com.yasmin.ai.databinding.FragmentPermissionsBinding

class PermissionsFragment : Fragment() {

    private var _binding: FragmentPermissionsBinding? = null
    private val binding get() = _binding!!

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) {
        refreshPermissionStatuses()
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentPermissionsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.btnGrantMic.setOnClickListener {
            permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }

        binding.btnGrantNotifications.setOnClickListener {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }

        binding.btnGrantContacts.setOnClickListener {
            permissionLauncher.launch(Manifest.permission.READ_CONTACTS)
        }

        binding.btnGrantCalendar.setOnClickListener {
            permissionLauncher.launch(Manifest.permission.READ_CALENDAR)
        }

        binding.btnOpenNotificationAccess.setOnClickListener {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }

        binding.btnOpenAccessibility.setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        binding.btnPermissionsDone.setOnClickListener {
            findNavController().popBackStack()
        }

        refreshPermissionStatuses()
    }

    override fun onResume() {
        super.onResume()
        refreshPermissionStatuses()
    }

    private fun refreshPermissionStatuses() {
        val micGranted = ContextCompat.checkSelfPermission(
            requireContext(),
            Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED
        binding.tvMicPermStatus.text =
            "Microphone (RECORD_AUDIO): ${if (micGranted) "GRANTED" else "NOT GRANTED"}"
        binding.btnGrantMic.isEnabled = !micGranted

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val notifGranted = ContextCompat.checkSelfPermission(
                requireContext(),
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            binding.tvNotificationPermStatus.text =
                "Notifications (Android 13+): ${if (notifGranted) "GRANTED" else "NOT GRANTED"}"
            binding.btnGrantNotifications.isEnabled = !notifGranted
        } else {
            binding.tvNotificationPermStatus.text = "Notifications: GRANTED (Pre-Android 13)"
            binding.btnGrantNotifications.isEnabled = false
        }

        val contactsGranted = ContextCompat.checkSelfPermission(
            requireContext(),
            Manifest.permission.READ_CONTACTS
        ) == PackageManager.PERMISSION_GRANTED
        binding.tvContactsPermStatus.text =
            "Contacts (READ_CONTACTS): ${if (contactsGranted) "GRANTED" else "NOT GRANTED"}"
        binding.btnGrantContacts.isEnabled = !contactsGranted

        val calendarGranted = ContextCompat.checkSelfPermission(
            requireContext(),
            Manifest.permission.READ_CALENDAR
        ) == PackageManager.PERMISSION_GRANTED
        binding.tvCalendarPermStatus.text =
            "Calendar (READ_CALENDAR): ${if (calendarGranted) "GRANTED" else "NOT GRANTED"}"
        binding.btnGrantCalendar.isEnabled = !calendarGranted

        val enabledListeners = Settings.Secure.getString(
            requireContext().contentResolver,
            "enabled_notification_listeners"
        ).orEmpty()
        val notifListenerEnabled = YasminNotificationListenerService.instance != null ||
            enabledListeners.contains(requireContext().packageName)
        binding.tvNotificationAccessStatus.text =
            "Notification Reader Service: ${if (notifListenerEnabled) "ACTIVE" else "DISABLED"}"

        val accConnected = YasminAccessibilityService.instance != null
        binding.tvAccessibilityStatus.text =
            "Accessibility Service: ${if (accConnected) "ACTIVE" else "DISABLED"}"
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
