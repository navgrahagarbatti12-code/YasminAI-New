package com.yasmin.ai.ui.python

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.OpenableColumns
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.fragment.app.viewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.yasmin.ai.R
import com.yasmin.ai.coding.CodeIntelligenceHelper
import com.yasmin.ai.coding.ProjectFileManager
import com.yasmin.ai.coding.SyntaxHighlighter
import com.yasmin.ai.databinding.FragmentPythonBinding
import com.yasmin.ai.ui.home.YasminSharedViewModel
import kotlinx.coroutines.launch

class PythonFragment : Fragment() {

    private var _binding: FragmentPythonBinding? = null
    private val binding get() = _binding!!
    private val viewModel: PythonViewModel by viewModels()
    private val sharedViewModel: YasminSharedViewModel by activityViewModels()
    private lateinit var fileManager: ProjectFileManager
    private var currentFileName = "main.py"
    private var isProgrammaticEdit = false

    private val importPythonLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri == null) return@registerForActivityResult
        val imported = fileManager.importTextFromUri(uri)
        if (imported == null) {
            Toast.makeText(requireContext(), "Unable to read selected Python file.", Toast.LENGTH_SHORT).show()
            return@registerForActivityResult
        }
        val displayName = resolveDisplayName(uri) ?: "imported.py"
        currentFileName = if (displayName.endsWith(".py")) displayName else "$displayName.py"
        binding.tvPythonFileName.text = "$currentFileName (Sandbox Active)"
        viewModel.updateCode(imported)
        Toast.makeText(requireContext(), "Imported $currentFileName", Toast.LENGTH_SHORT).show()
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentPythonBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        fileManager = ProjectFileManager(requireContext())

        setupEditor()
        setupSnippetChips()
        setupButtons()
        observeState()

        val incomingPrompt = sharedViewModel.consumePendingCodingPrompt()
        if (incomingPrompt.isNotBlank()) {
            binding.etPythonPrompt.setText(incomingPrompt)
            viewModel.generateWithGemini(incomingPrompt)
        }
    }

    private fun setupSnippetChips() {
        binding.pythonSnippetsRow.removeAllViews()
        val marginPx = (6 * resources.displayMetrics.density).toInt()
        CodeIntelligenceHelper.pythonSnippets.forEach { snippet ->
            val btn = Button(requireContext()).apply {
                text = snippet.label
                isAllCaps = false
                textSize = 11f
                setTextColor(ContextCompat.getColor(requireContext(), R.color.jarvis_cyan))
                setBackgroundResource(R.drawable.bg_status_chip)
                setPadding(20, 4, 20, 4)
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    (32 * resources.displayMetrics.density).toInt()
                ).apply { marginEnd = marginPx }
                setOnClickListener {
                    val cursor = binding.etPythonEditor.selectionStart.coerceAtLeast(0)
                    binding.etPythonEditor.text?.insert(cursor, snippet.insertText)
                }
            }
            binding.pythonSnippetsRow.addView(btn)
        }
    }

    private fun resolveDisplayName(uri: android.net.Uri): String? {
        return try {
            requireContext().contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (idx >= 0 && cursor.moveToFirst()) cursor.getString(idx) else null
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun setupEditor() {
        binding.etPythonEditor.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                if (s == null) return
                SyntaxHighlighter.highlight(requireContext(), s, "python")
                if (!isProgrammaticEdit) {
                    viewModel.updateCode(s.toString())
                }
            }
        })
    }

    private fun setupButtons() {
        binding.btnPythonSandboxMode.setOnClickListener {
            viewModel.toggleSandboxMode()
        }

        binding.btnPythonLint.setOnClickListener {
            viewModel.runStaticLint(binding.etPythonEditor.text?.toString().orEmpty())
        }

        binding.btnPythonGenerate.setOnClickListener {
            val prompt = binding.etPythonPrompt.text?.toString()?.trim().orEmpty()
            if (prompt.isEmpty()) {
                Toast.makeText(requireContext(), "Enter a Python prompt first.", Toast.LENGTH_SHORT).show()
            } else {
                viewModel.generateWithGemini(prompt)
            }
        }

        binding.btnPythonRun.setOnClickListener {
            val codeToRun = binding.etPythonEditor.text?.toString().orEmpty()
            if (codeToRun.isBlank()) {
                Toast.makeText(requireContext(), "Editor is empty.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val warning = buildString {
                if (viewModel.isAiGenerated.value) {
                    append("You are about to run AI-generated Python code.\n\n")
                } else {
                    append("Execute $currentFileName?\n\n")
                }
                if (viewModel.useRemoteSandbox.value) {
                    append("Backend OS-Isolated Subprocess: Runs in clean temp dir with RLIMIT_AS/CPU/FSIZE caps, scrubbed environment (no API keys), disabled sockets, and 4.5s SIGKILL.")
                } else {
                    append("On-Device Chaquopy AST Sandbox: Blocks os/sys/open/eval/network and aborts after 4s or 400k steps.")
                }
            }

            MaterialAlertDialogBuilder(requireContext())
                .setTitle("Confirm Sandboxed Python Execution")
                .setMessage(warning)
                .setPositiveButton("Execute") { _, _ ->
                    viewModel.executeApprovedCode(codeToRun)
                }
                .setNegativeButton("Cancel", null)
                .show()
        }

        binding.btnPythonFix.setOnClickListener { viewModel.debugWithGemini() }
        binding.btnPythonExplain.setOnClickListener { viewModel.explainWithGemini() }
        binding.btnPythonFormat.setOnClickListener { viewModel.formatCode() }
        binding.btnPythonClearOutput.setOnClickListener { viewModel.clearOutput() }

        binding.btnPythonImport.setOnClickListener {
            importPythonLauncher.launch(arrayOf("text/*", "application/octet-stream", "*/*"))
        }

        binding.btnPythonCopy.setOnClickListener {
            val cm = requireContext().getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("Python Code", binding.etPythonEditor.text.toString()))
            Toast.makeText(requireContext(), "Python code copied.", Toast.LENGTH_SHORT).show()
        }

        binding.btnPythonSave.setOnClickListener {
            val input = EditText(requireContext()).apply { setText(currentFileName) }
            MaterialAlertDialogBuilder(requireContext())
                .setTitle("Save Python Script")
                .setView(input)
                .setPositiveButton("Save") { _, _ ->
                    val name = input.text?.toString()?.trim().orEmpty().ifBlank { "main.py" }
                    val saved = fileManager.savePythonFile(name, binding.etPythonEditor.text.toString())
                    currentFileName = saved.name
                    binding.tvPythonFileName.text = "${saved.name} (Sandbox Active)"
                    Toast.makeText(requireContext(), "Saved ${saved.name}", Toast.LENGTH_SHORT).show()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }

        binding.btnPythonOpen.setOnClickListener {
            val files = fileManager.listPythonFiles()
            if (files.isEmpty()) {
                Toast.makeText(requireContext(), "No saved .py files yet.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val names = files.map { it.name }.toTypedArray()
            MaterialAlertDialogBuilder(requireContext())
                .setTitle("Open Python Script")
                .setItems(names) { _, which ->
                    val chosen = files[which]
                    currentFileName = chosen.name
                    binding.tvPythonFileName.text = "${chosen.name} (Sandbox Active)"
                    viewModel.updateCode(chosen.readText())
                }
                .show()
        }

        binding.btnPythonShare.setOnClickListener {
            val choices = arrayOf(
                "Open $currentFileName in External Editor",
                "Share $currentFileName File",
                "Copy & Export to GitHub Gist",
                "Open Multi-Language AI Coding Agent"
            )
            MaterialAlertDialogBuilder(requireContext())
                .setTitle("External Editor & Export")
                .setItems(choices) { _, which ->
                    val codeText = binding.etPythonEditor.text.toString()
                    when (which) {
                        0 -> {
                            val saved = fileManager.savePythonFile(currentFileName, codeText)
                            val preferred = sharedViewModel.preferences.value.externalEditorPackage
                            when (val res = com.yasmin.ai.coding.ExternalEditorHelper.openFileInExternalEditor(requireContext(), saved, preferred)) {
                                is com.yasmin.ai.coding.OpenEditorResult.Launched -> {
                                    Toast.makeText(requireContext(), "Opened ${saved.name} in ${res.targetLabel}", Toast.LENGTH_SHORT).show()
                                }
                                is com.yasmin.ai.coding.OpenEditorResult.NoEditorInstalled -> {
                                    MaterialAlertDialogBuilder(requireContext())
                                        .setTitle("No External Code Editor Installed")
                                        .setMessage("No compatible Android text/code editor was detected. You can share or export ${saved.name} instead.")
                                        .setPositiveButton("Share File") { _, _ ->
                                            startActivity(Intent.createChooser(fileManager.createShareFileIntent(saved, "text/x-python"), "Share ${saved.name}"))
                                        }
                                        .setNegativeButton("Close", null)
                                        .show()
                                }
                                is com.yasmin.ai.coding.OpenEditorResult.Failed -> {
                                    Toast.makeText(requireContext(), res.message, Toast.LENGTH_SHORT).show()
                                }
                            }
                        }
                        1 -> {
                            val saved = fileManager.savePythonFile(currentFileName, codeText)
                            val intent = fileManager.createShareFileIntent(saved, "text/x-python")
                            startActivity(Intent.createChooser(intent, "Share $currentFileName"))
                        }
                        2 -> CodeIntelligenceHelper.openGitHubGistExport(requireContext(), currentFileName, codeText)
                        else -> androidx.navigation.fragment.NavHostFragment.findNavController(this@PythonFragment).navigate(R.id.codingAgentFragment)
                    }
                }
                .show()
        }
    }

    private fun observeState() {
        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch {
                    viewModel.code.collect { codeText ->
                        val current = binding.etPythonEditor.text?.toString().orEmpty()
                        if (current != codeText) {
                            isProgrammaticEdit = true
                            binding.etPythonEditor.setText(codeText)
                            isProgrammaticEdit = false
                        }
                    }
                }
                launch {
                    viewModel.output.collect { outText ->
                        binding.tvPythonOutput.text = outText
                    }
                }
                launch {
                    viewModel.isErrorOutput.collect { isErr ->
                        val colorRes = if (isErr) R.color.jarvis_error else R.color.jarvis_success
                        binding.tvPythonOutput.setTextColor(ContextCompat.getColor(requireContext(), colorRes))
                    }
                }
                launch {
                    viewModel.useRemoteSandbox.collect { remote ->
                        binding.btnPythonSandboxMode.text = if (remote) {
                            "Sandbox: Backend OS-Isolated"
                        } else {
                            "Sandbox: Local Chaquopy AST"
                        }
                    }
                }
                launch {
                    viewModel.isLoading.collect { loading ->
                        binding.btnPythonRun.isEnabled = !loading
                        binding.btnPythonGenerate.isEnabled = !loading
                        binding.btnPythonFix.isEnabled = !loading
                        binding.btnPythonExplain.isEnabled = !loading
                    }
                }
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
