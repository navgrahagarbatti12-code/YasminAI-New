package com.yasmin.ai.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "chat_messages")
data class ChatMessageEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val role: String, // "user" or "assistant"
    val content: String,
    val language: String = "en",
    val timestamp: Long = System.currentTimeMillis()
)
