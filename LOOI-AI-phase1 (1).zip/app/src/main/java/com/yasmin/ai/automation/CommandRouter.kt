package com.yasmin.ai.automation

import android.media.AudioManager
import android.provider.Settings
import com.yasmin.ai.accessibility.YasminAccessibilityService
import com.yasmin.ai.assistant.CalendarHelper
import java.util.Locale

sealed class CommandActionResult {
    data class Handled(val responseText: String) : CommandActionResult()
    data class OpenPythonWorkspace(val prompt: String) : CommandActionResult()
    data class OpenHtmlWorkspace(val prompt: String) : CommandActionResult()
    data class OpenCodingAgent(val prompt: String) : CommandActionResult()
    data object OpenVisionWorkspace : CommandActionResult()
    data object OpenDailyHub : CommandActionResult()
    data class OpenYouTubeAgent(
        val initialQuery: String = "",
        val autoMode: String = ""
    ) : CommandActionResult()
    data class ReadScreenWithAi(val screenText: String) : CommandActionResult()
    data object RequestPermissionsSetup : CommandActionResult()
    data object StopVoiceSession : CommandActionResult()
    data class CreateReminder(val rawInput: String, val title: String, val delayMs: Long) : CommandActionResult()
    data class RequiresConfirmation(
        val actionTitle: String,
        val description: String,
        val onConfirmed: () -> String
    ) : CommandActionResult()
    data class UseAiPlanner(val prompt: String) : CommandActionResult()
}

class CommandRouter(
    private val deviceControl: DeviceControlManager,
    private val calendarHelper: CalendarHelper? = null,
    private val youTubeVoiceController: com.yasmin.ai.youtube.YouTubeVoiceController? = null
) {

    fun routeLocalFirst(rawInput: String): CommandActionResult {
        val cleaned = rawInput.trim()
        val lower = cleaned.lowercase(Locale.getDefault())
            .removePrefix("hey yasmin")
            .removePrefix("ok yasmin")
            .trim()

        if (lower.isEmpty()) {
            return CommandActionResult.Handled("Yes, I am listening. How can I help you?")
        }

        if (lower == "stop listening" || lower == "stop yasmin" || lower == "yasmin stop" || lower == "band karo") {
            return CommandActionResult.StopVoiceSession
        }

        if (lower.contains("flashlight on") || lower.contains("turn on flashlight") || lower.contains("torch jalao")) {
            return CommandActionResult.Handled(deviceControl.toggleFlashlight(true))
        }
        if (lower.contains("flashlight off") || lower.contains("turn off flashlight") || lower.contains("torch band")) {
            return CommandActionResult.Handled(deviceControl.toggleFlashlight(false))
        }

        if (lower.contains("volume up") || lower.contains("increase volume") || lower.contains("awaaz badhao")) {
            return CommandActionResult.Handled(deviceControl.adjustVolume(AudioManager.ADJUST_RAISE))
        }
        if (lower.contains("volume down") || lower.contains("decrease volume") || lower.contains("awaaz kam")) {
            return CommandActionResult.Handled(deviceControl.adjustVolume(AudioManager.ADJUST_LOWER))
        }

        val brightnessMatch = Regex("brightness\\s+(?:to\\s+)?(\\d{1,3})").find(lower)
        if (brightnessMatch != null) {
            val pct = brightnessMatch.groupValues[1].toIntOrNull() ?: 60
            return CommandActionResult.Handled(deviceControl.setScreenBrightnessPercent(pct))
        }

        if (lower == "time" || lower.contains("what time") || lower.contains("date and time") || lower.contains("kitna baja")) {
            return CommandActionResult.Handled(deviceControl.getCurrentDateTimeText())
        }
        if (lower.contains("battery") || lower.contains("internet status") || lower.contains("network status")) {
            return CommandActionResult.Handled(deviceControl.getTelemetrySummary())
        }

        if (lower.startsWith("remind me")) {
            val delayMs = com.yasmin.ai.assistant.ReminderScheduler.parseRelativeDelayMs(cleaned)
            if (delayMs != null) {
                val title = cleaned
                    .replace(Regex("(?i)^(?:hey yasmin|ok yasmin)?\\s*remind me\\s+in\\s+\\d+\\s+\\w+\\s*(?:to|about)?\\s*"), "")
                    .ifBlank { "Reminder" }
                return CommandActionResult.CreateReminder(cleaned, title, delayMs)
            }
        }

        if (lower.startsWith("show notification ") || lower.startsWith("notify me ")) {
            val body = cleaned.substringAfter(" ").substringAfter(" ").trim()
            return CommandActionResult.Handled(deviceControl.showLocalNotification("Yasmin AI", body))
        }

        if (calendarHelper != null && (lower.contains("read calendar") || lower.contains("my calendar") || lower.contains("upcoming events"))) {
            return CommandActionResult.Handled(calendarHelper.formatUpcomingEventsText())
        }
        if (calendarHelper != null && (lower.startsWith("add calendar event ") || lower.startsWith("schedule meeting "))) {
            val title = cleaned.substringAfter("event ").substringAfter("meeting ").trim()
            return CommandActionResult.Handled(calendarHelper.openAddCalendarEventIntent(title))
        }

        if (lower.contains("wifi settings")) {
            return CommandActionResult.Handled(deviceControl.openAndroidSettings(Settings.ACTION_WIFI_SETTINGS))
        }
        if (lower.contains("bluetooth settings")) {
            return CommandActionResult.Handled(deviceControl.openAndroidSettings(Settings.ACTION_BLUETOOTH_SETTINGS))
        }
        if (lower.contains("display settings")) {
            return CommandActionResult.Handled(deviceControl.openAndroidSettings(Settings.ACTION_DISPLAY_SETTINGS))
        }
        if (lower.contains("sound settings")) {
            return CommandActionResult.Handled(deviceControl.openAndroidSettings(Settings.ACTION_SOUND_SETTINGS))
        }
        if (lower.contains("battery settings")) {
            return CommandActionResult.Handled(deviceControl.openAndroidSettings(Settings.ACTION_BATTERY_SAVER_SETTINGS))
        }
        if (lower.contains("location settings")) {
            return CommandActionResult.Handled(deviceControl.openAndroidSettings(Settings.ACTION_LOCATION_SOURCE_SETTINGS))
        }
        if (lower.contains("app settings") || lower.contains("applications settings")) {
            return CommandActionResult.Handled(deviceControl.openAndroidSettings(Settings.ACTION_APPLICATION_SETTINGS))
        }
        if (lower.contains("open settings") || lower.contains("phone settings")) {
            return CommandActionResult.Handled(deviceControl.openAndroidSettings(Settings.ACTION_SETTINGS))
        }

        if (lower == "play music" || lower.contains("play music")) {
            return CommandActionResult.Handled(deviceControl.playMusic())
        }

        if (lower.contains("read notifications") || lower.contains("my notifications")) {
            val listener = YasminNotificationListenerService.instance
                ?: return CommandActionResult.RequestPermissionsSetup
            val items = listener.getRecentNotificationSummaries()
            if (items.isEmpty()) {
                return CommandActionResult.Handled("You have no active unread notifications.")
            }
            val summary = items.joinToString("\n") { "• ${it.title}: ${it.text}" }
            return CommandActionResult.Handled("Recent notifications:\n$summary")
        }

        val ytIntent = com.yasmin.ai.youtube.YouTubeVoiceController.parseCommand(cleaned)
        if (ytIntent != null) {
            return when (ytIntent) {
                is com.yasmin.ai.youtube.YouTubeVoiceIntent.OpenYouTubeAgent ->
                    CommandActionResult.OpenYouTubeAgent()
                is com.yasmin.ai.youtube.YouTubeVoiceIntent.SummarizeCurrent ->
                    CommandActionResult.OpenYouTubeAgent(
                        initialQuery = "",
                        autoMode = "summarize:${ytIntent.language?.code.orEmpty()}"
                    )
                is com.yasmin.ai.youtube.YouTubeVoiceIntent.AskAboutVideo ->
                    CommandActionResult.OpenYouTubeAgent(
                        initialQuery = "",
                        autoMode = "ask:${ytIntent.question}"
                    )
                is com.yasmin.ai.youtube.YouTubeVoiceIntent.GenerateNotes ->
                    CommandActionResult.OpenYouTubeAgent(autoMode = "notes")
                is com.yasmin.ai.youtube.YouTubeVoiceIntent.StartLearningOrQuiz ->
                    CommandActionResult.OpenYouTubeAgent(autoMode = "learn")
                else -> {
                    val controller = youTubeVoiceController
                    if (controller != null) {
                        val verification = controller.executeVoiceIntent(ytIntent)
                        if (verification.requiresAccessibilitySetup && !verification.verified) {
                            CommandActionResult.RequestPermissionsSetup
                        } else {
                            CommandActionResult.Handled(verification.message)
                        }
                    } else {
                        when (ytIntent) {
                            is com.yasmin.ai.youtube.YouTubeVoiceIntent.OpenYouTube ->
                                CommandActionResult.Handled(deviceControl.openYouTubeHome())
                            is com.yasmin.ai.youtube.YouTubeVoiceIntent.SearchVideos ->
                                CommandActionResult.Handled(deviceControl.searchYouTube(ytIntent.query))
                            is com.yasmin.ai.youtube.YouTubeVoiceIntent.OpenChannel ->
                                CommandActionResult.Handled(deviceControl.openYouTubeChannel(ytIntent.query))
                            is com.yasmin.ai.youtube.YouTubeVoiceIntent.OpenPlaylist ->
                                CommandActionResult.Handled(
                                    if (ytIntent.isWatchLater) deviceControl.openWatchLater()
                                    else deviceControl.openYouTubePlaylist(ytIntent.query)
                                )
                            else -> CommandActionResult.OpenYouTubeAgent()
                        }
                    }
                }
            }
        }

        if (lower.startsWith("search web for ") || lower.startsWith("search google for ") || lower.startsWith("search internet for ")) {
            val q = cleaned.substringAfter("for ").trim()
            return CommandActionResult.Handled(deviceControl.searchWeb(q))
        }
        if (lower.startsWith("google ") && lower.length > 8) {
            val q = cleaned.substringAfter(" ").trim()
            return CommandActionResult.Handled(deviceControl.searchWeb(q))
        }

        if (lower.startsWith("open url ") || lower.startsWith("open website ")) {
            val url = cleaned.substringAfter("url ").substringAfter("website ").trim()
            return CommandActionResult.Handled(deviceControl.openUrl(url))
        }

        if (lower.startsWith("open ") || lower.startsWith("launch ") || lower.endsWith(" kholo")) {
            val appQuery = when {
                lower.startsWith("open ") -> lower.removePrefix("open ").trim()
                lower.startsWith("launch ") -> lower.removePrefix("launch ").trim()
                else -> lower.removeSuffix(" kholo").trim()
            }
            if (appQuery == "youtube") return CommandActionResult.Handled(deviceControl.openYouTubeHome())
            if (appQuery == "chrome" || appQuery == "google chrome" || appQuery == "browser") {
                return CommandActionResult.Handled(deviceControl.openChrome())
            }
            if (appQuery == "calculator" || appQuery == "calc") {
                return CommandActionResult.Handled(deviceControl.openCalculator())
            }
            if (appQuery == "vision" || appQuery == "camera ai") return CommandActionResult.OpenVisionWorkspace
            if (appQuery == "daily" || appQuery == "tasks" || appQuery == "memory") return CommandActionResult.OpenDailyHub
            if (appQuery == "coding agent" || appQuery == "code agent" || appQuery == "project studio") {
                return CommandActionResult.OpenCodingAgent("")
            }
            if (appQuery.startsWith("http://") || appQuery.startsWith("https://") ||
                Regex("^[a-z0-9-]+\\.[a-z]{2,}(/.*)?$").matches(appQuery)
            ) {
                return CommandActionResult.Handled(deviceControl.openUrl(appQuery))
            }
            return CommandActionResult.Handled(deviceControl.openAppByName(appQuery))
        }

        if (lower.contains("read my screen") || lower.contains("read screen") || lower.contains("screen padho") ||
            lower.contains("screen par kya") || lower.contains("screen pe kya") ||
            lower.contains("what's on my screen") || lower.contains("what is on my screen") ||
            lower.contains("describe screen") || lower.contains("explain screen")
        ) {
            val service = YasminAccessibilityService.instance
                ?: return CommandActionResult.RequestPermissionsSetup
            val structured = service.describeScreenStructured()
            val text = if (structured.isNotBlank()) structured else service.readVisibleScreenText()
            return if (text.isBlank()) {
                CommandActionResult.Handled("No readable text was found on the active screen.")
            } else {
                CommandActionResult.ReadScreenWithAi(text)
            }
        }

        if (lower.contains("list buttons") || lower.contains("show buttons") || lower.contains("buttons dikhao") ||
            lower.contains("what can i click")
        ) {
            val service = YasminAccessibilityService.instance
                ?: return CommandActionResult.RequestPermissionsSetup
            val buttons = service.snapshotUiElements(200).filter { it.clickable && it.label.isNotBlank() }
                .map { it.label }.distinct().take(15)
            return CommandActionResult.Handled(
                if (buttons.isEmpty()) "I could not find any labelled clickable controls on this screen."
                else "Clickable controls I can see:\n" + buttons.joinToString("\n") { "• $it" }
            )
        }

        if (lower.startsWith("type ") || lower.startsWith("likho ")) {
            val toType = cleaned.substringAfter(" ").trim()
            val service = YasminAccessibilityService.instance
                ?: return CommandActionResult.RequestPermissionsSetup
            if (toType.isEmpty()) return CommandActionResult.Handled("Tell me what to type.")
            return CommandActionResult.RequiresConfirmation(
                actionTitle = "Confirm Typing",
                description = "Type \"${toType.take(60)}\" into the focused text field?"
            ) {
                when (val r = service.typeIntoFocusedField(toType)) {
                    is YasminAccessibilityService.ActionOutcome.Done -> r.message
                    is YasminAccessibilityService.ActionOutcome.Failed -> r.reason
                    is YasminAccessibilityService.ActionOutcome.Ambiguous -> "Ambiguous target."
                }
            }
        }

        if (lower.contains("scroll down") || lower.contains("neeche scroll")) {
            val service = YasminAccessibilityService.instance
                ?: return CommandActionResult.RequestPermissionsSetup
            val ok = service.performScrollDown()
            return CommandActionResult.Handled(if (ok) "Scrolled down." else "Nothing scrollable on current screen.")
        }

        if (lower.contains("scroll up") || lower.contains("upar scroll")) {
            val service = YasminAccessibilityService.instance
                ?: return CommandActionResult.RequestPermissionsSetup
            val ok = service.performScrollUp()
            return CommandActionResult.Handled(if (ok) "Scrolled up." else "Nothing scrollable on current screen.")
        }

        if (lower == "go back" || lower == "back navigation") {
            val service = YasminAccessibilityService.instance
                ?: return CommandActionResult.RequestPermissionsSetup
            return CommandActionResult.RequiresConfirmation(
                actionTitle = "Confirm Back Navigation",
                description = "Perform Android global Back action?"
            ) {
                if (service.performBackNavigation()) "Navigated back." else "Back action failed."
            }
        }

        if (lower.startsWith("click ") || lower.startsWith("tap ")) {
            val target = cleaned.substringAfter(" ").trim()
            val service = YasminAccessibilityService.instance
                ?: return CommandActionResult.RequestPermissionsSetup
            // Validate the target BEFORE asking for confirmation.
            val candidates = service.findClickableCandidates(target)
            if (candidates.size > 1) {
                return CommandActionResult.Handled(
                    "'$target' matches several controls: ${candidates.take(6).joinToString(", ")}. Please say the exact one."
                )
            }
            if (candidates.isEmpty()) {
                return CommandActionResult.Handled("I could not find a clickable control named '$target' on this screen.")
            }
            return CommandActionResult.RequiresConfirmation(
                actionTitle = "Confirm UI Click",
                description = "Allow Yasmin AI to click '${candidates.first()}' on screen?"
            ) {
                when (val r = service.clickNodeValidated(candidates.first())) {
                    is YasminAccessibilityService.ActionOutcome.Done -> r.message
                    is YasminAccessibilityService.ActionOutcome.Failed -> r.reason
                    is YasminAccessibilityService.ActionOutcome.Ambiguous -> "Several matches: ${r.candidates.joinToString(", ")}"
                }
            }
        }

        if (lower.contains("write python") || lower.contains("python code") || lower.contains("calculator in python")) {
            return CommandActionResult.OpenPythonWorkspace(cleaned)
        }
        if (lower.contains("create html") || lower.contains("html website") || lower.contains("web page")) {
            return CommandActionResult.OpenHtmlWorkspace(cleaned)
        }
        if (lower.contains("build project") || lower.contains("create project") ||
            lower.contains("multi-file") || lower.contains("coding agent")
        ) {
            return CommandActionResult.OpenCodingAgent(cleaned)
        }

        return CommandActionResult.UseAiPlanner(cleaned)
    }
}
