package com.yasmin.ai.automation

import android.media.AudioManager
import android.provider.Settings
import com.yasmin.ai.accessibility.YasminAccessibilityService
import com.yasmin.ai.assistant.CalendarHelper
import java.util.Locale

sealed class CommandActionResult {
    data class Handled(val responseText: String) : CommandActionResult()
    data class OpenPythonWorkspace(val prompt: String) : CommandActionResult()
    data class OpenHtmlWorkspace(val prompt: String) : CommandActionResult()
    data object OpenVisionWorkspace : CommandActionResult()
    data object OpenDailyHub : CommandActionResult()
    data class ReadScreenWithAi(val screenText: String) : CommandActionResult()
    data object RequestPermissionsSetup : CommandActionResult()
    data object StopVoiceSession : CommandActionResult()
    data class CreateReminder(val rawInput: String, val title: String, val delayMs: Long) : CommandActionResult()
    data class RequiresConfirmation(
        val actionTitle: String,
        val description: String,
        val onConfirmed: () -> String
    ) : CommandActionResult()
    data class UseAiPlanner(val prompt: String) : CommandActionResult()
}

class CommandRouter(
    private val deviceControl: DeviceControlManager,
    private val calendarHelper: CalendarHelper? = null
) {

    fun routeLocalFirst(rawInput: String): CommandActionResult {
        val cleaned = rawInput.trim()
        val lower = cleaned.lowercase(Locale.getDefault())
            .removePrefix("hey yasmin")
            .removePrefix("ok yasmin")
            .trim()

        if (lower.isEmpty()) {
            return CommandActionResult.Handled("Yes, I am listening. How can I assist you?")
        }

        if (lower == "stop listening" || lower == "stop yasmin" || lower == "yasmin stop" || lower == "band karo") {
            return CommandActionResult.StopVoiceSession
        }

        if (lower.contains("flashlight on") || lower.contains("turn on flashlight") || lower.contains("torch jalao")) {
            return CommandActionResult.Handled(deviceControl.toggleFlashlight(true))
        }
        if (lower.contains("flashlight off") || lower.contains("turn off flashlight") || lower.contains("torch band")) {
            return CommandActionResult.Handled(deviceControl.toggleFlashlight(false))
        }

        if (lower.contains("volume up") || lower.contains("increase volume") || lower.contains("awaaz badhao")) {
            return CommandActionResult.Handled(deviceControl.adjustVolume(AudioManager.ADJUST_RAISE))
        }
        if (lower.contains("volume down") || lower.contains("decrease volume") || lower.contains("awaaz kam")) {
            return CommandActionResult.Handled(deviceControl.adjustVolume(AudioManager.ADJUST_LOWER))
        }

        val brightnessMatch = Regex("brightness\\s+(?:to\\s+)?(\\d{1,3})").find(lower)
        if (brightnessMatch != null) {
            val pct = brightnessMatch.groupValues[1].toIntOrNull() ?: 60
            return CommandActionResult.Handled(deviceControl.setScreenBrightnessPercent(pct))
        }

        if (lower == "time" || lower.contains("what time") || lower.contains("date and time") || lower.contains("kitna baja")) {
            return CommandActionResult.Handled(deviceControl.getCurrentDateTimeText())
        }
        if (lower.contains("battery") || lower.contains("internet status") || lower.contains("network status")) {
            return CommandActionResult.Handled(deviceControl.getTelemetrySummary())
        }

        // Local reminder scheduling when explicit relative delay is provided
        if (lower.startsWith("remind me")) {
            val delayMs = com.yasmin.ai.assistant.ReminderScheduler.parseRelativeDelayMs(cleaned)
            if (delayMs != null) {
                val title = cleaned
                    .replace(Regex("(?i)^(?:hey yasmin|ok yasmin)?\\s*remind me\\s+in\\s+\\d+\\s+\\w+\\s*(?:to|about)?\\s*"), "")
                    .ifBlank { "Reminder" }
                return CommandActionResult.CreateReminder(cleaned, title, delayMs)
            }
        }

        // Local Calendar read / insert
        if (calendarHelper != null && (lower.contains("read calendar") || lower.contains("my calendar") || lower.contains("upcoming events"))) {
            return CommandActionResult.Handled(calendarHelper.formatUpcomingEventsText())
        }
        if (calendarHelper != null && (lower.startsWith("add calendar event ") || lower.startsWith("schedule meeting "))) {
            val title = cleaned.substringAfter("event ").substringAfter("meeting ").trim()
            return CommandActionResult.Handled(calendarHelper.openAddCalendarEventIntent(title))
        }

        if (lower.contains("open wifi settings")) {
            return CommandActionResult.Handled(deviceControl.openAndroidSettings(Settings.ACTION_WIFI_SETTINGS))
        }
        if (lower.contains("open bluetooth settings")) {
            return CommandActionResult.Handled(deviceControl.openAndroidSettings(Settings.ACTION_BLUETOOTH_SETTINGS))
        }
        if (lower.contains("open settings")) {
            return CommandActionResult.Handled(deviceControl.openAndroidSettings(Settings.ACTION_SETTINGS))
        }

        if (lower == "play music" || lower.contains("play music")) {
            return CommandActionResult.Handled(deviceControl.playMusic())
        }

        if (lower.contains("read notifications") || lower.contains("my notifications")) {
            val listener = YasminNotificationListenerService.instance
                ?: return CommandActionResult.RequestPermissionsSetup
            val items = listener.getRecentNotificationSummaries()
            if (items.isEmpty()) {
                return CommandActionResult.Handled("You have no active unread notifications.")
            }
            val summary = items.joinToString("\n") { "• ${it.title}: ${it.text}" }
            return CommandActionResult.Handled("Recent notifications:\n$summary")
        }

        if (lower.startsWith("search youtube for ")) {
            val q = cleaned.substringAfter("for ").trim()
            return CommandActionResult.Handled(deviceControl.searchYouTube(q))
        }
        if (lower.startsWith("search ") && (lower.contains("tutorial") || lower.contains("youtube") || lower.contains("video"))) {
            val q = lower.removePrefix("search ").replace("on youtube", "").trim()
            return CommandActionResult.Handled(deviceControl.searchYouTube(q))
        }

        if (lower.startsWith("open ") || lower.startsWith("launch ") || lower.endsWith(" kholo")) {
            val appQuery = when {
                lower.startsWith("open ") -> lower.removePrefix("open ").trim()
                lower.startsWith("launch ") -> lower.removePrefix("launch ").trim()
                else -> lower.removeSuffix(" kholo").trim()
            }
            if (appQuery == "youtube") return CommandActionResult.Handled(deviceControl.openYouTubeHome())
            if (appQuery == "vision" || appQuery == "camera ai") return CommandActionResult.OpenVisionWorkspace
            if (appQuery == "daily" || appQuery == "tasks" || appQuery == "memory") return CommandActionResult.OpenDailyHub
            return CommandActionResult.Handled(deviceControl.openAppByName(appQuery))
        }

        if (lower.contains("read my screen") || lower.contains("read screen") || lower.contains("screen padho")) {
            val service = YasminAccessibilityService.instance
                ?: return CommandActionResult.RequestPermissionsSetup
            val text = service.readVisibleScreenText()
            return if (text.isBlank()) {
                CommandActionResult.Handled("No readable text was found on the active screen.")
            } else {
                CommandActionResult.ReadScreenWithAi(text)
            }
        }

        if (lower.contains("scroll down") || lower.contains("neeche scroll")) {
            val service = YasminAccessibilityService.instance
                ?: return CommandActionResult.RequestPermissionsSetup
            val ok = service.performScrollDown()
            return CommandActionResult.Handled(if (ok) "Scrolled down." else "Nothing scrollable on current screen.")
        }

        if (lower.contains("scroll up") || lower.contains("upar scroll")) {
            val service = YasminAccessibilityService.instance
                ?: return CommandActionResult.RequestPermissionsSetup
            val ok = service.performScrollUp()
            return CommandActionResult.Handled(if (ok) "Scrolled up." else "Nothing scrollable on current screen.")
        }

        if (lower == "go back" || lower == "back navigation") {
            val service = YasminAccessibilityService.instance
                ?: return CommandActionResult.RequestPermissionsSetup
            return CommandActionResult.RequiresConfirmation(
                actionTitle = "Confirm Back Navigation",
                description = "Perform Android global Back action?"
            ) {
                if (service.performBackNavigation()) "Navigated back." else "Back action failed."
            }
        }

        if (lower.startsWith("click ") || lower.startsWith("tap ")) {
            val target = cleaned.substringAfter(" ").trim()
            val service = YasminAccessibilityService.instance
                ?: return CommandActionResult.RequestPermissionsSetup
            return CommandActionResult.RequiresConfirmation(
                actionTitle = "Confirm UI Click",
                description = "Allow Yasmin AI to click '$target' on screen?"
            ) {
                if (service.clickNodeByText(target)) "Clicked '$target'." else "Could not find clickable element '$target'."
            }
        }

        if (lower.contains("write python") || lower.contains("python code") || lower.contains("calculator in python")) {
            return CommandActionResult.OpenPythonWorkspace(cleaned)
        }
        if (lower.contains("create html") || lower.contains("html website") || lower.contains("web page")) {
            return CommandActionResult.OpenHtmlWorkspace(cleaned)
        }

        // Everything else uses Gemini Natural Intent & Multi-Step Tool Planner (or Offline Engine if offline)!
        return CommandActionResult.UseAiPlanner(cleaned)
    }
}
