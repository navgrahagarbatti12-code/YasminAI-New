package com.yasmin.ai.coding

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast

data class CodeSnippet(
    val label: String,
    val insertText: String
)

object CodeIntelligenceHelper {

    val pythonSnippets = listOf(
        CodeSnippet("def", "def my_func(x):\n    return x\n"),
        CodeSnippet("for", "for i in range(10):\n    print(i)\n"),
        CodeSnippet("if/else", "if condition:\n    pass\nelse:\n    pass\n"),
        CodeSnippet("try/except", "try:\n    pass\nexcept Exception as err:\n    print(err)\n"),
        CodeSnippet("import math", "import math, json, statistics\n"),
        CodeSnippet("list comp", "[x * 2 for x in range(10) if x % 2 == 0]")
    )

    val htmlSnippets = listOf(
        CodeSnippet("<section>", "<section class=\"card\">\n  <h2>Title</h2>\n  <p>Content</p>\n</section>\n"),
        CodeSnippet("<button>", "<button id=\"actionBtn\" type=\"button\">Click</button>\n"),
        CodeSnippet("<input>", "<input id=\"userInput\" type=\"text\" placeholder=\"Type here...\" />\n"),
        CodeSnippet("flex div", "<div class=\"row\">\n  <div>A</div>\n  <div>B</div>\n</div>\n")
    )

    val cssSnippets = listOf(
        CodeSnippet("flex-center", "display: flex;\nalign-items: center;\njustify-content: center;\n"),
        CodeSnippet("glass-card", "background: rgba(15, 23, 42, 0.8);\nborder: 1px solid #00e5ff;\nborder-radius: 12px;\npadding: 16px;\n"),
        CodeSnippet("grid-2col", "display: grid;\ngrid-template-columns: repeat(2, minmax(0, 1fr));\ngap: 12px;\n")
    )

    val jsSnippets = listOf(
        CodeSnippet("onClick", "document.getElementById('actionBtn')?.addEventListener('click', () => {\n  console.log('Clicked');\n});\n"),
        CodeSnippet("async fn", "async function runTask() {\n  try {\n    return true;\n  } catch (err) {\n    console.error(err);\n  }\n}\n"),
        CodeSnippet("forEach", "items.forEach((item, idx) => {\n  console.log(idx, item);\n});\n")
    )

    fun checkPythonIssues(code: String): List<String> {
        val issues = mutableListOf<String>()
        val blockedCalls = listOf("os.", "sys.", "subprocess", "socket", "eval(", "exec(", "open(", "__import__", "requests", "urllib")
        val lines = code.lines()

        var round = 0
        var square = 0
        var curly = 0

        lines.forEachIndexed { index, rawLine ->
            val lineNum = index + 1
            val trimmed = rawLine.trim()
            if (trimmed.isEmpty() || trimmed.startsWith("#")) return@forEachIndexed

            for (blocked in blockedCalls) {
                if (trimmed.contains(blocked)) {
                    issues.add("Line $lineNum [Policy]: '$blocked' is blocked inside Yasmin Python sandbox.")
                }
            }

            if (Regex("^(def|class|if|elif|else|for|while|try|except|finally|with)\\b.*").matches(trimmed) &&
                !trimmed.endsWith(":") && !trimmed.contains("#")
            ) {
                issues.add("Line $lineNum [Syntax]: Block header may be missing trailing ':'.")
            }

            var inSingle = false
            var inDouble = false
            var escaped = false
            for (ch in rawLine) {
                if (escaped) {
                    escaped = false
                    continue
                }
                if (ch == '\\') {
                    escaped = true
                    continue
                }
                if (ch == '\'' && !inDouble) inSingle = !inSingle
                else if (ch == '"' && !inSingle) inDouble = !inDouble
                else if (!inSingle && !inDouble) {
                    if (ch == '#') break
                    when (ch) {
                        '(' -> round++
                        ')' -> round--
                        '[' -> square++
                        ']' -> square--
                        '{' -> curly++
                        '}' -> curly--
                    }
                }
            }
            if ((inSingle || inDouble) && !trimmed.contains("\"\"\"") && !trimmed.contains("'''")) {
                issues.add("Line $lineNum [Syntax]: Unclosed string quote.")
            }
        }

        if (round != 0) issues.add("[Syntax]: Unbalanced parentheses '(' / ')'.")
        if (square != 0) issues.add("[Syntax]: Unbalanced brackets '[' / ']'.")
        if (curly != 0) issues.add("[Syntax]: Unbalanced braces '{' / '}'.")

        return issues
    }

    fun checkWebIssues(html: String, css: String, js: String): List<String> {
        val issues = mutableListOf<String>()
        if (html.isBlank()) issues.add("[HTML]: HTML document is empty.")
        if (css.count { it == '{' } != css.count { it == '}' }) {
            issues.add("[CSS]: Unbalanced '{' and '}' braces.")
        }
        if (js.count { it == '{' } != js.count { it == '}' }) {
            issues.add("[JS]: Unbalanced '{' and '}' braces.")
        }
        if (js.count { it == '(' } != js.count { it == ')' }) {
            issues.add("[JS]: Unbalanced '(' and ')' parentheses.")
        }
        if (js.contains("eval(") || js.contains("document.write(")) {
            issues.add("[JS Security]: Avoid eval() or document.write() for WebView sandbox safety.")
        }
        return issues
    }

    fun openGitHubGistExport(context: Context, label: String, codeContent: String) {
        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText(label, codeContent))
        Toast.makeText(
            context,
            "Code copied to clipboard. Opening GitHub Gist to create & commit.",
            Toast.LENGTH_LONG
        ).show()
        try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://gist.github.com/")).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (_: Exception) {
            Toast.makeText(context, "No browser app found to open GitHub Gist.", Toast.LENGTH_SHORT).show()
        }
    }
}
