package com.yasmin.ai.ui.python

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.chaquo.python.Python
import com.google.gson.Gson
import com.yasmin.ai.YasminApplication
import com.yasmin.ai.ai.AiResult
import com.yasmin.ai.coding.CodeIntelligenceHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull

data class PythonExecResult(
    val success: Boolean = true,
    val stdout: String = "",
    val stderr: String = "",
    val error: String = "",
    val elapsedMs: Long = 0L
)

class PythonViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = (application as YasminApplication).repository
    private val gson = Gson()

    private val _code = MutableStateFlow(
        """# Yasmin AI Isolated Python 3.11 Sandbox
import math, json

def circle_metrics(radius):
    return {
        "radius": radius,
        "circumference": round(2 * math.pi * radius, 3),
        "area": round(math.pi * (radius ** 2), 3),
    }

print(json.dumps(circle_metrics(12), indent=2))
"""
    )
    val code: StateFlow<String> = _code.asStateFlow()

    private val _output = MutableStateFlow(
        "Ready. Choose On-Device Chaquopy AST or Backend OS-Isolated Subprocess Sandbox."
    )
    val output: StateFlow<String> = _output.asStateFlow()

    private val _isErrorOutput = MutableStateFlow(false)
    val isErrorOutput: StateFlow<Boolean> = _isErrorOutput.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _isAiGenerated = MutableStateFlow(false)
    val isAiGenerated: StateFlow<Boolean> = _isAiGenerated.asStateFlow()

    private val _useRemoteSandbox = MutableStateFlow(false)
    val useRemoteSandbox: StateFlow<Boolean> = _useRemoteSandbox.asStateFlow()

    fun updateCode(newCode: String) {
        _code.value = newCode
    }

    fun toggleSandboxMode() {
        _useRemoteSandbox.value = !_useRemoteSandbox.value
        _isErrorOutput.value = false
        _output.value = if (_useRemoteSandbox.value) {
            "Switched to Backend OS-Isolated Subprocess (RLIMIT_AS/CPU + scrubbed env + SIGKILL)."
        } else {
            "Switched to On-Device Chaquopy 3.11 AST Sandbox (400k steps / 4s timeout)."
        }
    }

    fun runStaticLint(sourceCode: String) {
        val issues = CodeIntelligenceHelper.checkPythonIssues(sourceCode)
        if (issues.isEmpty()) {
            _isErrorOutput.value = false
            _output.value = "Static Check Passed: Balanced syntax and zero blocked imports detected."
        } else {
            _isErrorOutput.value = true
            _output.value = "Static Check Warnings (${issues.size}):\n" + issues.joinToString("\n") { "• $it" }
        }
    }

    fun formatCode() {
        val raw = _code.value
        val formatted = raw.lines()
            .map { line -> line.replace("\t", "    ").trimEnd() }
            .joinToString("\n")
            .trimEnd() + "\n"
        _code.value = formatted
        _isErrorOutput.value = false
        _output.value = "Formatted Python indentation (4 spaces) and trimmed trailing whitespace."
    }

    fun generateWithGemini(prompt: String) {
        if (prompt.isBlank()) return
        viewModelScope.launch {
            _isLoading.value = true
            _output.value = "Generating sandbox-compatible Python code…"
            _isErrorOutput.value = false

            when (
                val res = repository.requestCodeGeneration(
                    prompt = prompt,
                    target = "python",
                    existingCode = _code.value
                )
            ) {
                is AiResult.Success -> {
                    val generated = res.data.code?.takeIf { it.isNotBlank() }
                        ?: res.data.reply.orEmpty()
                    if (generated.isNotBlank()) {
                        _code.value = generated
                        _isAiGenerated.value = true
                        _output.value = res.data.explanation?.takeIf { it.isNotBlank() }
                            ?: "Code generated. Run Static Check or tap 'Run' to execute in sandbox."
                    } else {
                        _isErrorOutput.value = true
                        _output.value = "AI returned empty Python code."
                    }
                }
                is AiResult.Error -> {
                    _isErrorOutput.value = true
                    _output.value = "AI Error: ${res.message}"
                }
            }
            _isLoading.value = false
        }
    }

    fun debugWithGemini() {
        val currentCode = _code.value
        val currentErr = _output.value
        if (currentCode.isBlank()) return
        viewModelScope.launch {
            _isLoading.value = true
            _output.value = "Analyzing Python code and errors…"
            _isErrorOutput.value = false

            when (
                val res = repository.requestCodeGeneration(
                    prompt = "Fix any syntax, runtime, or sandbox-policy issues in this Python code and explain briefly.",
                    target = "debug",
                    existingCode = currentCode,
                    errorOutput = currentErr
                )
            ) {
                is AiResult.Success -> {
                    val fixed = res.data.code
                    if (!fixed.isNullOrBlank()) {
                        _code.value = fixed
                        _isAiGenerated.value = true
                    }
                    _output.value = res.data.explanation
                        ?: res.data.reply
                        ?: "Code updated. Review before running."
                }
                is AiResult.Error -> {
                    _isErrorOutput.value = true
                    _output.value = "Debug Error: ${res.message}"
                }
            }
            _isLoading.value = false
        }
    }

    fun explainWithGemini() {
        val currentCode = _code.value
        if (currentCode.isBlank()) return
        viewModelScope.launch {
            _isLoading.value = true
            _output.value = "Explaining Python script…"
            _isErrorOutput.value = false

            when (
                val res = repository.requestCodeGeneration(
                    prompt = "Explain clearly what this Python code does block-by-block. Return the same code unchanged.",
                    target = "explain",
                    existingCode = currentCode,
                    errorOutput = ""
                )
            ) {
                is AiResult.Success -> {
                    _output.value = res.data.explanation?.takeIf { it.isNotBlank() }
                        ?: res.data.reply
                        ?: "No explanation returned."
                }
                is AiResult.Error -> {
                    _isErrorOutput.value = true
                    _output.value = "Explain Error: ${res.message}"
                }
            }
            _isLoading.value = false
        }
    }

    fun executeApprovedCode(sourceCode: String) {
        viewModelScope.launch {
            _isLoading.value = true
            _isErrorOutput.value = false

            if (_useRemoteSandbox.value) {
                _output.value = "Executing inside OS-Isolated Backend Subprocess Sandbox…"
                when (val remoteRes = repository.executePythonRemote(sourceCode)) {
                    is AiResult.Success -> {
                        val r = remoteRes.data
                        if (r.success) {
                            _isErrorOutput.value = false
                            _output.value = buildString {
                                if (r.stdout.isNotBlank()) append(r.stdout.trimEnd())
                                if (r.stderr.isNotBlank()) {
                                    if (isNotEmpty()) append("\n")
                                    append("STDERR:\n").append(r.stderr.trimEnd())
                                }
                                if (isEmpty()) append("Execution finished cleanly (no output).")
                                append("\n\n[Completed in ${r.elapsedMs}ms · OS-isolated subprocess]")
                            }
                        } else {
                            _isErrorOutput.value = true
                            _output.value = buildString {
                                if (r.stdout.isNotBlank()) append(r.stdout.trimEnd()).append("\n")
                                append(r.error.ifBlank { r.stderr.ifBlank { "Execution failed." } })
                            }
                        }
                    }
                    is AiResult.Error -> {
                        _isErrorOutput.value = true
                        _output.value = "Remote Sandbox Error: ${remoteRes.message}\n(Tip: Switch to Local Chaquopy mode for offline execution.)"
                    }
                }
                _isLoading.value = false
                return@launch
            }

            _output.value = "Executing inside AST-validated Chaquopy 3.11 sandbox…"
            val result = withContext(Dispatchers.IO) {
                withTimeoutOrNull(6500L) {
                    try {
                        val py = Python.getInstance()
                        val runner = py.getModule("yasmin_runner")
                        val jsonStr = runner.callAttr("execute_python", sourceCode).toString()
                        gson.fromJson(jsonStr, PythonExecResult::class.java)
                    } catch (e: Exception) {
                        PythonExecResult(
                            success = false,
                            error = "Runtime exception: ${e.localizedMessage ?: e.toString()}"
                        )
                    }
                } ?: PythonExecResult(
                    success = false,
                    error = "Execution aborted: coroutine safety timeout (6.5s)."
                )
            }

            if (result.success) {
                _isErrorOutput.value = false
                val combined = buildString {
                    if (result.stdout.isNotBlank()) append(result.stdout.trimEnd())
                    if (result.stderr.isNotBlank()) {
                        if (isNotEmpty()) append("\n")
                        append("STDERR:\n").append(result.stderr.trimEnd())
                    }
                    if (isEmpty()) append("Execution finished cleanly (no output).")
                    append("\n\n[Completed in ${result.elapsedMs}ms inside Chaquopy AST sandbox]")
                }
                _output.value = combined
            } else {
                _isErrorOutput.value = true
                _output.value = buildString {
                    if (result.stdout.isNotBlank()) append(result.stdout.trimEnd()).append("\n")
                    append(result.error.ifBlank { result.stderr })
                }
            }
            _isLoading.value = false
        }
    }

    fun clearOutput() {
        _isErrorOutput.value = false
        _output.value = "Output cleared."
    }
}
