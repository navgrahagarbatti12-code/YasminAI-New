package com.yasmin.ai.voice

import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.ln
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

data class WakeDetectionScore(
    val detected: Boolean,
    val confidence: Double,
    val mode: String,
    val distance: Double
)

/**
 * Pure-offline acoustic wake-word detector for "Hey Yasmin".
 *
 * Uses Hamming-windowed Radix-2 FFT + 20-band Mel filterbank + DCT-II (13 MFCCs)
 * with utterance-level Cepstral Mean Normalization (CMN) and Dynamic Time Warping (DTW)
 * against locally enrolled acoustic templates (zero network or SpeechRecognizer dependency).
 *
 * When no personalized templates are enrolled yet, applies a conservative offline
 * multi-syllable speech cadence & formant-band ratio detector, prompting the user in
 * Settings to enroll 2 samples for significantly tighter speaker accuracy.
 */
class OfflineWakeWordDetector(private val storageFile: File?) {

    private val templates = mutableListOf<List<DoubleArray>>()

    init {
        loadTemplates()
    }

    @Synchronized
    fun getEnrolledTemplateCount(): Int = templates.size

    @Synchronized
    fun clearTemplates() {
        templates.clear()
        storageFile?.let {
            if (it.exists()) it.delete()
        }
    }

    @Synchronized
    fun enrollSample(pcmSamples: ShortArray, sampleRate: Int = 16000): Boolean {
        val trimmed = trimSilence(pcmSamples, sampleRate)
        if (trimmed.size < (sampleRate * 0.35).toInt()) return false
        val mfccs = extractMfccSequence(trimmed, sampleRate)
        if (mfccs.size < 12) return false
        templates.add(mfccs)
        if (templates.size > MAX_TEMPLATES) {
            templates.removeAt(0)
        }
        persistTemplates()
        return true
    }

    @Synchronized
    fun detect(pcmSamples: ShortArray, sensitivityPercent: Int, sampleRate: Int = 16000): WakeDetectionScore {
        val trimmed = trimSilence(pcmSamples, sampleRate)
        val durationSec = trimmed.size.toDouble() / sampleRate
        if (durationSec < 0.35 || durationSec > 2.0) {
            return WakeDetectionScore(false, 0.0, "duration_reject", Double.MAX_VALUE)
        }

        val sens = sensitivityPercent.coerceIn(10, 100)
        val activeTemplates = templates.toList()

        if (activeTemplates.isNotEmpty()) {
            val candidate = extractMfccSequence(trimmed, sampleRate)
            if (candidate.size < 10) {
                return WakeDetectionScore(false, 0.0, "mfcc_dtw", Double.MAX_VALUE)
            }
            var bestDistance = Double.MAX_VALUE
            for (tpl in activeTemplates) {
                val lenRatio = max(candidate.size, tpl.size).toDouble() / min(candidate.size, tpl.size).coerceAtLeast(1)
                if (lenRatio > 2.2) continue
                val d = computeDtwDistance(candidate, tpl)
                if (d < bestDistance) bestDistance = d
            }
            if (bestDistance == Double.MAX_VALUE) {
                return WakeDetectionScore(false, 0.0, "mfcc_dtw", bestDistance)
            }
            // Threshold scales with user sensitivity slider (higher sensitivity => wider margin)
            val threshold = 4.2 + (sens / 100.0) * 3.8
            val detected = bestDistance <= threshold
            val confidence = (1.0 - (bestDistance / (threshold * 1.6))).coerceIn(0.0, 1.0)
            return WakeDetectionScore(detected, confidence, "mfcc_dtw", bestDistance)
        }

        // Fallback pure-offline multi-syllable acoustic envelope detector ("Hey Yas-min")
        return detectBySyllableCadence(trimmed, sens, sampleRate)
    }

    private fun detectBySyllableCadence(
        samples: ShortArray,
        sensitivityPercent: Int,
        sampleRate: Int
    ): WakeDetectionScore {
        val frameSize = (sampleRate * 0.025).toInt() // 400 samples
        val hop = (sampleRate * 0.015).toInt() // 240 samples
        val energies = mutableListOf<Double>()
        var i = 0
        while (i + frameSize <= samples.size) {
            var sumSq = 0.0
            for (j in i until i + frameSize) {
                val v = samples[j].toDouble()
                sumSq += v * v
            }
            energies.add(sqrt(sumSq / frameSize))
            i += hop
        }
        if (energies.size < 18) {
            return WakeDetectionScore(false, 0.0, "acoustic_cadence", 99.0)
        }

        val maxE = energies.maxOrNull()?.coerceAtLeast(1.0) ?: 1.0
        val norm = energies.map { it / maxE }
        // Count distinct energy peaks above 0.42 separated by at least 4 frames (~60ms) with valley < 0.30
        var peaks = 0
        var inPeak = false
        var lastValleySeen = true
        for (e in norm) {
            if (e >= 0.44 && !inPeak && lastValleySeen) {
                peaks++
                inPeak = true
                lastValleySeen = false
            } else if (e < 0.28) {
                inPeak = false
                lastValleySeen = true
            }
        }

        val mfccs = extractMfccSequence(samples, sampleRate)
        val spectralSpread = if (mfccs.isNotEmpty()) {
            mfccs.map { abs(it[1]) + abs(it[2]) }.average()
        } else 0.0

        val minDuration = 0.48
        val maxDuration = 1.45
        val dur = samples.size.toDouble() / sampleRate
        val durationOk = dur in minDuration..maxDuration
        val allowedPeaks = if (sensitivityPercent >= 75) 2..3 else 2..3
        val peaksOk = peaks in allowedPeaks
        val voiceRichnessOk = spectralSpread >= (2.2 - (sensitivityPercent / 100.0) * 0.8)
        val detected = durationOk && peaksOk && voiceRichnessOk
        val confidence = if (detected) 0.62 else 0.25
        return WakeDetectionScore(detected, confidence, "acoustic_cadence", if (detected) 1.0 else 9.9)
    }

    internal fun extractMfccSequence(samples: ShortArray, sampleRate: Int = 16000): List<DoubleArray> {
        // 1. Pre-emphasis
        val pre = DoubleArray(samples.size)
        if (samples.isNotEmpty()) {
            pre[0] = samples[0].toDouble() / 32768.0
            for (n in 1 until samples.size) {
                val curr = samples[n].toDouble() / 32768.0
                val prev = samples[n - 1].toDouble() / 32768.0
                pre[n] = curr - 0.97 * prev
            }
        }

        val frameLen = (sampleRate * 0.025).toInt() // 400
        val hopLen = (sampleRate * 0.012).toInt() // 192 (~12ms hop keeps sequence compact)
        val fftSize = 512
        val window = DoubleArray(frameLen) { idx ->
            0.54 - 0.46 * cos((2.0 * PI * idx) / (frameLen - 1))
        }
        val melBank = buildMelFilterBank(NUM_MEL_FILTERS, fftSize, sampleRate, 120.0, (sampleRate / 2.0) - 200.0)

        val frames = mutableListOf<DoubleArray>()
        var offset = 0
        val re = DoubleArray(fftSize)
        val im = DoubleArray(fftSize)
        while (offset + frameLen <= pre.size) {
            re.fill(0.0)
            im.fill(0.0)
            for (k in 0 until frameLen) {
                re[k] = pre[offset + k] * window[k]
            }
            fftRadix2(re, im)

            val halfBins = fftSize / 2 + 1
            val power = DoubleArray(halfBins)
            for (k in 0 until halfBins) {
                power[k] = (re[k] * re[k] + im[k] * im[k]) / fftSize
            }

            val logMel = DoubleArray(NUM_MEL_FILTERS)
            for (m in 0 until NUM_MEL_FILTERS) {
                var energy = 1e-9
                val weights = melBank[m]
                for (k in 0 until halfBins) {
                    energy += power[k] * weights[k]
                }
                logMel[m] = ln(energy)
            }

            // DCT-II -> 13 MFCC coefficients (skipping c0 energy bias via index 1..13)
            val mfcc = DoubleArray(NUM_MFCC)
            for (c in 0 until NUM_MFCC) {
                val cepIndex = c + 1
                var sum = 0.0
                for (m in 0 until NUM_MEL_FILTERS) {
                    sum += logMel[m] * cos(PI * cepIndex * (m + 0.5) / NUM_MEL_FILTERS)
                }
                mfcc[c] = sum
            }
            frames.add(mfcc)
            offset += hopLen
        }

        if (frames.isEmpty()) return emptyList()

        // Cepstral Mean & Variance Normalization per utterance for speaker/volume invariance
        val mean = DoubleArray(NUM_MFCC)
        for (f in frames) {
            for (c in 0 until NUM_MFCC) mean[c] += f[c]
        }
        for (c in 0 until NUM_MFCC) mean[c] /= frames.size

        val std = DoubleArray(NUM_MFCC)
        for (f in frames) {
            for (c in 0 until NUM_MFCC) {
                val diff = f[c] - mean[c]
                std[c] += diff * diff
            }
        }
        for (c in 0 until NUM_MFCC) {
            std[c] = sqrt(std[c] / frames.size).coerceAtLeast(1e-4)
        }

        for (f in frames) {
            for (c in 0 until NUM_MFCC) {
                f[c] = (f[c] - mean[c]) / std[c]
            }
        }
        return frames
    }

    internal fun computeDtwDistance(seqA: List<DoubleArray>, seqB: List<DoubleArray>): Double {
        val n = seqA.size
        val m = seqB.size
        if (n == 0 || m == 0) return Double.MAX_VALUE

        val band = max(6, max(n, m) / 3)
        val dp = Array(n + 1) { DoubleArray(m + 1) { Double.POSITIVE_INFINITY } }
        dp[0][0] = 0.0

        for (i in 1..n) {
            val jStart = max(1, (i * m) / n - band)
            val jEnd = min(m, (i * m) / n + band)
            for (j in jStart..jEnd) {
                val cost = euclidean(seqA[i - 1], seqB[j - 1])
                val bestPrev = min(dp[i - 1][j], min(dp[i][j - 1], dp[i - 1][j - 1]))
                if (bestPrev.isFinite()) {
                    dp[i][j] = cost + bestPrev
                }
            }
        }

        val total = dp[n][m]
        return if (total.isFinite()) total / (n + m) * 2.0 else Double.MAX_VALUE
    }

    private fun euclidean(a: DoubleArray, b: DoubleArray): Double {
        var sumSq = 0.0
        for (k in a.indices) {
            val d = a[k] - b[k]
            sumSq += d * d
        }
        return sqrt(sumSq)
    }

    private fun trimSilence(samples: ShortArray, sampleRate: Int): ShortArray {
        if (samples.isEmpty()) return samples
        var peak = 0
        for (s in samples) {
            val a = abs(s.toInt())
            if (a > peak) peak = a
        }
        if (peak < 250) return ShortArray(0)

        val thresh = max(220, (peak * 0.14).toInt())
        val pad = (sampleRate * 0.04).toInt()
        var start = 0
        while (start < samples.size && abs(samples[start].toInt()) < thresh) start++
        var end = samples.size - 1
        while (end > start && abs(samples[end].toInt()) < thresh) end--

        val sIdx = max(0, start - pad)
        val eIdx = min(samples.size, end + pad + 1)
        return if (eIdx <= sIdx) ShortArray(0) else samples.copyOfRange(sIdx, eIdx)
    }

    private fun buildMelFilterBank(
        numFilters: Int,
        fftSize: Int,
        sampleRate: Int,
        lowFreqHz: Double,
        highFreqHz: Double
    ): Array<DoubleArray> {
        fun hzToMel(hz: Double) = 2595.0 * log10(1.0 + hz / 700.0)
        fun melToHz(mel: Double) = 700.0 * (Math.pow(10.0, mel / 2595.0) - 1.0)

        val lowMel = hzToMel(lowFreqHz)
        val highMel = hzToMel(highFreqHz)
        val melPoints = DoubleArray(numFilters + 2) { i ->
            lowMel + i * (highMel - lowMel) / (numFilters + 1)
        }
        val binIndices = IntArray(numFilters + 2) { i ->
            val hz = melToHz(melPoints[i])
            ((fftSize + 1) * hz / sampleRate).toInt().coerceIn(0, fftSize / 2)
        }

        val halfBins = fftSize / 2 + 1
        return Array(numFilters) { m ->
            val filter = DoubleArray(halfBins)
            val left = binIndices[m]
            val center = binIndices[m + 1]
            val right = binIndices[m + 2]
            for (k in left until center) {
                if (center > left) filter[k] = (k - left).toDouble() / (center - left)
            }
            for (k in center..right) {
                if (right > center && k < halfBins) filter[k] = (right - k).toDouble() / (right - center)
            }
            filter
        }
    }

    private fun fftRadix2(re: DoubleArray, im: DoubleArray) {
        val n = re.size
        var j = 0
        for (i in 1 until n) {
            var bit = n shr 1
            while (j and bit != 0) {
                j = j xor bit
                bit = bit shr 1
            }
            j = j xor bit
            if (i < j) {
                val tr = re[i]; re[i] = re[j]; re[j] = tr
                val ti = im[i]; im[i] = im[j]; im[j] = ti
            }
        }
        var len = 2
        while (len <= n) {
            val ang = -2.0 * PI / len
            val wLenRe = cos(ang)
            val wLenIm = sin(ang)
            var i = 0
            while (i < n) {
                var wRe = 1.0
                var wIm = 0.0
                for (k in 0 until len / 2) {
                    val uRe = re[i + k]
                    val uIm = im[i + k]
                    val idx2 = i + k + len / 2
                    val vRe = re[idx2] * wRe - im[idx2] * wIm
                    val vIm = re[idx2] * wIm + im[idx2] * wRe
                    re[i + k] = uRe + vRe
                    im[i + k] = uIm + vIm
                    re[idx2] = uRe - vRe
                    im[idx2] = uIm - vIm
                    val nextWRe = wRe * wLenRe - wIm * wLenIm
                    wIm = wRe * wLenIm + wIm * wLenRe
                    wRe = nextWRe
                }
                i += len
            }
            len = len shl 1
        }
    }

    private fun persistTemplates() {
        val file = storageFile ?: return
        try {
            val arr = JSONArray()
            for (tpl in templates) {
                val frameArr = JSONArray()
                for (vec in tpl) {
                    val coeffArr = JSONArray()
                    for (v in vec) coeffArr.put(v)
                    frameArr.put(coeffArr)
                }
                arr.put(frameArr)
            }
            val root = JSONObject().put("templates", arr)
            file.parentFile?.mkdirs()
            file.writeText(root.toString())
        } catch (_: Exception) {
        }
    }

    private fun loadTemplates() {
        val file = storageFile ?: return
        if (!file.exists()) return
        try {
            val root = JSONObject(file.readText())
            val arr = root.optJSONArray("templates") ?: return
            templates.clear()
            for (i in 0 until arr.length()) {
                val frameArr = arr.getJSONArray(i)
                val tpl = mutableListOf<DoubleArray>()
                for (f in 0 until frameArr.length()) {
                    val coeffArr = frameArr.getJSONArray(f)
                    val vec = DoubleArray(coeffArr.length()) { c -> coeffArr.getDouble(c) }
                    tpl.add(vec)
                }
                if (tpl.isNotEmpty()) templates.add(tpl)
            }
        } catch (_: Exception) {
        }
    }

    companion object {
        private const val NUM_MEL_FILTERS = 20
        private const val NUM_MFCC = 13
        private const val MAX_TEMPLATES = 5
    }
}
