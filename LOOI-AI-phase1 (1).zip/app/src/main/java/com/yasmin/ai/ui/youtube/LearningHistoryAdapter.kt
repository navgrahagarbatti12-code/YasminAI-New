package com.yasmin.ai.ui.youtube

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.yasmin.ai.data.local.LearningSessionEntity
import com.yasmin.ai.databinding.ItemLearningHistoryBinding
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class LearningHistoryAdapter(
    private val onResumeVideo: (LearningSessionEntity) -> Unit,
    private val onDeleteSession: (LearningSessionEntity) -> Unit
) : ListAdapter<LearningSessionEntity, LearningHistoryAdapter.HistoryViewHolder>(Diff) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): HistoryViewHolder {
        val binding = ItemLearningHistoryBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return HistoryViewHolder(binding)
    }

    override fun onBindViewHolder(holder: HistoryViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class HistoryViewHolder(private val binding: ItemLearningHistoryBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(item: LearningSessionEntity) {
            val dateStr = SimpleDateFormat("dd MMM · HH:mm", Locale.US).format(Date(item.lastStudiedAt))
            binding.tvHistoryTitle.text = item.videoTitle.ifBlank { item.topic }
            val quizInfo = if (item.totalQuestions > 0) " · Quiz ${item.quizScore}/${item.totalQuestions}" else ""
            binding.tvHistoryMeta.text = "${item.channelTitle.ifBlank { "YouTube" }} · ${item.difficultyLevel}$quizInfo · $dateStr"
            binding.tvHistoryProgress.text = "${item.progressPercent}%"
            binding.progressLearning.progress = item.progressPercent.coerceIn(0, 100)
            binding.btnHistoryReload.setOnClickListener { onResumeVideo(item) }
            binding.btnHistoryRemove.setOnClickListener { onDeleteSession(item) }
        }
    }

    private object Diff : DiffUtil.ItemCallback<LearningSessionEntity>() {
        override fun areItemsTheSame(oldItem: LearningSessionEntity, newItem: LearningSessionEntity): Boolean =
            oldItem.id == newItem.id

        override fun areContentsTheSame(oldItem: LearningSessionEntity, newItem: LearningSessionEntity): Boolean =
            oldItem == newItem
    }
}
