package com.yasmin.ai.ui.coding

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.google.gson.Gson
import com.yasmin.ai.YasminApplication
import com.yasmin.ai.ai.AiResult
import com.yasmin.ai.ai.GeneratedCodeFile
import com.yasmin.ai.ai.MultiFileCodeRequest
import com.yasmin.ai.coding.BackgroundCodingWorker
import com.yasmin.ai.coding.ProjectFileManager
import com.yasmin.ai.data.local.CodingJobEntity
import com.yasmin.ai.data.preferences.YasminUserPreferences
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File

class CodingAgentViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = (application as YasminApplication).repository
    private val fileManager = ProjectFileManager(application)
    private val gson = Gson()

    val preferences: StateFlow<YasminUserPreferences> = repository.preferencesFlow.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        YasminUserPreferences()
    )

    val codingJobs: StateFlow<List<CodingJobEntity>> = repository.codingJobsFlow.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        emptyList()
    )

    private val _projectName = MutableStateFlow("yasmin_app")
    val projectName: StateFlow<String> = _projectName.asStateFlow()

    private val _projectFiles = MutableStateFlow<List<GeneratedCodeFile>>(emptyList())
    val projectFiles: StateFlow<List<GeneratedCodeFile>> = _projectFiles.asStateFlow()

    private val _selectedFileIndex = MutableStateFlow(0)
    val selectedFileIndex: StateFlow<Int> = _selectedFileIndex.asStateFlow()

    private val _summaryOutput = MutableStateFlow("Ready. Describe a multi-file project or load an existing workspace.")
    val summaryOutput: StateFlow<String> = _summaryOutput.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _events = MutableSharedFlow<String>()
    val events: SharedFlow<String> = _events.asSharedFlow()

    init {
        viewModelScope.launch {
            BackgroundCodingWorker.reconcileInterruptedJobs(getApplication(), repository)
        }
    }

    fun setProjectName(name: String) {
        _projectName.value = ProjectFileManager.sanitizeProjectName(name, "yasmin_app")
    }

    fun selectFileIndex(index: Int) {
        if (index in _projectFiles.value.indices) {
            _selectedFileIndex.value = index
        }
    }

    fun updateSelectedFileContent(newContent: String) {
        val current = _projectFiles.value.toMutableList()
        val idx = _selectedFileIndex.value
        if (idx !in current.indices) return
        val file = current[idx]
        if (file.content == newContent) return
        current[idx] = file.copy(content = newContent)
        _projectFiles.value = current
    }

    fun saveCurrentFileToDisk(): File? {
        val idx = _selectedFileIndex.value
        val fileItem = _projectFiles.value.getOrNull(idx) ?: return null
        return fileManager.writeSingleProjectFile(_projectName.value, fileItem.path, fileItem.content)
    }

    fun saveWholeProjectToDisk(): File {
        val dir = fileManager.saveMultiFileProject(_projectName.value, _projectFiles.value)
        _projectFiles.value = fileManager.loadMultiFileProject(dir)
        return dir
    }

    fun runCodingTask(
        prompt: String,
        targetLanguage: String,
        mode: String,
        useBackgroundWorker: Boolean,
        includeDocs: Boolean
    ) {
        val cleanPrompt = prompt.trim()
        if (cleanPrompt.isEmpty()) {
            viewModelScope.launch { _events.emit("Enter a coding task prompt first.") }
            return
        }

        if (!repository.hasAnyAiConfigured(preferences.value)) {
            viewModelScope.launch {
                _events.emit("No AI provider configured. Add a Gemini or Groq API key in Settings first.")
            }
            return
        }

        val currentProject = _projectName.value.ifBlank { "yasmin_app" }
        if (useBackgroundWorker && mode != "explain") {
            viewModelScope.launch {
                val filesJson = gson.toJson(_projectFiles.value)
                BackgroundCodingWorker.enqueue(
                    context = getApplication(),
                    repository = repository,
                    projectName = currentProject,
                    language = targetLanguage,
                    prompt = cleanPrompt,
                    mode = mode,
                    includeDocs = includeDocs,
                    safUri = preferences.value.storageTreeUri,
                    initialFilesJson = filesJson
                )
                _summaryOutput.value = "Background coding task queued for '$currentProject' ($targetLanguage). Progress is shown below and in your notification shade."
                _events.emit("Queued background coding job.")
            }
            return
        }

        viewModelScope.launch {
            _isLoading.value = true
            _summaryOutput.value = "Yasmin AI is running '$mode' for $targetLanguage…"
            val res = repository.generateMultiFileProject(
                MultiFileCodeRequest(
                    prompt = cleanPrompt,
                    projectName = currentProject,
                    targetLanguage = targetLanguage,
                    existingFiles = _projectFiles.value,
                    mode = mode,
                    includeDocs = includeDocs
                )
            )
            when (res) {
                is AiResult.Success -> {
                    val data = res.data
                    if (mode == "explain") {
                        _summaryOutput.value = data.summary.ifBlank { "No explanation returned." }
                    } else {
                        val resolvedName = ProjectFileManager.sanitizeProjectName(
                            data.projectName.ifBlank { currentProject },
                            currentProject
                        )
                        _projectName.value = resolvedName
                        val merged = mergeFiles(_projectFiles.value, data.files, mode)
                        val dir = fileManager.saveMultiFileProject(
                            projectName = resolvedName,
                            files = merged,
                            readmeMarkdown = if (includeDocs) data.readmeMarkdown else ""
                        )
                        val loaded = fileManager.loadMultiFileProject(dir)
                        _projectFiles.value = loaded
                        _selectedFileIndex.value = 0
                        _summaryOutput.value = data.summary.ifBlank {
                            "Generated ${loaded.size} file(s) in $resolvedName."
                        }
                        val safUriStr = preferences.value.storageTreeUri
                        if (safUriStr.isNotBlank()) {
                            fileManager.syncProjectToSafTree(dir, Uri.parse(safUriStr))
                        }
                    }
                }
                is AiResult.Error -> {
                    _summaryOutput.value = "Error: ${res.message}"
                    _events.emit(res.message)
                }
            }
            _isLoading.value = false
        }
    }

    private fun mergeFiles(
        existing: List<GeneratedCodeFile>,
        incoming: List<GeneratedCodeFile>,
        mode: String
    ): List<GeneratedCodeFile> {
        if (mode == "generate" || existing.isEmpty()) return incoming
        val map = existing.associateBy { it.path }.toMutableMap()
        incoming.forEach { map[it.path] = it }
        return map.values.toList()
    }

    fun loadProjectDirectory(dir: File) {
        val loaded = fileManager.loadMultiFileProject(dir)
        _projectName.value = dir.name
        _projectFiles.value = loaded
        _selectedFileIndex.value = 0
        _summaryOutput.value = "Loaded project '${dir.name}' (${loaded.size} files)."
    }

    fun loadJobResult(job: CodingJobEntity) {
        val dir = if (job.projectPath.isNotBlank()) File(job.projectPath) else fileManager.getProjectDirectory(job.projectName)
        val loaded = fileManager.loadMultiFileProject(dir)
        _projectName.value = job.projectName
        _projectFiles.value = loaded
        _selectedFileIndex.value = 0
        _summaryOutput.value = job.summaryText.ifBlank { job.statusMessage }
    }

    fun cancelJob(jobId: String) {
        BackgroundCodingWorker.cancelJob(getApplication(), jobId)
        viewModelScope.launch {
            repository.updateCodingJobProgress(jobId, BackgroundCodingWorker.STATUS_CANCELLED, 0, "Cancelled by user.")
        }
    }

    fun retryJob(job: CodingJobEntity) {
        viewModelScope.launch {
            BackgroundCodingWorker.enqueue(
                context = getApplication(),
                repository = repository,
                projectName = job.projectName,
                language = job.language,
                prompt = job.prompt,
                mode = "generate",
                includeDocs = preferences.value.codingAutoGenerateDocs,
                safUri = preferences.value.storageTreeUri,
                initialFilesJson = job.filesJson
            )
            _events.emit("Retrying job '${job.projectName}'…")
        }
    }

    fun deleteJob(jobId: String) {
        viewModelScope.launch { repository.deleteCodingJob(jobId) }
    }

    fun importFromZip(uri: Uri, nameHint: String?) {
        val res = fileManager.importAnyProjectZip(uri, nameHint)
        if (res == null) {
            viewModelScope.launch { _events.emit("Could not read source files from selected ZIP.") }
        } else {
            _projectName.value = res.first
            _projectFiles.value = res.second
            _selectedFileIndex.value = 0
            _summaryOutput.value = "Imported ZIP project '${res.first}' (${res.second.size} files)."
        }
    }

    fun importFromSafFolder(treeUri: Uri) {
        fileManager.importProjectFromSafTree(treeUri).fold(
            onSuccess = { (name, files) ->
                _projectName.value = name
                _projectFiles.value = files
                _selectedFileIndex.value = 0
                _summaryOutput.value = "Reopened/imported folder '$name' (${files.size} files)."
            },
            onFailure = { err ->
                viewModelScope.launch { _events.emit(err.localizedMessage ?: "Failed to import folder.") }
            }
        )
    }

    fun syncCurrentProjectToSaf(treeUri: Uri) {
        if (_projectFiles.value.isEmpty()) {
            viewModelScope.launch { _events.emit("Generate or load a project first.") }
            return
        }
        val dir = saveWholeProjectToDisk()
        fileManager.syncProjectToSafTree(dir, treeUri).fold(
            onSuccess = { count ->
                viewModelScope.launch { _events.emit("Saved $count files into selected device folder.") }
            },
            onFailure = { err ->
                viewModelScope.launch { _events.emit(err.localizedMessage ?: "Folder sync failed.") }
            }
        )
    }
}
