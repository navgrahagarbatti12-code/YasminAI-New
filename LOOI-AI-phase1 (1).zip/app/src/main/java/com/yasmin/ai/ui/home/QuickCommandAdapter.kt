package com.yasmin.ai.ui.home

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.yasmin.ai.databinding.ItemQuickCommandBinding

class QuickCommandAdapter(
    private val commands: List<String>,
    private val onClick: (String) -> Unit
) : RecyclerView.Adapter<QuickCommandAdapter.QuickViewHolder>() {

    inner class QuickViewHolder(val binding: ItemQuickCommandBinding) :
        RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): QuickViewHolder {
        val binding = ItemQuickCommandBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return QuickViewHolder(binding)
    }

    override fun onBindViewHolder(holder: QuickViewHolder, position: Int) {
        val command = commands[position]
        holder.binding.tvQuickCommand.text = command
        holder.binding.root.setOnClickListener { onClick(command) }
    }

    override fun getItemCount(): Int = commands.size
}
