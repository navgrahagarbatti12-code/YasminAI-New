package com.yasmin.ai.voice

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import androidx.core.content.ContextCompat
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.sqrt

enum class AssistantVoiceState {
    IDLE,
    LISTENING,
    THINKING,
    SPEAKING
}

data class TtsVoiceOption(
    val name: String,
    val label: String
)

class VoiceAssistantManager(private val context: Context) {

    private val mainHandler = Handler(Looper.getMainLooper())
    private val audioManager = context.applicationContext.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private var speechRecognizer: SpeechRecognizer? = null
    private var textToSpeech: TextToSpeech? = null
    private var ttsReady = false
    private var activeFocusRequest: AudioFocusRequest? = null

    private val _voiceState = MutableStateFlow(AssistantVoiceState.IDLE)
    val voiceState: StateFlow<AssistantVoiceState> = _voiceState.asStateFlow()

    private val _rmsLevel = MutableStateFlow(0f)
    val rmsLevel: StateFlow<Float> = _rmsLevel.asStateFlow()

    private val _partialTranscript = MutableStateFlow("")
    val partialTranscript: StateFlow<String> = _partialTranscript.asStateFlow()

    private val _availableVoices = MutableStateFlow<List<TtsVoiceOption>>(emptyList())
    val availableVoices: StateFlow<List<TtsVoiceOption>> = _availableVoices.asStateFlow()

    private var onFinalResultCallback: ((String) -> Unit)? = null
    private var onErrorCallback: ((String) -> Unit)? = null
    private var onSpeechDoneCallback: (() -> Unit)? = null
    private var onBargeInCallback: (() -> Unit)? = null

    private var currentSpeechRate: Float = 1.0f
    private var currentSpeechPitch: Float = 1.0f
    private var currentLanguageMode: String = "hinglish"
    private var currentTimeoutSec: Int = 10
    private var preferredVoiceName: String = ""
    private var bargeInEnabled: Boolean = true

    private val bargeInActive = AtomicBoolean(false)
    private var bargeInThread: Thread? = null

    private val focusListener = AudioManager.OnAudioFocusChangeListener { change ->
        if (change == AudioManager.AUDIOFOCUS_LOSS || change == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT) {
            if (_voiceState.value == AssistantVoiceState.SPEAKING) {
                stopSpeaking()
            }
        }
    }

    init {
        initTextToSpeech()
    }

    private fun initTextToSpeech() {
        textToSpeech = TextToSpeech(context.applicationContext) { status ->
            ttsReady = status == TextToSpeech.SUCCESS
            if (ttsReady) {
                refreshAvailableVoices()
                applyVoiceSettings(
                    languageMode = currentLanguageMode,
                    speechRate = currentSpeechRate,
                    speechPitch = currentSpeechPitch,
                    timeoutSec = currentTimeoutSec,
                    voiceName = preferredVoiceName,
                    bargeIn = bargeInEnabled
                )
                textToSpeech?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        _voiceState.value = AssistantVoiceState.SPEAKING
                        if (bargeInEnabled) {
                            startBargeInMonitor()
                        }
                    }

                    override fun onDone(utteranceId: String?) {
                        stopBargeInMonitor()
                        abandonAudioFocus()
                        if (_voiceState.value == AssistantVoiceState.SPEAKING) {
                            _voiceState.value = AssistantVoiceState.IDLE
                            mainHandler.post { onSpeechDoneCallback?.invoke() }
                        }
                    }

                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        stopBargeInMonitor()
                        abandonAudioFocus()
                        _voiceState.value = AssistantVoiceState.IDLE
                    }
                })
            }
        }
    }

    private fun refreshAvailableVoices() {
        val tts = textToSpeech ?: return
        val voices: Set<Voice> = try {
            tts.voices.orEmpty()
        } catch (_: Exception) {
            emptySet()
        }
        val filtered = voices
            .filter { v ->
                val lang = v.locale?.language.orEmpty()
                lang == "en" || lang == "hi"
            }
            .sortedWith(compareBy<Voice> { it.locale?.toLanguageTag() }.thenBy { it.name })
            .take(30)
            .map { v ->
                val tag = v.locale?.toLanguageTag().orEmpty()
                val offline = if (v.isNetworkConnectionRequired) "Cloud" else "Offline"
                TtsVoiceOption(
                    name = v.name,
                    label = "${tag.uppercase(Locale.US)} · ${v.name.takeLast(14)} ($offline)"
                )
            }
        _availableVoices.value = listOf(TtsVoiceOption("", "Yasmin Natural Female (Auto)")) + filtered
    }

    fun applyVoiceSettings(
        languageMode: String,
        speechRate: Float,
        speechPitch: Float = 1.0f,
        timeoutSec: Int = 10,
        voiceName: String = preferredVoiceName,
        bargeIn: Boolean = bargeInEnabled
    ) {
        currentLanguageMode = languageMode
        currentSpeechRate = speechRate.coerceIn(0.5f, 2.0f)
        currentSpeechPitch = speechPitch.coerceIn(0.6f, 1.8f)
        currentTimeoutSec = timeoutSec.coerceIn(4, 30)
        preferredVoiceName = voiceName
        bargeInEnabled = bargeIn

        if (!ttsReady) return
        val locale = when (languageMode) {
            "hi" -> Locale("hi", "IN")
            "hinglish" -> Locale("en", "IN")
            else -> Locale.US
        }
        val res = textToSpeech?.setLanguage(locale)
        if (res == TextToSpeech.LANG_MISSING_DATA || res == TextToSpeech.LANG_NOT_SUPPORTED) {
            textToSpeech?.language = Locale.US
        }

        val voices = try {
            textToSpeech?.voices.orEmpty()
        } catch (_: Exception) {
            emptySet()
        }

        val chosenVoice = if (voiceName.isNotBlank()) {
            voices.firstOrNull { it.name == voiceName }
        } else {
            selectBestFemaleVoice(voices, locale)
        }
        if (chosenVoice != null) {
            textToSpeech?.voice = chosenVoice
        }

        textToSpeech?.setSpeechRate(currentSpeechRate)
        textToSpeech?.setPitch(currentSpeechPitch)
    }

    private fun selectBestFemaleVoice(voices: Set<Voice>, targetLocale: Locale): Voice? {
        if (voices.isEmpty()) return null
        val targetLang = targetLocale.language
        val targetCountry = targetLocale.country
        return voices
            .filter { it.locale?.language == targetLang }
            .maxByOrNull { voice ->
                var score = 0
                val lower = voice.name.lowercase(Locale.US)
                if (voice.locale?.country.equals(targetCountry, ignoreCase = true)) score += 10
                if (FEMALE_VOICE_TOKENS.any { lower.contains(it) }) score += 25
                if (MALE_VOICE_TOKENS.any { lower.contains(it) }) score -= 20
                if (!voice.isNetworkConnectionRequired) score += 4
                if (voice.quality >= Voice.QUALITY_HIGH) score += 3
                score
            }
    }

    fun setOnSpeechCompletedListener(listener: (() -> Unit)?) {
        onSpeechDoneCallback = listener
    }

    fun setOnBargeInDetectedListener(listener: (() -> Unit)?) {
        onBargeInCallback = listener
    }

    fun setThinkingState() {
        _voiceState.value = AssistantVoiceState.THINKING
    }

    fun setIdleState() {
        _voiceState.value = AssistantVoiceState.IDLE
    }

    fun startListening(
        languageMode: String,
        onResult: (String) -> Unit,
        onError: (String) -> Unit
    ) {
        stopSpeaking()
        requestAudioFocus()
        if (!SpeechRecognizer.isRecognitionAvailable(context) &&
            !(Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && SpeechRecognizer.isOnDeviceRecognitionAvailable(context))
        ) {
            abandonAudioFocus()
            onError("Speech recognition service is not available on this device.")
            return
        }

        onFinalResultCallback = onResult
        onErrorCallback = onError
        currentLanguageMode = languageMode

        speechRecognizer?.destroy()
        speechRecognizer = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
            SpeechRecognizer.isOnDeviceRecognitionAvailable(context)
        ) {
            SpeechRecognizer.createOnDeviceSpeechRecognizer(context.applicationContext)
        } else {
            SpeechRecognizer.createSpeechRecognizer(context.applicationContext)
        }.apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {
                    _voiceState.value = AssistantVoiceState.LISTENING
                    _partialTranscript.value = "Listening…"
                }

                override fun onBeginningOfSpeech() {}

                override fun onRmsChanged(rmsdB: Float) {
                    val normalized = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f)
                    _rmsLevel.value = normalized
                }

                override fun onBufferReceived(buffer: ByteArray?) {}

                override fun onEndOfSpeech() {
                    _rmsLevel.value = 0f
                }

                override fun onError(error: Int) {
                    _rmsLevel.value = 0f
                    abandonAudioFocus()
                    _voiceState.value = AssistantVoiceState.IDLE
                    val message = when (error) {
                        SpeechRecognizer.ERROR_AUDIO -> "Audio recording error."
                        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission required."
                        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT ->
                            "Network issue during speech recognition."
                        SpeechRecognizer.ERROR_NO_MATCH -> "No speech recognized. Please try again."
                        SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Listening timed out."
                        else -> "Speech recognition error ($error)."
                    }
                    onErrorCallback?.invoke(message)
                }

                override fun onResults(results: Bundle?) {
                    _rmsLevel.value = 0f
                    abandonAudioFocus()
                    val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    val best = matches?.firstOrNull()?.trim().orEmpty()
                    if (best.isNotEmpty()) {
                        _partialTranscript.value = best
                        if (isStopListeningCommand(best)) {
                            _voiceState.value = AssistantVoiceState.IDLE
                        } else {
                            _voiceState.value = AssistantVoiceState.THINKING
                        }
                        onFinalResultCallback?.invoke(best)
                    } else {
                        _voiceState.value = AssistantVoiceState.IDLE
                        onErrorCallback?.invoke("Did not catch that. Please speak again.")
                    }
                }

                override fun onPartialResults(partialResults: Bundle?) {
                    val partial = partialResults
                        ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull()
                    if (!partial.isNullOrBlank()) {
                        _partialTranscript.value = partial
                        if (isStopListeningCommand(partial)) {
                            stopListening()
                        }
                    }
                }

                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
        }

        val recognitionLocale = when (languageMode) {
            "hi" -> "hi-IN"
            "hinglish" -> "en-IN"
            else -> "en-US"
        }

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, recognitionLocale)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(
                RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS,
                (currentTimeoutSec * 160L).coerceIn(1100L, 4500L)
            )
        }

        _voiceState.value = AssistantVoiceState.LISTENING
        speechRecognizer?.startListening(intent)
    }

    fun stopListening() {
        speechRecognizer?.stopListening()
        _rmsLevel.value = 0f
        abandonAudioFocus()
        if (_voiceState.value == AssistantVoiceState.LISTENING) {
            _voiceState.value = AssistantVoiceState.IDLE
        }
    }

    fun speak(text: String) {
        if (!ttsReady || text.isBlank()) {
            _voiceState.value = AssistantVoiceState.IDLE
            return
        }
        requestAudioFocus()
        val cleanText = text
            .replace("```[\\s\\S]*?```".toRegex(), " Code snippet ready on screen. ")
            .replace("*", "")
            .replace("#", "")
            .take(1500)

        textToSpeech?.speak(
            cleanText,
            TextToSpeech.QUEUE_FLUSH,
            null,
            "yasmin_utterance_${System.currentTimeMillis()}"
        )
    }

    fun stopSpeaking() {
        stopBargeInMonitor()
        textToSpeech?.stop()
        _rmsLevel.value = 0f
        abandonAudioFocus()
        if (_voiceState.value == AssistantVoiceState.SPEAKING) {
            _voiceState.value = AssistantVoiceState.IDLE
        }
    }

    @SuppressLint("MissingPermission")
    private fun startBargeInMonitor() {
        if (!bargeInEnabled) return
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED
        ) {
            return
        }
        if (bargeInActive.getAndSet(true)) return

        bargeInThread = Thread {
            val sampleRate = 16000
            val frameSamples = 640 // 40ms frames
            val minBuf = AudioRecord.getMinBufferSize(
                sampleRate,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT
            ).coerceAtLeast(frameSamples * 4)

            val recorder = try {
                AudioRecord(
                    MediaRecorder.AudioSource.VOICE_COMMUNICATION,
                    sampleRate,
                    AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT,
                    minBuf
                )
            } catch (_: Exception) {
                null
            }

            if (recorder == null || recorder.state != AudioRecord.STATE_INITIALIZED) {
                recorder?.release()
                bargeInActive.set(false)
                return@Thread
            }

            val buffer = ShortArray(frameSamples)
            var speechFrames = 0
            val startAt = System.currentTimeMillis()
            try {
                recorder.startRecording()
                while (bargeInActive.get() && _voiceState.value == AssistantVoiceState.SPEAKING) {
                    val read = recorder.read(buffer, 0, buffer.size)
                    if (read <= 0) continue
                    // Ignore initial 480ms so TTS start click doesn't self-interrupt
                    if (System.currentTimeMillis() - startAt < 480L) continue

                    var sumSq = 0.0
                    for (i in 0 until read) {
                        val s = buffer[i].toDouble()
                        sumSq += s * s
                    }
                    val rms = sqrt(sumSq / read)
                    if (rms > 2400.0) {
                        speechFrames++
                        if (speechFrames >= 4) {
                            bargeInActive.set(false)
                            mainHandler.post {
                                stopSpeaking()
                                onBargeInCallback?.invoke()
                            }
                            break
                        }
                    } else {
                        speechFrames = (speechFrames - 1).coerceAtLeast(0)
                    }
                }
            } catch (_: Exception) {
            } finally {
                try {
                    recorder.stop()
                } catch (_: Exception) {
                }
                recorder.release()
                bargeInActive.set(false)
            }
        }.apply {
            name = "YasminBargeInMonitor"
            isDaemon = true
            start()
        }
    }

    private fun stopBargeInMonitor() {
        bargeInActive.set(false)
        bargeInThread = null
    }

    fun isStopListeningCommand(text: String): Boolean {
        val norm = text.lowercase(Locale.US).trim()
        return norm == "stop listening" ||
            norm == "stop yasmin" ||
            norm == "yasmin stop" ||
            norm == "band karo" ||
            norm == "sunna band karo" ||
            norm == "chup ho jao"
    }

    private fun requestAudioFocus() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ASSISTANT)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                .setAcceptsDelayedFocusGain(false)
                .setOnAudioFocusChangeListener(focusListener)
                .build()
            activeFocusRequest = req
            audioManager.requestAudioFocus(req)
        } else {
            @Suppress("DEPRECATION")
            audioManager.requestAudioFocus(
                focusListener,
                AudioManager.STREAM_MUSIC,
                AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK
            )
        }
    }

    private fun abandonAudioFocus() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            activeFocusRequest?.let { audioManager.abandonAudioFocusRequest(it) }
            activeFocusRequest = null
        } else {
            @Suppress("DEPRECATION")
            audioManager.abandonAudioFocus(focusListener)
        }
    }

    fun release() {
        stopBargeInMonitor()
        abandonAudioFocus()
        speechRecognizer?.destroy()
        speechRecognizer = null
        textToSpeech?.stop()
        textToSpeech?.shutdown()
        textToSpeech = null
    }

    companion object {
        private val FEMALE_VOICE_TOKENS = listOf(
            "female", "-sfg-", "-sfb-", "-wavenet-a", "-wavenet-c", "-wavenet-e",
            "-wavenet-f", "-hia-", "-hic-", "-hie-", "-ena-", "-enc-", "-tpf-",
            "-tpc-", "veena", "lekha", "samantha", "karen", "moira", "-f-"
        )
        private val MALE_VOICE_TOKENS = listOf(
            "male", "-sbm-", "-wavenet-b", "-wavenet-d", "-hib-", "-hid-", "-enb-", "-end-"
        )
    }
}
