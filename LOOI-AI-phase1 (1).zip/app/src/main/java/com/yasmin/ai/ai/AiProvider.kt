package com.yasmin.ai.ai

import kotlinx.coroutines.flow.Flow

/**
 * Modular AI Provider contract supporting Direct Google Gemini API, Direct Groq API,
 * optional self-hosted Gemini/Groq backend proxy, automatic fallback, streaming responses,
 * multi-file coding agent, dynamic model listing, and daily briefings.
 */
interface AiProvider {
    suspend fun chat(request: GeminiChatRequest): AiResult<GeminiResponse>
    fun streamChat(request: GeminiChatRequest): Flow<String>
    suspend fun planActions(request: GeminiAgentRequest): AiResult<GeminiAgentResponse>
    suspend fun generateCode(request: GeminiCodeRequest): AiResult<GeminiResponse>
    suspend fun generateMultiFileProject(request: MultiFileCodeRequest): AiResult<MultiFileCodeResponse>
    suspend fun analyzeVision(request: GeminiVisionRequest): AiResult<GeminiResponse>
    suspend fun fetchBriefing(request: BriefingRequest): AiResult<GeminiResponse>
    suspend fun executePythonRemote(code: String): AiResult<PythonSandboxResponse>
    suspend fun checkHealth(): AiResult<Boolean>
}
