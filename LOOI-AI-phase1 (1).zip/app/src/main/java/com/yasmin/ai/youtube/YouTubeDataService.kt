package com.yasmin.ai.youtube

import android.net.Uri
import com.google.gson.Gson
import com.google.gson.JsonArray
import com.google.gson.JsonElement
import com.google.gson.JsonObject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory
import java.io.IOException
import java.io.StringReader
import java.util.concurrent.TimeUnit

/**
 * Authorized YouTube data, metadata, playlist/channel, and caption retrieval service.
 * - Uses official YouTube Data API v3 when an encrypted API key is configured in SecureVault.
 * - Falls back legitimately to official YouTube oEmbed metadata + public caption track manifests
 *   where enabled by creators; never bypasses authentication/DRM or invents missing transcripts.
 */
class YouTubeDataService(
    private val apiKeyProvider: () -> String = { "" }
) {
    private val gson = Gson()
    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(25, TimeUnit.SECONDS)
        .build()

    sealed class DataResult<out T> {
        data class Success<T>(val data: T, val usedOfficialApi: Boolean = false) : DataResult<T>()
        data class Error(val message: String, val code: Int? = null) : DataResult<Nothing>()
    }

    suspend fun search(
        rawQuery: String,
        filter: YouTubeSearchFilter = YouTubeSearchFilter.VIDEO,
        creatorName: String = "",
        maxResults: Int = 12
    ): DataResult<List<YouTubeVideoInfo>> = withContext(Dispatchers.IO) {
        val cleanQuery = rawQuery.trim()
        val apiKey = apiKeyProvider().trim()
        if (apiKey.isEmpty()) {
            return@withContext DataResult.Error(
                "YouTube Data API v3 key is not configured in Settings. " +
                    "You can still paste any YouTube video/playlist URL directly or open YouTube search in the app/browser."
            )
        }
        val queryWithFilter = buildFilteredQuery(cleanQuery, filter, creatorName)
        val typeParam = when (filter) {
            YouTubeSearchFilter.CHANNEL -> "channel"
            YouTubeSearchFilter.PLAYLIST -> "playlist"
            else -> "video"
        }
        val uriBuilder = Uri.parse("$YT_API_BASE/search").buildUpon()
            .appendQueryParameter("part", "snippet")
            .appendQueryParameter("q", queryWithFilter)
            .appendQueryParameter("type", typeParam)
            .appendQueryParameter("maxResults", maxResults.coerceIn(1, 20).toString())
            .appendQueryParameter("key", apiKey)

        if (filter == YouTubeSearchFilter.SHORTS) {
            uriBuilder.appendQueryParameter("videoDuration", "short")
        }
        if (filter == YouTubeSearchFilter.LATEST) {
            uriBuilder.appendQueryParameter("order", "date")
        }
        if (filter == YouTubeSearchFilter.EDUCATION) {
            uriBuilder.appendQueryParameter("videoCategoryId", "27")
        }

        val req = Request.Builder().url(uriBuilder.build().toString()).get().build()
        try {
            httpClient.newCall(req).execute().use { response ->
                val raw = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    return@withContext DataResult.Error(mapYouTubeApiError(response.code, raw), response.code)
                }
                val root = gson.fromJson(raw, JsonObject::class.java)
                val items = root?.getAsJsonArray("items") ?: JsonArray()
                val baseResults = mutableListOf<YouTubeVideoInfo>()
                val videoIds = mutableListOf<String>()

                for (el in items) {
                    val itemObj = el?.takeIf { it.isJsonObject }?.asJsonObject ?: continue
                    val idObj = itemObj.getAsJsonObject("id") ?: continue
                    val snippet = itemObj.getAsJsonObject("snippet") ?: continue
                    val kind = idObj.get("kind").asSafeString().orEmpty()
                    val title = unescapeHtml(snippet.get("title").asSafeString().orEmpty())
                    val channelId = snippet.get("channelId").asSafeString().orEmpty()
                    val channelTitle = unescapeHtml(snippet.get("channelTitle").asSafeString().orEmpty())
                    val description = unescapeHtml(snippet.get("description").asSafeString().orEmpty())
                    val publishedAt = snippet.get("publishedAt").asSafeString().orEmpty()
                    val thumb = extractBestThumbnail(snippet.getAsJsonObject("thumbnails"))

                    when {
                        kind.endsWith("#channel") || filter == YouTubeSearchFilter.CHANNEL -> {
                            val chId = idObj.get("channelId").asSafeString().orEmpty().ifBlank { channelId }
                            if (chId.isNotBlank()) {
                                baseResults.add(
                                    YouTubeVideoInfo(
                                        videoId = chId,
                                        title = title,
                                        channelId = chId,
                                        channelTitle = channelTitle.ifBlank { title },
                                        description = description,
                                        publishedAt = publishedAt,
                                        thumbnailUrl = thumb,
                                        itemType = YouTubeItemType.CHANNEL,
                                        sourceUrl = "https://www.youtube.com/channel/$chId"
                                    )
                                )
                            }
                        }
                        kind.endsWith("#playlist") || filter == YouTubeSearchFilter.PLAYLIST -> {
                            val plId = idObj.get("playlistId").asSafeString().orEmpty()
                            if (plId.isNotBlank()) {
                                baseResults.add(
                                    YouTubeVideoInfo(
                                        videoId = plId,
                                        title = title,
                                        channelId = channelId,
                                        channelTitle = channelTitle,
                                        description = description,
                                        publishedAt = publishedAt,
                                        thumbnailUrl = thumb,
                                        itemType = YouTubeItemType.PLAYLIST,
                                        playlistId = plId,
                                        sourceUrl = "https://www.youtube.com/playlist?list=$plId"
                                    )
                                )
                            }
                        }
                        else -> {
                            val vid = idObj.get("videoId").asSafeString().orEmpty()
                            if (vid.isNotBlank()) {
                                videoIds.add(vid)
                                baseResults.add(
                                    YouTubeVideoInfo(
                                        videoId = vid,
                                        title = title,
                                        channelId = channelId,
                                        channelTitle = channelTitle,
                                        description = description,
                                        publishedAt = publishedAt,
                                        thumbnailUrl = thumb.ifBlank { "https://i.ytimg.com/vi/$vid/hqdefault.jpg" },
                                        isShort = filter == YouTubeSearchFilter.SHORTS,
                                        itemType = YouTubeItemType.VIDEO,
                                        sourceUrl = "https://www.youtube.com/watch?v=$vid",
                                        chapters = parseChaptersFromDescription(description)
                                    )
                                )
                            }
                        }
                    }
                }

                // Hydrate durations & full descriptions for video results
                val hydrated = if (videoIds.isNotEmpty()) {
                    hydrateVideoDetails(videoIds, apiKey, baseResults)
                } else {
                    baseResults
                }
                DataResult.Success(hydrated, usedOfficialApi = true)
            }
        } catch (e: IOException) {
            DataResult.Error("YouTube search network error: ${e.localizedMessage ?: "Offline or unreachable"}")
        } catch (e: Exception) {
            DataResult.Error("Failed to parse YouTube search response: ${e.localizedMessage ?: "Unexpected error"}")
        }
    }

    private fun hydrateVideoDetails(
        videoIds: List<String>,
        apiKey: String,
        fallback: List<YouTubeVideoInfo>
    ): List<YouTubeVideoInfo> {
        val url = Uri.parse("$YT_API_BASE/videos").buildUpon()
            .appendQueryParameter("part", "snippet,contentDetails,statistics")
            .appendQueryParameter("id", videoIds.joinToString(","))
            .appendQueryParameter("key", apiKey)
            .build()
            .toString()
        val req = Request.Builder().url(url).get().build()
        val detailsMap = mutableMapOf<String, YouTubeVideoInfo>()
        try {
            httpClient.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return fallback
                val root = gson.fromJson(resp.body?.string().orEmpty(), JsonObject::class.java)
                val items = root?.getAsJsonArray("items") ?: return fallback
                for (el in items) {
                    val obj = el?.takeIf { it.isJsonObject }?.asJsonObject ?: continue
                    val vid = obj.get("id").asSafeString().orEmpty()
                    val snippet = obj.getAsJsonObject("snippet")
                    val contentDetails = obj.getAsJsonObject("contentDetails")
                    val stats = obj.getAsJsonObject("statistics")
                    val title = unescapeHtml(snippet?.get("title").asSafeString().orEmpty())
                    val channelId = snippet?.get("channelId").asSafeString().orEmpty()
                    val channelTitle = unescapeHtml(snippet?.get("channelTitle").asSafeString().orEmpty())
                    val desc = unescapeHtml(snippet?.get("description").asSafeString().orEmpty())
                    val isoDur = contentDetails?.get("duration").asSafeString().orEmpty()
                    val seconds = parseIsoDurationSeconds(isoDur)
                    val durLabel = formatTimestampSeconds(seconds)
                    val views = formatViewCount(stats?.get("viewCount").asSafeString().orEmpty())
                    val thumb = extractBestThumbnail(snippet?.getAsJsonObject("thumbnails"))
                        .ifBlank { "https://i.ytimg.com/vi/$vid/hqdefault.jpg" }

                    if (vid.isNotBlank()) {
                        detailsMap[vid] = YouTubeVideoInfo(
                            videoId = vid,
                            title = title,
                            channelId = channelId,
                            channelTitle = channelTitle,
                            description = desc,
                            durationSeconds = seconds,
                            durationFormatted = durLabel,
                            publishedAt = snippet?.get("publishedAt").asSafeString().orEmpty(),
                            thumbnailUrl = thumb,
                            viewCount = views,
                            isShort = seconds in 1..60,
                            itemType = YouTubeItemType.VIDEO,
                            sourceUrl = "https://www.youtube.com/watch?v=$vid",
                            chapters = parseChaptersFromDescription(desc)
                        )
                    }
                }
            }
        } catch (_: Exception) {
            return fallback
        }
        return fallback.map { detailsMap[it.videoId] ?: it }
    }

    suspend fun fetchVideoMetadata(videoIdOrUrl: String): DataResult<YouTubeVideoInfo> = withContext(Dispatchers.IO) {
        val videoId = extractVideoId(videoIdOrUrl)
            ?: return@withContext DataResult.Error("Could not extract a valid YouTube video ID from '$videoIdOrUrl'.")

        val apiKey = apiKeyProvider().trim()
        if (apiKey.isNotEmpty()) {
            val url = Uri.parse("$YT_API_BASE/videos").buildUpon()
                .appendQueryParameter("part", "snippet,contentDetails,statistics")
                .appendQueryParameter("id", videoId)
                .appendQueryParameter("key", apiKey)
                .build()
                .toString()
            val req = Request.Builder().url(url).get().build()
            try {
                httpClient.newCall(req).execute().use { resp ->
                    val raw = resp.body?.string().orEmpty()
                    if (resp.isSuccessful) {
                        val items = gson.fromJson(raw, JsonObject::class.java)?.getAsJsonArray("items")
                        val item = items?.firstOrNull()?.takeIf { it.isJsonObject }?.asJsonObject
                        if (item != null) {
                            val snippet = item.getAsJsonObject("snippet")
                            val contentDetails = item.getAsJsonObject("contentDetails")
                            val stats = item.getAsJsonObject("statistics")
                            val desc = unescapeHtml(snippet?.get("description").asSafeString().orEmpty())
                            val sec = parseIsoDurationSeconds(contentDetails?.get("duration").asSafeString().orEmpty())
                            return@withContext DataResult.Success(
                                YouTubeVideoInfo(
                                    videoId = videoId,
                                    title = unescapeHtml(snippet?.get("title").asSafeString().orEmpty()),
                                    channelId = snippet?.get("channelId").asSafeString().orEmpty(),
                                    channelTitle = unescapeHtml(snippet?.get("channelTitle").asSafeString().orEmpty()),
                                    description = desc,
                                    durationSeconds = sec,
                                    durationFormatted = formatTimestampSeconds(sec),
                                    publishedAt = snippet?.get("publishedAt").asSafeString().orEmpty(),
                                    thumbnailUrl = extractBestThumbnail(snippet?.getAsJsonObject("thumbnails"))
                                        .ifBlank { "https://i.ytimg.com/vi/$videoId/hqdefault.jpg" },
                                    viewCount = formatViewCount(stats?.get("viewCount").asSafeString().orEmpty()),
                                    isShort = sec in 1..60,
                                    itemType = YouTubeItemType.VIDEO,
                                    sourceUrl = "https://www.youtube.com/watch?v=$videoId",
                                    chapters = parseChaptersFromDescription(desc)
                                ),
                                usedOfficialApi = true
                            )
                        } else {
                            return@withContext DataResult.Error("Video '$videoId' was not found or is private/unavailable.")
                        }
                    }
                }
            } catch (_: IOException) {
                // Fall through to official oEmbed endpoint
            }
        }

        // Official YouTube oEmbed endpoint (no API key required)
        val watchUrl = "https://www.youtube.com/watch?v=$videoId"
        val oembedUrl = "https://www.youtube.com/oembed?url=${Uri.encode(watchUrl)}&format=json"
        val oembedReq = Request.Builder().url(oembedUrl).get().build()
        try {
            httpClient.newCall(oembedReq).execute().use { resp ->
                if (!resp.isSuccessful) {
                    return@withContext DataResult.Error(
                        when (resp.code) {
                            401, 403 -> "Video '$videoId' is private or embedding-restricted (HTTP ${resp.code})."
                            404 -> "Video '$videoId' does not exist or has been removed (HTTP 404)."
                            else -> "Could not fetch video metadata (HTTP ${resp.code})."
                        },
                        resp.code
                    )
                }
                val root = gson.fromJson(resp.body?.string().orEmpty(), JsonObject::class.java)
                val title = unescapeHtml(root?.get("title").asSafeString().orEmpty())
                val author = unescapeHtml(root?.get("author_name").asSafeString().orEmpty())
                val thumb = root?.get("thumbnail_url").asSafeString().orEmpty()
                    .ifBlank { "https://i.ytimg.com/vi/$videoId/hqdefault.jpg" }
                return@withContext DataResult.Success(
                    YouTubeVideoInfo(
                        videoId = videoId,
                        title = title.ifBlank { "YouTube Video ($videoId)" },
                        channelTitle = author.ifBlank { "YouTube Creator" },
                        thumbnailUrl = thumb,
                        sourceUrl = watchUrl
                    ),
                    usedOfficialApi = false
                )
            }
        } catch (e: IOException) {
            DataResult.Error("Network error while fetching video metadata: ${e.localizedMessage ?: "Offline"}")
        }
    }

    suspend fun fetchPlaylistVideos(playlistIdOrUrl: String, maxResults: Int = 15): DataResult<List<YouTubeVideoInfo>> =
        withContext(Dispatchers.IO) {
            val playlistId = extractPlaylistId(playlistIdOrUrl) ?: playlistIdOrUrl.trim()
            if (playlistId.equals("WL", ignoreCase = true) || playlistId.equals("LL", ignoreCase = true)) {
                return@withContext DataResult.Error(
                    "Personal account playlists like Watch Later (WL) require signed-in YouTube OAuth or opening directly in the YouTube app."
                )
            }
            val apiKey = apiKeyProvider().trim()
            if (apiKey.isEmpty()) {
                return@withContext DataResult.Error("Configure your YouTube Data API v3 key in Settings to inspect playlists inside Yasmin AI.")
            }
            val url = Uri.parse("$YT_API_BASE/playlistItems").buildUpon()
                .appendQueryParameter("part", "snippet,contentDetails")
                .appendQueryParameter("playlistId", playlistId)
                .appendQueryParameter("maxResults", maxResults.coerceIn(1, 25).toString())
                .appendQueryParameter("key", apiKey)
                .build()
                .toString()
            val req = Request.Builder().url(url).get().build()
            try {
                httpClient.newCall(req).execute().use { resp ->
                    val raw = resp.body?.string().orEmpty()
                    if (!resp.isSuccessful) {
                        return@withContext DataResult.Error(mapYouTubeApiError(resp.code, raw), resp.code)
                    }
                    val items = gson.fromJson(raw, JsonObject::class.java)?.getAsJsonArray("items") ?: JsonArray()
                    val videos = items.mapNotNull { el ->
                        val obj = el?.takeIf { it.isJsonObject }?.asJsonObject ?: return@mapNotNull null
                        val snippet = obj.getAsJsonObject("snippet") ?: return@mapNotNull null
                        val resourceId = snippet.getAsJsonObject("resourceId")
                        val vid = resourceId?.get("videoId").asSafeString().orEmpty()
                        if (vid.isBlank()) return@mapNotNull null
                        val title = unescapeHtml(snippet.get("title").asSafeString().orEmpty())
                        if (title == "Deleted video" || title == "Private video") return@mapNotNull null
                        val desc = unescapeHtml(snippet.get("description").asSafeString().orEmpty())
                        YouTubeVideoInfo(
                            videoId = vid,
                            title = title,
                            channelId = snippet.get("videoOwnerChannelId").asSafeString().orEmpty(),
                            channelTitle = unescapeHtml(
                                snippet.get("videoOwnerChannelTitle").asSafeString()
                                    ?: snippet.get("channelTitle").asSafeString().orEmpty()
                            ),
                            description = desc,
                            publishedAt = snippet.get("publishedAt").asSafeString().orEmpty(),
                            thumbnailUrl = extractBestThumbnail(snippet.getAsJsonObject("thumbnails"))
                                .ifBlank { "https://i.ytimg.com/vi/$vid/hqdefault.jpg" },
                            playlistId = playlistId,
                            sourceUrl = "https://www.youtube.com/watch?v=$vid&list=$playlistId",
                            chapters = parseChaptersFromDescription(desc)
                        )
                    }
                    if (videos.isEmpty()) {
                        DataResult.Error("No playable public videos found in playlist '$playlistId'.")
                    } else {
                        DataResult.Success(hydrateVideoDetails(videos.map { it.videoId }, apiKey, videos), usedOfficialApi = true)
                    }
                }
            } catch (e: IOException) {
                DataResult.Error("Network error while loading playlist: ${e.localizedMessage ?: "Offline"}")
            }
        }

    suspend fun fetchRelatedRecommendations(video: YouTubeVideoInfo): DataResult<List<YouTubeVideoInfo>> {
        val cleanTitleTopic = video.title.split("|", "-", "—", ":").firstOrNull()?.trim().orEmpty()
        val query = cleanTitleTopic.ifBlank { video.channelTitle }.ifBlank { "tutorial" }
        return search(query, YouTubeSearchFilter.VIDEO, maxResults = 8)
    }

    /**
     * Fetches authorized / creator-enabled captions without cookie extraction or unauthorized scraping.
     * Supports language selection (preferredLanguage -> en -> hi -> first available) and clearly reports
     * UNAVAILABLE or RESTRICTED when captions are disabled or blocked.
     */
    suspend fun fetchTranscript(
        videoIdOrUrl: String,
        preferredLanguage: String = "en"
    ): TranscriptResult = withContext(Dispatchers.IO) {
        val videoId = extractVideoId(videoIdOrUrl) ?: return@withContext TranscriptResult(
            videoId = videoIdOrUrl,
            status = TranscriptStatus.ERROR,
            statusReason = "Invalid YouTube video ID or URL."
        )

        // Step 1: Discover available public caption tracks via standard watch page player metadata
        val discovered = discoverPublicCaptionTracks(videoId)
        if (discovered.restrictedReason != null) {
            return@withContext TranscriptResult(
                videoId = videoId,
                status = TranscriptStatus.RESTRICTED,
                statusReason = discovered.restrictedReason
            )
        }

        val chosenTrack = selectPreferredTrack(discovered.tracks, preferredLanguage)
        if (chosenTrack != null) {
            val segments = fetchTrackSegments(chosenTrack.baseUrl)
            if (segments.isNotEmpty()) {
                val formatted = formatSegmentsWithTimestamps(segments)
                val chunks = chunkTranscriptText(formatted)
                return@withContext TranscriptResult(
                    videoId = videoId,
                    status = TranscriptStatus.AVAILABLE,
                    languageCode = chosenTrack.languageCode,
                    availableLanguages = discovered.tracks.map { it.languageCode }.distinct(),
                    segments = segments,
                    rawTextWithTimestamps = formatted,
                    statusReason = "Captions loaded (${chosenTrack.languageCode}, ${segments.size} segments).",
                    isChunked = chunks.size > 1,
                    chunkCount = chunks.size
                )
            }
        }

        // Step 2: Public TimedText fallback check across requested language & common fallbacks
        val candidateLangs = listOf(preferredLanguage, "en", "en-US", "hi", "en-IN").distinct()
        for (lang in candidateLangs) {
            val timedTextUrl = "https://www.youtube.com/api/timedtext?lang=${Uri.encode(lang)}&v=$videoId"
            val segments = fetchTrackSegments(timedTextUrl)
            if (segments.isNotEmpty()) {
                val formatted = formatSegmentsWithTimestamps(segments)
                val chunks = chunkTranscriptText(formatted)
                return@withContext TranscriptResult(
                    videoId = videoId,
                    status = TranscriptStatus.AVAILABLE,
                    languageCode = lang,
                    availableLanguages = candidateLangs,
                    segments = segments,
                    rawTextWithTimestamps = formatted,
                    statusReason = "Captions loaded ($lang, ${segments.size} segments).",
                    isChunked = chunks.size > 1,
                    chunkCount = chunks.size
                )
            }
        }

        TranscriptResult(
            videoId = videoId,
            status = TranscriptStatus.UNAVAILABLE,
            availableLanguages = discovered.tracks.map { it.languageCode }.distinct(),
            statusReason = if (discovered.tracks.isEmpty()) {
                "Creator-enabled captions/transcripts are unavailable for this video. Summaries & Q&A will rely strictly on available metadata or your consented screen text."
            } else {
                "Caption tracks were listed (${discovered.tracks.joinToString { it.languageCode }}) but could not be downloaded."
            }
        )
    }

    private data class DiscoveredTrack(val languageCode: String, val name: String, val baseUrl: String)
    private data class DiscoveryOutcome(val tracks: List<DiscoveredTrack>, val restrictedReason: String? = null)

    private fun discoverPublicCaptionTracks(videoId: String): DiscoveryOutcome {
        val watchReq = Request.Builder()
            .url("https://www.youtube.com/watch?v=$videoId")
            .addHeader("Accept-Language", "en-US,en;q=0.9,hi;q=0.8")
            .get()
            .build()
        return try {
            httpClient.newCall(watchReq).execute().use { resp ->
                if (!resp.isSuccessful) {
                    val restricted = if (resp.code in listOf(401, 403, 451)) {
                        "Video access is restricted (HTTP ${resp.code})."
                    } else null
                    return DiscoveryOutcome(emptyList(), restricted)
                }
                val html = resp.body?.string().orEmpty()
                if (html.contains("\"playabilityStatus\":{\"status\":\"LOGIN_REQUIRED\"", ignoreCase = true) ||
                    html.contains("\"status\":\"UNPLAYABLE\"", ignoreCase = true)
                ) {
                    return DiscoveryOutcome(
                        emptyList(),
                        "This video requires login, is age-restricted, or is unavailable in this region."
                    )
                }
                val captionIdx = html.indexOf("\"captionTracks\":[")
                if (captionIdx < 0) return DiscoveryOutcome(emptyList(), null)
                val arrayStart = html.indexOf('[', captionIdx)
                val arrayEnd = findMatchingBracket(html, arrayStart)
                if (arrayStart < 0 || arrayEnd <= arrayStart) return DiscoveryOutcome(emptyList(), null)
                val jsonArrStr = html.substring(arrayStart, arrayEnd + 1)
                val arr = gson.fromJson(jsonArrStr, JsonArray::class.java) ?: return DiscoveryOutcome(emptyList(), null)
                val tracks = arr.mapNotNull { el ->
                    val obj = el?.takeIf { it.isJsonObject }?.asJsonObject ?: return@mapNotNull null
                    val code = obj.get("languageCode").asSafeString().orEmpty()
                    val url = obj.get("baseUrl").asSafeString().orEmpty()
                    val nameObj = obj.getAsJsonObject("name")
                    val name = nameObj?.get("simpleText").asSafeString().orEmpty().ifBlank { code }
                    if (code.isNotBlank() && url.startsWith("https://")) DiscoveredTrack(code, name, url) else null
                }
                DiscoveryOutcome(tracks, null)
            }
        } catch (_: Exception) {
            DiscoveryOutcome(emptyList(), null)
        }
    }

    private fun selectPreferredTrack(tracks: List<DiscoveredTrack>, preferredLang: String): DiscoveredTrack? {
        if (tracks.isEmpty()) return null
        val pref = preferredLang.lowercase()
        return tracks.firstOrNull { it.languageCode.equals(pref, ignoreCase = true) }
            ?: tracks.firstOrNull { it.languageCode.lowercase().startsWith(pref) }
            ?: tracks.firstOrNull { it.languageCode.equals("en", ignoreCase = true) }
            ?: tracks.firstOrNull { it.languageCode.lowercase().startsWith("en") }
            ?: tracks.firstOrNull { it.languageCode.lowercase().startsWith("hi") }
            ?: tracks.firstOrNull()
    }

    private fun fetchTrackSegments(baseUrl: String): List<TranscriptSegment> {
        val req = Request.Builder().url(baseUrl).get().build()
        return try {
            httpClient.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return emptyList()
                val body = resp.body?.string().orEmpty().trim()
                if (body.isEmpty()) return emptyList()
                if (body.startsWith("{")) parseTimedTextJson3(body) else parseTimedTextXml(body)
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun findMatchingBracket(source: String, openIndex: Int): Int {
        if (openIndex < 0 || openIndex >= source.length) return -1
        var depth = 0
        var inString = false
        var escape = false
        for (i in openIndex until source.length) {
            val c = source[i]
            if (escape) {
                escape = false
                continue
            }
            if (c == '\\' && inString) {
                escape = true
                continue
            }
            if (c == '"') {
                inString = !inString
                continue
            }
            if (!inString) {
                if (c == '[') depth++
                else if (c == ']') {
                    depth--
                    if (depth == 0) return i
                }
            }
        }
        return -1
    }

    private fun extractBestThumbnail(thumbs: JsonObject?): String {
        if (thumbs == null) return ""
        for (key in listOf("high", "medium", "standard", "default")) {
            val u = thumbs.getAsJsonObject(key)?.get("url").asSafeString()
            if (!u.isNullOrBlank()) return u
        }
        return ""
    }

    private fun mapYouTubeApiError(code: Int, rawBody: String): String {
        val msg = runCatching {
            gson.fromJson(rawBody, JsonObject::class.java)
                ?.getAsJsonObject("error")
                ?.get("message")?.asString
        }.getOrNull()
        return when (code) {
            400 -> msg ?: "Invalid YouTube Data API request (HTTP 400)."
            401, 403 -> msg ?: "YouTube Data API v3 key rejected or quota exceeded (HTTP $code). Check key in Settings."
            404 -> "Requested YouTube resource not found (HTTP 404)."
            429 -> "YouTube API rate limit reached (HTTP 429). Retry shortly."
            else -> msg ?: "YouTube Data API error (HTTP $code)."
        }
    }

    companion object {
        private const val YT_API_BASE = "https://www.googleapis.com/youtube/v3"

        fun buildFilteredQuery(rawQuery: String, filter: YouTubeSearchFilter, creatorName: String = ""): String {
            val base = rawQuery.trim()
            val creator = creatorName.trim()
            return buildString {
                if (creator.isNotEmpty() && !base.contains(creator, ignoreCase = true)) {
                    append(creator).append(' ')
                }
                append(base)
                when (filter) {
                    YouTubeSearchFilter.TUTORIAL -> if (!base.contains("tutorial", ignoreCase = true)) append(" tutorial")
                    YouTubeSearchFilter.EDUCATION -> if (!base.contains("course", ignoreCase = true) && !base.contains("lecture", ignoreCase = true)) append(" explained course")
                    YouTubeSearchFilter.SHORTS -> if (!base.contains("shorts", ignoreCase = true)) append(" #shorts")
                    else -> Unit
                }
            }.trim()
        }

        fun extractVideoId(input: String): String? {
            val trimmed = input.trim()
            if (trimmed.isEmpty()) return null
            if (Regex("^[a-zA-Z0-9_-]{11}$").matches(trimmed)) return trimmed

            val patterns = listOf(
                Regex("(?:v=|/v/|/embed/|/shorts/|/live/|youtu\\.be/)([a-zA-Z0-9_-]{11})")
            )
            for (regex in patterns) {
                val m = regex.find(trimmed)
                if (m != null) return m.groupValues[1]
            }
            return null
        }

        fun extractPlaylistId(input: String): String? {
            val trimmed = input.trim()
            if (trimmed.isEmpty()) return null
            val m = Regex("[?&]list=([a-zA-Z0-9_-]+)").find(trimmed)
            if (m != null) return m.groupValues[1]
            if (Regex("^(PL|UU|OL|RD|WL|LL)[a-zA-Z0-9_-]*$").matches(trimmed)) return trimmed
            return null
        }

        fun parseIsoDurationSeconds(isoDuration: String): Int {
            if (isoDuration.isBlank()) return 0
            val m = Regex("^PT(?:(\\d+)H)?(?:(\\d+)M)?(?:(\\d+)S)?$").matchEntire(isoDuration.trim()) ?: return 0
            val h = m.groupValues[1].toIntOrNull() ?: 0
            val min = m.groupValues[2].toIntOrNull() ?: 0
            val s = m.groupValues[3].toIntOrNull() ?: 0
            return (h * 3600) + (min * 60) + s
        }

        fun formatTimestampSeconds(totalSeconds: Int): String {
            val safe = totalSeconds.coerceAtLeast(0)
            val h = safe / 3600
            val m = (safe % 3600) / 60
            val s = safe % 60
            return if (h > 0) String.format("%d:%02d:%02d", h, m, s) else String.format("%02d:%02d", m, s)
        }

        fun parseChaptersFromDescription(description: String): List<VideoChapter> {
            if (description.isBlank()) return emptyList()
            val regex = Regex("(?m)^\\s*(?:(\\d{1,2}):)?(\\d{1,2}):(\\d{2})\\s*[-–:|]?\\s*(.+)$")
            return regex.findAll(description).mapNotNull { match ->
                val h = match.groupValues[1].toIntOrNull() ?: 0
                val m = match.groupValues[2].toIntOrNull() ?: 0
                val s = match.groupValues[3].toIntOrNull() ?: 0
                val title = match.groupValues[4].trim()
                if (title.isBlank()) return@mapNotNull null
                val totalSec = h * 3600 + m * 60 + s
                VideoChapter(
                    startSeconds = totalSec,
                    timestampLabel = formatTimestampSeconds(totalSec),
                    title = title.take(120)
                )
            }.toList()
        }

        fun parseTimedTextXml(xml: String): List<TranscriptSegment> {
            if (xml.isBlank()) return emptyList()
            val segments = mutableListOf<TranscriptSegment>()
            try {
                val factory = XmlPullParserFactory.newInstance()
                val parser = factory.newPullParser()
                parser.setInput(StringReader(xml))
                var eventType = parser.eventType
                while (eventType != XmlPullParser.END_DOCUMENT) {
                    if (eventType == XmlPullParser.START_TAG && (parser.name == "text" || parser.name == "p")) {
                        val startAttr = parser.getAttributeValue(null, "start")?.toDoubleOrNull()
                            ?: (parser.getAttributeValue(null, "t")?.toDoubleOrNull()?.div(1000.0) ?: 0.0)
                        val durAttr = parser.getAttributeValue(null, "dur")?.toDoubleOrNull()
                            ?: (parser.getAttributeValue(null, "d")?.toDoubleOrNull()?.div(1000.0) ?: 2.0)
                        val text = unescapeHtml(parser.nextText()).replace(Regex("\\s+"), " ").trim()
                        if (text.isNotEmpty()) {
                            segments.add(
                                TranscriptSegment(
                                    startSeconds = startAttr,
                                    durationSeconds = durAttr,
                                    timestampLabel = formatTimestampSeconds(startAttr.toInt()),
                                    text = text
                                )
                            )
                        }
                    }
                    eventType = parser.next()
                }
            } catch (_: Exception) {
                // Fallback simple regex parser for pure JVM unit test environments without Android XmlPullParser impl
                val tagRegex = Regex("<text[^>]*start=\"([0-9.]+)\"[^>]*?(?:dur=\"([0-9.]+)\")?[^>]*>([\\s\\S]*?)</text>")
                tagRegex.findAll(xml).forEach { match ->
                    val start = match.groupValues[1].toDoubleOrNull() ?: 0.0
                    val dur = match.groupValues[2].toDoubleOrNull() ?: 2.0
                    val rawTxt = match.groupValues[3].replace(Regex("<[^>]+>"), "")
                    val clean = unescapeHtml(rawTxt).replace(Regex("\\s+"), " ").trim()
                    if (clean.isNotEmpty()) {
                        segments.add(
                            TranscriptSegment(
                                startSeconds = start,
                                durationSeconds = dur,
                                timestampLabel = formatTimestampSeconds(start.toInt()),
                                text = clean
                            )
                        )
                    }
                }
            }
            return segments
        }

        fun parseTimedTextJson3(jsonRaw: String): List<TranscriptSegment> {
            return try {
                val root = Gson().fromJson(jsonRaw, JsonObject::class.java) ?: return emptyList()
                val events = root.getAsJsonArray("events") ?: return emptyList()
                val out = mutableListOf<TranscriptSegment>()
                for (el in events) {
                    val ev = el?.takeIf { it.isJsonObject }?.asJsonObject ?: continue
                    val startMs = ev.get("tStartMs").asSafeDouble() ?: continue
                    val durMs = ev.get("dDurationMs").asSafeDouble() ?: 2000.0
                    val segs = ev.getAsJsonArray("segs") ?: continue
                    val text = buildString {
                        for (sEl in segs) {
                            val utf8 = sEl?.takeIf { it.isJsonObject }?.asJsonObject?.get("utf8").asSafeString()
                            if (!utf8.isNullOrEmpty()) append(utf8)
                        }
                    }.replace(Regex("\\s+"), " ").trim()
                    if (text.isNotEmpty()) {
                        val startSec = startMs / 1000.0
                        out.add(
                            TranscriptSegment(
                                startSeconds = startSec,
                                durationSeconds = durMs / 1000.0,
                                timestampLabel = formatTimestampSeconds(startSec.toInt()),
                                text = text
                            )
                        )
                    }
                }
                out
            } catch (_: Exception) {
                emptyList()
            }
        }

        fun formatSegmentsWithTimestamps(segments: List<TranscriptSegment>): String {
            return segments.joinToString("\n") { "[${it.timestampLabel}] ${it.text}" }
        }

        fun chunkTranscriptText(transcriptWithTimestamps: String, maxCharsPerChunk: Int = 8500): List<String> {
            val clean = transcriptWithTimestamps.trim()
            if (clean.isEmpty()) return emptyList()
            if (clean.length <= maxCharsPerChunk) return listOf(clean)

            val chunks = mutableListOf<String>()
            val lines = clean.lines()
            val current = StringBuilder()
            for (line in lines) {
                if (current.isNotEmpty() && current.length + line.length + 1 > maxCharsPerChunk) {
                    chunks.add(current.toString().trim())
                    current.clear()
                }
                if (line.length > maxCharsPerChunk) {
                    var start = 0
                    while (start < line.length) {
                        val end = minOf(start + maxCharsPerChunk, line.length)
                        chunks.add(line.substring(start, end))
                        start = end
                    }
                } else {
                    if (current.isNotEmpty()) current.append('\n')
                    current.append(line)
                }
            }
            if (current.isNotEmpty()) chunks.add(current.toString().trim())
            return chunks
        }

        fun formatViewCount(raw: String): String {
            val count = raw.toLongOrNull() ?: return ""
            return when {
                count >= 1_000_000_000L -> String.format("%.1fB views", count / 1_000_000_000.0)
                count >= 1_000_000L -> String.format("%.1fM views", count / 1_000_000.0)
                count >= 1_000L -> String.format("%.1fK views", count / 1_000.0)
                else -> "$count views"
            }
        }

        fun unescapeHtml(raw: String): String {
            return raw
                .replace("&amp;", "&")
                .replace("&lt;", "<")
                .replace("&gt;", ">")
                .replace("&quot;", "\"")
                .replace("&#39;", "'")
                .replace("&apos;", "'")
                .replace("&#x27;", "'")
                .replace("&nbsp;", " ")
        }

        private fun JsonElement?.asSafeString(): String? =
            if (this != null && !isJsonNull && isJsonPrimitive) asString else null

        private fun JsonElement?.asSafeDouble(): Double? =
            if (this != null && !isJsonNull && isJsonPrimitive) {
                try { asDouble } catch (_: Exception) { null }
            } else null
    }
}
