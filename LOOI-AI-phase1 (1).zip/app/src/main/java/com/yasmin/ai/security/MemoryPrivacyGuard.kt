package com.yasmin.ai.security

/**
 * Ensures confidential credentials, passwords, OTPs, PINs, card numbers, and
 * API tokens are never persisted as conversational memory.
 */
object MemoryPrivacyGuard {

    private val sensitivePatterns = listOf(
        Regex("\\b(password|passcode|pin|otp|cvv|secret\\s*key|private\\s*key|bearer\\s+token)\\b", RegexOption.IGNORE_CASE),
        Regex("\\bAIza[0-9A-Za-z_-]{20,}\\b"),
        Regex("\\bsk-[0-9A-Za-z]{20,}\\b"),
        Regex("\\b(?:\\d[ -]*?){13,19}\\b") // Potential payment card digits
    )

    fun containsSensitiveData(text: String): Boolean {
        return sensitivePatterns.any { it.containsMatchIn(text) }
    }

    fun sanitizeOrReject(text: String): Result<String> {
        val trimmed = text.trim()
        if (trimmed.isEmpty()) {
            return Result.failure(IllegalArgumentException("Memory content cannot be empty."))
        }
        if (containsSensitiveData(trimmed)) {
            return Result.failure(
                SecurityException("Blocked saving memory: contains sensitive credentials, tokens, or payment numbers.")
            )
        }
        return Result.success(trimmed)
    }
}
