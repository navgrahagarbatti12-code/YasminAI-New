package com.yasmin.ai.ui.chat

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.yasmin.ai.MainActivity
import com.yasmin.ai.databinding.FragmentChatBinding
import com.yasmin.ai.ui.home.YasminSharedViewModel
import kotlinx.coroutines.launch

class ChatFragment : Fragment() {

    private var _binding: FragmentChatBinding? = null
    private val binding get() = _binding!!
    private val sharedViewModel: YasminSharedViewModel by activityViewModels()
    private lateinit var chatAdapter: ChatAdapter

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentChatBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        chatAdapter = ChatAdapter(
            onCopyClick = { text ->
                val cm = requireContext().getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("Yasmin Message", text))
                Toast.makeText(requireContext(), "Copied to clipboard", Toast.LENGTH_SHORT).show()
            },
            onSpeakClick = { text ->
                sharedViewModel.speakText(text)
            }
        )

        binding.rvChatMessages.apply {
            layoutManager = LinearLayoutManager(requireContext()).apply {
                stackFromEnd = true
            }
            adapter = chatAdapter
        }

        binding.btnChatSend.setOnClickListener {
            val text = binding.etChatInput.text?.toString()?.trim().orEmpty()
            if (text.isNotEmpty()) {
                binding.etChatInput.text?.clear()
                sharedViewModel.handleUserInput(text)
            }
        }

        binding.btnChatVoice.setOnClickListener {
            val hasMic = ContextCompat.checkSelfPermission(
                requireContext(),
                Manifest.permission.RECORD_AUDIO
            ) == PackageManager.PERMISSION_GRANTED
            if (!hasMic) {
                (activity as? MainActivity)?.requestAudioPermission()
                return@setOnClickListener
            }
            sharedViewModel.startVoiceCapture {
                (activity as? MainActivity)?.requestAudioPermission()
            }
        }

        binding.btnClearChat.setOnClickListener {
            MaterialAlertDialogBuilder(requireContext())
                .setTitle("Clear Chat History?")
                .setMessage("This will permanently remove saved messages from local storage.")
                .setPositiveButton("Clear") { _, _ ->
                    sharedViewModel.clearChatHistory()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }

        observeChat()
    }

    private fun observeChat() {
        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch {
                    sharedViewModel.messages.collect { list ->
                        chatAdapter.submitList(list) {
                            if (list.isNotEmpty()) {
                                binding.rvChatMessages.scrollToPosition(list.size - 1)
                            }
                        }
                        binding.tvChatEmpty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
                    }
                }
                launch {
                    sharedViewModel.isBusy.collect { busy ->
                        binding.progressChat.visibility = if (busy) View.VISIBLE else View.GONE
                    }
                }
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
