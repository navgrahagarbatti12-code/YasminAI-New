package com.yasmin.ai.assistant

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.provider.CalendarContract
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class CalendarEventSummary(
    val title: String,
    val startMs: Long,
    val location: String
)

class CalendarHelper(private val context: Context) {

    fun hasCalendarPermission(): Boolean {
        return ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CALENDAR) ==
            PackageManager.PERMISSION_GRANTED
    }

    fun getUpcomingEvents(limit: Int = 5): List<CalendarEventSummary> {
        if (!hasCalendarPermission()) return emptyList()

        val now = System.currentTimeMillis()
        val endWindow = now + 7L * 86_400_000L // Next 7 days
        val results = mutableListOf<CalendarEventSummary>()

        val projection = arrayOf(
            CalendarContract.Events.TITLE,
            CalendarContract.Events.DTSTART,
            CalendarContract.Events.EVENT_LOCATION
        )
        val selection = "${CalendarContract.Events.DTSTART} >= ? AND ${CalendarContract.Events.DTSTART} <= ? AND ${CalendarContract.Events.DELETED} = 0"
        val args = arrayOf(now.toString(), endWindow.toString())

        try {
            context.contentResolver.query(
                CalendarContract.Events.CONTENT_URI,
                projection,
                selection,
                args,
                "${CalendarContract.Events.DTSTART} ASC"
            )?.use { cursor ->
                val titleIdx = cursor.getColumnIndex(CalendarContract.Events.TITLE)
                val startIdx = cursor.getColumnIndex(CalendarContract.Events.DTSTART)
                val locIdx = cursor.getColumnIndex(CalendarContract.Events.EVENT_LOCATION)
                while (cursor.moveToNext() && results.size < limit) {
                    val title = if (titleIdx >= 0) cursor.getString(titleIdx).orEmpty() else "Event"
                    val startMs = if (startIdx >= 0) cursor.getLong(startIdx) else now
                    val loc = if (locIdx >= 0) cursor.getString(locIdx).orEmpty() else ""
                    if (title.isNotBlank()) {
                        results.add(CalendarEventSummary(title, startMs, loc))
                    }
                }
            }
        } catch (_: Exception) {
        }
        return results
    }

    fun formatUpcomingEventsText(limit: Int = 5): String {
        if (!hasCalendarPermission()) {
            return "Calendar access not granted (enable READ_CALENDAR in Permission Center)."
        }
        val events = getUpcomingEvents(limit)
        if (events.isEmpty()) {
            return "No upcoming calendar events in the next 7 days."
        }
        val fmt = SimpleDateFormat("EEE dd MMM · hh:mm a", Locale.getDefault())
        return events.joinToString("\n") { evt ->
            val locSuffix = if (evt.location.isNotBlank()) " @ ${evt.location}" else ""
            "• ${evt.title} (${fmt.format(Date(evt.startMs))})$locSuffix"
        }
    }

    fun openAddCalendarEventIntent(title: String, startMs: Long = System.currentTimeMillis() + 3_600_000L): String {
        val intent = Intent(Intent.ACTION_INSERT).apply {
            data = CalendarContract.Events.CONTENT_URI
            putExtra(CalendarContract.Events.TITLE, title.ifBlank { "Yasmin AI Event" })
            putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, startMs)
            putExtra(CalendarContract.EXTRA_EVENT_END_TIME, startMs + 3_600_000L)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return try {
            context.startActivity(intent)
            "Opened Calendar to save event '$title'."
        } catch (_: Exception) {
            "No Calendar app available to insert event."
        }
    }
}
