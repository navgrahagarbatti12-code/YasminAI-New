package com.yasmin.ai.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "assistant_tasks")
data class TaskEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val type: String, // "todo", "note", "reminder"
    val title: String,
    val details: String = "",
    val dueLabel: String = "",
    val reminderEpochMs: Long = 0L,
    val isCompleted: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)
