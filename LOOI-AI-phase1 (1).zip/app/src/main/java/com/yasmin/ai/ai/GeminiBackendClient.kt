package com.yasmin.ai.ai

import com.google.gson.Gson
import com.google.gson.JsonElement
import com.google.gson.JsonObject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.BufferedReader
import java.io.IOException
import java.io.InputStreamReader
import java.util.concurrent.TimeUnit

class GeminiBackendClient(
    private val baseUrlProvider: () -> String,
    private val authTokenProvider: () -> String = { "" },
    private val providerTypeProvider: () -> String = { "gemini_proxy" },
    private val customProviderUrlProvider: () -> String = { "" },
    private val customModelProvider: () -> String = { "gpt-4o-mini" },
    private val customKeyProvider: () -> String = { "" },
    private val autoFallbackProvider: () -> Boolean = { true }
) : AiProvider {

    private val gson = Gson()
    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    override suspend fun chat(request: GeminiChatRequest): AiResult<GeminiResponse> {
        val preferCustom = providerTypeProvider() == "openai_compatible"
        val hasCustom = isValidHttpUrl(customProviderUrlProvider().trim())
        val hasProxy = isValidHttpUrl(cleanBaseUrl)
        val allowFallback = autoFallbackProvider()

        return if (preferCustom && hasCustom) {
            val primary = callOpenAiCompatibleChat(request)
            if (primary is AiResult.Error && allowFallback && hasProxy) {
                val fb = postWithRetry("$cleanBaseUrl/api/gemini/chat", request, GeminiResponse::class.java)
                if (fb is AiResult.Success) {
                    AiResult.Success(fb.data.copy(reply = "${fb.data.reply.orEmpty()}\n\n[Fallback: Gemini Proxy]"))
                } else primary
            } else primary
        } else {
            val primary = postWithRetry("$cleanBaseUrl/api/gemini/chat", request, GeminiResponse::class.java)
            if (primary is AiResult.Error && allowFallback && hasCustom) {
                val fb = callOpenAiCompatibleChat(request)
                if (fb is AiResult.Success) {
                    AiResult.Success(fb.data.copy(reply = "${fb.data.reply.orEmpty()}\n\n[Fallback: OpenAI-Compatible]"))
                } else primary
            } else primary
        }
    }

    override fun streamChat(request: GeminiChatRequest): Flow<String> = flow {
        val preferCustom = providerTypeProvider() == "openai_compatible"
        val hasCustom = isValidHttpUrl(customProviderUrlProvider().trim())
        val hasProxy = isValidHttpUrl(cleanBaseUrl)
        val allowFallback = autoFallbackProvider()

        if (preferCustom && hasCustom) {
            try {
                streamOpenAiCompatible(request) { chunk -> emit(chunk) }
                return@flow
            } catch (e: Exception) {
                if (allowFallback && hasProxy) {
                    streamGeminiProxy(request) { chunk -> emit(chunk) }
                    return@flow
                }
                throw e
            }
        }

        if (!hasProxy && allowFallback && hasCustom) {
            streamOpenAiCompatible(request) { chunk -> emit(chunk) }
            return@flow
        }

        try {
            streamGeminiProxy(request) { chunk -> emit(chunk) }
        } catch (e: Exception) {
            if (allowFallback && hasCustom) {
                streamOpenAiCompatible(request) { chunk -> emit(chunk) }
            } else {
                throw e
            }
        }
    }.flowOn(Dispatchers.IO)

    private suspend fun streamGeminiProxy(
        request: GeminiChatRequest,
        onDelta: suspend (String) -> Unit
    ) {
        val base = cleanBaseUrl
        if (!isValidHttpUrl(base)) {
            throw IllegalStateException("Configure a valid Backend Proxy URL in Settings first.")
        }
        val reqBuilder = Request.Builder()
            .url("$base/api/gemini/stream")
            .post(gson.toJson(request).toRequestBody(jsonMediaType))
        val token = authTokenProvider().trim()
        if (token.isNotEmpty()) {
            reqBuilder.addHeader("Authorization", "Bearer $token")
        }

        httpClient.newCall(reqBuilder.build()).execute().use { response ->
            if (!response.isSuccessful) {
                throw IOException("Stream failed with HTTP ${response.code}")
            }
            val body = response.body ?: throw IOException("Empty stream body")
            BufferedReader(InputStreamReader(body.byteStream())).use { reader ->
                var line: String?
                while (reader.readLine().also { line = it } != null) {
                    val trimmed = line?.trim().orEmpty()
                    if (!trimmed.startsWith("data:")) continue
                    val payload = trimmed.removePrefix("data:").trim()
                    if (payload.isEmpty()) continue
                    val jsonObj = try {
                        gson.fromJson(payload, JsonObject::class.java)
                    } catch (_: Exception) {
                        null
                    } ?: continue
                    val errText = jsonObj.get("error").asSafeString()
                    if (!errText.isNullOrEmpty()) {
                        throw IOException(errText)
                    }
                    val deltaText = jsonObj.get("delta").asSafeString()
                    if (!deltaText.isNullOrEmpty()) {
                        onDelta(deltaText)
                    }
                    if (jsonObj.get("done").asSafeBoolean() == true) {
                        break
                    }
                }
            }
        }
    }

    private suspend fun streamOpenAiCompatible(
        request: GeminiChatRequest,
        onDelta: suspend (String) -> Unit
    ) {
        val endpoint = normalizeOpenAiBaseUrl(customProviderUrlProvider())
        if (!isValidHttpUrl(endpoint)) throw IllegalStateException("Invalid custom provider URL.")

        val payload = buildOpenAiPayload(request, stream = true)
        val reqBuilder = Request.Builder()
            .url("$endpoint/chat/completions")
            .post(gson.toJson(payload).toRequestBody(jsonMediaType))
        val key = customKeyProvider().trim()
        if (key.isNotEmpty()) {
            reqBuilder.addHeader("Authorization", "Bearer $key")
        }

        httpClient.newCall(reqBuilder.build()).execute().use { response ->
            if (!response.isSuccessful) throw IOException("OpenAI stream HTTP ${response.code}")
            val body = response.body ?: throw IOException("Empty OpenAI stream body")
            BufferedReader(InputStreamReader(body.byteStream())).use { reader ->
                var line: String?
                while (reader.readLine().also { line = it } != null) {
                    val trimmed = line?.trim().orEmpty()
                    if (!trimmed.startsWith("data:")) continue
                    val raw = trimmed.removePrefix("data:").trim()
                    if (raw == "[DONE]" || raw.isEmpty()) break
                    val obj = try {
                        gson.fromJson(raw, JsonObject::class.java)
                    } catch (_: Exception) {
                        null
                    } ?: continue
                    val delta = obj.getAsJsonArray("choices")
                        ?.takeIf { it.size() > 0 }
                        ?.get(0)?.takeIf { it.isJsonObject }?.asJsonObject
                        ?.getAsJsonObject("delta")
                        ?.get("content")
                        .asSafeString()
                    if (!delta.isNullOrEmpty()) onDelta(delta)
                }
            }
        }
    }

    override suspend fun planActions(request: GeminiAgentRequest): AiResult<GeminiAgentResponse> {
        val preferCustom = providerTypeProvider() == "openai_compatible"
        val hasCustom = isValidHttpUrl(customProviderUrlProvider().trim())
        val hasProxy = isValidHttpUrl(cleanBaseUrl)
        val allowFallback = autoFallbackProvider()

        if (preferCustom && hasCustom) {
            val chatRes = callOpenAiCompatibleChat(
                GeminiChatRequest(
                    message = request.message,
                    language = request.language,
                    personality = request.personality,
                    memories = request.memories,
                    userName = request.userName
                )
            )
            if (chatRes is AiResult.Success) {
                return AiResult.Success(GeminiAgentResponse(reply = chatRes.data.reply.orEmpty()))
            }
            if (allowFallback && hasProxy) {
                return postWithRetry("$cleanBaseUrl/api/gemini/agent", request, GeminiAgentResponse::class.java)
            }
            return chatRes
        }

        val proxyRes = postWithRetry("$cleanBaseUrl/api/gemini/agent", request, GeminiAgentResponse::class.java)
        if (proxyRes is AiResult.Error && allowFallback && hasCustom) {
            val fb = callOpenAiCompatibleChat(
                GeminiChatRequest(
                    message = request.message,
                    language = request.language,
                    personality = request.personality,
                    memories = request.memories,
                    userName = request.userName
                )
            )
            if (fb is AiResult.Success) {
                return AiResult.Success(GeminiAgentResponse(reply = "${fb.data.reply.orEmpty()}\n\n[Fallback: OpenAI-Compatible]"))
            }
        }
        return proxyRes
    }

    override suspend fun generateCode(request: GeminiCodeRequest): AiResult<GeminiResponse> =
        postWithRetry("$cleanBaseUrl/api/gemini/code", request, GeminiResponse::class.java)

    override suspend fun analyzeVision(request: GeminiVisionRequest): AiResult<GeminiResponse> =
        postWithRetry("$cleanBaseUrl/api/gemini/vision", request, GeminiResponse::class.java)

    override suspend fun fetchBriefing(request: BriefingRequest): AiResult<GeminiResponse> =
        postWithRetry("$cleanBaseUrl/api/assistant/briefing", request, GeminiResponse::class.java)

    override suspend fun executePythonRemote(code: String): AiResult<PythonSandboxResponse> =
        postWithRetry("$cleanBaseUrl/api/sandbox/python", PythonSandboxRequest(code), PythonSandboxResponse::class.java)

    override suspend fun checkHealth(): AiResult<Boolean> {
        val preferCustom = providerTypeProvider() == "openai_compatible"
        if (preferCustom && isValidHttpUrl(customProviderUrlProvider().trim())) {
            return pingCustomProvider(customProviderUrlProvider().trim())
        }
        return pingHealth(cleanBaseUrl)
    }

    suspend fun pingHealth(baseUrl: String): AiResult<Boolean> = withContext(Dispatchers.IO) {
        val cleanBase = baseUrl.trim().trimEnd('/')
        if (!isValidHttpUrl(cleanBase)) {
            return@withContext AiResult.Error("Backend Proxy URL not configured or invalid.")
        }
        val request = Request.Builder()
            .url("$cleanBase/api/health")
            .get()
            .build()
        try {
            httpClient.newCall(request).execute().use { response ->
                if (response.isSuccessful) AiResult.Success(true)
                else AiResult.Error("Proxy returned HTTP ${response.code}", response.code)
            }
        } catch (e: IOException) {
            AiResult.Error("Offline or unreachable: ${e.localizedMessage ?: "Network error"}")
        }
    }

    private suspend fun pingCustomProvider(endpoint: String): AiResult<Boolean> = withContext(Dispatchers.IO) {
        val clean = normalizeOpenAiBaseUrl(endpoint)
        if (!isValidHttpUrl(clean)) {
            return@withContext AiResult.Error("Custom provider URL invalid.")
        }
        val reqBuilder = Request.Builder().url("$clean/models").get()
        val key = customKeyProvider().trim()
        if (key.isNotEmpty()) reqBuilder.addHeader("Authorization", "Bearer $key")
        try {
            httpClient.newCall(reqBuilder.build()).execute().use { response ->
                if (response.isSuccessful || response.code == 404 || response.code == 405) {
                    AiResult.Success(true)
                } else {
                    AiResult.Error("Custom provider HTTP ${response.code}", response.code)
                }
            }
        } catch (e: IOException) {
            AiResult.Error("Custom provider unreachable: ${e.localizedMessage ?: "Network error"}")
        }
    }

    private val cleanBaseUrl: String
        get() = baseUrlProvider().trim().trimEnd('/')

    private fun isValidHttpUrl(url: String): Boolean =
        url.startsWith("https://") || url.startsWith("http://")

    private fun normalizeOpenAiBaseUrl(raw: String): String {
        val trimmed = raw.trim().trimEnd('/')
        if (trimmed.isEmpty()) return ""
        return if (Regex(".*/v\\d+($|/.*)").matches(trimmed)) trimmed else "$trimmed/v1"
    }

    private fun JsonElement?.asSafeString(): String? =
        if (this != null && !isJsonNull && isJsonPrimitive) asString else null

    private fun JsonElement?.asSafeBoolean(): Boolean? =
        if (this != null && !isJsonNull && isJsonPrimitive) {
            try { asBoolean } catch (_: Exception) { null }
        } else null

    private suspend fun <T> postWithRetry(
        url: String,
        bodyObj: Any,
        responseClass: Class<T>
    ): AiResult<T> = withContext(Dispatchers.IO) {
        if (!isValidHttpUrl(url)) {
            return@withContext AiResult.Error("Configure a valid Backend Proxy URL in Settings first.")
        }

        val json = gson.toJson(bodyObj)
        var attempt = 0
        val maxRetries = 2

        while (attempt <= maxRetries) {
            val reqBuilder = Request.Builder()
                .url(url)
                .post(json.toRequestBody(jsonMediaType))
            val token = authTokenProvider().trim()
            if (token.isNotEmpty()) {
                reqBuilder.addHeader("Authorization", "Bearer $token")
            }

            var shouldRetry = false
            try {
                httpClient.newCall(reqBuilder.build()).execute().use { response ->
                    val rawBody = response.body?.string().orEmpty()
                    if (response.isSuccessful) {
                        val parsed = try {
                            gson.fromJson(rawBody, responseClass)
                        } catch (_: Exception) {
                            null
                        }
                        return@withContext if (parsed != null) {
                            AiResult.Success(parsed)
                        } else {
                            AiResult.Error("Invalid JSON response from backend.")
                        }
                    }

                    val retryable = response.code == 429 || response.code in 500..504
                    if (retryable && attempt < maxRetries) {
                        shouldRetry = true
                    } else {
                        val parsedErr = try {
                            gson.fromJson(rawBody, GeminiResponse::class.java)?.error
                        } catch (_: Exception) {
                            null
                        }
                        val friendlyMsg = when (response.code) {
                            429 -> parsedErr ?: "Rate limit reached. Please wait a moment."
                            401, 403 -> parsedErr ?: "Authentication rejected by backend proxy."
                            400 -> parsedErr ?: "Invalid request payload."
                            else -> parsedErr ?: "Backend error (HTTP ${response.code})."
                        }
                        return@withContext AiResult.Error(friendlyMsg, response.code)
                    }
                }
            } catch (_: IOException) {
                if (attempt < maxRetries) {
                    shouldRetry = true
                } else {
                    return@withContext AiResult.Error(
                        "Cannot connect to AI backend. Check internet connection and Settings > Backend Proxy URL."
                    )
                }
            }

            if (shouldRetry) {
                attempt++
                delay(750L * attempt)
            } else {
                break
            }
        }
        AiResult.Error("Unexpected network state")
    }

    private fun buildOpenAiPayload(request: GeminiChatRequest, stream: Boolean): Map<String, Any> {
        val memCtx = if (request.memories.isNotEmpty()) {
            "\nPersonal context:\n" + request.memories.joinToString("\n") { "- ${it.keyTitle}: ${it.content}" }
        } else ""
        val sysContent = "You are Yasmin AI 3.0 (${request.personality}) for ${request.userName}. Language: ${request.language}.$memCtx"
        val messagesPayload = buildList {
            add(mapOf("role" to "system", "content" to sysContent))
            request.history.takeLast(8).forEach {
                add(mapOf("role" to it.role, "content" to it.content))
            }
            add(mapOf("role" to "user", "content" to request.message))
        }
        return mapOf(
            "model" to customModelProvider(),
            "messages" to messagesPayload,
            "stream" to stream
        )
    }

    private suspend fun callOpenAiCompatibleChat(request: GeminiChatRequest): AiResult<GeminiResponse> =
        withContext(Dispatchers.IO) {
            val endpoint = normalizeOpenAiBaseUrl(customProviderUrlProvider())
            if (!isValidHttpUrl(endpoint)) {
                return@withContext AiResult.Error("Invalid custom provider URL.")
            }
            val payload = buildOpenAiPayload(request, stream = false)
            val reqBuilder = Request.Builder()
                .url("$endpoint/chat/completions")
                .post(gson.toJson(payload).toRequestBody(jsonMediaType))
            val key = customKeyProvider().trim()
            if (key.isNotEmpty()) {
                reqBuilder.addHeader("Authorization", "Bearer $key")
            }

            try {
                httpClient.newCall(reqBuilder.build()).execute().use { response ->
                    val raw = response.body?.string().orEmpty()
                    if (!response.isSuccessful) {
                        return@withContext AiResult.Error("Custom provider HTTP ${response.code}", response.code)
                    }
                    val root = try {
                        gson.fromJson(raw, JsonObject::class.java)
                    } catch (_: Exception) {
                        null
                    }
                    val replyText = root?.getAsJsonArray("choices")
                        ?.takeIf { it.size() > 0 }
                        ?.get(0)?.takeIf { it.isJsonObject }?.asJsonObject
                        ?.getAsJsonObject("message")
                        ?.get("content")
                        .asSafeString()
                        .orEmpty()
                    AiResult.Success(GeminiResponse(reply = replyText))
                }
            } catch (e: IOException) {
                AiResult.Error("Custom provider unreachable: ${e.localizedMessage ?: "Network error"}")
            }
        }
}
