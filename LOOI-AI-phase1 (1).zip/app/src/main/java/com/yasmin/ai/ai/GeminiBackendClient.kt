package com.yasmin.ai.ai

import com.google.gson.Gson
import com.google.gson.JsonArray
import com.google.gson.JsonElement
import com.google.gson.JsonObject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.BufferedReader
import java.io.IOException
import java.io.InputStreamReader
import java.util.concurrent.TimeUnit

class GeminiBackendClient(
    private val baseUrlProvider: () -> String = { "" },
    private val authTokenProvider: () -> String = { "" },
    private val providerTypeProvider: () -> String = { "groq" },
    private val geminiKeyProvider: () -> String = { "" },
    private val geminiModelProvider: () -> String = { "gemini-2.5-flash" },
    private val groqKeyProvider: () -> String = { "" },
    private val groqModelProvider: () -> String = { "llama-3.3-70b-versatile" },
    private val autoFallbackProvider: () -> Boolean = { true }
) : AiProvider {

    private val gson = Gson()
    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(75, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    fun hasAnyConfiguredProvider(): Boolean {
        return geminiKeyProvider().isNotBlank() ||
            groqKeyProvider().isNotBlank() ||
            isValidHttpUrl(cleanBaseUrl)
    }

    private fun buildProviderOrder(): List<String> {
        val primary = providerTypeProvider()
        val available = buildList {
            if (geminiKeyProvider().isNotBlank()) add(PROVIDER_GEMINI_DIRECT)
            if (groqKeyProvider().isNotBlank()) add(PROVIDER_GROQ)
            if (isValidHttpUrl(cleanBaseUrl)) add(PROVIDER_GEMINI_PROXY)
        }
        if (available.isEmpty()) return listOf(primary)
        val ordered = mutableListOf<String>()
        if (available.contains(primary)) ordered.add(primary)
        if (autoFallbackProvider()) {
            available.forEach { if (!ordered.contains(it)) ordered.add(it) }
        }
        return if (ordered.isEmpty()) available else ordered
    }

    override suspend fun chat(request: GeminiChatRequest): AiResult<GeminiResponse> {
        val providers = buildProviderOrder()
        var lastError: AiResult.Error? = null
        for ((index, provider) in providers.withIndex()) {
            val res = when (provider) {
                PROVIDER_GEMINI_DIRECT -> callGeminiDirectChat(request)
                PROVIDER_GROQ -> callOpenAiChatAt(
                    baseUrl = GROQ_BASE_URL,
                    apiKey = groqKeyProvider().trim(),
                    model = groqModelProvider().ifBlank { DEFAULT_GROQ_MODEL },
                    providerLabel = "Groq",
                    request = request
                )
                else -> postWithRetry("$cleanBaseUrl/api/gemini/chat", request, GeminiResponse::class.java)
            }
            if (res is AiResult.Success) {
                return if (index > 0) {
                    val label = providerDisplayLabel(provider)
                    AiResult.Success(res.data.copy(reply = "${res.data.reply.orEmpty()}\n\n[Auto-Fallback: $label]"))
                } else res
            }
            if (res is AiResult.Error) lastError = res
        }
        return lastError ?: AiResult.Error("No AI provider configured. Open Settings to add a Gemini or Groq API key.")
    }

    override fun streamChat(request: GeminiChatRequest): Flow<String> = flow {
        val providers = buildProviderOrder()
        var lastException: Exception? = null
        for (provider in providers) {
            try {
                when (provider) {
                    PROVIDER_GEMINI_DIRECT -> {
                        streamGeminiDirectChat(request) { emit(it) }
                        return@flow
                    }
                    PROVIDER_GROQ -> {
                        streamOpenAiAt(
                            baseUrl = GROQ_BASE_URL,
                            apiKey = groqKeyProvider().trim(),
                            model = groqModelProvider().ifBlank { DEFAULT_GROQ_MODEL },
                            providerLabel = "Groq",
                            request = request
                        ) { emit(it) }
                        return@flow
                    }
                    else -> {
                        streamGeminiProxy(request) { emit(it) }
                        return@flow
                    }
                }
            } catch (e: Exception) {
                lastException = e
                if (!autoFallbackProvider()) throw e
            }
        }
        throw lastException ?: IllegalStateException("No AI provider configured in Settings.")
    }.flowOn(Dispatchers.IO)

    override suspend fun planActions(request: GeminiAgentRequest): AiResult<GeminiAgentResponse> {
        val providers = buildProviderOrder()
        var lastError: AiResult.Error? = null
        for (provider in providers) {
            val res = when (provider) {
                PROVIDER_GEMINI_DIRECT -> callGeminiDirectAgent(request)
                PROVIDER_GROQ -> callOpenAiAgentAt(
                    baseUrl = GROQ_BASE_URL,
                    apiKey = groqKeyProvider().trim(),
                    model = groqModelProvider().ifBlank { DEFAULT_GROQ_MODEL },
                    providerLabel = "Groq",
                    request = request
                )
                else -> postWithRetry("$cleanBaseUrl/api/gemini/agent", request, GeminiAgentResponse::class.java)
            }
            if (res is AiResult.Success) return res
            if (res is AiResult.Error) lastError = res
        }
        return lastError ?: AiResult.Error("No AI provider configured in Settings.")
    }

    override suspend fun generateCode(request: GeminiCodeRequest): AiResult<GeminiResponse> {
        val providers = buildProviderOrder()
        var lastError: AiResult.Error? = null
        for (provider in providers) {
            val res = when (provider) {
                PROVIDER_GEMINI_DIRECT -> callGeminiDirectCode(request)
                PROVIDER_GROQ -> callOpenAiCodeAt(
                    baseUrl = GROQ_BASE_URL,
                    apiKey = groqKeyProvider().trim(),
                    model = groqModelProvider().ifBlank { DEFAULT_GROQ_MODEL },
                    providerLabel = "Groq",
                    request = request
                )
                else -> postWithRetry("$cleanBaseUrl/api/gemini/code", request, GeminiResponse::class.java)
            }
            if (res is AiResult.Success) return res
            if (res is AiResult.Error) lastError = res
        }
        return lastError ?: AiResult.Error("No AI provider configured in Settings.")
    }

    override suspend fun generateMultiFileProject(request: MultiFileCodeRequest): AiResult<MultiFileCodeResponse> {
        val providers = buildProviderOrder()
        var lastError: AiResult.Error? = null
        for (provider in providers) {
            val res = when (provider) {
                PROVIDER_GEMINI_DIRECT -> callGeminiDirectMultiFile(request)
                PROVIDER_GROQ -> callOpenAiMultiFileAt(
                    baseUrl = GROQ_BASE_URL,
                    apiKey = groqKeyProvider().trim(),
                    model = groqModelProvider().ifBlank { DEFAULT_GROQ_MODEL },
                    providerLabel = "Groq",
                    request = request
                )
                else -> {
                    val codePrompt = buildMultiFilePrompt(request)
                    when (val proxyRes = chat(GeminiChatRequest(message = codePrompt, language = "en", personality = "coding_mentor", enableWebSearch = false))) {
                        is AiResult.Success -> AiResult.Success(parseMultiFileResponse(proxyRes.data.reply.orEmpty(), request.projectName))
                        is AiResult.Error -> proxyRes
                    }
                }
            }
            if (res is AiResult.Success) return res
            if (res is AiResult.Error) lastError = res
        }
        return lastError ?: AiResult.Error("No AI provider configured. Add a Gemini or Groq API key in Settings.")
    }

    override suspend fun analyzeVision(request: GeminiVisionRequest): AiResult<GeminiResponse> {
        val providers = buildProviderOrder()
        var lastError: AiResult.Error? = null
        for (provider in providers) {
            val res = when (provider) {
                PROVIDER_GEMINI_DIRECT -> callGeminiDirectVision(request)
                PROVIDER_GEMINI_PROXY -> postWithRetry("$cleanBaseUrl/api/gemini/vision", request, GeminiResponse::class.java)
                else -> continue // Vision binary inlineData handled by Gemini Direct / Proxy
            }
            if (res is AiResult.Success) return res
            if (res is AiResult.Error) lastError = res
        }
        if (geminiKeyProvider().isNotBlank()) return callGeminiDirectVision(request)
        if (isValidHttpUrl(cleanBaseUrl)) return postWithRetry("$cleanBaseUrl/api/gemini/vision", request, GeminiResponse::class.java)
        return lastError ?: AiResult.Error("AI Vision requires a Google Gemini API key or Gemini Backend Proxy in Settings.")
    }

    override suspend fun fetchBriefing(request: BriefingRequest): AiResult<GeminiResponse> {
        if (providerTypeProvider() == PROVIDER_GEMINI_PROXY && isValidHttpUrl(cleanBaseUrl)) {
            return postWithRetry("$cleanBaseUrl/api/assistant/briefing", request, GeminiResponse::class.java)
        }
        val prompt = buildString {
            append("Give a concise, helpful daily briefing for ${request.userName}. ")
            if (request.cityOrContext.isNotBlank()) append("Context/City: ${request.cityOrContext}. ")
            if (request.pendingTasks.isNotEmpty()) append("Pending tasks: ${request.pendingTasks.joinToString("; ")}. ")
            if (request.upcomingEvents.isNotEmpty()) append("Upcoming calendar events: ${request.upcomingEvents.joinToString("; ")}.")
        }
        return chat(
            GeminiChatRequest(
                message = prompt,
                language = request.language,
                personality = request.personality,
                userName = request.userName,
                enableWebSearch = true
            )
        )
    }

    override suspend fun executePythonRemote(code: String): AiResult<PythonSandboxResponse> =
        postWithRetry("$cleanBaseUrl/api/sandbox/python", PythonSandboxRequest(code), PythonSandboxResponse::class.java)

    /**
     * Executes a prompt with explicit system instruction across configured Groq / Gemini providers
     * using automatic fallback, timeout, and bounded transient retry (no OpenAI provider).
     */
    suspend fun generateWithSystemPrompt(
        systemPrompt: String,
        userPrompt: String,
        expectJson: Boolean = false
    ): AiResult<String> {
        val providers = buildProviderOrder()
        var lastError: AiResult.Error? = null
        for ((index, provider) in providers.withIndex()) {
            val res: AiResult<String> = when (provider) {
                PROVIDER_GEMINI_DIRECT -> withContext(Dispatchers.IO) {
                    val key = geminiKeyProvider().trim()
                    if (key.isEmpty()) return@withContext AiResult.Error("Gemini API key not configured in Settings.")
                    val model = geminiModelProvider().ifBlank { DEFAULT_GEMINI_MODEL }
                    val genConfig = mutableMapOf<String, Any>("temperature" to if (expectJson) 0.2 else 0.4)
                    if (expectJson) genConfig["responseMimeType"] = "application/json"
                    val payload = mapOf(
                        "systemInstruction" to mapOf("parts" to listOf(mapOf("text" to systemPrompt))),
                        "contents" to listOf(
                            mapOf("role" to "user", "parts" to listOf(mapOf("text" to userPrompt)))
                        ),
                        "generationConfig" to genConfig
                    )
                    when (val exec = executeGeminiGenerate(model, key, payload)) {
                        is AiResult.Success -> AiResult.Success(extractGeminiText(exec.data))
                        is AiResult.Error -> exec
                    }
                }
                PROVIDER_GROQ -> withContext(Dispatchers.IO) {
                    val key = groqKeyProvider().trim()
                    if (key.isEmpty()) return@withContext AiResult.Error("Groq API key not configured.")
                    val model = groqModelProvider().ifBlank { DEFAULT_GROQ_MODEL }
                    val payload = mutableMapOf<String, Any>(
                        "model" to model,
                        "temperature" to if (expectJson) 0.2 else 0.4,
                        "messages" to listOf(
                            mapOf("role" to "system", "content" to systemPrompt),
                            mapOf("role" to "user", "content" to userPrompt)
                        )
                    )
                    if (expectJson) payload["response_format"] = mapOf("type" to "json_object")
                    val req = Request.Builder()
                        .url("$GROQ_BASE_URL/chat/completions")
                        .addHeader("Authorization", "Bearer $key")
                        .post(gson.toJson(payload).toRequestBody(jsonMediaType))
                        .build()
                    executeHttpCallWithRetry("Groq", req) { raw ->
                        AiResult.Success(extractOpenAiChoiceText(raw))
                    }
                }
                else -> {
                    val combined = "$systemPrompt\n\n$userPrompt"
                    when (val proxyRes = postWithRetry("$cleanBaseUrl/api/gemini/chat", GeminiChatRequest(message = combined, enableWebSearch = false), GeminiResponse::class.java)) {
                        is AiResult.Success -> AiResult.Success(proxyRes.data.reply.orEmpty())
                        is AiResult.Error -> proxyRes
                    }
                }
            }
            if (res is AiResult.Success && res.data.isNotBlank()) {
                return if (index > 0 && !expectJson) {
                    val label = providerDisplayLabel(provider)
                    AiResult.Success("${res.data}\n\n[Auto-Fallback: $label]")
                } else {
                    res
                }
            }
            if (res is AiResult.Error) lastError = res
        }
        return lastError ?: AiResult.Error("No AI provider configured. Open Settings to add a Groq or Gemini API key.")
    }

    override suspend fun checkHealth(): AiResult<Boolean> {
        val primary = providerTypeProvider()
        return when (primary) {
            PROVIDER_GEMINI_DIRECT -> when (val res = testGeminiConnection()) {
                is AiResult.Success -> AiResult.Success(true)
                is AiResult.Error -> res
            }
            PROVIDER_GROQ -> when (val res = testGroqConnection()) {
                is AiResult.Success -> AiResult.Success(true)
                is AiResult.Error -> res
            }
            else -> pingHealth(cleanBaseUrl)
        }
    }

    suspend fun testGeminiConnection(explicitKey: String? = null): AiResult<String> = withContext(Dispatchers.IO) {
        val key = (explicitKey ?: geminiKeyProvider()).trim()
        if (key.isEmpty()) {
            return@withContext AiResult.Error("Gemini API key is empty.")
        }
        val req = Request.Builder()
            .url("$GEMINI_V1BETA_BASE/models?pageSize=20")
            .addHeader("x-goog-api-key", key)
            .get()
            .build()
        try {
            httpClient.newCall(req).execute().use { response ->
                val raw = response.body?.string().orEmpty()
                if (response.isSuccessful) {
                    val models = parseGeminiModelList(raw)
                    AiResult.Success("Connected · ${models.size} Gemini models available")
                } else {
                    AiResult.Error(mapHttpErrorMessage("Gemini", response.code, raw), response.code)
                }
            }
        } catch (e: IOException) {
            AiResult.Error("Gemini network error: ${e.localizedMessage ?: "Offline or unreachable"}")
        }
    }

    suspend fun fetchGeminiModels(explicitKey: String? = null): AiResult<List<AiModelOption>> = withContext(Dispatchers.IO) {
        val key = (explicitKey ?: geminiKeyProvider()).trim()
        if (key.isEmpty()) return@withContext AiResult.Error("Enter and save a Gemini API key first.")
        val req = Request.Builder()
            .url("$GEMINI_V1BETA_BASE/models?pageSize=50")
            .addHeader("x-goog-api-key", key)
            .get()
            .build()
        try {
            httpClient.newCall(req).execute().use { response ->
                val raw = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    return@withContext AiResult.Error(mapHttpErrorMessage("Gemini", response.code, raw), response.code)
                }
                val parsed = parseGeminiModelList(raw)
                if (parsed.isEmpty()) {
                    AiResult.Error("No generateContent models returned by Gemini.")
                } else {
                    AiResult.Success(parsed)
                }
            }
        } catch (e: IOException) {
            AiResult.Error("Failed to fetch Gemini models: ${e.localizedMessage ?: "Network error"}")
        }
    }

    suspend fun testGroqConnection(explicitKey: String? = null): AiResult<String> = withContext(Dispatchers.IO) {
        val key = (explicitKey ?: groqKeyProvider()).trim()
        if (key.isEmpty()) {
            return@withContext AiResult.Error("Groq API key is empty.")
        }
        val req = Request.Builder()
            .url("$GROQ_BASE_URL/models")
            .addHeader("Authorization", "Bearer $key")
            .get()
            .build()
        try {
            httpClient.newCall(req).execute().use { response ->
                val raw = response.body?.string().orEmpty()
                if (response.isSuccessful) {
                    val models = parseOpenAiModelList(raw, "groq")
                    AiResult.Success("Connected · ${models.size} Groq models available")
                } else {
                    AiResult.Error(mapHttpErrorMessage("Groq", response.code, raw), response.code)
                }
            }
        } catch (e: IOException) {
            AiResult.Error("Groq network error: ${e.localizedMessage ?: "Offline or unreachable"}")
        }
    }

    suspend fun fetchGroqModels(explicitKey: String? = null): AiResult<List<AiModelOption>> = withContext(Dispatchers.IO) {
        val key = (explicitKey ?: groqKeyProvider()).trim()
        if (key.isEmpty()) return@withContext AiResult.Error("Enter and save a Groq API key first.")
        val req = Request.Builder()
            .url("$GROQ_BASE_URL/models")
            .addHeader("Authorization", "Bearer $key")
            .get()
            .build()
        try {
            httpClient.newCall(req).execute().use { response ->
                val raw = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    return@withContext AiResult.Error(mapHttpErrorMessage("Groq", response.code, raw), response.code)
                }
                val parsed = parseOpenAiModelList(raw, "groq")
                if (parsed.isEmpty()) {
                    AiResult.Error("No models returned by Groq.")
                } else {
                    AiResult.Success(parsed)
                }
            }
        } catch (e: IOException) {
            AiResult.Error("Failed to fetch Groq models: ${e.localizedMessage ?: "Network error"}")
        }
    }

    suspend fun pingHealth(baseUrl: String): AiResult<Boolean> = withContext(Dispatchers.IO) {
        val cleanBase = baseUrl.trim().trimEnd('/')
        if (!isValidHttpUrl(cleanBase)) {
            return@withContext AiResult.Error("Backend Proxy URL not configured or invalid.")
        }
        val request = Request.Builder().url("$cleanBase/api/health").get().build()
        try {
            httpClient.newCall(request).execute().use { response ->
                if (response.isSuccessful) AiResult.Success(true)
                else AiResult.Error("Proxy returned HTTP ${response.code}", response.code)
            }
        } catch (e: IOException) {
            AiResult.Error("Offline or unreachable: ${e.localizedMessage ?: "Network error"}")
        }
    }

    // ---- Google Gemini Direct REST v1beta ----

    private suspend fun callGeminiDirectChat(request: GeminiChatRequest): AiResult<GeminiResponse> =
        withContext(Dispatchers.IO) {
            val key = geminiKeyProvider().trim()
            if (key.isEmpty()) return@withContext AiResult.Error("Gemini API key not configured in Settings.")
            val model = geminiModelProvider().ifBlank { DEFAULT_GEMINI_MODEL }

            val payload = buildGeminiPayload(request, useSearch = request.enableWebSearch, jsonMode = false)
            var result = executeGeminiGenerate(model, key, payload)
            // Retry without google_search if specific Gemini model rejects search tool with 400
            if (result is AiResult.Error && result.code == 400 && request.enableWebSearch) {
                result = executeGeminiGenerate(model, key, buildGeminiPayload(request, useSearch = false, jsonMode = false))
            }
            when (result) {
                is AiResult.Success -> {
                    val text = extractGeminiText(result.data)
                    val sources = extractGeminiGroundingSources(result.data)
                    AiResult.Success(GeminiResponse(reply = text, sources = sources.ifEmpty { null }))
                }
                is AiResult.Error -> result
            }
        }

    private suspend fun streamGeminiDirectChat(
        request: GeminiChatRequest,
        onDelta: suspend (String) -> Unit
    ) {
        val key = geminiKeyProvider().trim()
        if (key.isEmpty()) throw IllegalStateException("Gemini API key not configured in Settings.")
        val model = geminiModelProvider().ifBlank { DEFAULT_GEMINI_MODEL }
        val payload = buildGeminiPayload(request, useSearch = false, jsonMode = false)

        val req = Request.Builder()
            .url("$GEMINI_V1BETA_BASE/models/$model:streamGenerateContent?alt=sse")
            .addHeader("x-goog-api-key", key)
            .post(gson.toJson(payload).toRequestBody(jsonMediaType))
            .build()

        httpClient.newCall(req).execute().use { response ->
            if (!response.isSuccessful) {
                val errBody = response.body?.string().orEmpty()
                throw IOException(mapHttpErrorMessage("Gemini", response.code, errBody))
            }
            val body = response.body ?: throw IOException("Empty Gemini stream body")
            BufferedReader(InputStreamReader(body.byteStream())).use { reader ->
                var line: String?
                while (reader.readLine().also { line = it } != null) {
                    val trimmed = line?.trim().orEmpty()
                    if (!trimmed.startsWith("data:")) continue
                    val raw = trimmed.removePrefix("data:").trim()
                    if (raw.isEmpty() || raw == "[DONE]") continue
                    val root = try {
                        gson.fromJson(raw, JsonObject::class.java)
                    } catch (_: Exception) {
                        null
                    } ?: continue
                    val delta = extractGeminiText(root)
                    if (delta.isNotEmpty()) onDelta(delta)
                }
            }
        }
    }

    private suspend fun callGeminiDirectAgent(request: GeminiAgentRequest): AiResult<GeminiAgentResponse> =
        withContext(Dispatchers.IO) {
            val key = geminiKeyProvider().trim()
            if (key.isEmpty()) return@withContext AiResult.Error("Gemini API key not configured in Settings.")
            val model = geminiModelProvider().ifBlank { DEFAULT_GEMINI_MODEL }

            val sysPrompt = buildAgentSystemPrompt(request)
            val payload = mapOf(
                "systemInstruction" to mapOf("parts" to listOf(mapOf("text" to sysPrompt))),
                "contents" to listOf(
                    mapOf("role" to "user", "parts" to listOf(mapOf("text" to request.message)))
                ),
                "generationConfig" to mapOf(
                    "temperature" to 0.25,
                    "responseMimeType" to "application/json"
                )
            )
            when (val res = executeGeminiGenerate(model, key, payload)) {
                is AiResult.Success -> {
                    val rawText = extractGeminiText(res.data)
                    AiResult.Success(parseAgentJson(rawText))
                }
                is AiResult.Error -> res
            }
        }

    private suspend fun callGeminiDirectCode(request: GeminiCodeRequest): AiResult<GeminiResponse> =
        withContext(Dispatchers.IO) {
            val key = geminiKeyProvider().trim()
            if (key.isEmpty()) return@withContext AiResult.Error("Gemini API key not configured in Settings.")
            val model = geminiModelProvider().ifBlank { DEFAULT_GEMINI_MODEL }

            val promptText = buildSingleCodePrompt(request)
            val payload = mapOf(
                "systemInstruction" to mapOf(
                    "parts" to listOf(mapOf("text" to "You are Yasmin, an expert senior software engineer. Return clean JSON matching the requested schema."))
                ),
                "contents" to listOf(
                    mapOf("role" to "user", "parts" to listOf(mapOf("text" to promptText)))
                ),
                "generationConfig" to mapOf(
                    "temperature" to 0.2,
                    "responseMimeType" to "application/json"
                )
            )
            when (val res = executeGeminiGenerate(model, key, payload)) {
                is AiResult.Success -> AiResult.Success(parseCodeResponseJson(extractGeminiText(res.data), request.target))
                is AiResult.Error -> res
            }
        }

    private suspend fun callGeminiDirectMultiFile(request: MultiFileCodeRequest): AiResult<MultiFileCodeResponse> =
        withContext(Dispatchers.IO) {
            val key = geminiKeyProvider().trim()
            if (key.isEmpty()) return@withContext AiResult.Error("Gemini API key not configured in Settings.")
            val model = geminiModelProvider().ifBlank { DEFAULT_GEMINI_MODEL }

            val payload = mapOf(
                "systemInstruction" to mapOf(
                    "parts" to listOf(mapOf("text" to "You are Yasmin, an autonomous multi-language coding architect. Always output strictly valid JSON with projectName, summary, readmeMarkdown, and files array."))
                ),
                "contents" to listOf(
                    mapOf("role" to "user", "parts" to listOf(mapOf("text" to buildMultiFilePrompt(request))))
                ),
                "generationConfig" to mapOf(
                    "temperature" to 0.2,
                    "responseMimeType" to "application/json"
                )
            )
            when (val res = executeGeminiGenerate(model, key, payload)) {
                is AiResult.Success -> {
                    val parsed = parseMultiFileResponse(extractGeminiText(res.data), request.projectName)
                    if (parsed.files.isEmpty() && parsed.summary.isBlank()) {
                        AiResult.Error("Gemini returned an empty project response. Please retry with a clearer prompt.")
                    } else {
                        AiResult.Success(parsed)
                    }
                }
                is AiResult.Error -> res
            }
        }

    private suspend fun callGeminiDirectVision(request: GeminiVisionRequest): AiResult<GeminiResponse> =
        withContext(Dispatchers.IO) {
            val key = geminiKeyProvider().trim()
            if (key.isEmpty()) return@withContext AiResult.Error("Gemini API key not configured in Settings.")
            val model = geminiModelProvider().ifBlank { DEFAULT_GEMINI_MODEL }

            val modeDirective = when (request.mode) {
                "ocr" -> "Extract all visible text accurately and preserve structure."
                "document" -> "Summarize key points, action items, and data from this document."
                "ui" -> "Explain the mobile/UI screen and suggest helpful next actions."
                "objects" -> "Identify objects, components, and technical details in the image."
                else -> "Analyze this image clearly and helpfully."
            }

            val payload = mapOf(
                "systemInstruction" to mapOf(
                    "parts" to listOf(
                        mapOf("text" to "${buildYasminPersonaPrompt("jarvis_formal", request.language, "Commander")}\nVision mode: $modeDirective")
                    )
                ),
                "contents" to listOf(
                    mapOf(
                        "role" to "user",
                        "parts" to listOf(
                            mapOf("text" to request.prompt),
                            mapOf(
                                "inlineData" to mapOf(
                                    "mimeType" to request.mimeType,
                                    "data" to request.imageBase64
                                )
                            )
                        )
                    )
                )
            )
            when (val res = executeGeminiGenerate(model, key, payload)) {
                is AiResult.Success -> AiResult.Success(GeminiResponse(reply = extractGeminiText(res.data)))
                is AiResult.Error -> res
            }
        }

    private suspend fun executeGeminiGenerate(model: String, apiKey: String, payload: Map<String, Any>): AiResult<JsonObject> {
        val req = Request.Builder()
            .url("$GEMINI_V1BETA_BASE/models/$model:generateContent")
            .addHeader("x-goog-api-key", apiKey)
            .post(gson.toJson(payload).toRequestBody(jsonMediaType))
            .build()
        return executeHttpCallWithRetry("Gemini", req) { raw ->
            val root = try {
                gson.fromJson(raw, JsonObject::class.java)
            } catch (_: Exception) {
                null
            }
            if (root == null) AiResult.Error("Invalid JSON response from Gemini.")
            else AiResult.Success(root)
        }
    }

    private fun buildGeminiPayload(
        request: GeminiChatRequest,
        useSearch: Boolean,
        jsonMode: Boolean
    ): Map<String, Any> {
        val sysPrompt = buildYasminPersonaPrompt(request.personality, request.language, request.userName, request.memories)
        val contents = buildList {
            request.history.takeLast(12).forEach { turn ->
                if (turn.content.isNotBlank()) {
                    val geminiRole = if (turn.role == "assistant" || turn.role == "model") "model" else "user"
                    add(mapOf("role" to geminiRole, "parts" to listOf(mapOf("text" to turn.content))))
                }
            }
            if (request.history.lastOrNull()?.content != request.message) {
                add(mapOf("role" to "user", "parts" to listOf(mapOf("text" to request.message))))
            }
        }
        val payload = mutableMapOf<String, Any>(
            "systemInstruction" to mapOf("parts" to listOf(mapOf("text" to sysPrompt))),
            "contents" to contents
        )
        if (useSearch) {
            payload["tools"] = listOf(mapOf("google_search" to emptyMap<String, Any>()))
        }
        if (jsonMode) {
            payload["generationConfig"] = mapOf("responseMimeType" to "application/json")
        }
        return payload
    }

    // ---- Groq Calls (Groq exposes an OpenAI-wire-format REST endpoint; no OpenAI provider is used) ----

    private suspend fun callOpenAiChatAt(
        baseUrl: String,
        apiKey: String,
        model: String,
        providerLabel: String,
        request: GeminiChatRequest
    ): AiResult<GeminiResponse> = withContext(Dispatchers.IO) {
        if (!isValidHttpUrl(baseUrl)) return@withContext AiResult.Error("$providerLabel URL is invalid.")
        if (providerLabel == "Groq" && apiKey.isEmpty()) return@withContext AiResult.Error("Groq API key not configured.")

        val payload = buildOpenAiPayload(request, model = model, stream = false)
        val reqBuilder = Request.Builder()
            .url("$baseUrl/chat/completions")
            .post(gson.toJson(payload).toRequestBody(jsonMediaType))
        if (apiKey.isNotEmpty()) reqBuilder.addHeader("Authorization", "Bearer $apiKey")

        executeHttpCallWithRetry(providerLabel, reqBuilder.build()) { raw ->
            val replyText = extractOpenAiChoiceText(raw)
            AiResult.Success(GeminiResponse(reply = replyText))
        }
    }

    private suspend fun <T> executeHttpCallWithRetry(
        providerLabel: String,
        request: Request,
        maxRetries: Int = 2,
        onSuccess: (String) -> AiResult<T>
    ): AiResult<T> = withContext(Dispatchers.IO) {
        var attempt = 0
        while (attempt <= maxRetries) {
            var shouldRetry = false
            try {
                httpClient.newCall(request).execute().use { response ->
                    val raw = response.body?.string().orEmpty()
                    if (response.isSuccessful) {
                        return@withContext onSuccess(raw)
                    }
                    val retryable = response.code == 429 || response.code in 500..504
                    if (retryable && attempt < maxRetries) {
                        shouldRetry = true
                    } else {
                        return@withContext AiResult.Error(mapHttpErrorMessage(providerLabel, response.code, raw), response.code)
                    }
                }
            } catch (e: IOException) {
                if (attempt < maxRetries) {
                    shouldRetry = true
                } else {
                    return@withContext AiResult.Error(
                        "$providerLabel network failure: ${e.localizedMessage ?: "Offline or timed out"}"
                    )
                }
            }
            if (shouldRetry) {
                attempt++
                delay(650L * attempt)
            } else {
                break
            }
        }
        AiResult.Error("$providerLabel request failed after retries.")
    }

    private suspend fun streamOpenAiAt(
        baseUrl: String,
        apiKey: String,
        model: String,
        providerLabel: String,
        request: GeminiChatRequest,
        onDelta: suspend (String) -> Unit
    ) {
        if (!isValidHttpUrl(baseUrl)) throw IllegalStateException("Invalid $providerLabel URL.")
        if (providerLabel == "Groq" && apiKey.isEmpty()) throw IllegalStateException("Groq API key not configured.")

        val payload = buildOpenAiPayload(request, model = model, stream = true)
        val reqBuilder = Request.Builder()
            .url("$baseUrl/chat/completions")
            .post(gson.toJson(payload).toRequestBody(jsonMediaType))
        if (apiKey.isNotEmpty()) reqBuilder.addHeader("Authorization", "Bearer $apiKey")

        httpClient.newCall(reqBuilder.build()).execute().use { response ->
            if (!response.isSuccessful) {
                val errBody = response.body?.string().orEmpty()
                throw IOException(mapHttpErrorMessage(providerLabel, response.code, errBody))
            }
            val body = response.body ?: throw IOException("Empty $providerLabel stream body")
            BufferedReader(InputStreamReader(body.byteStream())).use { reader ->
                var line: String?
                while (reader.readLine().also { line = it } != null) {
                    val trimmed = line?.trim().orEmpty()
                    if (!trimmed.startsWith("data:")) continue
                    val raw = trimmed.removePrefix("data:").trim()
                    if (raw == "[DONE]" || raw.isEmpty()) break
                    val obj = try {
                        gson.fromJson(raw, JsonObject::class.java)
                    } catch (_: Exception) {
                        null
                    } ?: continue
                    val delta = obj.getAsJsonArray("choices")
                        ?.takeIf { it.size() > 0 }
                        ?.get(0)?.takeIf { it.isJsonObject }?.asJsonObject
                        ?.getAsJsonObject("delta")
                        ?.get("content")
                        .asSafeString()
                    if (!delta.isNullOrEmpty()) onDelta(delta)
                }
            }
        }
    }

    private suspend fun callOpenAiAgentAt(
        baseUrl: String,
        apiKey: String,
        model: String,
        providerLabel: String,
        request: GeminiAgentRequest
    ): AiResult<GeminiAgentResponse> = withContext(Dispatchers.IO) {
        if (!isValidHttpUrl(baseUrl)) return@withContext AiResult.Error("$providerLabel URL is invalid.")
        if (providerLabel == "Groq" && apiKey.isEmpty()) return@withContext AiResult.Error("Groq API key not configured.")

        val payload = mapOf(
            "model" to model,
            "temperature" to 0.2,
            "response_format" to mapOf("type" to "json_object"),
            "messages" to listOf(
                mapOf("role" to "system", "content" to buildAgentSystemPrompt(request)),
                mapOf("role" to "user", "content" to request.message)
            )
        )
        val reqBuilder = Request.Builder()
            .url("$baseUrl/chat/completions")
            .post(gson.toJson(payload).toRequestBody(jsonMediaType))
        if (apiKey.isNotEmpty()) reqBuilder.addHeader("Authorization", "Bearer $apiKey")

        try {
            httpClient.newCall(reqBuilder.build()).execute().use { response ->
                val raw = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    return@withContext AiResult.Error(mapHttpErrorMessage(providerLabel, response.code, raw), response.code)
                }
                val content = extractOpenAiChoiceText(raw)
                AiResult.Success(parseAgentJson(content))
            }
        } catch (e: IOException) {
            AiResult.Error("$providerLabel unreachable: ${e.localizedMessage ?: "Network error"}")
        }
    }

    private suspend fun callOpenAiCodeAt(
        baseUrl: String,
        apiKey: String,
        model: String,
        providerLabel: String,
        request: GeminiCodeRequest
    ): AiResult<GeminiResponse> = withContext(Dispatchers.IO) {
        if (!isValidHttpUrl(baseUrl)) return@withContext AiResult.Error("$providerLabel URL is invalid.")
        if (providerLabel == "Groq" && apiKey.isEmpty()) return@withContext AiResult.Error("Groq API key not configured.")

        val payload = mapOf(
            "model" to model,
            "temperature" to 0.2,
            "response_format" to mapOf("type" to "json_object"),
            "messages" to listOf(
                mapOf("role" to "system", "content" to "You are Yasmin, an expert senior software engineer. Return strictly valid JSON."),
                mapOf("role" to "user", "content" to buildSingleCodePrompt(request))
            )
        )
        val reqBuilder = Request.Builder()
            .url("$baseUrl/chat/completions")
            .post(gson.toJson(payload).toRequestBody(jsonMediaType))
        if (apiKey.isNotEmpty()) reqBuilder.addHeader("Authorization", "Bearer $apiKey")

        try {
            httpClient.newCall(reqBuilder.build()).execute().use { response ->
                val raw = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    return@withContext AiResult.Error(mapHttpErrorMessage(providerLabel, response.code, raw), response.code)
                }
                AiResult.Success(parseCodeResponseJson(extractOpenAiChoiceText(raw), request.target))
            }
        } catch (e: IOException) {
            AiResult.Error("$providerLabel unreachable: ${e.localizedMessage ?: "Network error"}")
        }
    }

    private suspend fun callOpenAiMultiFileAt(
        baseUrl: String,
        apiKey: String,
        model: String,
        providerLabel: String,
        request: MultiFileCodeRequest
    ): AiResult<MultiFileCodeResponse> = withContext(Dispatchers.IO) {
        if (!isValidHttpUrl(baseUrl)) return@withContext AiResult.Error("$providerLabel URL is invalid.")
        if (providerLabel == "Groq" && apiKey.isEmpty()) return@withContext AiResult.Error("Groq API key not configured.")

        val payload = mapOf(
            "model" to model,
            "temperature" to 0.2,
            "response_format" to mapOf("type" to "json_object"),
            "messages" to listOf(
                mapOf("role" to "system", "content" to "You are Yasmin, a senior multi-language coding architect. Always respond with valid JSON containing projectName, summary, readmeMarkdown, and files array."),
                mapOf("role" to "user", "content" to buildMultiFilePrompt(request))
            )
        )
        val reqBuilder = Request.Builder()
            .url("$baseUrl/chat/completions")
            .post(gson.toJson(payload).toRequestBody(jsonMediaType))
        if (apiKey.isNotEmpty()) reqBuilder.addHeader("Authorization", "Bearer $apiKey")

        try {
            httpClient.newCall(reqBuilder.build()).execute().use { response ->
                val raw = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    return@withContext AiResult.Error(mapHttpErrorMessage(providerLabel, response.code, raw), response.code)
                }
                val parsed = parseMultiFileResponse(extractOpenAiChoiceText(raw), request.projectName)
                if (parsed.files.isEmpty() && parsed.summary.isBlank()) {
                    AiResult.Error("$providerLabel returned empty project output. Please retry.")
                } else {
                    AiResult.Success(parsed)
                }
            }
        } catch (e: IOException) {
            AiResult.Error("$providerLabel unreachable: ${e.localizedMessage ?: "Network error"}")
        }
    }

    // ---- Legacy Backend Proxy Streaming + POST Retry ----

    private suspend fun streamGeminiProxy(
        request: GeminiChatRequest,
        onDelta: suspend (String) -> Unit
    ) {
        val base = cleanBaseUrl
        if (!isValidHttpUrl(base)) {
            throw IllegalStateException("Configure a Gemini API key, Groq API key, or Backend Proxy URL in Settings first.")
        }
        val reqBuilder = Request.Builder()
            .url("$base/api/gemini/stream")
            .post(gson.toJson(request).toRequestBody(jsonMediaType))
        val token = authTokenProvider().trim()
        if (token.isNotEmpty()) {
            reqBuilder.addHeader("Authorization", "Bearer $token")
        }

        httpClient.newCall(reqBuilder.build()).execute().use { response ->
            if (!response.isSuccessful) {
                throw IOException("Stream failed with HTTP ${response.code}")
            }
            val body = response.body ?: throw IOException("Empty stream body")
            BufferedReader(InputStreamReader(body.byteStream())).use { reader ->
                var line: String?
                while (reader.readLine().also { line = it } != null) {
                    val trimmed = line?.trim().orEmpty()
                    if (!trimmed.startsWith("data:")) continue
                    val payload = trimmed.removePrefix("data:").trim()
                    if (payload.isEmpty()) continue
                    val jsonObj = try {
                        gson.fromJson(payload, JsonObject::class.java)
                    } catch (_: Exception) {
                        null
                    } ?: continue
                    val errText = jsonObj.get("error").asSafeString()
                    if (!errText.isNullOrEmpty()) throw IOException(errText)
                    val deltaText = jsonObj.get("delta").asSafeString()
                    if (!deltaText.isNullOrEmpty()) onDelta(deltaText)
                    if (jsonObj.get("done").asSafeBoolean() == true) break
                }
            }
        }
    }

    private suspend fun <T> postWithRetry(
        url: String,
        bodyObj: Any,
        responseClass: Class<T>
    ): AiResult<T> = withContext(Dispatchers.IO) {
        if (!isValidHttpUrl(url)) {
            return@withContext AiResult.Error("Configure a Gemini key, Groq key, or Backend Proxy URL in Settings first.")
        }

        val json = gson.toJson(bodyObj)
        var attempt = 0
        val maxRetries = 2

        while (attempt <= maxRetries) {
            val reqBuilder = Request.Builder()
                .url(url)
                .post(json.toRequestBody(jsonMediaType))
            val token = authTokenProvider().trim()
            if (token.isNotEmpty()) {
                reqBuilder.addHeader("Authorization", "Bearer $token")
            }

            var shouldRetry = false
            try {
                httpClient.newCall(reqBuilder.build()).execute().use { response ->
                    val rawBody = response.body?.string().orEmpty()
                    if (response.isSuccessful) {
                        val parsed = try {
                            gson.fromJson(rawBody, responseClass)
                        } catch (_: Exception) {
                            null
                        }
                        return@withContext if (parsed != null) {
                            AiResult.Success(parsed)
                        } else {
                            AiResult.Error("Invalid JSON response from backend.")
                        }
                    }

                    val retryable = response.code == 429 || response.code in 500..504
                    if (retryable && attempt < maxRetries) {
                        shouldRetry = true
                    } else {
                        return@withContext AiResult.Error(mapHttpErrorMessage("Backend Proxy", response.code, rawBody), response.code)
                    }
                }
            } catch (_: IOException) {
                if (attempt < maxRetries) {
                    shouldRetry = true
                } else {
                    return@withContext AiResult.Error(
                        "Cannot connect to AI backend. Check internet connection and Settings."
                    )
                }
            }

            if (shouldRetry) {
                attempt++
                delay(750L * attempt)
            } else {
                break
            }
        }
        AiResult.Error("Unexpected network state")
    }

    // ---- Prompt Builders & Safe JSON Extractors ----

    private fun buildYasminPersonaPrompt(
        personality: String,
        language: String,
        userName: String,
        memories: List<MemoryContextItem> = emptyList()
    ): String {
        val styleNote = when (personality) {
            "concise_tactical" -> "Keep replies crisp, tactical, and concise like JARVIS in combat ops."
            "friendly_companion" -> "Be warm, conversational, encouraging, and approachable."
            "coding_mentor" -> "Be a senior software architect and clear engineering mentor."
            else -> "Be polished, diplomatic, intelligent, and calm like JARVIS."
        }
        val langNote = when (language) {
            "hi" -> "Respond naturally in Hindi (Devanagari) using natural female grammar (e.g. 'मैं कर रही हूँ', 'मैं आपकी मदद कर सकती हूँ')."
            "hinglish" -> "Respond naturally in conversational Hinglish (Roman Hindi + English mix) using female persona phrasing (e.g. 'Main aapki help kar rahi hoon', 'Main check kar sakti hoon')."
            else -> "Respond in clear, natural English as a refined female AI assistant."
        }
        val memCtx = if (memories.isNotEmpty()) {
            "\nPersonal memory context for $userName:\n" + memories.joinToString("\n") { "- ${it.keyTitle}: ${it.content}" }
        } else ""
        return "You are Yasmin, a female JARVIS-style personal AI assistant for $userName. $styleNote $langNote Never invent fake tool actions you did not execute.$memCtx"
    }

    private fun buildAgentSystemPrompt(request: GeminiAgentRequest): String {
        val memCtx = if (request.memories.isNotEmpty()) {
            request.memories.joinToString("; ") { "${it.keyTitle}=${it.content}" }
        } else "none"
        val tasksCtx = if (request.pendingTasks.isNotEmpty()) {
            request.pendingTasks.joinToString("; ")
        } else "none"

        return """
You are Yasmin, a female JARVIS-style Android AI assistant for ${request.userName}.
Language preference: ${request.language}. Personality: ${request.personality}.
Memories: $memCtx. Pending tasks: $tasksCtx.

Return strictly JSON:
{"reply": "spoken reply in requested language", "actions": [{"tool": "...", "arg1": "...", "arg2": "...", "arg3": "..."}]}

Supported tools (use ONLY when the user genuinely intends a device/app action; otherwise return actions: []):
- "open_app" (arg1: app name)
- "open_chrome" (arg1: optional URL)
- "open_calculator"
- "open_url" (arg1: url)
- "web_search" (arg1: search query)
- "youtube_search" (arg1: query)
- "toggle_flashlight" (arg1: "on"|"off"|"toggle")
- "adjust_volume" (arg1: "up"|"down")
- "set_alarm" (arg1: hour 0-23, arg2: minute 0-59, arg3: label)
- "set_timer" (arg1: seconds, arg2: label)
- "create_task" (arg1: "todo"|"reminder", arg2: title, arg3: due label like "in 10 minutes")
- "create_calendar_event" (arg1: title)
- "save_memory" (arg1: category, arg2: title, arg3: content)
- "prepare_call" (arg1: contact name or phone number)
- "prepare_sms" (arg1: contact name or number, arg2: message body)
- "prepare_whatsapp" (arg1: contact name or number, arg2: message body)
- "show_notification" (arg1: title, arg2: message)
- "read_notifications"
- "read_calendar"
- "open_settings" (arg1: "wifi"|"bluetooth"|"display"|"sound"|"battery"|"location"|"apps"|"general")
- "read_screen"
- "scroll" (arg1: "up"|"down")
- "open_python" (arg1: prompt)
- "open_web_ide" (arg1: prompt)
- "open_coding_agent" (arg1: project prompt)
- "daily_briefing"
        """.trimIndent()
    }

    private fun buildSingleCodePrompt(request: GeminiCodeRequest): String {
        return when (request.target) {
            "web" -> """
Create or update a web project (HTML, CSS, JS) for: ${request.prompt}
Existing HTML/code context:
${request.existingCode.take(6000)}
Return JSON: {"html": "...", "css": "...", "js": "...", "explanation": "..."}
            """.trimIndent()
            "debug" -> """
Fix the bug in this code. Error output: ${request.errorOutput}
Prompt: ${request.prompt}
Code:
${request.existingCode.take(6000)}
Return JSON: {"code": "fixed complete code", "explanation": "what was wrong and how you fixed it"}
            """.trimIndent()
            "explain" -> """
Explain the following code clearly and concisely (${request.prompt}):
${request.existingCode.take(6000)}
Return JSON: {"explanation": "clear step-by-step explanation"}
            """.trimIndent()
            else -> """
Write clean Python 3.11 code (avoiding blocked OS/network/eval calls when possible) for: ${request.prompt}
Existing code (if any):
${request.existingCode.take(6000)}
Return JSON: {"code": "complete python script", "explanation": "short summary"}
            """.trimIndent()
        }
    }

    private fun buildMultiFilePrompt(request: MultiFileCodeRequest): String {
        val existingBlock = if (request.existingFiles.isNotEmpty()) {
            "\nExisting project files:\n" + request.existingFiles.take(12).joinToString("\n\n") { f ->
                "--- FILE: ${f.path} (${f.language}) ---\n${f.content.take(3500)}"
            }
        } else ""

        return """
Mode: ${request.mode} ("generate", "update", "debug", or "explain")
Project Name: ${request.projectName}
Target Language / Stack: ${request.targetLanguage}
Include README.md docs: ${request.includeDocs}
User Request: ${request.prompt}
$existingBlock

Return strictly valid JSON in this exact schema:
{
  "projectName": "safe_snake_or_kebab_project_name",
  "summary": "Clear explanation / summary of changes or architecture",
  "readmeMarkdown": "# Project Title\nUsage and structure documentation...",
  "files": [
    {
      "path": "relative/path/FileName.ext",
      "language": "Kotlin|Python|HTML|CSS|JavaScript|Java|JSON|XML|PHP|C|C++|Markdown",
      "content": "full file source code"
    }
  ]
}
For "explain" mode, you may leave "files" empty and put the full explanation in "summary". For "generate", "update", and "debug", always return complete, ready-to-save file contents with relative paths (no '..' or leading '/').
        """.trimIndent()
    }

    private fun buildOpenAiPayload(request: GeminiChatRequest, model: String, stream: Boolean): Map<String, Any> {
        val sysContent = buildYasminPersonaPrompt(request.personality, request.language, request.userName, request.memories)
        val messagesPayload = buildList {
            add(mapOf("role" to "system", "content" to sysContent))
            request.history.takeLast(10).forEach { turn ->
                if (turn.content.isNotBlank()) {
                    val role = if (turn.role == "model") "assistant" else turn.role
                    add(mapOf("role" to role, "content" to turn.content))
                }
            }
            if (request.history.lastOrNull()?.content != request.message) {
                add(mapOf("role" to "user", "content" to request.message))
            }
        }
        return mapOf(
            "model" to model,
            "messages" to messagesPayload,
            "stream" to stream
        )
    }

    private fun extractGeminiText(root: JsonObject): String {
        val candidates = root.getAsJsonArray("candidates") ?: return ""
        if (candidates.size() == 0) return ""
        val parts = candidates[0]?.takeIf { it.isJsonObject }?.asJsonObject
            ?.getAsJsonObject("content")
            ?.getAsJsonArray("parts") ?: return ""
        val sb = StringBuilder()
        for (part in parts) {
            val txt = part?.takeIf { it.isJsonObject }?.asJsonObject?.get("text").asSafeString()
            if (!txt.isNullOrEmpty()) sb.append(txt)
        }
        return sb.toString()
    }

    private fun extractGeminiGroundingSources(root: JsonObject): List<GroundingSource> {
        val candidates = root.getAsJsonArray("candidates") ?: return emptyList()
        if (candidates.size() == 0) return emptyList()
        val chunks = candidates[0]?.takeIf { it.isJsonObject }?.asJsonObject
            ?.getAsJsonObject("groundingMetadata")
            ?.getAsJsonArray("groundingChunks") ?: return emptyList()
        val list = mutableListOf<GroundingSource>()
        for (chunk in chunks) {
            val web = chunk?.takeIf { it.isJsonObject }?.asJsonObject?.getAsJsonObject("web") ?: continue
            val title = web.get("title").asSafeString().orEmpty()
            val uri = web.get("uri").asSafeString().orEmpty()
            if (uri.isNotBlank()) list.add(GroundingSource(title.ifBlank { uri }, uri))
        }
        return list.distinctBy { it.uri }.take(5)
    }

    private fun extractOpenAiChoiceText(rawJson: String): String {
        val root = try {
            gson.fromJson(rawJson, JsonObject::class.java)
        } catch (_: Exception) {
            null
        } ?: return ""
        return root.getAsJsonArray("choices")
            ?.takeIf { it.size() > 0 }
            ?.get(0)?.takeIf { it.isJsonObject }?.asJsonObject
            ?.getAsJsonObject("message")
            ?.get("content")
            .asSafeString()
            .orEmpty()
    }

    private fun parseAgentJson(rawText: String): GeminiAgentResponse {
        val cleanedJson = unwrapJsonFence(rawText)
        return try {
            val obj = gson.fromJson(cleanedJson, JsonObject::class.java)
            val reply = obj.get("reply").asSafeString().orEmpty()
            val actionsArr = obj.getAsJsonArray("actions") ?: JsonArray()
            val actions = actionsArr.mapNotNull { el ->
                val a = el?.takeIf { it.isJsonObject }?.asJsonObject ?: return@mapNotNull null
                val tool = a.get("tool").asSafeString().orEmpty()
                if (tool.isBlank()) null else PlannedAction(
                    tool = tool,
                    arg1 = a.get("arg1").asSafeString().orEmpty(),
                    arg2 = a.get("arg2").asSafeString().orEmpty(),
                    arg3 = a.get("arg3").asSafeString().orEmpty()
                )
            }
            GeminiAgentResponse(reply = reply, actions = actions)
        } catch (_: Exception) {
            GeminiAgentResponse(reply = rawText.trim(), actions = emptyList())
        }
    }

    private fun parseCodeResponseJson(rawText: String, target: String): GeminiResponse {
        val cleaned = unwrapJsonFence(rawText)
        return try {
            val obj = gson.fromJson(cleaned, JsonObject::class.java)
            GeminiResponse(
                code = obj.get("code").asSafeString(),
                html = obj.get("html").asSafeString(),
                css = obj.get("css").asSafeString(),
                js = obj.get("js").asSafeString(),
                explanation = obj.get("explanation").asSafeString(),
                reply = obj.get("reply").asSafeString()
            )
        } catch (_: Exception) {
            when (target) {
                "explain" -> GeminiResponse(explanation = rawText)
                "web" -> GeminiResponse(html = rawText, css = "", js = "", explanation = "Generated web markup.")
                else -> GeminiResponse(code = unwrapCodeFence(rawText), explanation = "Generated code.")
            }
        }
    }

    fun parseMultiFileResponse(rawText: String, fallbackProjectName: String): MultiFileCodeResponse {
        val cleaned = unwrapJsonFence(rawText)
        return try {
            val obj = gson.fromJson(cleaned, JsonObject::class.java)
            val name = obj.get("projectName").asSafeString().orEmpty().ifBlank { fallbackProjectName }
            val summary = obj.get("summary").asSafeString().orEmpty()
            val readme = obj.get("readmeMarkdown").asSafeString().orEmpty()
            val filesArr = obj.getAsJsonArray("files") ?: JsonArray()
            val files = filesArr.mapNotNull { el ->
                val fObj = el?.takeIf { it.isJsonObject }?.asJsonObject ?: return@mapNotNull null
                val path = fObj.get("path").asSafeString().orEmpty().trim().trimStart('/')
                val content = fObj.get("content").asSafeString().orEmpty()
                val lang = fObj.get("language").asSafeString().orEmpty()
                if (path.isBlank() || path.contains("..")) null
                else GeneratedCodeFile(path = path, content = content, language = lang)
            }
            MultiFileCodeResponse(
                projectName = name,
                summary = summary,
                readmeMarkdown = readme,
                files = files
            )
        } catch (_: Exception) {
            MultiFileCodeResponse(
                projectName = fallbackProjectName,
                summary = rawText.trim(),
                files = emptyList()
            )
        }
    }

    private fun parseGeminiModelList(rawJson: String): List<AiModelOption> {
        val root = try {
            gson.fromJson(rawJson, JsonObject::class.java)
        } catch (_: Exception) {
            return emptyList()
        }
        val models = root.getAsJsonArray("models") ?: return emptyList()
        val parsed = mutableListOf<AiModelOption>()
        for (el in models) {
            val obj = el?.takeIf { it.isJsonObject }?.asJsonObject ?: continue
            val methods = obj.getAsJsonArray("supportedGenerationMethods")
            val supportsGenerate = methods?.any { it.asSafeString() == "generateContent" } == true
            if (!supportsGenerate) continue
            val rawName = obj.get("name").asSafeString().orEmpty()
            val id = rawName.removePrefix("models/").trim()
            if (id.isEmpty()) continue
            val display = obj.get("displayName").asSafeString().orEmpty().ifBlank { id }
            parsed.add(AiModelOption(id = id, displayName = display, provider = PROVIDER_GEMINI_DIRECT))
        }
        return parsed.sortedWith(compareBy<AiModelOption> {
            when {
                it.id.contains("2.5-flash") -> 0
                it.id.contains("2.5-pro") -> 1
                it.id.contains("2.0-flash") -> 2
                else -> 3
            }
        }.thenBy { it.id })
    }

    private fun parseOpenAiModelList(rawJson: String, provider: String): List<AiModelOption> {
        val root = try {
            gson.fromJson(rawJson, JsonObject::class.java)
        } catch (_: Exception) {
            return emptyList()
        }
        val data = root.getAsJsonArray("data") ?: return emptyList()
        return data.mapNotNull { el ->
            val obj = el?.takeIf { it.isJsonObject }?.asJsonObject ?: return@mapNotNull null
            val id = obj.get("id").asSafeString().orEmpty().trim()
            if (id.isEmpty() || id.contains("whisper", ignoreCase = true) || id.contains("guard", ignoreCase = true)) {
                null
            } else {
                AiModelOption(id = id, displayName = id, provider = provider)
            }
        }.sortedWith(compareBy<AiModelOption> {
            when {
                it.id.contains("llama-3.3-70b") -> 0
                it.id.contains("llama-3.1") -> 1
                it.id.contains("qwen") -> 2
                else -> 3
            }
        }.thenBy { it.id })
    }

    private fun unwrapJsonFence(raw: String): String {
        val trimmed = raw.trim()
        val fenceRegex = Regex("^```(?:json)?\\s*([\\s\\S]*?)```$", RegexOption.IGNORE_CASE)
        fenceRegex.find(trimmed)?.let { return it.groupValues[1].trim() }
        val start = trimmed.indexOf('{')
        val end = trimmed.lastIndexOf('}')
        return if (start >= 0 && end > start) trimmed.substring(start, end + 1) else trimmed
    }

    private fun unwrapCodeFence(raw: String): String {
        val trimmed = raw.trim()
        val regex = Regex("^```[a-zA-Z0-9_-]*\\s*([\\s\\S]*?)```$")
        return regex.find(trimmed)?.groupValues?.get(1)?.trim() ?: trimmed
    }

    private val cleanBaseUrl: String
        get() = baseUrlProvider().trim().trimEnd('/')

    private fun isValidHttpUrl(url: String): Boolean =
        url.startsWith("https://") || url.startsWith("http://")

    private fun JsonElement?.asSafeString(): String? =
        if (this != null && !isJsonNull && isJsonPrimitive) asString else null

    private fun JsonElement?.asSafeBoolean(): Boolean? =
        if (this != null && !isJsonNull && isJsonPrimitive) {
            try { asBoolean } catch (_: Exception) { null }
        } else null

    companion object {
        const val PROVIDER_GEMINI_DIRECT = "gemini_direct"
        const val PROVIDER_GROQ = "groq"
        const val PROVIDER_GEMINI_PROXY = "gemini_proxy"

        const val GEMINI_V1BETA_BASE = "https://generativelanguage.googleapis.com/v1beta"
        const val GROQ_BASE_URL = "https://api.groq.com/openai/v1"
        const val DEFAULT_GEMINI_MODEL = "gemini-2.5-flash"
        const val DEFAULT_GROQ_MODEL = "llama-3.3-70b-versatile"

        fun providerDisplayLabel(provider: String): String = when (provider) {
            PROVIDER_GEMINI_DIRECT -> "Google Gemini"
            PROVIDER_GROQ -> "Groq Cloud"
            else -> "Backend Proxy"
        }

        fun mapHttpErrorMessage(providerLabel: String, httpCode: Int, rawBody: String): String {
            val apiMessage = extractNestedErrorMessage(rawBody)
            return when (httpCode) {
                401, 403 -> "$providerLabel API key rejected (HTTP $httpCode). Verify your key in Settings."
                429 -> "$providerLabel rate limit exceeded (HTTP 429). Wait briefly or switch provider/model."
                400 -> apiMessage ?: "$providerLabel rejected the request (HTTP 400). Check selected model."
                404 -> "$providerLabel model or endpoint not found (HTTP 404). Fetch models again in Settings."
                in 500..599 -> "$providerLabel server temporarily unavailable (HTTP $httpCode)."
                else -> apiMessage ?: "$providerLabel returned HTTP $httpCode."
            }
        }

        private fun extractNestedErrorMessage(rawBody: String): String? {
            if (rawBody.isBlank()) return null
            return try {
                val obj = Gson().fromJson(rawBody, JsonObject::class.java)
                val errEl = obj.get("error")
                when {
                    errEl != null && errEl.isJsonObject -> errEl.asJsonObject.get("message")?.asString
                    errEl != null && errEl.isJsonPrimitive -> errEl.asString
                    else -> null
                }?.take(180)
            } catch (_: Exception) {
                null
            }
        }
    }
}
