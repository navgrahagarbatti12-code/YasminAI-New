package com.yasmin.ai.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "coding_jobs")
data class CodingJobEntity(
    @PrimaryKey
    val jobId: String,
    val projectName: String,
    val language: String,
    val prompt: String,
    val status: String, // "QUEUED" | "RUNNING" | "COMPLETED" | "FAILED" | "CANCELLED" | "INTERRUPTED"
    val progress: Int,
    val statusMessage: String,
    val projectPath: String,
    val summaryText: String,
    val filesJson: String,
    val errorMessage: String,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)
