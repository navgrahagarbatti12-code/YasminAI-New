package com.yasmin.ai.memory

import com.yasmin.ai.data.local.MemoryEntity
import com.yasmin.ai.security.MemoryPrivacyGuard
import kotlin.math.exp
import kotlin.math.min

data class ExtractedMemoryCandidate(
    val category: String,
    val keyTitle: String,
    val content: String,
    val importance: Int = 2
)

/**
 * Yasmin AI 3.0 Intelligent Memory Engine:
 * - Semantic token overlap + BM25-inspired relevance scoring + recency + importance + frequency
 * - Duplicate / near-duplicate detection (merges updates instead of creating duplicate entries)
 * - Automatic safe fact/preference extraction strictly gated through MemoryPrivacyGuard
 */
object MemoryEngine {

    private val stopWords = setOf(
        "the", "is", "at", "which", "on", "a", "an", "and", "or", "to", "for", "of",
        "in", "it", "my", "me", "you", "your", "i", "am", "are", "that", "this", "with",
        "hai", "hoon", "mera", "meri", "kya", "ko", "ka", "ki", "ke", "se"
    )

    fun tokenize(text: String): Set<String> {
        return text.lowercase()
            .replace("[^a-z0-9\\u0900-\\u097f\\s]".toRegex(), " ")
            .split("\\s+".toRegex())
            .filter { it.length >= 2 && it !in stopWords }
            .toSet()
    }

    fun tokenSimilarity(a: String, b: String): Double {
        val ta = tokenize(a)
        val tb = tokenize(b)
        if (ta.isEmpty() || tb.isEmpty()) return 0.0
        val intersection = ta.intersect(tb).size.toDouble()
        val union = ta.union(tb).size.toDouble()
        return if (union == 0.0) 0.0 else intersection / union
    }

    fun findDuplicate(
        keyTitle: String,
        content: String,
        existing: List<MemoryEntity>
    ): MemoryEntity? {
        val cleanKey = keyTitle.trim().lowercase()
        val exactKey = existing.firstOrNull { it.keyTitle.trim().lowercase() == cleanKey }
        if (exactKey != null) return exactKey

        val candidateFull = "$keyTitle $content"
        return existing.firstOrNull { mem ->
            tokenSimilarity(candidateFull, "${mem.keyTitle} ${mem.content}") >= 0.72
        }
    }

    /**
     * Ranks memories by relevance to the current user query combining:
     * 1. Semantic token overlap & substring matches
     * 2. Importance weight (1..5)
     * 3. Access count boost
     * 4. Smooth recency decay
     */
    fun rankRelevantMemories(
        query: String,
        memories: List<MemoryEntity>,
        limit: Int = 8,
        nowMs: Long = System.currentTimeMillis()
    ): List<MemoryEntity> {
        if (memories.isEmpty()) return emptyList()
        val qTokens = tokenize(query)
        val qLower = query.lowercase()

        return memories
            .map { mem ->
                val memText = "${mem.category} ${mem.keyTitle} ${mem.content}"
                val mTokens = tokenize(memText)
                val overlap = if (qTokens.isEmpty() || mTokens.isEmpty()) {
                    0.0
                } else {
                    qTokens.intersect(mTokens).size.toDouble() / min(qTokens.size, mTokens.size).toDouble()
                }
                val exactPhraseBonus = if (qLower.contains(mem.keyTitle.lowercase()) && mem.keyTitle.length >= 3) 0.45 else 0.0
                val daysOld = ((nowMs - mem.updatedAt).coerceAtLeast(0L) / 86_400_000.0)
                val recencyScore = exp(-daysOld / 30.0) * 0.25
                val importanceScore = (mem.importance.coerceIn(1, 5) / 5.0) * 0.25
                val freqScore = (mem.accessCount.coerceAtMost(20) / 20.0) * 0.15
                val totalScore = (overlap * 1.35) + exactPhraseBonus + recencyScore + importanceScore + freqScore
                mem to totalScore
            }
            .sortedByDescending { it.second }
            .take(limit)
            .map { it.first }
    }

    /**
     * Automatically extracts benign personal preferences/facts/instructions from user utterances.
     * Strictly rejects anything flagged by MemoryPrivacyGuard (passwords, OTPs, keys, cards).
     */
    fun extractSafeCandidate(userUtterance: String): ExtractedMemoryCandidate? {
        val clean = userUtterance.trim()
        if (clean.length < 8 || clean.length > 260) return null
        if (MemoryPrivacyGuard.containsSensitiveData(clean)) return null

        val lower = clean.lowercase()
        val matchExplicitRemember = Regex("(?:remember that|yaad rakhna|note that)\\s+(.+)", RegexOption.IGNORE_CASE)
            .find(clean)
        if (matchExplicitRemember != null) {
            val detail = matchExplicitRemember.groupValues[1].trim()
            if (detail.length >= 4 && !MemoryPrivacyGuard.containsSensitiveData(detail)) {
                return ExtractedMemoryCandidate(
                    category = "instruction",
                    keyTitle = detail.split(" ").take(4).joinToString(" "),
                    content = detail,
                    importance = 4
                )
            }
        }

        val nameMatch = Regex("(?:my name is|call me|mera naam)\\s+([A-Za-z][A-Za-z\\s]{1,28})", RegexOption.IGNORE_CASE)
            .find(clean)
        if (nameMatch != null) {
            val name = nameMatch.groupValues[1].trim().removeSuffix("hai").trim()
            if (name.isNotBlank()) {
                return ExtractedMemoryCandidate("person", "User Name", name, importance = 5)
            }
        }

        val prefMatch = Regex("(?:i prefer|my favorite|i like working with|mujhe pasand)\\s+(.+)", RegexOption.IGNORE_CASE)
            .find(clean)
        if (prefMatch != null && !lower.contains("?")) {
            val pref = prefMatch.groupValues[1].trim()
            if (pref.length in 3..140 && !MemoryPrivacyGuard.containsSensitiveData(pref)) {
                return ExtractedMemoryCandidate("preference", "Preference", pref, importance = 3)
            }
        }

        val projectMatch = Regex("(?:i am working on|my project is|building)\\s+(.+)", RegexOption.IGNORE_CASE)
            .find(clean)
        if (projectMatch != null && !lower.contains("?")) {
            val proj = projectMatch.groupValues[1].trim()
            if (proj.length in 3..140 && !MemoryPrivacyGuard.containsSensitiveData(proj)) {
                return ExtractedMemoryCandidate("project", "Active Project", proj, importance = 3)
            }
        }

        return null
    }
}
