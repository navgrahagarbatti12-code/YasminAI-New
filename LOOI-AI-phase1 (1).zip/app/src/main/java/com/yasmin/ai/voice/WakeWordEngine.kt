package com.yasmin.ai.voice

import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File
import kotlin.math.sqrt

enum class WakeEngineState {
    STOPPED,
    CALIBRATING,
    MONITORING_VAD,
    VERIFYING_WAKE_PHRASE,
    COOLDOWN
}

/**
 * Pure-offline battery-conscious wake-word engine for "Hey Yasmin":
 * - Stage 1 (Low-power VAD): 16kHz PCM ring buffer measures adaptive ambient noise floor,
 *   RMS energy, and speech zero-crossing rate.
 * - Stage 2 (100% Offline Keyword Spotting): Extracts pre-speech + burst PCM frames (~0.45s..1.7s)
 *   and scores them directly through OfflineWakeWordDetector (MFCC + DTW acoustic matching or
 *   multi-syllable cadence fallback) without invoking SpeechRecognizer or network services.
 */
class WakeWordEngine(
    private val context: Context,
    private val sensitivityPercent: () -> Int,
    private val onWakeDetected: () -> Unit
) {
    private val detector = OfflineWakeWordDetector(templateFile(context))
    private var monitorJob: Job? = null

    private val _engineState = MutableStateFlow(WakeEngineState.STOPPED)
    val engineState: StateFlow<WakeEngineState> = _engineState.asStateFlow()

    @SuppressLint("MissingPermission")
    fun start(scope: CoroutineScope) {
        if (monitorJob?.isActive == true) return
        monitorJob = scope.launch(Dispatchers.IO) {
            val sampleRate = 16000
            val minBuf = AudioRecord.getMinBufferSize(
                sampleRate,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT
            ).coerceAtLeast(3200)

            val recorder = try {
                AudioRecord(
                    MediaRecorder.AudioSource.VOICE_RECOGNITION,
                    sampleRate,
                    AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT,
                    minBuf
                )
            } catch (_: Exception) {
                _engineState.value = WakeEngineState.STOPPED
                return@launch
            }

            if (recorder.state != AudioRecord.STATE_INITIALIZED) {
                recorder.release()
                _engineState.value = WakeEngineState.STOPPED
                return@launch
            }

            // 80ms frame = 1280 samples @ 16kHz
            val frame = ShortArray(1280)
            val preRoll = ArrayDeque<ShortArray>(4)
            val speechCapture = mutableListOf<ShortArray>()
            var noiseFloorRms = 170.0
            var capturingSpeech = false
            var silenceFramesAfterSpeech = 0

            try {
                _engineState.value = WakeEngineState.CALIBRATING
                recorder.startRecording()

                var calibSum = 0.0
                var calibCount = 0
                while (isActive && calibCount < 6) {
                    val read = recorder.read(frame, 0, frame.size)
                    if (read > 0) {
                        calibSum += computeRms(frame, read)
                        calibCount++
                    }
                }
                if (calibCount > 0) {
                    noiseFloorRms = (calibSum / calibCount).coerceIn(100.0, 1400.0)
                }

                _engineState.value = WakeEngineState.MONITORING_VAD

                while (isActive) {
                    val read = recorder.read(frame, 0, frame.size)
                    if (read <= 0) {
                        delay(40)
                        continue
                    }

                    val copy = frame.copyOf(read)
                    val rms = computeRms(copy, read)
                    val zcr = computeZeroCrossingRate(copy, read)

                    val sens = sensitivityPercent().coerceIn(10, 100)
                    val multiplier = 4.2 - ((sens / 100.0) * 2.4)
                    val threshold = (noiseFloorRms * multiplier).coerceAtLeast(300.0)
                    val isSpeechLike = rms > threshold && zcr in 0.025..0.34

                    if (!capturingSpeech) {
                        if (preRoll.size >= 3) preRoll.removeFirstOrNull()
                        preRoll.addLast(copy)

                        if (isSpeechLike) {
                            capturingSpeech = true
                            silenceFramesAfterSpeech = 0
                            speechCapture.clear()
                            speechCapture.addAll(preRoll)
                            speechCapture.add(copy)
                        } else {
                            noiseFloorRms = (noiseFloorRms * 0.94 + rms * 0.06).coerceIn(100.0, 1400.0)
                        }
                    } else {
                        speechCapture.add(copy)
                        if (isSpeechLike) {
                            silenceFramesAfterSpeech = 0
                        } else {
                            silenceFramesAfterSpeech++
                        }

                        val totalSamples = speechCapture.sumOf { it.size }
                        // End burst after ~320ms silence (4 frames) or max ~1.8s capture
                        if (silenceFramesAfterSpeech >= 4 || totalSamples >= 28800) {
                            capturingSpeech = false
                            _engineState.value = WakeEngineState.VERIFYING_WAKE_PHRASE
                            val combined = ShortArray(totalSamples)
                            var pos = 0
                            for (chunk in speechCapture) {
                                System.arraycopy(chunk, 0, combined, pos, chunk.size)
                                pos += chunk.size
                            }
                            speechCapture.clear()

                            val score = detector.detect(combined, sens, sampleRate)
                            if (score.detected) {
                                onWakeDetected()
                                _engineState.value = WakeEngineState.COOLDOWN
                                delay(2200)
                            }
                            if (isActive) {
                                _engineState.value = WakeEngineState.MONITORING_VAD
                            }
                        }
                    }
                }
            } finally {
                try {
                    if (recorder.recordingState == AudioRecord.RECORDSTATE_RECORDING) {
                        recorder.stop()
                    }
                } catch (_: Exception) {
                }
                recorder.release()
                _engineState.value = WakeEngineState.STOPPED
            }
        }
    }

    fun stop() {
        monitorJob?.cancel()
        monitorJob = null
        _engineState.value = WakeEngineState.STOPPED
    }

    private fun computeRms(samples: ShortArray, count: Int): Double {
        var sumSq = 0.0
        for (i in 0 until count) {
            val v = samples[i].toDouble()
            sumSq += v * v
        }
        return sqrt(sumSq / count.coerceAtLeast(1))
    }

    private fun computeZeroCrossingRate(samples: ShortArray, count: Int): Double {
        if (count < 2) return 0.0
        var crossings = 0
        for (i in 1 until count) {
            if ((samples[i] >= 0 && samples[i - 1] < 0) || (samples[i] < 0 && samples[i - 1] >= 0)) {
                crossings++
            }
        }
        return crossings.toDouble() / count
    }

    companion object {
        fun templateFile(context: Context): File =
            File(context.applicationContext.filesDir, "wake_mfcc_templates.json")
    }
}
