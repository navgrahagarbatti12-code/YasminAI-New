package com.yasmin.ai.screen

import android.app.Notification
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.yasmin.ai.R
import com.yasmin.ai.YasminApplication
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withTimeoutOrNull

class MediaProjectionService : Service() {

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            _isForegroundReady.value = false
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }

        val notification: Notification = NotificationCompat.Builder(
            this,
            YasminApplication.CHANNEL_MEDIA_PROJECTION
        )
            .setSmallIcon(R.drawable.ic_screen)
            .setContentTitle("Yasmin AI Screen Capture")
            .setContentText("Capturing user-approved screenshot for Gemini analysis…")
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
        _isForegroundReady.value = true
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        _isForegroundReady.value = false
        super.onDestroy()
    }

    companion object {
        const val NOTIFICATION_ID = 4201
        const val ACTION_STOP = "com.yasmin.ai.STOP_PROJECTION"

        private val _isForegroundReady = MutableStateFlow(false)
        val isForegroundReady: StateFlow<Boolean> = _isForegroundReady.asStateFlow()

        fun startForegroundProjection(context: Context) {
            _isForegroundReady.value = false
            val intent = Intent(context, MediaProjectionService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        suspend fun awaitForegroundReady(timeoutMs: Long = 2500L): Boolean {
            return withTimeoutOrNull(timeoutMs) {
                isForegroundReady.first { it }
            } ?: false
        }

        fun stopForegroundProjection(context: Context) {
            _isForegroundReady.value = false
            val intent = Intent(context, MediaProjectionService::class.java).apply {
                action = ACTION_STOP
            }
            context.startService(intent)
        }
    }
}
