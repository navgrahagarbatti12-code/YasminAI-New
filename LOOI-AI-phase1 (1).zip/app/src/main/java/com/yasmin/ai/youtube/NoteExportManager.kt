package com.yasmin.ai.youtube

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import androidx.core.content.FileProvider
import androidx.documentfile.provider.DocumentFile
import com.yasmin.ai.data.local.VideoNoteEntity
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Exports saved YouTube video notes cleanly to TXT and multi-page Android PdfDocument PDFs,
 * saving into cacheDir/exports/ (FileProvider-shareable) and optionally syncing to user SAF folder.
 */
class NoteExportManager(private val context: Context) {

    data class ExportResult(
        val file: File,
        val contentUri: Uri,
        val safSynced: Boolean,
        val mimeType: String
    )

    private fun exportsDir(): File = File(context.cacheDir, "exports").apply { mkdirs() }

    fun exportAsTxt(note: VideoNoteEntity, safTreeUriString: String = ""): Result<ExportResult> {
        return runCatching {
            val safeName = sanitizeFilename(note.videoTitle.ifBlank { note.topic })
            val outFile = File(exportsDir(), "${safeName}_${note.id}.txt")
            val textBody = buildPlainTextNote(note)
            outFile.writeText(textBody, Charsets.UTF_8)

            val safSynced = copyToSafIfConfigured(
                safTreeUriString = safTreeUriString,
                mimeType = "text/plain",
                displayName = outFile.name,
                sourceFile = outFile
            )
            val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", outFile)
            ExportResult(outFile, uri, safSynced, "text/plain")
        }
    }

    fun exportAsPdf(note: VideoNoteEntity, safTreeUriString: String = ""): Result<ExportResult> {
        return runCatching {
            val safeName = sanitizeFilename(note.videoTitle.ifBlank { note.topic })
            val outFile = File(exportsDir(), "${safeName}_${note.id}.pdf")

            val pageWidth = 595
            val pageHeight = 842
            val margin = 42f
            val usableWidth = pageWidth - (margin * 2)

            val headerPaint = Paint().apply {
                color = Color.rgb(0, 140, 170)
                textSize = 18f
                typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
                isAntiAlias = true
            }
            val metaPaint = Paint().apply {
                color = Color.rgb(90, 105, 120)
                textSize = 10f
                typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
                isAntiAlias = true
            }
            val bodyPaint = Paint().apply {
                color = Color.rgb(25, 32, 42)
                textSize = 11.5f
                typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
                isAntiAlias = true
            }
            val dividerPaint = Paint().apply {
                color = Color.rgb(200, 215, 228)
                strokeWidth = 1f
            }

            val document = PdfDocument()
            var pageNumber = 1
            var page = document.startPage(PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create())
            var canvas = page.canvas
            var y = margin + 12f

            // Title & metadata header
            val titleLines = wrapText(note.videoTitle.ifBlank { note.topic }, headerPaint, usableWidth)
            for (line in titleLines) {
                canvas.drawText(line, margin, y, headerPaint)
                y += 22f
            }
            val dateStr = SimpleDateFormat("dd MMM yyyy · hh:mm a", Locale.US).format(Date(note.updatedAt))
            canvas.drawText(
                "Channel: ${note.channelTitle.ifBlank { "YouTube" }} · Topic: ${note.topic} · Exported $dateStr",
                margin,
                y,
                metaPaint
            )
            y += 12f
            canvas.drawLine(margin, y, pageWidth - margin, y, dividerPaint)
            y += 20f

            val allText = buildPlainTextNote(note)
            val paragraphs = allText.lines()
            val lineHeight = 16.5f

            for (para in paragraphs) {
                val wrappedLines = if (para.isBlank()) listOf("") else wrapText(para, bodyPaint, usableWidth)
                for (wLine in wrappedLines) {
                    if (y > pageHeight - margin - 24f) {
                        canvas.drawText("Yasmin AI YouTube Agent · Page $pageNumber", margin, pageHeight - 18f, metaPaint)
                        document.finishPage(page)
                        pageNumber++
                        page = document.startPage(PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create())
                        canvas = page.canvas
                        y = margin + 10f
                    }
                    if (wLine.isNotEmpty()) {
                        canvas.drawText(wLine, margin, y, bodyPaint)
                    }
                    y += lineHeight
                }
            }
            canvas.drawText("Yasmin AI YouTube Agent · Page $pageNumber", margin, pageHeight - 18f, metaPaint)
            document.finishPage(page)

            FileOutputStream(outFile).use { fos -> document.writeTo(fos) }
            document.close()

            val safSynced = copyToSafIfConfigured(
                safTreeUriString = safTreeUriString,
                mimeType = "application/pdf",
                displayName = outFile.name,
                sourceFile = outFile
            )
            val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", outFile)
            ExportResult(outFile, uri, safSynced, "application/pdf")
        }
    }

    fun buildShareOrOpenIntent(result: ExportResult, title: String): Intent {
        val share = Intent(Intent.ACTION_SEND).apply {
            type = result.mimeType
            putExtra(Intent.EXTRA_STREAM, result.contentUri)
            putExtra(Intent.EXTRA_SUBJECT, title)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        return Intent.createChooser(share, "Share or Open ${result.file.name}").apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
    }

    private fun copyToSafIfConfigured(
        safTreeUriString: String,
        mimeType: String,
        displayName: String,
        sourceFile: File
    ): Boolean {
        if (safTreeUriString.isBlank()) return false
        return try {
            val treeUri = Uri.parse(safTreeUriString)
            val dir = DocumentFile.fromTreeUri(context, treeUri) ?: return false
            val targetDoc = dir.findFile(displayName) ?: dir.createFile(mimeType, displayName) ?: return false
            context.contentResolver.openOutputStream(targetDoc.uri, "wt")?.use { out ->
                sourceFile.inputStream().use { input -> input.copyTo(out) }
            } ?: return false
            true
        } catch (_: Exception) {
            false
        }
    }

    private fun wrapText(text: String, paint: Paint, maxWidth: Float): List<String> {
        val words = text.split(' ')
        val lines = mutableListOf<String>()
        var current = StringBuilder()
        for (word in words) {
            val candidate = if (current.isEmpty()) word else "$current $word"
            if (paint.measureText(candidate) <= maxWidth) {
                current.clear()
                current.append(candidate)
            } else {
                if (current.isNotEmpty()) {
                    lines.add(current.toString())
                    current.clear()
                }
                if (paint.measureText(word) <= maxWidth) {
                    current.append(word)
                } else {
                    var start = 0
                    while (start < word.length) {
                        var end = word.length
                        while (end > start + 1 && paint.measureText(word.substring(start, end)) > maxWidth) {
                            end--
                        }
                        lines.add(word.substring(start, end))
                        start = end
                    }
                }
            }
        }
        if (current.isNotEmpty()) lines.add(current.toString())
        return lines.ifEmpty { listOf("") }
    }

    companion object {
        fun sanitizeFilename(raw: String): String {
            return raw.trim()
                .replace(Regex("[^a-zA-Z0-9._-]+"), "_")
                .trim('_')
                .take(48)
                .ifBlank { "yasmin_youtube_notes" }
        }

        fun buildPlainTextNote(note: VideoNoteEntity): String {
            return buildString {
                appendLine("YASMIN AI — YOUTUBE VIDEO NOTES")
                appendLine("============================================================")
                appendLine("Title: ${note.videoTitle}")
                appendLine("Channel: ${note.channelTitle}")
                appendLine("Topic: ${note.topic}")
                appendLine("Video URL: https://www.youtube.com/watch?v=${note.videoId}")
                appendLine("Language: ${note.language.uppercase()}")
                appendLine("============================================================")
                appendLine()
                if (note.markdownContent.isNotBlank()) {
                    appendLine(note.markdownContent.trim())
                } else {
                    if (note.definitionsText.isNotBlank()) {
                        appendLine("DEFINITIONS:")
                        appendLine(note.definitionsText.trim())
                        appendLine()
                    }
                    if (note.bulletPointsText.isNotBlank()) {
                        appendLine("KEY BULLET POINTS:")
                        appendLine(note.bulletPointsText.trim())
                        appendLine()
                    }
                    if (note.stepsText.isNotBlank()) {
                        appendLine("STEP-BY-STEP NOTES:")
                        appendLine(note.stepsText.trim())
                        appendLine()
                    }
                    if (note.timestampsText.isNotBlank()) {
                        appendLine("IMPORTANT TIMESTAMPS:")
                        appendLine(note.timestampsText.trim())
                    }
                }
            }.trim()
        }
    }
}
