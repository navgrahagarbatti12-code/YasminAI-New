package com.yasmin.ai.ui.html

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.yasmin.ai.YasminApplication
import com.yasmin.ai.ai.AiResult
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

enum class WebEditorTab {
    HTML,
    CSS,
    JS,
    PREVIEW
}

class HtmlViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = (application as YasminApplication).repository

    private val _htmlCode = MutableStateFlow(
        """<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Yasmin Web Studio</title>
</head>
<body>
  <main class="card">
    <h1>Yasmin AI Web Studio</h1>
    <p>Edit HTML, CSS, and JS or ask Gemini to build a complete webpage.</p>
    <button id="pingBtn">Test Interactive Script</button>
    <p id="status"></p>
  </main>
</body>
</html>"""
    )
    val htmlCode: StateFlow<String> = _htmlCode.asStateFlow()

    private val _cssCode = MutableStateFlow(
        """body {
  margin: 0;
  font-family: system-ui, sans-serif;
  background: #040814;
  color: #e6f4ff;
  display: grid;
  place-items: center;
  min-height: 100vh;
  padding: 16px;
}
.card {
  background: #0d1b33;
  border: 1px solid #00e5ff44;
  border-radius: 14px;
  padding: 24px;
  max-width: 420px;
}
button {
  background: #00e5ff;
  color: #040814;
  border: none;
  padding: 10px 16px;
  border-radius: 8px;
  font-weight: 700;
  cursor: pointer;
}"""
    )
    val cssCode: StateFlow<String> = _cssCode.asStateFlow()

    private val _jsCode = MutableStateFlow(
        """document.getElementById('pingBtn')?.addEventListener('click', () => {
  const el = document.getElementById('status');
  if (el) el.textContent = 'Interactive JS running cleanly at ' + new Date().toLocaleTimeString();
});"""
    )
    val jsCode: StateFlow<String> = _jsCode.asStateFlow()

    private val _activeTab = MutableStateFlow(WebEditorTab.HTML)
    val activeTab: StateFlow<WebEditorTab> = _activeTab.asStateFlow()

    private val _statusLog = MutableStateFlow("Console: Ready")
    val statusLog: StateFlow<String> = _statusLog.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _explanationDialogText = MutableStateFlow<String?>(null)
    val explanationDialogText: StateFlow<String?> = _explanationDialogText.asStateFlow()

    fun selectTab(tab: WebEditorTab) {
        _activeTab.value = tab
    }

    fun updateCurrentTabCode(text: String) {
        when (_activeTab.value) {
            WebEditorTab.HTML -> _htmlCode.value = text
            WebEditorTab.CSS -> _cssCode.value = text
            WebEditorTab.JS -> _jsCode.value = text
            WebEditorTab.PREVIEW -> Unit
        }
    }

    fun loadProject(html: String, css: String, js: String) {
        _htmlCode.value = html
        _cssCode.value = css
        _jsCode.value = js
    }

    fun formatCurrentTab() {
        fun cleanLines(input: String): String =
            input.lines()
                .map { it.replace("\t", "  ").trimEnd() }
                .joinToString("\n")
                .trimEnd() + "\n"

        when (_activeTab.value) {
            WebEditorTab.HTML -> {
                _htmlCode.value = cleanLines(_htmlCode.value)
                _statusLog.value = "Console: Formatted HTML indentation & whitespace."
            }
            WebEditorTab.CSS -> {
                _cssCode.value = cleanLines(_cssCode.value)
                _statusLog.value = "Console: Formatted CSS indentation & whitespace."
            }
            WebEditorTab.JS -> {
                _jsCode.value = cleanLines(_jsCode.value)
                _statusLog.value = "Console: Formatted JS indentation & whitespace."
            }
            WebEditorTab.PREVIEW -> {
                _htmlCode.value = cleanLines(_htmlCode.value)
                _cssCode.value = cleanLines(_cssCode.value)
                _jsCode.value = cleanLines(_jsCode.value)
                _statusLog.value = "Console: Formatted HTML, CSS, and JS files."
            }
        }
    }

    fun generateWebsiteWithGemini(prompt: String) {
        if (prompt.isBlank()) return
        viewModelScope.launch {
            _isLoading.value = true
            _statusLog.value = "Console: Generating HTML/CSS/JS with Gemini…"
            when (
                val res = repository.requestCodeGeneration(
                    prompt = prompt,
                    target = "web",
                    existingCode = buildCombinedDocument()
                )
            ) {
                is AiResult.Success -> {
                    val data = res.data
                    if (!data.html.isNullOrBlank()) _htmlCode.value = data.html
                    if (!data.css.isNullOrBlank()) _cssCode.value = data.css
                    if (!data.js.isNullOrBlank()) _jsCode.value = data.js
                    if (data.html.isNullOrBlank() && !data.code.isNullOrBlank()) {
                        _htmlCode.value = data.code
                    }
                    _statusLog.value = "Console: Gemini generated updated project. Tap Preview."
                }
                is AiResult.Error -> {
                    _statusLog.value = "Error: ${res.message}"
                }
            }
            _isLoading.value = false
        }
    }

    fun explainWithGemini() {
        viewModelScope.launch {
            _isLoading.value = true
            _statusLog.value = "Console: Explaining current web project with Gemini…"
            when (
                val res = repository.requestCodeGeneration(
                    prompt = "Explain clearly how this HTML, CSS, and JavaScript web page works, including structure, layout styling, and interactive script behavior.",
                    target = "explain",
                    existingCode = buildCombinedDocument()
                )
            ) {
                is AiResult.Success -> {
                    val explanation = res.data.explanation?.takeIf { it.isNotBlank() }
                        ?: res.data.reply?.takeIf { it.isNotBlank() }
                        ?: "No explanation generated."
                    _explanationDialogText.value = explanation
                    _statusLog.value = "Console: Explanation ready."
                }
                is AiResult.Error -> {
                    _statusLog.value = "Explain Error: ${res.message}"
                }
            }
            _isLoading.value = false
        }
    }

    fun clearExplanation() {
        _explanationDialogText.value = null
    }

    fun buildCombinedDocument(): String {
        val rawHtml = _htmlCode.value
        val styleTag = "<style>\n${_cssCode.value}\n</style>"
        val scriptTag = "<script>\n${_jsCode.value}\n</script>"

        return if (rawHtml.contains("</head>", ignoreCase = true) && rawHtml.contains("</body>", ignoreCase = true)) {
            rawHtml
                .replace("</head>", "$styleTag\n</head>", ignoreCase = true)
                .replace("</body>", "$scriptTag\n</body>", ignoreCase = true)
        } else {
            """<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
$styleTag
</head>
<body>
$rawHtml
$scriptTag
</body>
</html>"""
        }
    }

    fun appendConsoleLog(line: String) {
        _statusLog.value = "Console: $line"
    }
}
