package com.yasmin.ai.ui.coding

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.yasmin.ai.R
import com.yasmin.ai.coding.BackgroundCodingWorker
import com.yasmin.ai.data.local.CodingJobEntity
import com.yasmin.ai.databinding.ItemCodingJobBinding

class CodingJobAdapter(
    private val onLoadProject: (CodingJobEntity) -> Unit,
    private val onCancelJob: (CodingJobEntity) -> Unit,
    private val onRetryJob: (CodingJobEntity) -> Unit,
    private val onDeleteJob: (CodingJobEntity) -> Unit
) : ListAdapter<CodingJobEntity, CodingJobAdapter.JobViewHolder>(DiffCallback) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): JobViewHolder {
        val binding = ItemCodingJobBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return JobViewHolder(binding)
    }

    override fun onBindViewHolder(holder: JobViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class JobViewHolder(private val binding: ItemCodingJobBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(item: CodingJobEntity) {
            val ctx = binding.root.context
            binding.tvJobTitle.text = "${item.projectName} · ${item.language}"
            binding.tvJobStatus.text = item.status
            binding.tvJobMessage.text = item.statusMessage
            binding.progressJob.progress = item.progress.coerceIn(0, 100)

            val statusColor = when (item.status) {
                BackgroundCodingWorker.STATUS_COMPLETED -> R.color.jarvis_success
                BackgroundCodingWorker.STATUS_FAILED,
                BackgroundCodingWorker.STATUS_INTERRUPTED -> R.color.jarvis_error
                BackgroundCodingWorker.STATUS_CANCELLED -> R.color.jarvis_warning
                else -> R.color.jarvis_cyan
            }
            binding.tvJobStatus.setTextColor(ContextCompat.getColor(ctx, statusColor))

            val isActive = item.status == BackgroundCodingWorker.STATUS_QUEUED ||
                item.status == BackgroundCodingWorker.STATUS_RUNNING
            val isCompleted = item.status == BackgroundCodingWorker.STATUS_COMPLETED
            val canRetry = item.status == BackgroundCodingWorker.STATUS_FAILED ||
                item.status == BackgroundCodingWorker.STATUS_INTERRUPTED ||
                item.status == BackgroundCodingWorker.STATUS_CANCELLED

            binding.btnJobCancel.visibility = if (isActive) View.VISIBLE else View.GONE
            binding.btnJobLoad.visibility = if (isCompleted) View.VISIBLE else View.GONE
            binding.btnJobRetry.visibility = if (canRetry) View.VISIBLE else View.GONE
            binding.btnJobDelete.visibility = if (!isActive) View.VISIBLE else View.GONE

            binding.btnJobLoad.setOnClickListener { onLoadProject(item) }
            binding.btnJobCancel.setOnClickListener { onCancelJob(item) }
            binding.btnJobRetry.setOnClickListener { onRetryJob(item) }
            binding.btnJobDelete.setOnClickListener { onDeleteJob(item) }
        }
    }

    private object DiffCallback : DiffUtil.ItemCallback<CodingJobEntity>() {
        override fun areItemsTheSame(oldItem: CodingJobEntity, newItem: CodingJobEntity): Boolean =
            oldItem.jobId == newItem.jobId

        override fun areContentsTheSame(oldItem: CodingJobEntity, newItem: CodingJobEntity): Boolean =
            oldItem == newItem
    }
}
