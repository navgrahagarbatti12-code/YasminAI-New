package com.yasmin.ai.repository

import com.yasmin.ai.ai.AiResult
import com.yasmin.ai.ai.BriefingRequest
import com.yasmin.ai.ai.ChatTurn
import com.yasmin.ai.ai.GeminiAgentRequest
import com.yasmin.ai.ai.GeminiAgentResponse
import com.yasmin.ai.ai.GeminiBackendClient
import com.yasmin.ai.ai.GeminiChatRequest
import com.yasmin.ai.ai.GeminiCodeRequest
import com.yasmin.ai.ai.GeminiResponse
import com.yasmin.ai.ai.GeminiVisionRequest
import com.yasmin.ai.ai.MemoryContextItem
import com.yasmin.ai.ai.PythonSandboxResponse
import com.yasmin.ai.data.local.ChatDao
import com.yasmin.ai.data.local.ChatMessageEntity
import com.yasmin.ai.data.local.MemoryDao
import com.yasmin.ai.data.local.MemoryEntity
import com.yasmin.ai.data.local.TaskDao
import com.yasmin.ai.data.local.TaskEntity
import com.yasmin.ai.data.local.VoiceHistoryDao
import com.yasmin.ai.data.local.VoiceHistoryEntity
import com.yasmin.ai.data.preferences.UserPreferencesDataStore
import com.yasmin.ai.data.preferences.YasminUserPreferences
import com.yasmin.ai.memory.MemoryEngine
import com.yasmin.ai.security.MemoryPrivacyGuard
import com.yasmin.ai.security.SecureVault
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class YasminRepository(
    private val chatDao: ChatDao,
    private val memoryDao: MemoryDao,
    private val taskDao: TaskDao,
    private val voiceHistoryDao: VoiceHistoryDao,
    private val preferencesDataStore: UserPreferencesDataStore,
    private val secureVault: SecureVault
) {
    val messagesFlow: Flow<List<ChatMessageEntity>> = chatDao.observeAllMessages()
    val memoriesFlow: Flow<List<MemoryEntity>> = memoryDao.observeAllMemories()
    val tasksFlow: Flow<List<TaskEntity>> = taskDao.observeAllTasks()
    val voiceHistoryFlow: Flow<List<VoiceHistoryEntity>> = voiceHistoryDao.observeVoiceHistory()
    val preferencesFlow: Flow<YasminUserPreferences> = preferencesDataStore.preferencesFlow

    private val repoScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    @Volatile
    private var cachedPrefs: YasminUserPreferences = YasminUserPreferences()

    init {
        // Non-blocking background sync avoids main-thread I/O stalls on startup
        repoScope.launch {
            preferencesDataStore.preferencesFlow.collect { prefs ->
                cachedPrefs = prefs
            }
        }
    }

    val aiProvider: GeminiBackendClient = GeminiBackendClient(
        baseUrlProvider = { cachedPrefs.backendProxyUrl },
        authTokenProvider = { secureVault.getSecret(SecureVault.KEY_PROXY_AUTH_TOKEN) },
        providerTypeProvider = { cachedPrefs.providerType },
        customProviderUrlProvider = { cachedPrefs.customProviderUrl },
        customModelProvider = { cachedPrefs.customProviderModel },
        customKeyProvider = { secureVault.getSecret(SecureVault.KEY_CUSTOM_PROVIDER_KEY) },
        autoFallbackProvider = { cachedPrefs.autoFallbackEnabled }
    )

    suspend fun getPreferencesSnapshot(): YasminUserPreferences {
        return preferencesFlow.first().also { cachedPrefs = it }
    }

    suspend fun saveUserMessage(content: String, language: String) {
        chatDao.insertMessage(ChatMessageEntity(role = "user", content = content, language = language))
    }

    suspend fun saveAssistantMessage(content: String, language: String) {
        chatDao.insertMessage(ChatMessageEntity(role = "assistant", content = content, language = language))
    }

    suspend fun updateOrInsertAssistantMessage(existingId: Long?, content: String, language: String): Long {
        if (existingId != null && existingId > 0L) {
            chatDao.insertMessage(
                ChatMessageEntity(
                    id = existingId,
                    role = "assistant",
                    content = content,
                    language = language
                )
            )
            return existingId
        }
        return chatDao.insertMessage(ChatMessageEntity(role = "assistant", content = content, language = language))
    }

    suspend fun recordVoiceCommand(transcript: String, source: String) {
        voiceHistoryDao.insertVoiceCommand(VoiceHistoryEntity(transcript = transcript, source = source))
    }

    suspend fun getSemanticMemoriesForQuery(query: String, limit: Int = 8): List<MemoryContextItem> {
        val all = memoryDao.getAllMemoriesSnapshot()
        if (all.isEmpty()) return emptyList()
        val ranked = MemoryEngine.rankRelevantMemories(query, all, limit = limit)
        if (ranked.isNotEmpty()) {
            memoryDao.incrementAccessCounts(ranked.map { it.id })
        }
        return ranked.map { MemoryContextItem(it.keyTitle, it.content) }
    }

    suspend fun tryAutoExtractMemory(userUtterance: String): Boolean {
        val candidate = MemoryEngine.extractSafeCandidate(userUtterance) ?: return false
        val saved = savePersonalMemory(
            category = candidate.category,
            keyTitle = candidate.keyTitle,
            content = candidate.content,
            importance = candidate.importance,
            isUserApproved = false
        )
        return saved.isSuccess
    }

    suspend fun savePersonalMemory(
        category: String,
        keyTitle: String,
        content: String,
        importance: Int = 2,
        isUserApproved: Boolean = true
    ): Result<Long> {
        val checked = MemoryPrivacyGuard.sanitizeOrReject("$keyTitle: $content")
        if (checked.isFailure) {
            return Result.failure(checked.exceptionOrNull() ?: SecurityException("Blocked by privacy guard"))
        }

        val allExisting = memoryDao.getAllMemoriesSnapshot()
        val duplicate = MemoryEngine.findDuplicate(keyTitle, content, allExisting)
        return if (duplicate != null) {
            memoryDao.updateMemory(
                duplicate.copy(
                    category = category,
                    keyTitle = keyTitle.trim(),
                    content = content.trim(),
                    importance = maxOf(duplicate.importance, importance.coerceIn(1, 5)),
                    isUserApproved = duplicate.isUserApproved || isUserApproved,
                    updatedAt = System.currentTimeMillis()
                )
            )
            Result.success(duplicate.id)
        } else {
            val id = memoryDao.insertMemory(
                MemoryEntity(
                    category = category,
                    keyTitle = keyTitle.trim(),
                    content = content.trim(),
                    importance = importance.coerceIn(1, 5),
                    isUserApproved = isUserApproved
                )
            )
            Result.success(id)
        }
    }

    suspend fun updateExistingMemory(memory: MemoryEntity, newCategory: String, newTitle: String, newContent: String): Result<Unit> {
        val checked = MemoryPrivacyGuard.sanitizeOrReject("$newTitle: $newContent")
        if (checked.isFailure) {
            return Result.failure(checked.exceptionOrNull() ?: SecurityException("Blocked by privacy guard"))
        }
        memoryDao.updateMemory(
            memory.copy(
                category = newCategory,
                keyTitle = newTitle.trim(),
                content = newContent.trim(),
                isUserApproved = true,
                updatedAt = System.currentTimeMillis()
            )
        )
        return Result.success(Unit)
    }

    suspend fun searchMemoriesLocal(query: String): List<MemoryEntity> =
        if (query.isBlank()) memoryDao.getAllMemoriesSnapshot() else memoryDao.searchMemories(query.trim())

    suspend fun deleteMemory(memory: MemoryEntity) = memoryDao.deleteMemory(memory)
    suspend fun clearAllMemories() = memoryDao.clearAllMemories()

    suspend fun addTask(
        type: String,
        title: String,
        details: String = "",
        dueLabel: String = "",
        reminderEpochMs: Long = 0L
    ): Long {
        return taskDao.insertTask(
            TaskEntity(
                type = type,
                title = title.trim(),
                details = details.trim(),
                dueLabel = dueLabel.trim(),
                reminderEpochMs = reminderEpochMs
            )
        )
    }

    suspend fun getPendingTasksSnapshot(limit: Int = 8): List<TaskEntity> = taskDao.getPendingTasks(limit)

    suspend fun toggleTaskCompleted(task: TaskEntity) {
        taskDao.updateTask(task.copy(isCompleted = !task.isCompleted))
    }

    suspend fun deleteTask(task: TaskEntity) = taskDao.deleteTask(task)

    suspend fun searchChatHistoryLocal(query: String): List<ChatMessageEntity> {
        val q = query.trim().lowercase()
        val recent = chatDao.getRecentMessages(50)
        return if (q.isEmpty()) recent else recent.filter { it.content.lowercase().contains(q) }
    }

    suspend fun sendChatPrompt(userText: String, enableSearch: Boolean = true): AiResult<GeminiResponse> {
        val prefs = getPreferencesSnapshot()
        saveUserMessage(userText, prefs.languageMode)
        tryAutoExtractMemory(userText)

        val recentHistory = chatDao.getRecentMessages(10)
            .reversed()
            .map { ChatTurn(role = it.role, content = it.content) }
        val relevantMemories = getSemanticMemoriesForQuery(userText, limit = 8)

        return when (
            val result = aiProvider.chat(
                GeminiChatRequest(
                    message = userText,
                    language = prefs.languageMode,
                    personality = prefs.aiPersonality,
                    history = recentHistory,
                    memories = relevantMemories,
                    userName = prefs.userName,
                    enableWebSearch = enableSearch
                )
            )
        ) {
            is AiResult.Success -> {
                val baseReply = result.data.reply?.takeIf { it.isNotBlank() }
                    ?: "I received an empty response from the AI service."
                val sourcesSuffix = result.data.sources
                    ?.takeIf { it.isNotEmpty() }
                    ?.joinToString("\n") { "• ${it.title}: ${it.uri}" }
                    ?.let { "\n\nSources:\n$it" }
                    .orEmpty()
                val fullReply = baseReply + sourcesSuffix
                saveAssistantMessage(fullReply, prefs.languageMode)
                AiResult.Success(result.data.copy(reply = fullReply))
            }
            is AiResult.Error -> {
                saveAssistantMessage("Error: ${result.message}", prefs.languageMode)
                result
            }
        }
    }

    fun streamChatReply(userText: String, historyTurns: List<ChatTurn>, memories: List<MemoryContextItem>): Flow<String> {
        return aiProvider.streamChat(
            GeminiChatRequest(
                message = userText,
                language = cachedPrefs.languageMode,
                personality = cachedPrefs.aiPersonality,
                history = historyTurns,
                memories = memories,
                userName = cachedPrefs.userName,
                enableWebSearch = true
            )
        )
    }

    suspend fun getRecentHistoryTurns(limit: Int = 10): List<ChatTurn> =
        chatDao.getRecentMessages(limit).reversed().map { ChatTurn(it.role, it.content) }

    suspend fun planNaturalIntent(userText: String): AiResult<GeminiAgentResponse> {
        val prefs = getPreferencesSnapshot()
        val relevantMemories = getSemanticMemoriesForQuery(userText, limit = 8)
        val pendingTasks = taskDao.getPendingTasks(8).map { "${it.type}: ${it.title} (${it.dueLabel})" }

        return aiProvider.planActions(
            GeminiAgentRequest(
                message = userText,
                language = prefs.languageMode,
                personality = prefs.aiPersonality,
                memories = relevantMemories,
                pendingTasks = pendingTasks,
                userName = prefs.userName
            )
        )
    }

    suspend fun fetchDailyBriefing(cityOrContext: String, upcomingEvents: List<String>): AiResult<GeminiResponse> {
        val prefs = getPreferencesSnapshot()
        val pendingTasks = taskDao.getPendingTasks(8).map { "${it.type}: ${it.title} ${it.dueLabel}".trim() }
        return aiProvider.fetchBriefing(
            BriefingRequest(
                cityOrContext = cityOrContext,
                pendingTasks = pendingTasks,
                upcomingEvents = upcomingEvents,
                language = prefs.languageMode,
                personality = prefs.aiPersonality,
                userName = prefs.userName
            )
        )
    }

    suspend fun executePythonRemote(code: String): AiResult<PythonSandboxResponse> {
        getPreferencesSnapshot()
        return aiProvider.executePythonRemote(code)
    }

    suspend fun requestCodeGeneration(
        prompt: String,
        target: String,
        existingCode: String = "",
        errorOutput: String = ""
    ): AiResult<GeminiResponse> {
        getPreferencesSnapshot()
        return aiProvider.generateCode(
            GeminiCodeRequest(
                prompt = prompt,
                target = target,
                existingCode = existingCode,
                errorOutput = errorOutput
            )
        )
    }

    suspend fun explainScreenText(screenText: String): AiResult<String> {
        val prompt = "Read and summarize the following Android screen content clearly and concisely:\n\n$screenText"
        return when (val res = sendChatPrompt(prompt, enableSearch = false)) {
            is AiResult.Success -> AiResult.Success(res.data.reply.orEmpty())
            is AiResult.Error -> res
        }
    }

    suspend fun analyzeVisionImage(
        base64Jpeg: String,
        prompt: String,
        mode: String
    ): AiResult<String> {
        val prefs = getPreferencesSnapshot()
        saveUserMessage("[Visual analysis ($mode)]: $prompt", prefs.languageMode)
        return when (
            val result = aiProvider.analyzeVision(
                GeminiVisionRequest(
                    prompt = prompt,
                    imageBase64 = base64Jpeg,
                    mimeType = "image/jpeg",
                    language = prefs.languageMode,
                    mode = mode
                )
            )
        ) {
            is AiResult.Success -> {
                val reply = result.data.reply ?: "Could not extract visual explanation."
                saveAssistantMessage(reply, prefs.languageMode)
                AiResult.Success(reply)
            }
            is AiResult.Error -> {
                saveAssistantMessage("Vision error: ${result.message}", prefs.languageMode)
                result
            }
        }
    }

    suspend fun clearChatHistory() = chatDao.clearAll()
    suspend fun clearVoiceHistory() = voiceHistoryDao.clearVoiceHistory()
    suspend fun updateUserName(name: String) = preferencesDataStore.updateUserName(name)
    suspend fun updateProxyUrl(url: String) {
        preferencesDataStore.updateBackendProxyUrl(url)
        getPreferencesSnapshot()
    }
    suspend fun updateProviderConfig(type: String, customUrl: String, customModel: String, autoFallback: Boolean) {
        preferencesDataStore.updateProviderConfig(type, customUrl, customModel, autoFallback)
        getPreferencesSnapshot()
    }
    suspend fun updateAiPersonality(personality: String) = preferencesDataStore.updateAiPersonality(personality)
    suspend fun testProxyConnection(url: String): AiResult<Boolean> = aiProvider.pingHealth(url)
    suspend fun updateLanguageMode(mode: String) = preferencesDataStore.updateLanguageMode(mode)
    suspend fun updateAutoSpeak(enabled: Boolean) = preferencesDataStore.updateAutoSpeak(enabled)
    suspend fun updateContinuousConversation(enabled: Boolean) =
        preferencesDataStore.updateContinuousConversation(enabled)
    suspend fun updateSpeechRate(rate: Float) = preferencesDataStore.updateSpeechRate(rate)
    suspend fun updateSpeechPitch(pitch: Float) = preferencesDataStore.updateSpeechPitch(pitch)
    suspend fun updateTtsVoiceName(voiceName: String) = preferencesDataStore.updateTtsVoiceName(voiceName)
    suspend fun updateWakeSensitivity(sensitivity: Int) = preferencesDataStore.updateWakeSensitivity(sensitivity)
    suspend fun updateScreenConsent(allowed: Boolean) = preferencesDataStore.updateScreenConsent(allowed)
    suspend fun updateWakeSession(enabled: Boolean) = preferencesDataStore.updateWakeSession(enabled)

    fun saveProxyAuthToken(token: String) = secureVault.putSecret(SecureVault.KEY_PROXY_AUTH_TOKEN, token)
    fun hasProxyAuthToken(): Boolean = secureVault.getSecret(SecureVault.KEY_PROXY_AUTH_TOKEN).isNotBlank()
    fun saveCustomProviderKey(key: String) = secureVault.putSecret(SecureVault.KEY_CUSTOM_PROVIDER_KEY, key)
    fun hasCustomProviderKey(): Boolean = secureVault.getSecret(SecureVault.KEY_CUSTOM_PROVIDER_KEY).isNotBlank()

    suspend fun resetAllPreferences() {
        preferencesDataStore.clearAllPreferences()
        secureVault.clearAll()
        getPreferencesSnapshot()
    }
}
