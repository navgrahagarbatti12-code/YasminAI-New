package com.yasmin.ai.data.preferences

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.yasmin.ai.BuildConfig
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "yasmin_preferences")

data class YasminUserPreferences(
    val userName: String = "Commander",
    val backendProxyUrl: String = BuildConfig.DEFAULT_PROXY_URL,
    val providerType: String = "gemini_proxy", // "gemini_proxy" | "openai_compatible"
    val customProviderUrl: String = "",
    val customProviderModel: String = "gpt-4o-mini",
    val autoFallbackEnabled: Boolean = true,
    val aiPersonality: String = "jarvis_formal", // "jarvis_formal" | "concise_tactical" | "friendly_companion" | "coding_mentor"
    val languageMode: String = "hinglish", // "en", "hi", "hinglish"
    val autoSpeakResponses: Boolean = true,
    val continuousConversation: Boolean = false,
    val speechRate: Float = 1.0f,
    val speechPitch: Float = 1.0f,
    val ttsVoiceName: String = "",
    val conversationTimeoutSec: Int = 10,
    val wakeSensitivity: Int = 60, // 10..100
    val screenReadingConsent: Boolean = false,
    val wakeSessionEnabled: Boolean = false
)

class UserPreferencesDataStore(private val context: Context) {

    private object Keys {
        val USER_NAME = stringPreferencesKey("user_name")
        val BACKEND_PROXY_URL = stringPreferencesKey("backend_proxy_url")
        val PROVIDER_TYPE = stringPreferencesKey("provider_type")
        val CUSTOM_PROVIDER_URL = stringPreferencesKey("custom_provider_url")
        val CUSTOM_PROVIDER_MODEL = stringPreferencesKey("custom_provider_model")
        val AUTO_FALLBACK = booleanPreferencesKey("auto_fallback")
        val AI_PERSONALITY = stringPreferencesKey("ai_personality")
        val LANGUAGE_MODE = stringPreferencesKey("language_mode")
        val AUTO_SPEAK = booleanPreferencesKey("auto_speak")
        val CONTINUOUS_CONVERSATION = booleanPreferencesKey("continuous_conversation")
        val SPEECH_RATE = floatPreferencesKey("speech_rate")
        val SPEECH_PITCH = floatPreferencesKey("speech_pitch")
        val TTS_VOICE_NAME = stringPreferencesKey("tts_voice_name")
        val CONVERSATION_TIMEOUT = intPreferencesKey("conversation_timeout_sec")
        val WAKE_SENSITIVITY = intPreferencesKey("wake_sensitivity")
        val SCREEN_CONSENT = booleanPreferencesKey("screen_consent")
        val WAKE_SESSION = booleanPreferencesKey("wake_session")
    }

    val preferencesFlow: Flow<YasminUserPreferences> = context.dataStore.data.map { prefs ->
        YasminUserPreferences(
            userName = prefs[Keys.USER_NAME] ?: "Commander",
            backendProxyUrl = prefs[Keys.BACKEND_PROXY_URL] ?: BuildConfig.DEFAULT_PROXY_URL,
            providerType = prefs[Keys.PROVIDER_TYPE] ?: "gemini_proxy",
            customProviderUrl = prefs[Keys.CUSTOM_PROVIDER_URL] ?: "",
            customProviderModel = prefs[Keys.CUSTOM_PROVIDER_MODEL] ?: "gpt-4o-mini",
            autoFallbackEnabled = prefs[Keys.AUTO_FALLBACK] ?: true,
            aiPersonality = prefs[Keys.AI_PERSONALITY] ?: "jarvis_formal",
            languageMode = prefs[Keys.LANGUAGE_MODE] ?: "hinglish",
            autoSpeakResponses = prefs[Keys.AUTO_SPEAK] ?: true,
            continuousConversation = prefs[Keys.CONTINUOUS_CONVERSATION] ?: false,
            speechRate = prefs[Keys.SPEECH_RATE] ?: 1.0f,
            speechPitch = prefs[Keys.SPEECH_PITCH] ?: 1.0f,
            ttsVoiceName = prefs[Keys.TTS_VOICE_NAME] ?: "",
            conversationTimeoutSec = prefs[Keys.CONVERSATION_TIMEOUT] ?: 10,
            wakeSensitivity = prefs[Keys.WAKE_SENSITIVITY] ?: 60,
            screenReadingConsent = prefs[Keys.SCREEN_CONSENT] ?: false,
            wakeSessionEnabled = prefs[Keys.WAKE_SESSION] ?: false
        )
    }

    suspend fun updateUserName(name: String) {
        context.dataStore.edit { it[Keys.USER_NAME] = name.trim().ifBlank { "Commander" } }
    }

    suspend fun updateBackendProxyUrl(url: String) {
        context.dataStore.edit { it[Keys.BACKEND_PROXY_URL] = url.trim().trimEnd('/') }
    }

    suspend fun updateProviderConfig(type: String, customUrl: String, customModel: String, autoFallback: Boolean) {
        context.dataStore.edit {
            it[Keys.PROVIDER_TYPE] = type
            it[Keys.CUSTOM_PROVIDER_URL] = customUrl.trim().trimEnd('/')
            it[Keys.CUSTOM_PROVIDER_MODEL] = customModel.trim().ifBlank { "gpt-4o-mini" }
            it[Keys.AUTO_FALLBACK] = autoFallback
        }
    }

    suspend fun updateAiPersonality(personality: String) {
        context.dataStore.edit { it[Keys.AI_PERSONALITY] = personality }
    }

    suspend fun updateLanguageMode(mode: String) {
        context.dataStore.edit { it[Keys.LANGUAGE_MODE] = mode }
    }

    suspend fun updateAutoSpeak(enabled: Boolean) {
        context.dataStore.edit { it[Keys.AUTO_SPEAK] = enabled }
    }

    suspend fun updateContinuousConversation(enabled: Boolean) {
        context.dataStore.edit { it[Keys.CONTINUOUS_CONVERSATION] = enabled }
    }

    suspend fun updateSpeechRate(rate: Float) {
        context.dataStore.edit { it[Keys.SPEECH_RATE] = rate.coerceIn(0.5f, 2.0f) }
    }

    suspend fun updateSpeechPitch(pitch: Float) {
        context.dataStore.edit { it[Keys.SPEECH_PITCH] = pitch.coerceIn(0.6f, 1.8f) }
    }

    suspend fun updateTtsVoiceName(voiceName: String) {
        context.dataStore.edit { it[Keys.TTS_VOICE_NAME] = voiceName }
    }

    suspend fun updateWakeSensitivity(sensitivity: Int) {
        context.dataStore.edit { it[Keys.WAKE_SENSITIVITY] = sensitivity.coerceIn(10, 100) }
    }

    suspend fun updateScreenConsent(allowed: Boolean) {
        context.dataStore.edit { it[Keys.SCREEN_CONSENT] = allowed }
    }

    suspend fun updateWakeSession(enabled: Boolean) {
        context.dataStore.edit { it[Keys.WAKE_SESSION] = enabled }
    }

    suspend fun clearAllPreferences() {
        context.dataStore.edit { it.clear() }
    }
}
