package com.yasmin.ai.ui.chat

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.yasmin.ai.R
import com.yasmin.ai.data.local.ChatMessageEntity
import com.yasmin.ai.databinding.ItemChatMessageBinding

class ChatAdapter(
    private val onCopyClick: (String) -> Unit,
    private val onSpeakClick: (String) -> Unit
) : ListAdapter<ChatMessageEntity, ChatAdapter.MessageViewHolder>(DiffCallback) {

    inner class MessageViewHolder(val binding: ItemChatMessageBinding) :
        RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MessageViewHolder {
        val binding = ItemChatMessageBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return MessageViewHolder(binding)
    }

    override fun onBindViewHolder(holder: MessageViewHolder, position: Int) {
        val msg = getItem(position)
        val isUser = msg.role == "user"
        holder.binding.tvMessageRole.text = if (isUser) "YOU" else "YASMIN AI"
        holder.binding.tvMessageContent.text = msg.content
        holder.binding.bubbleContainer.setBackgroundResource(
            if (isUser) R.drawable.bg_message_user else R.drawable.bg_message_assistant
        )
        holder.binding.tvMessageCopy.setOnClickListener { onCopyClick(msg.content) }
        holder.binding.tvMessageSpeak.setOnClickListener { onSpeakClick(msg.content) }
    }

    private object DiffCallback : DiffUtil.ItemCallback<ChatMessageEntity>() {
        override fun areItemsTheSame(oldItem: ChatMessageEntity, newItem: ChatMessageEntity): Boolean =
            oldItem.id == newItem.id

        override fun areContentsTheSame(oldItem: ChatMessageEntity, newItem: ChatMessageEntity): Boolean =
            oldItem == newItem
    }
}
