package com.yasmin.ai.youtube

import com.google.gson.Gson
import com.google.gson.JsonArray
import com.google.gson.JsonElement
import com.google.gson.JsonObject
import com.yasmin.ai.ai.AiResult
import com.yasmin.ai.ai.GeminiBackendClient

/**
 * YouTube AI Intelligence Engine powered exclusively by Groq + Google Gemini (via GeminiBackendClient).
 * Strictly enforces grounding in available transcript, chapters, metadata, or user-consented screen text.
 */
class YouTubeAiEngine(
    private val aiClient: GeminiBackendClient
) {
    private val gson = Gson()

    suspend fun summarizeVideo(
        video: YouTubeVideoInfo,
        transcript: TranscriptResult,
        style: SummaryStyle,
        language: SummaryLanguage,
        screenContextText: String = ""
    ): AiResult<String> {
        val groundingBlock = buildVideoGroundingBlock(video, transcript, screenContextText)
        val langInstruction = languageDirective(language)
        val styleInstruction = when (style) {
            SummaryStyle.SHORT -> "Provide a crisp 4-6 line executive summary highlighting the core thesis."
            SummaryStyle.DETAILED -> "Provide a thorough multi-section detailed summary covering all main arguments and takeaways."
            SummaryStyle.COMPLETE_TRANSCRIPT -> "Walk chronologically through the complete video transcript so nothing important is skipped."
            SummaryStyle.TOPIC_WISE -> "Break the video into clear Topic Headings with concise explanations under each topic."
            SummaryStyle.STEP_BY_STEP -> "Organize the content into numbered Step 1, Step 2, Step 3 actionable instructions."
            SummaryStyle.IMPORTANT_POINTS -> "List the most critical bullet takeaways, key facts, and warnings."
            SummaryStyle.PRACTICAL_EXAMPLES -> "Focus on practical examples, real-world use cases, commands, or demonstrations discussed."
            SummaryStyle.CHAPTER_WISE -> if (video.chapters.isNotEmpty() || transcript.segments.isNotEmpty()) {
                "Summarize chapter-by-chapter or timestamp-by-timestamp preserving exact [MM:SS] markers."
            } else {
                "No explicit chapters were found; organize logically into Beginning, Middle, and Key Takeaways based strictly on available data."
            }
        }

        val chunks = if (transcript.status == TranscriptStatus.AVAILABLE) {
            YouTubeDataService.chunkTranscriptText(transcript.rawTextWithTimestamps, maxCharsPerChunk = 8000)
        } else {
            emptyList()
        }

        val systemPrompt = """
You are Yasmin, an expert female JARVIS-style YouTube AI Analyst.
$langInstruction
GROUNDING RULE (CRITICAL):
- Use ONLY the provided video metadata, chapters, transcript, and optional user-consented screen text.
- If the transcript is marked UNAVAILABLE or RESTRICTED, state clearly upfront that captions are unavailable and DO NOT invent spoken details or quotes.
- Preserve [MM:SS] timestamps whenever referencing transcript sections or chapters.
        """.trimIndent()

        // Multi-chunk map-reduce summarization for long videos
        if (chunks.size > 1) {
            val partSummaries = mutableListOf<String>()
            val limitedChunks = chunks.take(6)
            for ((idx, chunk) in limitedChunks.withIndex()) {
                val partPrompt = """
Video Title: ${video.title}
Channel: ${video.channelTitle}
Part ${idx + 1} of ${limitedChunks.size} of transcript:
$chunk

Extract key concepts, topics, steps, examples, and [MM:SS] timestamps from this segment ONLY.
                """.trimIndent()
                when (val partRes = aiClient.generateWithSystemPrompt(systemPrompt, partPrompt, expectJson = false)) {
                    is AiResult.Success -> partSummaries.add("Segment ${idx + 1}:\n${partRes.data}")
                    is AiResult.Error -> return partRes
                }
            }
            val finalPrompt = """
Style requested: ${style.label} — $styleInstruction
$langInstruction
Video Title: ${video.title} (${video.channelTitle})
Chapters: ${formatChaptersLine(video)}

Synthesize these verified segment summaries into one cohesive final output:
${partSummaries.joinToString("\n\n")}
            """.trimIndent()
            return aiClient.generateWithSystemPrompt(systemPrompt, finalPrompt, expectJson = false)
        }

        val userPrompt = """
Summary Mode: ${style.label}
Directive: $styleInstruction
$langInstruction

$groundingBlock
        """.trimIndent()

        return aiClient.generateWithSystemPrompt(systemPrompt, userPrompt, expectJson = false)
    }

    suspend fun answerVideoQuestion(
        video: YouTubeVideoInfo,
        transcript: TranscriptResult,
        history: List<YouTubeChatMessage>,
        question: String,
        language: SummaryLanguage,
        screenContextText: String = ""
    ): AiResult<String> {
        val grounding = buildVideoGroundingBlock(video, transcript, screenContextText, maxTranscriptChars = 11000)
        val recentTurns = history.takeLast(6).joinToString("\n") { "${it.role}: ${it.content.take(300)}" }
        val systemPrompt = """
You are Yasmin, answering a user's question about a YouTube video.
${languageDirective(language)}
STRICT GROUNDING POLICY:
- Answer using ONLY facts present in the provided transcript, chapters, metadata, or user-consented screen text.
- Quote or cite [MM:SS] timestamps whenever relevant.
- If the transcript is unavailable OR the video data does not mention the answer, explicitly say so — never fabricate dialogue.
        """.trimIndent()

        val userPrompt = """
$grounding

Recent conversation:
${recentTurns.ifBlank { "(none)" }}

User Question: $question
        """.trimIndent()

        return aiClient.generateWithSystemPrompt(systemPrompt, userPrompt, expectJson = false)
    }

    suspend fun generateStructuredNotes(
        video: YouTubeVideoInfo,
        transcript: TranscriptResult,
        language: SummaryLanguage,
        screenContextText: String = ""
    ): AiResult<GeneratedNotesBundle> {
        val grounding = buildVideoGroundingBlock(video, transcript, screenContextText, maxTranscriptChars = 11000)
        val systemPrompt = """
You are Yasmin, an expert study-notes architect. ${languageDirective(language)}
Return strictly valid JSON matching this schema:
{
  "topic": "concise main topic",
  "definitions": "key terms & clear definitions grounded in video",
  "bulletPoints": "concise bullet points of core ideas",
  "stepByStep": "numbered step-by-step workflow or explanation",
  "importantTimestamps": "[MM:SS] event descriptions based ONLY on available timestamps/chapters",
  "fullMarkdown": "complete formatted study guide combining all sections cleanly"
}
Never invent timestamps or facts missing from the provided context.
        """.trimIndent()

        val res = aiClient.generateWithSystemPrompt(
            systemPrompt = systemPrompt,
            userPrompt = "Generate structured study notes for:\n\n$grounding",
            expectJson = true
        )
        return when (res) {
            is AiResult.Success -> AiResult.Success(parseNotesJson(res.data, video))
            is AiResult.Error -> res
        }
    }

    suspend fun generateLearningLesson(
        video: YouTubeVideoInfo,
        transcript: TranscriptResult,
        depth: LearningDepth,
        language: SummaryLanguage,
        screenContextText: String = ""
    ): AiResult<String> {
        val grounding = buildVideoGroundingBlock(video, transcript, screenContextText, maxTranscriptChars = 10000)
        val depthPrompt = when (depth) {
            LearningDepth.BASIC -> "1) Identify the core topic clearly. 2) Teach fundamentals in simple intuitive language with everyday analogies."
            LearningDepth.ADVANCED -> "1) Identify the core topic. 2) Teach deep technical concepts, nuances, edge cases, and architecture."
            LearningDepth.PRACTICAL -> "1) Identify the core topic. 2) Walk through concrete practical examples, exercises, and real-world applications."
            LearningDepth.INTERACTIVE -> "1) Identify the core topic. 2) Teach interactively in short checkpoints, ending with 2 thought-provoking reflection questions for the learner."
        }
        val systemPrompt = """
You are Yasmin, an encouraging JARVIS-style Personal Tutor. ${languageDirective(language)}
Ground all teaching strictly in the provided video data; if transcript captions are missing, teach from verified topic/metadata and clearly state that captions were unavailable.
        """.trimIndent()
        val userPrompt = """
Learning Mode: ${depth.label}
Instruction: $depthPrompt

$grounding
        """.trimIndent()
        return aiClient.generateWithSystemPrompt(systemPrompt, userPrompt, expectJson = false)
    }

    suspend fun generateQuiz(
        video: YouTubeVideoInfo,
        transcript: TranscriptResult,
        language: SummaryLanguage,
        questionCount: Int = 5,
        screenContextText: String = ""
    ): AiResult<List<QuizQuestion>> {
        val grounding = buildVideoGroundingBlock(video, transcript, screenContextText, maxTranscriptChars = 10000)
        val systemPrompt = """
You are Yasmin, creating a comprehension quiz grounded in a YouTube video. ${languageDirective(language)}
Return strictly valid JSON:
{
  "questions": [
    {
      "question": "clear question text",
      "options": ["Option A", "Option B", "Option C", "Option D"],
      "correctIndex": 0,
      "explanation": "clear explanation of why the correct option is right",
      "topicTag": "subtopic name"
    }
  ]
}
Provide exactly $questionCount multiple-choice questions with 4 options each. correctIndex must be 0..3.
        """.trimIndent()

        return when (val res = aiClient.generateWithSystemPrompt(systemPrompt, grounding, expectJson = true)) {
            is AiResult.Success -> {
                val parsed = parseQuizQuestionsJson(res.data)
                if (parsed.isEmpty()) {
                    AiResult.Error("AI returned an invalid quiz format. Please tap Generate Quiz again.")
                } else {
                    AiResult.Success(parsed)
                }
            }
            is AiResult.Error -> res
        }
    }

    companion object {
        fun languageDirective(language: SummaryLanguage): String = when (language) {
            SummaryLanguage.HINDI -> "Respond in natural Hindi (Devanagari script) with clear technical terms where helpful."
            SummaryLanguage.HINGLISH -> "Respond in clear conversational Hinglish (natural mix of Roman Hindi and English)."
            SummaryLanguage.ENGLISH -> "Respond in clear, structured English."
        }

        fun formatChaptersLine(video: YouTubeVideoInfo): String {
            return if (video.chapters.isEmpty()) "(none)"
            else video.chapters.joinToString("; ") { "[${it.timestampLabel}] ${it.title}" }
        }

        fun buildVideoGroundingBlock(
            video: YouTubeVideoInfo,
            transcript: TranscriptResult,
            screenContextText: String = "",
            maxTranscriptChars: Int = 9000
        ): String {
            val transcriptBlock = when {
                transcript.status == TranscriptStatus.AVAILABLE && transcript.rawTextWithTimestamps.isNotBlank() ->
                    transcript.rawTextWithTimestamps.take(maxTranscriptChars)
                else -> "(Transcript status: ${transcript.status.badgeLabel} — ${transcript.statusReason})"
            }
            return buildString {
                appendLine("Video ID: ${video.videoId}")
                appendLine("Title: ${video.title}")
                appendLine("Channel: ${video.channelTitle}")
                if (video.durationFormatted.isNotBlank()) appendLine("Duration: ${video.durationFormatted}")
                if (video.chapters.isNotEmpty()) appendLine("Chapters: ${formatChaptersLine(video)}")
                if (video.description.isNotBlank()) {
                    appendLine("Description:")
                    appendLine(video.description.take(1500))
                }
                appendLine("Transcript (${transcript.languageCode.ifBlank { "n/a" }}):")
                appendLine(transcriptBlock)
                if (screenContextText.isNotBlank()) {
                    appendLine("User-Consented Visible Screen Text:")
                    appendLine(screenContextText.take(2500))
                }
            }
        }

        fun parseNotesJson(rawText: String, video: YouTubeVideoInfo): GeneratedNotesBundle {
            val cleaned = unwrapJson(rawText)
            return try {
                val obj = Gson().fromJson(cleaned, JsonObject::class.java)
                val topic = obj.get("topic").asSafeStr().ifBlank { video.title }
                val defs = obj.get("definitions").asSafeStr()
                val bullets = obj.get("bulletPoints").asSafeStr()
                val steps = obj.get("stepByStep").asSafeStr()
                val timestamps = obj.get("importantTimestamps").asSafeStr()
                val markdown = obj.get("fullMarkdown").asSafeStr().ifBlank {
                    buildString {
                        appendLine("# $topic")
                        appendLine("Video: ${video.title} (${video.channelTitle})")
                        if (defs.isNotBlank()) appendLine("\n## Definitions\n$defs")
                        if (bullets.isNotBlank()) appendLine("\n## Key Points\n$bullets")
                        if (steps.isNotBlank()) appendLine("\n## Step-by-Step\n$steps")
                        if (timestamps.isNotBlank()) appendLine("\n## Important Timestamps\n$timestamps")
                    }.trim()
                }
                GeneratedNotesBundle(
                    topic = topic,
                    definitions = defs,
                    bulletPoints = bullets,
                    stepByStep = steps,
                    importantTimestamps = timestamps,
                    fullMarkdown = markdown
                )
            } catch (_: Exception) {
                GeneratedNotesBundle(
                    topic = video.title,
                    definitions = "",
                    bulletPoints = "",
                    stepByStep = "",
                    importantTimestamps = formatChaptersLine(video),
                    fullMarkdown = rawText.trim()
                )
            }
        }

        fun parseQuizQuestionsJson(rawText: String): List<QuizQuestion> {
            val cleaned = unwrapJson(rawText)
            return try {
                val root = Gson().fromJson(cleaned, JsonObject::class.java) ?: return emptyList()
                val arr: JsonArray = root.getAsJsonArray("questions") ?: return emptyList()
                arr.mapIndexedNotNull { idx, el ->
                    val qObj = el?.takeIf { it.isJsonObject }?.asJsonObject ?: return@mapIndexedNotNull null
                    val qText = qObj.get("question").asSafeStr()
                    val optsArr = qObj.getAsJsonArray("options") ?: return@mapIndexedNotNull null
                    val options = optsArr.mapNotNull { it.asSafeStr().takeIf { s -> s.isNotBlank() } }
                    if (qText.isBlank() || options.size < 2) return@mapIndexedNotNull null
                    val rawIdx = qObj.get("correctIndex").asSafeInt(0)
                    val safeIdx = rawIdx.coerceIn(0, options.size - 1)
                    val explanation = qObj.get("explanation").asSafeStr()
                        .ifBlank { "Correct answer: ${options[safeIdx]}" }
                    val tag = qObj.get("topicTag").asSafeStr()
                    QuizQuestion(
                        index = idx + 1,
                        question = qText,
                        options = options,
                        correctIndex = safeIdx,
                        explanation = explanation,
                        topicTag = tag
                    )
                }
            } catch (_: Exception) {
                emptyList()
            }
        }

        fun evaluateQuiz(questions: List<QuizQuestion>, selectedAnswers: Map<Int, Int>): QuizEvaluation {
            if (questions.isEmpty()) {
                return QuizEvaluation(0, 0, 0, "No quiz questions to evaluate.", emptyList())
            }
            var correct = 0
            val feedbackList = questions.map { q ->
                val chosen = selectedAnswers[q.index] ?: -1
                val isCorrect = chosen == q.correctIndex
                if (isCorrect) correct++
                val correctLabel = q.options.getOrElse(q.correctIndex) { "" }
                val explanationText = if (isCorrect) {
                    "Correct! ${q.explanation}"
                } else {
                    val chosenLabel = if (chosen in q.options.indices) q.options[chosen] else "Not answered"
                    "Incorrect (you selected: $chosenLabel). Correct answer: $correctLabel. ${q.explanation}"
                }
                QuizQuestionFeedback(
                    index = q.index,
                    selectedIndex = chosen,
                    correctIndex = q.correctIndex,
                    isCorrect = isCorrect,
                    explanation = explanationText
                )
            }
            val pct = ((correct.toDouble() / questions.size) * 100.0).toInt()
            val summary = "Score: $correct / ${questions.size} ($pct%). " + when {
                pct >= 80 -> "Excellent mastery of this video topic!"
                pct >= 50 -> "Good progress! Review the incorrect answers below."
                else -> "Keep practicing — revisit the topic notes and explanations below."
            }
            return QuizEvaluation(
                totalQuestions = questions.size,
                correctCount = correct,
                scorePercent = pct,
                summaryMessage = summary,
                feedback = feedbackList
            )
        }

        private fun unwrapJson(raw: String): String {
            val trimmed = raw.trim()
            val fenceRegex = Regex("^```(?:json)?\\s*([\\s\\S]*?)```$", RegexOption.IGNORE_CASE)
            fenceRegex.find(trimmed)?.let { return it.groupValues[1].trim() }
            val start = trimmed.indexOf('{')
            val end = trimmed.lastIndexOf('}')
            return if (start >= 0 && end > start) trimmed.substring(start, end + 1) else trimmed
        }

        private fun JsonElement?.asSafeStr(): String =
            if (this != null && !isJsonNull && isJsonPrimitive) asString.trim() else ""

        private fun JsonElement?.asSafeInt(defaultVal: Int): Int =
            if (this != null && !isJsonNull && isJsonPrimitive) {
                try { asInt } catch (_: Exception) { defaultVal }
            } else defaultVal
    }
}
