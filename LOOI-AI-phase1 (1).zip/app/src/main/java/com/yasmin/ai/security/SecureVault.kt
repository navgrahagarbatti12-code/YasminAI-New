package com.yasmin.ai.security

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Hardware-backed Android Keystore AES-256-GCM encrypted vault for sensitive
 * preferences such as backend proxy authentication tokens or custom endpoints.
 * Includes automatic corrupted-key recovery and key rotation without logging secrets.
 */
class SecureVault(context: Context) {

    private val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    private fun getOrCreateSecretKey(): SecretKey {
        val keyStore = KeyStore.getInstance(ANDROID_KEYSTORE).apply { load(null) }
        val existing = keyStore.getKey(KEY_ALIAS, null) as? SecretKey
        if (existing != null) return existing

        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, ANDROID_KEYSTORE)
        val spec = KeyGenParameterSpec.Builder(
            KEY_ALIAS,
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
        )
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256)
            .build()
        generator.init(spec)
        return generator.generateKey()
    }

    private fun recreateSecretKey(): SecretKey {
        val keyStore = KeyStore.getInstance(ANDROID_KEYSTORE).apply { load(null) }
        if (keyStore.containsAlias(KEY_ALIAS)) {
            keyStore.deleteEntry(KEY_ALIAS)
        }
        return getOrCreateSecretKey()
    }

    fun putSecret(key: String, value: String) {
        if (value.isBlank()) {
            removeSecret(key)
            return
        }
        try {
            encryptAndSave(key, value, getOrCreateSecretKey())
        } catch (_: Exception) {
            // Recover cleanly if Android Keystore key was invalidated after lock-screen reset
            val freshKey = recreateSecretKey()
            encryptAndSave(key, value, freshKey)
        }
    }

    private fun encryptAndSave(key: String, value: String, secretKey: SecretKey) {
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.ENCRYPT_MODE, secretKey)
        val iv = cipher.iv
        val ciphertext = cipher.doFinal(value.toByteArray(Charsets.UTF_8))
        val combined = ByteArray(1 + iv.size + ciphertext.size)
        combined[0] = iv.size.toByte()
        System.arraycopy(iv, 0, combined, 1, iv.size)
        System.arraycopy(ciphertext, 0, combined, 1 + iv.size, ciphertext.size)
        val encoded = Base64.encodeToString(combined, Base64.NO_WRAP)
        prefs.edit().putString(key, encoded).apply()
    }

    fun getSecret(key: String): String {
        val encoded = prefs.getString(key, null) ?: return ""
        return try {
            val combined = Base64.decode(encoded, Base64.NO_WRAP)
            if (combined.size < 2) return ""
            val ivLength = combined[0].toInt() and 0xFF
            if (ivLength !in 12..16 || combined.size <= 1 + ivLength) return ""
            val iv = combined.copyOfRange(1, 1 + ivLength)
            val ciphertext = combined.copyOfRange(1 + ivLength, combined.size)
            val cipher = Cipher.getInstance(TRANSFORMATION)
            cipher.init(Cipher.DECRYPT_MODE, getOrCreateSecretKey(), GCMParameterSpec(128, iv))
            String(cipher.doFinal(ciphertext), Charsets.UTF_8)
        } catch (_: Exception) {
            ""
        }
    }

    fun rotateSecretKey() {
        val preserved = listOf(KEY_PROXY_AUTH_TOKEN, KEY_CUSTOM_PROVIDER_KEY)
            .associateWith { getSecret(it) }
            .filterValues { it.isNotBlank() }
        val freshKey = recreateSecretKey()
        preserved.forEach { (k, v) -> encryptAndSave(k, v, freshKey) }
    }

    fun removeSecret(key: String) {
        prefs.edit().remove(key).apply()
    }

    fun clearAll() {
        prefs.edit().clear().apply()
    }

    companion object {
        private const val ANDROID_KEYSTORE = "AndroidKeyStore"
        private const val KEY_ALIAS = "yasmin_vault_aes256"
        private const val PREFS_NAME = "yasmin_secure_vault"
        private const val TRANSFORMATION = "AES/GCM/NoPadding"

        const val KEY_PROXY_AUTH_TOKEN = "proxy_auth_token"
        const val KEY_CUSTOM_PROVIDER_KEY = "custom_provider_key"
    }
}
