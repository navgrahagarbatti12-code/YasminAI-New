package com.yasmin.ai.ui.settings

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.SeekBar
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.fragment.app.viewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.navigation.fragment.findNavController
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.yasmin.ai.BuildConfig
import com.yasmin.ai.MainActivity
import com.yasmin.ai.R
import com.yasmin.ai.ai.AiModelOption
import com.yasmin.ai.ai.GeminiBackendClient
import com.yasmin.ai.coding.ExternalEditorHelper
import com.yasmin.ai.coding.InstalledEditorApp
import com.yasmin.ai.databinding.FragmentSettingsBinding
import com.yasmin.ai.ui.home.YasminSharedViewModel
import com.yasmin.ai.voice.OfflineWakeWordDetector
import com.yasmin.ai.voice.TtsVoiceOption
import com.yasmin.ai.voice.WakeWordEngine
import com.yasmin.ai.voice.WakeWordForegroundService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class SettingsFragment : Fragment() {

    private var _binding: FragmentSettingsBinding? = null
    private val binding get() = _binding!!
    private val viewModel: SettingsViewModel by viewModels()
    private val sharedViewModel: YasminSharedViewModel by activityViewModels()

    private val languageCodes = listOf("hinglish", "en", "hi")
    private val languageLabels = listOf(
        "Hinglish (English + Hindi)",
        "English (US / Global)",
        "Hindi (हिन्दी)"
    )

    private val providerCodes = listOf(
        GeminiBackendClient.PROVIDER_GROQ,
        GeminiBackendClient.PROVIDER_GEMINI_DIRECT,
        GeminiBackendClient.PROVIDER_GEMINI_PROXY
    )
    private val providerLabels = listOf(
        "Groq Cloud (Direct API) — default",
        "Google Gemini (Direct API)",
        "Gemini Backend Proxy"
    )

    private val personalityCodes = listOf("jarvis_formal", "concise_tactical", "friendly_companion", "coding_mentor")
    private val personalityLabels = listOf(
        "JARVIS Formal & Diplomatic",
        "Concise Tactical Co-Pilot",
        "Friendly & Conversational",
        "Senior Engineering Mentor"
    )

    private val codingLanguages = listOf(
        "Kotlin", "Python", "HTML/CSS/JS", "Java", "JavaScript", "PHP", "C++", "C", "JSON/XML", "Multi-Language"
    )

    private var voiceOptions: List<TtsVoiceOption> = listOf(TtsVoiceOption("", "Yasmin Natural Female (Auto)"))
    private var geminiModelList: List<AiModelOption> = emptyList()
    private var groqModelList: List<AiModelOption> = emptyList()
    private var editorOptions: List<InstalledEditorApp> = emptyList()
    private lateinit var wakeDetector: OfflineWakeWordDetector

    private val pickStorageFolderLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocumentTree()
    ) { treeUri ->
        if (treeUri == null) return@registerForActivityResult
        try {
            requireContext().contentResolver.takePersistableUriPermission(
                treeUri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
        } catch (_: Exception) {
        }
        viewModel.setStorageTreeUri(treeUri.toString())
        Toast.makeText(requireContext(), "Default project folder saved.", Toast.LENGTH_SHORT).show()
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentSettingsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        wakeDetector = OfflineWakeWordDetector(WakeWordEngine.templateFile(requireContext()))
        refreshWakeEnrollStatus()

        binding.tvAboutYasmin.text =
            "Yasmin AI v${BuildConfig.VERSION_NAME} · JARVIS-style Female Android Assistant & Multi-Language Coding Studio.\n" +
                "API keys are encrypted on-device in Android Keystore AES-256-GCM and never stored in source code."

        setupSpinners()
        setupListeners()
        observeSettings()
    }

    private fun setupSpinners() {
        binding.spinnerLanguage.adapter = ArrayAdapter(
            requireContext(),
            android.R.layout.simple_spinner_dropdown_item,
            languageLabels
        )
        binding.spinnerLanguage.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, v: View?, position: Int, id: Long) {
                val code = languageCodes.getOrElse(position) { "hinglish" }
                if (viewModel.preferences.value.languageMode != code) {
                    viewModel.setLanguageMode(code)
                }
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        binding.spinnerAiProvider.adapter = ArrayAdapter(
            requireContext(),
            android.R.layout.simple_spinner_dropdown_item,
            providerLabels
        )
        binding.spinnerAiProvider.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, v: View?, position: Int, id: Long) {
                val code = providerCodes.getOrElse(position) { GeminiBackendClient.PROVIDER_GEMINI_DIRECT }
                if (viewModel.preferences.value.providerType != code) {
                    viewModel.setPrimaryProvider(code)
                    sharedViewModel.refreshConnectionHealth()
                }
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        binding.spinnerPersonality.adapter = ArrayAdapter(
            requireContext(),
            android.R.layout.simple_spinner_dropdown_item,
            personalityLabels
        )
        binding.spinnerPersonality.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, v: View?, position: Int, id: Long) {
                val preset = personalityCodes.getOrElse(position) { "jarvis_formal" }
                if (viewModel.preferences.value.aiPersonality != preset) {
                    viewModel.setAiPersonality(preset)
                }
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        binding.spinnerGeminiModel.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, v: View?, position: Int, id: Long) {
                val chosen = geminiModelList.getOrNull(position)?.id ?: return
                if (viewModel.preferences.value.geminiModel != chosen) {
                    viewModel.setGeminiModel(chosen)
                }
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        binding.spinnerGroqModel.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, v: View?, position: Int, id: Long) {
                val chosen = groqModelList.getOrNull(position)?.id ?: return
                if (viewModel.preferences.value.groqModel != chosen) {
                    viewModel.setGroqModel(chosen)
                }
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        binding.spinnerTtsVoice.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, v: View?, position: Int, id: Long) {
                val chosen = voiceOptions.getOrNull(position)?.name.orEmpty()
                if (viewModel.preferences.value.ttsVoiceName != chosen) {
                    viewModel.setTtsVoiceName(chosen)
                }
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        binding.spinnerCodingDefaultLang.adapter = ArrayAdapter(
            requireContext(),
            android.R.layout.simple_spinner_dropdown_item,
            codingLanguages
        )
        binding.spinnerCodingDefaultLang.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, v: View?, position: Int, id: Long) {
                val lang = codingLanguages.getOrElse(position) { "Kotlin" }
                val prefs = viewModel.preferences.value
                if (prefs.codingDefaultLanguage != lang) {
                    viewModel.setCodingSettings(lang, prefs.codingAutoGenerateDocs, prefs.codingUseBackgroundWorker)
                }
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        val installed = ExternalEditorHelper.findCompatibleEditors(requireContext())
        editorOptions = listOf(InstalledEditorApp("", "Android Chooser (Ask Every Time)")) + installed
        binding.spinnerExternalEditor.adapter = ArrayAdapter(
            requireContext(),
            android.R.layout.simple_spinner_dropdown_item,
            editorOptions.map { if (it.packageName.isEmpty()) it.label else "${it.label} (${it.packageName})" }
        )
        binding.spinnerExternalEditor.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, v: View?, position: Int, id: Long) {
                val pkg = editorOptions.getOrNull(position)?.packageName.orEmpty()
                if (viewModel.preferences.value.externalEditorPackage != pkg) {
                    viewModel.setExternalEditorPackage(pkg)
                }
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
    }

    private fun setupListeners() {
        binding.btnTestGemini.setOnClickListener {
            val raw = binding.etGeminiApiKey.text?.toString().orEmpty()
            viewModel.testGeminiConnection(raw)
            if (raw.isNotBlank()) binding.etGeminiApiKey.text?.clear()
            sharedViewModel.refreshConnectionHealth()
        }

        binding.btnClearGeminiKey.setOnClickListener {
            binding.etGeminiApiKey.text?.clear()
            viewModel.clearGeminiKey()
            sharedViewModel.refreshConnectionHealth()
        }

        binding.btnTestGroq.setOnClickListener {
            val raw = binding.etGroqApiKey.text?.toString().orEmpty()
            viewModel.testGroqConnection(raw)
            if (raw.isNotBlank()) binding.etGroqApiKey.text?.clear()
            sharedViewModel.refreshConnectionHealth()
        }

        binding.btnClearGroqKey.setOnClickListener {
            binding.etGroqApiKey.text?.clear()
            viewModel.clearGroqKey()
            sharedViewModel.refreshConnectionHealth()
        }

        binding.btnSaveYouTubeKey.setOnClickListener {
            val raw = binding.etYouTubeApiKey.text?.toString().orEmpty()
            viewModel.saveYouTubeApiKey(raw)
            if (raw.isNotBlank()) binding.etYouTubeApiKey.text?.clear()
        }

        binding.btnClearYouTubeKey.setOnClickListener {
            binding.etYouTubeApiKey.text?.clear()
            viewModel.clearYouTubeApiKey()
        }

        binding.btnFetchGeminiModels.setOnClickListener {
            viewModel.fetchGeminiModels(binding.etGeminiApiKey.text?.toString())
        }

        binding.btnFetchGroqModels.setOnClickListener {
            viewModel.fetchGroqModels(binding.etGroqApiKey.text?.toString())
        }

        binding.btnSaveProxy.setOnClickListener {
            val geminiInput = binding.etGeminiApiKey.text?.toString().orEmpty()
            val groqInput = binding.etGroqApiKey.text?.toString().orEmpty()
            val proxyTokenInput = binding.etProxyToken.text?.toString().orEmpty()
            val selectedProvider = providerCodes.getOrElse(binding.spinnerAiProvider.selectedItemPosition) {
                GeminiBackendClient.PROVIDER_GEMINI_DIRECT
            }
            val selectedGeminiModel = geminiModelList.getOrNull(binding.spinnerGeminiModel.selectedItemPosition)?.id
                ?: viewModel.preferences.value.geminiModel
            val selectedGroqModel = groqModelList.getOrNull(binding.spinnerGroqModel.selectedItemPosition)?.id
                ?: viewModel.preferences.value.groqModel

            viewModel.saveAndVerifyAllProviders(
                userName = binding.etUserName.text?.toString().orEmpty(),
                providerType = selectedProvider,
                newGeminiKey = geminiInput,
                geminiModel = selectedGeminiModel,
                newGroqKey = groqInput,
                groqModel = selectedGroqModel,
                proxyUrl = binding.etProxyUrl.text?.toString().orEmpty(),
                newProxyToken = proxyTokenInput,
                autoFallback = binding.switchAutoFallback.isChecked
            )
            if (geminiInput.isNotBlank()) binding.etGeminiApiKey.text?.clear()
            if (groqInput.isNotBlank()) binding.etGroqApiKey.text?.clear()
            if (proxyTokenInput.isNotBlank()) binding.etProxyToken.text?.clear()
            sharedViewModel.refreshConnectionHealth()
        }

        binding.switchAutoFallback.setOnCheckedChangeListener { buttonView, isChecked ->
            if (buttonView.isPressed) viewModel.setAutoFallback(isChecked)
        }

        binding.switchAutoSpeak.setOnCheckedChangeListener { buttonView, isChecked ->
            if (buttonView.isPressed) viewModel.setAutoSpeak(isChecked)
        }

        binding.switchContinuousMode.setOnCheckedChangeListener { buttonView, isChecked ->
            if (buttonView.isPressed) viewModel.setContinuousMode(isChecked)
        }

        binding.switchBargeIn.setOnCheckedChangeListener { buttonView, isChecked ->
            if (buttonView.isPressed) viewModel.setBargeInEnabled(isChecked)
        }

        binding.switchScreenConsent.setOnCheckedChangeListener { buttonView, isChecked ->
            if (buttonView.isPressed) viewModel.setScreenConsent(isChecked)
        }

        binding.switchCodingBackground.setOnCheckedChangeListener { buttonView, isChecked ->
            if (buttonView.isPressed) {
                val p = viewModel.preferences.value
                viewModel.setCodingSettings(p.codingDefaultLanguage, p.codingAutoGenerateDocs, isChecked)
            }
        }

        binding.switchCodingAutoDocs.setOnCheckedChangeListener { buttonView, isChecked ->
            if (buttonView.isPressed) {
                val p = viewModel.preferences.value
                viewModel.setCodingSettings(p.codingDefaultLanguage, isChecked, p.codingUseBackgroundWorker)
            }
        }

        binding.seekSpeechRate.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) viewModel.setSpeechRate(0.5f + (progress * 0.1f))
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        binding.seekSpeechPitch.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) viewModel.setSpeechPitch(0.6f + (progress * 0.1f))
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        binding.seekWakeSensitivity.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) viewModel.setWakeSensitivity((progress + 10).coerceIn(10, 100))
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        binding.btnEnrollWakeWord.setOnClickListener {
            val hasMic = ContextCompat.checkSelfPermission(
                requireContext(),
                Manifest.permission.RECORD_AUDIO
            ) == PackageManager.PERMISSION_GRANTED
            if (!hasMic) {
                (activity as? MainActivity)?.requestAudioPermission()
                return@setOnClickListener
            }
            recordAndEnrollWakeSample()
        }

        binding.btnClearWakeTemplates.setOnClickListener {
            wakeDetector.clearTemplates()
            refreshWakeEnrollStatus()
            Toast.makeText(requireContext(), "Cleared enrolled MFCC wake templates.", Toast.LENGTH_SHORT).show()
        }

        binding.btnOpenCodingAgent.setOnClickListener {
            findNavController().navigate(R.id.codingAgentFragment)
        }

        binding.btnPickStorageFolder.setOnClickListener {
            pickStorageFolderLauncher.launch(null)
        }

        binding.btnClearStorageFolder.setOnClickListener {
            viewModel.setStorageTreeUri("")
            Toast.makeText(requireContext(), "Reset to internal app storage.", Toast.LENGTH_SHORT).show()
        }

        binding.btnManagePermissions.setOnClickListener {
            findNavController().navigate(R.id.permissionsFragment)
        }

        binding.btnOpenMemoryDashboard.setOnClickListener {
            findNavController().navigate(R.id.assistantHubFragment)
        }

        binding.btnClearHistory.setOnClickListener {
            MaterialAlertDialogBuilder(requireContext())
                .setTitle("Clear Conversation & Voice History?")
                .setMessage("All locally stored chat messages and voice command logs will be deleted.")
                .setPositiveButton("Delete") { _, _ -> viewModel.clearHistory() }
                .setNegativeButton("Cancel", null)
                .show()
        }

        binding.btnResetPreferences.setOnClickListener {
            MaterialAlertDialogBuilder(requireContext())
                .setTitle("Delete Preferences & Encrypted Vault?")
                .setMessage("Resets name, language, Gemini/Groq API keys, models, voice settings, coding settings, and SecureVault tokens.")
                .setPositiveButton("Reset") { _, _ ->
                    viewModel.resetPreferences()
                    sharedViewModel.refreshConnectionHealth()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
    }

    @SuppressLint("MissingPermission")
    private fun recordAndEnrollWakeSample() {
        val appCtx = requireContext().applicationContext
        val wakeWasActive = WakeWordForegroundService.isRunning.value
        if (wakeWasActive) {
            WakeWordForegroundService.pauseEngine(appCtx)
        }
        binding.btnEnrollWakeWord.isEnabled = false
        binding.tvWakeEnrollStatus.text = "Recording 1.6s… Say \"Hey Yasmin\" clearly now!"

        viewLifecycleOwner.lifecycleScope.launch {
            val enrolled = try {
                withContext(Dispatchers.IO) {
                    val sampleRate = 16000
                    val totalSamples = (sampleRate * 1.6).toInt()
                    val pcm = ShortArray(totalSamples)
                    val minBuf = AudioRecord.getMinBufferSize(
                        sampleRate,
                        AudioFormat.CHANNEL_IN_MONO,
                        AudioFormat.ENCODING_PCM_16BIT
                    ).coerceAtLeast(3200)

                    val rec = AudioRecord(
                        MediaRecorder.AudioSource.VOICE_RECOGNITION,
                        sampleRate,
                        AudioFormat.CHANNEL_IN_MONO,
                        AudioFormat.ENCODING_PCM_16BIT,
                        minBuf
                    )
                    if (rec.state != AudioRecord.STATE_INITIALIZED) {
                        rec.release()
                        return@withContext false
                    }
                    try {
                        rec.startRecording()
                        var offset = 0
                        while (offset < totalSamples) {
                            val read = rec.read(pcm, offset, totalSamples - offset)
                            if (read <= 0) break
                            offset += read
                        }
                        rec.stop()
                        wakeDetector.enrollSample(pcm, sampleRate)
                    } catch (_: Exception) {
                        false
                    } finally {
                        rec.release()
                    }
                }
            } finally {
                if (wakeWasActive) {
                    WakeWordForegroundService.resumeEngine(appCtx)
                }
            }
            if (_binding == null || !isAdded) return@launch
            binding.btnEnrollWakeWord.isEnabled = true
            refreshWakeEnrollStatus()
            Toast.makeText(
                requireContext(),
                if (enrolled) "Enrolled 'Hey Yasmin' voiceprint!" else "Sample too quiet or short. Please try again.",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    private fun refreshWakeEnrollStatus() {
        val count = wakeDetector.getEnrolledTemplateCount()
        binding.tvWakeEnrollStatus.text = if (count == 0) {
            "Offline Wake Voiceprints: 0 enrolled (Enroll 2–3 samples for personalized MFCC+DTW matching)"
        } else {
            "Offline Wake Voiceprints: $count enrolled · Active MFCC+DTW speaker profile"
        }
    }

    private fun observeSettings() {
        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch {
                    sharedViewModel.voiceManager.availableVoices.collect { list ->
                        if (list.isNotEmpty()) {
                            voiceOptions = list
                            binding.spinnerTtsVoice.adapter = ArrayAdapter(
                                requireContext(),
                                android.R.layout.simple_spinner_dropdown_item,
                                list.map { it.label }
                            )
                            val savedIdx = list.indexOfFirst { it.name == viewModel.preferences.value.ttsVoiceName }
                                .coerceAtLeast(0)
                            binding.spinnerTtsVoice.setSelection(savedIdx)
                        }
                    }
                }
                launch {
                    viewModel.geminiModels.collect { list ->
                        geminiModelList = list
                        binding.spinnerGeminiModel.adapter = ArrayAdapter(
                            requireContext(),
                            android.R.layout.simple_spinner_dropdown_item,
                            list.map { it.id }
                        )
                        val savedIdx = list.indexOfFirst { it.id == viewModel.preferences.value.geminiModel }.coerceAtLeast(0)
                        binding.spinnerGeminiModel.setSelection(savedIdx)
                    }
                }
                launch {
                    viewModel.groqModels.collect { list ->
                        groqModelList = list
                        binding.spinnerGroqModel.adapter = ArrayAdapter(
                            requireContext(),
                            android.R.layout.simple_spinner_dropdown_item,
                            list.map { it.id }
                        )
                        val savedIdx = list.indexOfFirst { it.id == viewModel.preferences.value.groqModel }.coerceAtLeast(0)
                        binding.spinnerGroqModel.setSelection(savedIdx)
                    }
                }
                launch {
                    viewModel.geminiConnection.collect { status ->
                        binding.tvGeminiStatus.text = status.statusText
                        val colorRes = if (status.connected) R.color.jarvis_success else R.color.jarvis_warning
                        binding.tvGeminiStatus.setTextColor(ContextCompat.getColor(requireContext(), colorRes))
                    }
                }
                launch {
                    viewModel.groqConnection.collect { status ->
                        binding.tvGroqStatus.text = status.statusText
                        val colorRes = if (status.connected) R.color.jarvis_success else R.color.jarvis_warning
                        binding.tvGroqStatus.setTextColor(ContextCompat.getColor(requireContext(), colorRes))
                    }
                }
                launch {
                    viewModel.geminiKeyMasked.collect { masked ->
                        binding.tvGeminiKeyMasked.text = if (masked.isNotBlank()) {
                            "Encrypted Key Saved ($masked) · Enter new key to replace"
                        } else {
                            "Encrypted in Android Keystore AES-256-GCM"
                        }
                    }
                }
                launch {
                    viewModel.groqKeyMasked.collect { masked ->
                        binding.tvGroqKeyMasked.text = if (masked.isNotBlank()) {
                            "Encrypted Key Saved ($masked) · Enter new key to replace"
                        } else {
                            "Encrypted in Android Keystore AES-256-GCM"
                        }
                    }
                }
                launch {
                    viewModel.youTubeKeyMasked.collect { masked ->
                        binding.tvYouTubeKeyMasked.text = if (masked.isNotBlank()) {
                            "Encrypted YouTube Key Saved ($masked) · Unlocks Data API v3 Search & Playlists"
                        } else {
                            "Encrypted in Android Keystore · oEmbed & public captions work without a key"
                        }
                    }
                }
                launch {
                    viewModel.preferences.collect { prefs ->
                        if (binding.etUserName.text?.toString() != prefs.userName && !binding.etUserName.hasFocus()) {
                            binding.etUserName.setText(prefs.userName)
                        }
                        if (binding.etProxyUrl.text?.toString() != prefs.backendProxyUrl && !binding.etProxyUrl.hasFocus()) {
                            binding.etProxyUrl.setText(prefs.backendProxyUrl)
                        }
                        val provIdx = providerCodes.indexOf(prefs.providerType).coerceAtLeast(0)
                        if (binding.spinnerAiProvider.selectedItemPosition != provIdx) {
                            binding.spinnerAiProvider.setSelection(provIdx)
                        }
                        val persIdx = personalityCodes.indexOf(prefs.aiPersonality).coerceAtLeast(0)
                        if (binding.spinnerPersonality.selectedItemPosition != persIdx) {
                            binding.spinnerPersonality.setSelection(persIdx)
                        }
                        if (binding.switchAutoFallback.isChecked != prefs.autoFallbackEnabled) {
                            binding.switchAutoFallback.isChecked = prefs.autoFallbackEnabled
                        }
                        val idx = languageCodes.indexOf(prefs.languageMode).coerceAtLeast(0)
                        if (binding.spinnerLanguage.selectedItemPosition != idx) {
                            binding.spinnerLanguage.setSelection(idx)
                        }
                        if (binding.switchAutoSpeak.isChecked != prefs.autoSpeakResponses) {
                            binding.switchAutoSpeak.isChecked = prefs.autoSpeakResponses
                        }
                        if (binding.switchContinuousMode.isChecked != prefs.continuousConversation) {
                            binding.switchContinuousMode.isChecked = prefs.continuousConversation
                        }
                        if (binding.switchBargeIn.isChecked != prefs.bargeInEnabled) {
                            binding.switchBargeIn.isChecked = prefs.bargeInEnabled
                        }
                        if (binding.switchScreenConsent.isChecked != prefs.screenReadingConsent) {
                            binding.switchScreenConsent.isChecked = prefs.screenReadingConsent
                        }
                        if (binding.switchCodingBackground.isChecked != prefs.codingUseBackgroundWorker) {
                            binding.switchCodingBackground.isChecked = prefs.codingUseBackgroundWorker
                        }
                        if (binding.switchCodingAutoDocs.isChecked != prefs.codingAutoGenerateDocs) {
                            binding.switchCodingAutoDocs.isChecked = prefs.codingAutoGenerateDocs
                        }
                        val langIdx = codingLanguages.indexOfFirst {
                            it.equals(prefs.codingDefaultLanguage, ignoreCase = true)
                        }.coerceAtLeast(0)
                        if (binding.spinnerCodingDefaultLang.selectedItemPosition != langIdx) {
                            binding.spinnerCodingDefaultLang.setSelection(langIdx)
                        }
                        val edIdx = editorOptions.indexOfFirst { it.packageName == prefs.externalEditorPackage }.coerceAtLeast(0)
                        if (binding.spinnerExternalEditor.selectedItemPosition != edIdx) {
                            binding.spinnerExternalEditor.setSelection(edIdx)
                        }
                        binding.tvStorageFolderPath.text = if (prefs.storageTreeUri.isNotBlank()) {
                            "Default Project Folder: ${prefs.storageTreeUri}"
                        } else {
                            "Default Project Folder: Internal App Storage (No SAF folder chosen)"
                        }

                        val rateProgress = ((prefs.speechRate - 0.5f) / 0.1f).toInt().coerceIn(0, 15)
                        if (binding.seekSpeechRate.progress != rateProgress) {
                            binding.seekSpeechRate.progress = rateProgress
                        }
                        val pitchProgress = ((prefs.speechPitch - 0.6f) / 0.1f).toInt().coerceIn(0, 12)
                        if (binding.seekSpeechPitch.progress != pitchProgress) {
                            binding.seekSpeechPitch.progress = pitchProgress
                        }
                        val wakeProgress = (prefs.wakeSensitivity - 10).coerceIn(0, 90)
                        if (binding.seekWakeSensitivity.progress != wakeProgress) {
                            binding.seekWakeSensitivity.progress = wakeProgress
                        }
                    }
                }
                launch {
                    viewModel.hasSavedToken.collect { hasToken ->
                        binding.etProxyToken.hint = if (hasToken) {
                            "Encrypted proxy token saved (enter to replace)"
                        } else {
                            "Optional Proxy Bearer Token (Encrypted)"
                        }
                    }
                }
                launch {
                    viewModel.toastMessage.collect { msg ->
                        Toast.makeText(requireContext(), msg, Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
