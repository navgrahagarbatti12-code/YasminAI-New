package com.yasmin.ai.ui.settings

import android.Manifest
import android.annotation.SuppressLint
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.SeekBar
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.fragment.app.viewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.navigation.fragment.findNavController
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.yasmin.ai.MainActivity
import com.yasmin.ai.R
import com.yasmin.ai.databinding.FragmentSettingsBinding
import com.yasmin.ai.ui.home.YasminSharedViewModel
import com.yasmin.ai.voice.OfflineWakeWordDetector
import com.yasmin.ai.voice.TtsVoiceOption
import com.yasmin.ai.voice.WakeWordEngine
import com.yasmin.ai.voice.WakeWordForegroundService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class SettingsFragment : Fragment() {

    private var _binding: FragmentSettingsBinding? = null
    private val binding get() = _binding!!
    private val viewModel: SettingsViewModel by viewModels()
    private val sharedViewModel: YasminSharedViewModel by activityViewModels()

    private val languageCodes = listOf("hinglish", "en", "hi")
    private val languageLabels = listOf(
        "Hinglish (English + Hindi)",
        "English (US / Global)",
        "Hindi (हिन्दी)"
    )

    private val providerCodes = listOf("gemini_proxy", "openai_compatible")
    private val providerLabels = listOf(
        "Gemini Backend Proxy (Default)",
        "OpenAI-Compatible Endpoint"
    )

    private val personalityCodes = listOf("jarvis_formal", "concise_tactical", "friendly_companion", "coding_mentor")
    private val personalityLabels = listOf(
        "JARVIS Formal & Diplomatic",
        "Concise Tactical Co-Pilot",
        "Friendly & Conversational",
        "Senior Engineering Mentor"
    )

    private var voiceOptions: List<TtsVoiceOption> = listOf(TtsVoiceOption("", "System Default Voice"))
    private lateinit var wakeDetector: OfflineWakeWordDetector

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentSettingsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        wakeDetector = OfflineWakeWordDetector(WakeWordEngine.templateFile(requireContext()))
        refreshWakeEnrollStatus()

        setupSpinners()
        setupListeners()
        observeSettings()
    }

    private fun setupSpinners() {
        binding.spinnerLanguage.adapter = ArrayAdapter(
            requireContext(),
            android.R.layout.simple_spinner_dropdown_item,
            languageLabels
        )
        binding.spinnerLanguage.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, v: View?, position: Int, id: Long) {
                val code = languageCodes.getOrElse(position) { "hinglish" }
                if (viewModel.preferences.value.languageMode != code) {
                    viewModel.setLanguageMode(code)
                }
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        binding.spinnerAiProvider.adapter = ArrayAdapter(
            requireContext(),
            android.R.layout.simple_spinner_dropdown_item,
            providerLabels
        )

        binding.spinnerPersonality.adapter = ArrayAdapter(
            requireContext(),
            android.R.layout.simple_spinner_dropdown_item,
            personalityLabels
        )
        binding.spinnerPersonality.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, v: View?, position: Int, id: Long) {
                val preset = personalityCodes.getOrElse(position) { "jarvis_formal" }
                if (viewModel.preferences.value.aiPersonality != preset) {
                    viewModel.setAiPersonality(preset)
                }
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        binding.spinnerTtsVoice.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, v: View?, position: Int, id: Long) {
                val chosen = voiceOptions.getOrNull(position)?.name.orEmpty()
                if (viewModel.preferences.value.ttsVoiceName != chosen) {
                    viewModel.setTtsVoiceName(chosen)
                }
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
    }

    private fun setupListeners() {
        binding.btnSaveProxy.setOnClickListener {
            val proxyTokenInput = binding.etProxyToken.text?.toString().orEmpty()
            val customKeyInput = binding.etCustomProviderKey.text?.toString().orEmpty()
            val selectedProvider = providerCodes.getOrElse(binding.spinnerAiProvider.selectedItemPosition) { "gemini_proxy" }

            viewModel.saveAndTestProviders(
                userName = binding.etUserName.text?.toString().orEmpty(),
                proxyUrl = binding.etProxyUrl.text?.toString().orEmpty(),
                newProxyToken = proxyTokenInput,
                providerType = selectedProvider,
                customUrl = binding.etCustomProviderUrl.text?.toString().orEmpty(),
                customModel = binding.etCustomProviderModel.text?.toString().orEmpty(),
                newCustomKey = customKeyInput,
                autoFallback = binding.switchAutoFallback.isChecked
            )
            if (proxyTokenInput.isNotBlank()) binding.etProxyToken.text?.clear()
            if (customKeyInput.isNotBlank()) binding.etCustomProviderKey.text?.clear()
            sharedViewModel.refreshConnectionHealth()
        }

        binding.switchAutoSpeak.setOnCheckedChangeListener { buttonView, isChecked ->
            if (buttonView.isPressed) viewModel.setAutoSpeak(isChecked)
        }

        binding.switchContinuousMode.setOnCheckedChangeListener { buttonView, isChecked ->
            if (buttonView.isPressed) viewModel.setContinuousMode(isChecked)
        }

        binding.switchScreenConsent.setOnCheckedChangeListener { buttonView, isChecked ->
            if (buttonView.isPressed) viewModel.setScreenConsent(isChecked)
        }

        binding.seekSpeechRate.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) viewModel.setSpeechRate(0.5f + (progress * 0.1f))
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        binding.seekSpeechPitch.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) viewModel.setSpeechPitch(0.6f + (progress * 0.1f))
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        binding.seekWakeSensitivity.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) viewModel.setWakeSensitivity((progress + 10).coerceIn(10, 100))
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        binding.btnEnrollWakeWord.setOnClickListener {
            val hasMic = ContextCompat.checkSelfPermission(
                requireContext(),
                Manifest.permission.RECORD_AUDIO
            ) == PackageManager.PERMISSION_GRANTED
            if (!hasMic) {
                (activity as? MainActivity)?.requestAudioPermission()
                return@setOnClickListener
            }
            recordAndEnrollWakeSample()
        }

        binding.btnClearWakeTemplates.setOnClickListener {
            wakeDetector.clearTemplates()
            refreshWakeEnrollStatus()
            Toast.makeText(requireContext(), "Cleared enrolled MFCC wake templates.", Toast.LENGTH_SHORT).show()
        }

        binding.btnManagePermissions.setOnClickListener {
            findNavController().navigate(R.id.permissionsFragment)
        }

        binding.btnOpenMemoryDashboard.setOnClickListener {
            findNavController().navigate(R.id.assistantHubFragment)
        }

        binding.btnClearHistory.setOnClickListener {
            MaterialAlertDialogBuilder(requireContext())
                .setTitle("Clear Conversation & Voice History?")
                .setMessage("All locally stored chat messages and voice command logs will be deleted.")
                .setPositiveButton("Delete") { _, _ -> viewModel.clearHistory() }
                .setNegativeButton("Cancel", null)
                .show()
        }

        binding.btnResetPreferences.setOnClickListener {
            MaterialAlertDialogBuilder(requireContext())
                .setTitle("Delete Preferences & Encrypted Vault?")
                .setMessage("Resets name, language, AI provider config, voice settings, wake sensitivity, and SecureVault tokens.")
                .setPositiveButton("Reset") { _, _ -> viewModel.resetPreferences() }
                .setNegativeButton("Cancel", null)
                .show()
        }
    }

    @SuppressLint("MissingPermission")
    private fun recordAndEnrollWakeSample() {
        val appCtx = requireContext().applicationContext
        val wakeWasActive = WakeWordForegroundService.isRunning.value
        if (wakeWasActive) {
            WakeWordForegroundService.pauseEngine(appCtx)
        }
        binding.btnEnrollWakeWord.isEnabled = false
        binding.tvWakeEnrollStatus.text = "Recording 1.6s… Say \"Hey Yasmin\" clearly now!"

        viewLifecycleOwner.lifecycleScope.launch {
            val enrolled = try {
                withContext(Dispatchers.IO) {
                    val sampleRate = 16000
                    val totalSamples = (sampleRate * 1.6).toInt()
                    val pcm = ShortArray(totalSamples)
                    val minBuf = AudioRecord.getMinBufferSize(
                        sampleRate,
                        AudioFormat.CHANNEL_IN_MONO,
                        AudioFormat.ENCODING_PCM_16BIT
                    ).coerceAtLeast(3200)

                    val rec = AudioRecord(
                        MediaRecorder.AudioSource.VOICE_RECOGNITION,
                        sampleRate,
                        AudioFormat.CHANNEL_IN_MONO,
                        AudioFormat.ENCODING_PCM_16BIT,
                        minBuf
                    )
                    if (rec.state != AudioRecord.STATE_INITIALIZED) {
                        rec.release()
                        return@withContext false
                    }
                    try {
                        rec.startRecording()
                        var offset = 0
                        while (offset < totalSamples) {
                            val read = rec.read(pcm, offset, totalSamples - offset)
                            if (read <= 0) break
                            offset += read
                        }
                        rec.stop()
                        wakeDetector.enrollSample(pcm, sampleRate)
                    } catch (_: Exception) {
                        false
                    } finally {
                        rec.release()
                    }
                }
            } finally {
                if (wakeWasActive) {
                    WakeWordForegroundService.resumeEngine(appCtx)
                }
            }
            binding.btnEnrollWakeWord.isEnabled = true
            refreshWakeEnrollStatus()
            Toast.makeText(
                requireContext(),
                if (enrolled) "Enrolled 'Hey Yasmin' voiceprint! (Enroll 2–3 samples for best accuracy)" else "Sample too quiet or short. Please try again.",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    private fun refreshWakeEnrollStatus() {
        val count = wakeDetector.getEnrolledTemplateCount()
        binding.tvWakeEnrollStatus.text = if (count == 0) {
            "Offline Wake Voiceprints: 0 enrolled (Enroll 2–3 samples for personalized MFCC+DTW matching)"
        } else {
            "Offline Wake Voiceprints: $count enrolled · Active MFCC+DTW speaker profile"
        }
    }

    private fun observeSettings() {
        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch {
                    sharedViewModel.voiceManager.availableVoices.collect { list ->
                        if (list.isNotEmpty()) {
                            voiceOptions = list
                            binding.spinnerTtsVoice.adapter = ArrayAdapter(
                                requireContext(),
                                android.R.layout.simple_spinner_dropdown_item,
                                list.map { it.label }
                            )
                            val savedIdx = list.indexOfFirst { it.name == viewModel.preferences.value.ttsVoiceName }
                                .coerceAtLeast(0)
                            binding.spinnerTtsVoice.setSelection(savedIdx)
                        }
                    }
                }
                launch {
                    viewModel.preferences.collect { prefs ->
                        if (binding.etUserName.text?.toString() != prefs.userName && !binding.etUserName.hasFocus()) {
                            binding.etUserName.setText(prefs.userName)
                        }
                        if (binding.etProxyUrl.text?.toString() != prefs.backendProxyUrl && !binding.etProxyUrl.hasFocus()) {
                            binding.etProxyUrl.setText(prefs.backendProxyUrl)
                        }
                        if (binding.etCustomProviderUrl.text?.toString() != prefs.customProviderUrl && !binding.etCustomProviderUrl.hasFocus()) {
                            binding.etCustomProviderUrl.setText(prefs.customProviderUrl)
                        }
                        if (binding.etCustomProviderModel.text?.toString() != prefs.customProviderModel && !binding.etCustomProviderModel.hasFocus()) {
                            binding.etCustomProviderModel.setText(prefs.customProviderModel)
                        }
                        val provIdx = providerCodes.indexOf(prefs.providerType).coerceAtLeast(0)
                        if (binding.spinnerAiProvider.selectedItemPosition != provIdx) {
                            binding.spinnerAiProvider.setSelection(provIdx)
                        }
                        val persIdx = personalityCodes.indexOf(prefs.aiPersonality).coerceAtLeast(0)
                        if (binding.spinnerPersonality.selectedItemPosition != persIdx) {
                            binding.spinnerPersonality.setSelection(persIdx)
                        }
                        if (binding.switchAutoFallback.isChecked != prefs.autoFallbackEnabled) {
                            binding.switchAutoFallback.isChecked = prefs.autoFallbackEnabled
                        }
                        val idx = languageCodes.indexOf(prefs.languageMode).coerceAtLeast(0)
                        if (binding.spinnerLanguage.selectedItemPosition != idx) {
                            binding.spinnerLanguage.setSelection(idx)
                        }
                        if (binding.switchAutoSpeak.isChecked != prefs.autoSpeakResponses) {
                            binding.switchAutoSpeak.isChecked = prefs.autoSpeakResponses
                        }
                        if (binding.switchContinuousMode.isChecked != prefs.continuousConversation) {
                            binding.switchContinuousMode.isChecked = prefs.continuousConversation
                        }
                        if (binding.switchScreenConsent.isChecked != prefs.screenReadingConsent) {
                            binding.switchScreenConsent.isChecked = prefs.screenReadingConsent
                        }
                        val rateProgress = ((prefs.speechRate - 0.5f) / 0.1f).toInt().coerceIn(0, 15)
                        if (binding.seekSpeechRate.progress != rateProgress) {
                            binding.seekSpeechRate.progress = rateProgress
                        }
                        val pitchProgress = ((prefs.speechPitch - 0.6f) / 0.1f).toInt().coerceIn(0, 12)
                        if (binding.seekSpeechPitch.progress != pitchProgress) {
                            binding.seekSpeechPitch.progress = pitchProgress
                        }
                        val wakeProgress = (prefs.wakeSensitivity - 10).coerceIn(0, 90)
                        if (binding.seekWakeSensitivity.progress != wakeProgress) {
                            binding.seekWakeSensitivity.progress = wakeProgress
                        }
                    }
                }
                launch {
                    viewModel.hasSavedToken.collect { hasToken ->
                        binding.etProxyToken.hint = if (hasToken) {
                            "Encrypted proxy token saved (enter to replace)"
                        } else {
                            "Optional Proxy Bearer Token (Encrypted)"
                        }
                    }
                }
                launch {
                    viewModel.hasSavedCustomKey.collect { hasKey ->
                        binding.etCustomProviderKey.hint = if (hasKey) {
                            "Encrypted OpenAI key saved (enter to replace)"
                        } else {
                            "OpenAI-Compatible API Key (Encrypted)"
                        }
                    }
                }
                launch {
                    viewModel.toastMessage.collect { msg ->
                        Toast.makeText(requireContext(), msg, Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
