package com.yasmin.ai

import android.Manifest
import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.ui.setupWithNavController
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.yasmin.ai.databinding.ActivityMainBinding
import com.yasmin.ai.screen.MediaProjectionService
import com.yasmin.ai.screen.ScreenCaptureManager
import com.yasmin.ai.ui.home.NavigationEvent
import com.yasmin.ai.ui.home.YasminSharedViewModel
import com.yasmin.ai.voice.WakeWordForegroundService
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val sharedViewModel: YasminSharedViewModel by viewModels()
    private lateinit var screenCaptureManager: ScreenCaptureManager
    private var pendingVisionCallback: ((String) -> Unit)? = null

    private val wakeTriggerReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == WakeWordForegroundService.ACTION_WAKE_TRIGGERED) {
                handleWakeVoiceTrigger()
            }
        }
    }

    private val audioPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            sharedViewModel.startVoiceCapture { }
        } else {
            Toast.makeText(
                this,
                "Microphone permission is required for voice commands.",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }

    private val mediaProjectionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val data = result.data
        if (result.resultCode == Activity.RESULT_OK && data != null) {
            lifecycleScope.launch {
                MediaProjectionService.startForegroundProjection(this@MainActivity)
                val ready = MediaProjectionService.awaitForegroundReady(2500L)
                if (!ready) {
                    MediaProjectionService.stopForegroundProjection(this@MainActivity)
                    Toast.makeText(
                        this@MainActivity,
                        "Screen capture foreground service timed out.",
                        Toast.LENGTH_SHORT
                    ).show()
                    pendingVisionCallback = null
                    return@launch
                }

                val base64 = screenCaptureManager.captureSingleScreenshotBase64(result.resultCode, data)
                if (base64 != null) {
                    val customCb = pendingVisionCallback
                    pendingVisionCallback = null
                    if (customCb != null) {
                        customCb(base64)
                    } else {
                        sharedViewModel.analyzeScreenshotBase64(base64)
                    }
                } else {
                    pendingVisionCallback = null
                    Toast.makeText(
                        this@MainActivity,
                        "Screen capture failed or returned no frame.",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        } else {
            pendingVisionCallback = null
            Toast.makeText(this, "Screen capture cancelled by user.", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        screenCaptureManager = ScreenCaptureManager(this)

        val navHostFragment = supportFragmentManager
            .findFragmentById(R.id.navHostFragment) as NavHostFragment
        val navController = navHostFragment.navController
        binding.bottomNav.setupWithNavController(navController)

        binding.btnTopVision.setOnClickListener {
            navController.navigate(R.id.visionFragment)
        }
        binding.btnTopDailyHub.setOnClickListener {
            navController.navigate(R.id.assistantHubFragment)
        }
        binding.btnTopPermissions.setOnClickListener {
            navController.navigate(R.id.permissionsFragment)
        }

        requestNotificationPermissionIfNeeded()
        observeNavigationEvents(navController)
        handleLaunchIntent(intent)
    }

    override fun onStart() {
        super.onStart()
        ContextCompat.registerReceiver(
            this,
            wakeTriggerReceiver,
            IntentFilter(WakeWordForegroundService.ACTION_WAKE_TRIGGERED),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
    }

    override fun onStop() {
        try {
            unregisterReceiver(wakeTriggerReceiver)
        } catch (_: IllegalArgumentException) {
        }
        super.onStop()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleLaunchIntent(intent)
    }

    private fun handleLaunchIntent(intent: Intent?) {
        if (intent?.getBooleanExtra(WakeWordForegroundService.EXTRA_TRIGGER_VOICE, false) == true) {
            handleWakeVoiceTrigger()
        }
    }

    private fun handleWakeVoiceTrigger() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            == PackageManager.PERMISSION_GRANTED
        ) {
            sharedViewModel.startVoiceCapture("wake") { requestAudioPermission() }
        } else {
            requestAudioPermission()
        }
    }

    private fun observeNavigationEvents(navController: androidx.navigation.NavController) {
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                sharedViewModel.navigationEvents.collect { event ->
                    when (event) {
                        is NavigationEvent.OpenPython -> navController.navigate(R.id.pythonFragment)
                        is NavigationEvent.OpenHtml -> navController.navigate(R.id.htmlFragment)
                        is NavigationEvent.OpenVision -> navController.navigate(R.id.visionFragment)
                        is NavigationEvent.OpenDailyHub -> navController.navigate(R.id.assistantHubFragment)
                        is NavigationEvent.OpenPermissions -> navController.navigate(R.id.permissionsFragment)
                        is NavigationEvent.ConfirmAutomation -> {
                            MaterialAlertDialogBuilder(this@MainActivity)
                                .setTitle(event.title)
                                .setMessage(event.description)
                                .setPositiveButton("Allow") { _, _ ->
                                    sharedViewModel.executeConfirmedAction(event.onConfirmed)
                                }
                                .setNegativeButton("Deny", null)
                                .show()
                        }
                    }
                }
            }
        }
    }

    fun requestAudioPermission() {
        audioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
    }

    fun requestScreenCapture(onBase64Captured: ((String) -> Unit)? = null) {
        pendingVisionCallback = onBase64Captured
        mediaProjectionLauncher.launch(screenCaptureManager.createConsentIntent())
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED
            ) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }
}
