package com.yasmin.ai.automation

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import com.yasmin.ai.assistant.CalendarHelper
import com.yasmin.ai.assistant.ReminderScheduler
import com.yasmin.ai.repository.YasminRepository
import java.util.Locale

/**
 * Provides genuine offline-first local intelligence without fabricating cloud LLM replies:
 * - Local arithmetic expression evaluator
 * - Local Room Memory search & note saving
 * - Pending Tasks / Reminders inspection & AlarmManager scheduling
 * - Local Chat History keyword search
 * - Local Calendar events & Device telemetry
 */
class OfflineAssistantEngine(
    private val context: Context,
    private val repository: YasminRepository,
    private val deviceControl: DeviceControlManager,
    private val calendarHelper: CalendarHelper,
    private val reminderScheduler: ReminderScheduler
) {

    fun hasNetworkConnection(): Boolean {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val net = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(net) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    suspend fun handleOfflineQuery(rawInput: String): String {
        val trimmed = rawInput.trim()
        val lower = trimmed.lowercase(Locale.getDefault())

        // 1. Offline Math Expression Solver
        val mathCandidate = extractMathExpression(trimmed)
        if (mathCandidate != null) {
            val result = evaluateArithmetic(mathCandidate)
            if (result != null) {
                val formatted = if (result % 1.0 == 0.0) result.toLong().toString() else String.format(Locale.US, "%.4f", result).trimEnd('0').trimEnd('.')
                return "[Offline Local Calculator]\n$mathCandidate = $formatted"
            }
        }

        // 2. Offline Reminder scheduling
        if (lower.startsWith("remind me")) {
            val delayMs = ReminderScheduler.parseRelativeDelayMs(trimmed)
            if (delayMs != null) {
                val triggerAt = System.currentTimeMillis() + delayMs
                val dueLabel = ReminderScheduler.formatDueLabel(triggerAt)
                val title = trimmed.replace(Regex("(?i)^remind me\\s+(?:in\\s+\\d+\\s+\\w+\\s+(?:to|about)?\\s*)?"), "").ifBlank { "Reminder" }
                val id = repository.addTask(
                    type = "reminder",
                    title = title,
                    dueLabel = dueLabel,
                    reminderEpochMs = triggerAt
                )
                reminderScheduler.scheduleReminder(id, title, dueLabel, triggerAt)
                return "[Offline Reminder Scheduled]\n\"$title\" at $dueLabel."
            }
        }

        // 3. Offline Memory Query / Storage
        if (lower.startsWith("remember that ") || lower.startsWith("remember ")) {
            val fact = trimmed.substringAfter("remember").removePrefix(" that").trim()
            if (fact.isNotBlank()) {
                val saved = repository.savePersonalMemory("fact", fact.take(36), fact, importance = 3, isUserApproved = true)
                return if (saved.isSuccess) {
                    "[Offline Memory Saved]\nStored securely on-device: \"$fact\"."
                } else {
                    "Memory skipped by Privacy Guard (sensitive patterns cannot be stored)."
                }
            }
        }

        if (lower.contains("memory") || lower.contains("memories") || lower.contains("what do you know") || lower.contains("what did i tell")) {
            val query = lower.replace("what do you remember about", "")
                .replace("search memory", "")
                .replace("memories", "")
                .trim()
            val hits = repository.searchMemoriesLocal(query)
            return if (hits.isEmpty()) {
                "[Offline Memory]\nNo stored personal memories matched your query."
            } else {
                "[Offline Memory (${hits.size} matched)]\n" + hits.take(5).joinToString("\n") { "• [${it.category}] ${it.keyTitle}: ${it.content}" }
            }
        }

        // 4. Offline Tasks / Reminders
        if (lower.contains("task") || lower.contains("todo") || lower.contains("reminder") || lower.contains("agenda")) {
            val tasks = repository.getPendingTasksSnapshot(8)
            return if (tasks.isEmpty()) {
                "[Offline Planner]\nYou have no pending tasks or reminders."
            } else {
                "[Offline Pending Tasks]\n" + tasks.joinToString("\n") {
                    val due = if (it.dueLabel.isNotBlank()) " (${it.dueLabel})" else ""
                    "• [${it.type}] ${it.title}$due"
                }
            }
        }

        // 5. Offline Chat Search
        if (lower.startsWith("search chat")) {
            val q = trimmed.substringAfter("chat").removePrefix("for ").trim()
            val hits = repository.searchChatHistoryLocal(q)
            return if (hits.isEmpty()) {
                "[Offline Chat Search]\nNo matching saved conversations found."
            } else {
                "[Offline Chat Search]\n" + hits.take(4).joinToString("\n") { "• ${it.role}: ${it.content.take(90)}" }
            }
        }

        // 6. Calendar
        if (lower.contains("calendar") || lower.contains("meeting") || lower.contains("schedule")) {
            return "[Offline Calendar]\n${calendarHelper.formatUpcomingEventsText()}"
        }

        // 7. Honest Offline Boundary & Available Capabilities
        val relevant = repository.searchMemoriesLocal(trimmed).take(2)
        val memHint = if (relevant.isNotEmpty()) {
            "\n\nRelated saved memory:\n" + relevant.joinToString("\n") { "• ${it.keyTitle}: ${it.content}" }
        } else ""

        return "Offline Mode Active — Cloud AI is currently unreachable.\n" +
            "Local capabilities still working offline:\n" +
            "• Device controls (flashlight, volume, brightness, open apps, read notifications)\n" +
            "• Quick math (e.g. \"calculate (24 * 5) + 18\")\n" +
            "• Reminders & Tasks (\"remind me in 15 minutes to drink water\", \"my tasks\")\n" +
            "• On-device memories & chat search (\"remember that ...\", \"my memories\")\n" +
            "• Offline Calendar & Time/Battery status$memHint"
    }

    private fun extractMathExpression(input: String): String? {
        val cleaned = input.lowercase(Locale.US)
            .removePrefix("calculate ")
            .removePrefix("what is ")
            .removePrefix("compute ")
            .removePrefix("solve ")
            .replace("x", "*")
            .replace("×", "*")
            .replace("÷", "/")
            .trim()
        val match = Regex("[0-9()\\s.+\\-*/%]+").matchEntire(cleaned) ?: return null
        val expr = match.value.trim()
        return if (expr.any { it in "+-*/%" } && expr.any { it.isDigit() }) expr else null
    }

    internal fun evaluateArithmetic(expression: String): Double? {
        return try {
            object : Any() {
                var pos = -1
                var ch = 0
                fun nextChar() {
                    ch = if (++pos < expression.length) expression[pos].code else -1
                }
                fun eat(charToEat: Int): Boolean {
                    while (ch == ' '.code) nextChar()
                    if (ch == charToEat) {
                        nextChar()
                        return true
                    }
                    return false
                }
                fun parse(): Double {
                    nextChar()
                    val x = parseExpression()
                    if (pos < expression.length) throw IllegalArgumentException("Unexpected char")
                    return x
                }
                fun parseExpression(): Double {
                    var x = parseTerm()
                    while (true) {
                        x = when {
                            eat('+'.code) -> x + parseTerm()
                            eat('-'.code) -> x - parseTerm()
                            else -> return x
                        }
                    }
                }
                fun parseTerm(): Double {
                    var x = parseFactor()
                    while (true) {
                        when {
                            eat('*'.code) -> x *= parseFactor()
                            eat('/'.code) -> {
                                val d = parseFactor()
                                if (d == 0.0) throw ArithmeticException("Divide by zero")
                                x /= d
                            }
                            eat('%'.code) -> x %= parseFactor()
                            else -> return x
                        }
                    }
                }
                fun parseFactor(): Double {
                    if (eat('+'.code)) return +parseFactor()
                    if (eat('-'.code)) return -parseFactor()
                    var x: Double
                    val startPos = pos
                    if (eat('('.code)) {
                        x = parseExpression()
                        if (!eat(')'.code)) throw IllegalArgumentException("Missing ')'")
                    } else if ((ch in '0'.code..'9'.code) || ch == '.'.code) {
                        while ((ch in '0'.code..'9'.code) || ch == '.'.code) nextChar()
                        x = expression.substring(startPos, pos).toDouble()
                    } else {
                        throw IllegalArgumentException("Unexpected")
                    }
                    return x
                }
            }.parse()
        } catch (_: Exception) {
            null
        }
    }
}
