package com.yasmin.ai.coding

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

class ProjectFileManager(private val context: Context) {

    private val projectsDir: File
        get() = File(context.filesDir, "projects").apply { if (!exists()) mkdirs() }

    private val exportsDir: File
        get() = File(context.cacheDir, "exports").apply { if (!exists()) mkdirs() }

    fun savePythonFile(fileName: String, content: String): File {
        val safeName = sanitizeFileName(fileName, ".py")
        val target = File(projectsDir, safeName)
        target.writeText(content)
        return target
    }

    fun listPythonFiles(): List<File> {
        return projectsDir.listFiles { file -> file.isFile && file.name.endsWith(".py") }
            ?.sortedByDescending { it.lastModified() }
            ?: emptyList()
    }

    fun saveWebProject(projectName: String, html: String, css: String, js: String): File {
        val safeDirName = projectName.replace("[^a-zA-Z0-9_-]".toRegex(), "_").ifBlank { "web_project" }
        val projectDir = File(projectsDir, safeDirName).apply { if (!exists()) mkdirs() }
        File(projectDir, "index.html").writeText(html)
        File(projectDir, "styles.css").writeText(css)
        File(projectDir, "app.js").writeText(js)
        return projectDir
    }

    fun listWebProjects(): List<File> {
        return projectsDir.listFiles { file -> file.isDirectory && File(file, "index.html").exists() }
            ?.sortedByDescending { it.lastModified() }
            ?: emptyList()
    }

    fun loadWebProject(projectDir: File): Triple<String, String, String> {
        val html = File(projectDir, "index.html").takeIf { it.exists() }?.readText().orEmpty()
        val css = File(projectDir, "styles.css").takeIf { it.exists() }?.readText().orEmpty()
        val js = File(projectDir, "app.js").takeIf { it.exists() }?.readText().orEmpty()
        return Triple(html, css, js)
    }

    fun exportWebProjectZip(projectName: String, html: String, css: String, js: String): File {
        val safe = projectName.replace("[^a-zA-Z0-9_-]".toRegex(), "_").ifBlank { "web_project" }
        val zipFile = File(exportsDir, "${safe}.zip")
        ZipOutputStream(FileOutputStream(zipFile)).use { zos ->
            writeZipEntry(zos, "index.html", html)
            writeZipEntry(zos, "styles.css", css)
            writeZipEntry(zos, "app.js", js)
        }
        return zipFile
    }

    fun importTextFromUri(uri: Uri): String? {
        return try {
            context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
        } catch (_: Exception) {
            null
        }
    }

    fun importWebProjectZip(uri: Uri): Triple<String, String, String>? {
        return try {
            var html = ""
            var css = ""
            var js = ""
            context.contentResolver.openInputStream(uri)?.use { stream ->
                ZipInputStream(stream).use { zis ->
                    var entry = zis.nextEntry
                    val buf = ByteArray(8192)
                    while (entry != null) {
                        val name = entry.name.lowercase()
                        val isTargetExt = name.endsWith(".html") || name.endsWith(".htm") ||
                            name.endsWith(".css") || name.endsWith(".js")
                        if (!entry.isDirectory && !name.contains("..") && isTargetExt) {
                            val out = java.io.ByteArrayOutputStream()
                            var totalRead = 0
                            var count: Int
                            while (zis.read(buf).also { count = it } != -1) {
                                totalRead += count
                                if (totalRead > 2_000_000) break
                                out.write(buf, 0, count)
                            }
                            val body = out.toString("UTF-8")
                            when {
                                name.endsWith(".html") || name.endsWith(".htm") -> html = body
                                name.endsWith(".css") -> css = body
                                name.endsWith(".js") -> js = body
                            }
                        }
                        zis.closeEntry()
                        entry = zis.nextEntry
                    }
                }
            }
            if (html.isBlank() && css.isBlank() && js.isBlank()) null else Triple(html, css, js)
        } catch (_: Exception) {
            null
        }
    }

    private fun writeZipEntry(zos: ZipOutputStream, name: String, content: String) {
        zos.putNextEntry(ZipEntry(name))
        zos.write(content.toByteArray(Charsets.UTF_8))
        zos.closeEntry()
    }

    fun createShareFileIntent(file: File, mimeType: String = "text/plain"): Intent {
        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )
        return Intent(Intent.ACTION_SEND).apply {
            type = mimeType
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
    }

    private fun sanitizeFileName(raw: String, requiredExt: String): String {
        val cleaned = raw.trim().replace("[^a-zA-Z0-9._-]".toRegex(), "_")
            .ifBlank { "script$requiredExt" }
        return if (cleaned.endsWith(requiredExt)) cleaned else "$cleaned$requiredExt"
    }
}
