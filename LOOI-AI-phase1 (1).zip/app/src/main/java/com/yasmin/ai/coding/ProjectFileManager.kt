package com.yasmin.ai.coding

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.content.FileProvider
import androidx.documentfile.provider.DocumentFile
import com.yasmin.ai.ai.GeneratedCodeFile
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

class ProjectFileManager(private val context: Context) {

    private val projectsDir: File
        get() = File(context.filesDir, "projects").apply { if (!exists()) mkdirs() }

    private val exportsDir: File
        get() = File(context.cacheDir, "exports").apply { if (!exists()) mkdirs() }

    fun savePythonFile(fileName: String, content: String): File {
        val safeName = sanitizeFileName(fileName, ".py")
        val target = File(projectsDir, safeName)
        target.writeText(content)
        return target
    }

    fun listPythonFiles(): List<File> {
        return projectsDir.listFiles { file -> file.isFile && file.name.endsWith(".py") }
            ?.sortedByDescending { it.lastModified() }
            ?: emptyList()
    }

    fun saveWebProject(projectName: String, html: String, css: String, js: String): File {
        val safeDirName = sanitizeProjectName(projectName, "web_project")
        val projectDir = File(projectsDir, safeDirName).apply { if (!exists()) mkdirs() }
        File(projectDir, "index.html").writeText(html)
        File(projectDir, "styles.css").writeText(css)
        File(projectDir, "app.js").writeText(js)
        return projectDir
    }

    fun listWebProjects(): List<File> {
        return projectsDir.listFiles { file -> file.isDirectory && File(file, "index.html").exists() }
            ?.sortedByDescending { it.lastModified() }
            ?: emptyList()
    }

    fun loadWebProject(projectDir: File): Triple<String, String, String> {
        val html = File(projectDir, "index.html").takeIf { it.exists() }?.readText().orEmpty()
        val css = File(projectDir, "styles.css").takeIf { it.exists() }?.readText().orEmpty()
        val js = File(projectDir, "app.js").takeIf { it.exists() }?.readText().orEmpty()
        return Triple(html, css, js)
    }

    fun exportWebProjectZip(projectName: String, html: String, css: String, js: String): File {
        val safe = sanitizeProjectName(projectName, "web_project")
        val zipFile = File(exportsDir, "$safe.zip")
        ZipOutputStream(FileOutputStream(zipFile)).use { zos ->
            writeZipEntry(zos, "index.html", html)
            writeZipEntry(zos, "styles.css", css)
            writeZipEntry(zos, "app.js", js)
        }
        return zipFile
    }

    // ---- Multi-Language Multi-File Project Support ----

    fun getProjectDirectory(projectName: String): File {
        val safeName = sanitizeProjectName(projectName, "yasmin_project")
        return File(projectsDir, safeName).apply { if (!exists()) mkdirs() }
    }

    fun saveMultiFileProject(
        projectName: String,
        files: List<GeneratedCodeFile>,
        readmeMarkdown: String = ""
    ): File {
        val projectDir = getProjectDirectory(projectName)
        val rootCanonical = projectDir.canonicalPath
        files.forEach { codeFile ->
            val relPath = sanitizeRelativePath(codeFile.path) ?: return@forEach
            val dest = File(projectDir, relPath)
            if (!dest.canonicalPath.startsWith(rootCanonical)) return@forEach
            dest.parentFile?.mkdirs()
            dest.writeText(codeFile.content)
        }
        val hasReadmeAlready = files.any { it.path.equals("README.md", ignoreCase = true) }
        if (readmeMarkdown.isNotBlank() && !hasReadmeAlready) {
            File(projectDir, "README.md").writeText(readmeMarkdown)
        }
        return projectDir
    }

    fun writeSingleProjectFile(projectName: String, relativePath: String, content: String): File? {
        val projectDir = getProjectDirectory(projectName)
        val rel = sanitizeRelativePath(relativePath) ?: return null
        val dest = File(projectDir, rel)
        if (!dest.canonicalPath.startsWith(projectDir.canonicalPath)) return null
        dest.parentFile?.mkdirs()
        dest.writeText(content)
        return dest
    }

    fun getFileInProject(projectName: String, relativePath: String): File? {
        val projectDir = getProjectDirectory(projectName)
        val rel = sanitizeRelativePath(relativePath) ?: return null
        val target = File(projectDir, rel)
        if (!target.canonicalPath.startsWith(projectDir.canonicalPath)) return null
        return target
    }

    fun listMultiFileProjects(): List<File> {
        return projectsDir.listFiles { file -> file.isDirectory }
            ?.sortedByDescending { it.lastModified() }
            ?: emptyList()
    }

    fun loadMultiFileProject(projectDir: File): List<GeneratedCodeFile> {
        if (!projectDir.exists() || !projectDir.isDirectory) return emptyList()
        val result = mutableListOf<GeneratedCodeFile>()
        val rootPath = projectDir.canonicalPath
        projectDir.walkTopDown()
            .filter { it.isFile && it.length() <= 512_000 }
            .take(150)
            .forEach { file ->
                val rel = file.canonicalPath.removePrefix(rootPath).trimStart(File.separatorChar)
                    .replace(File.separatorChar, '/')
                if (rel.isNotEmpty()) {
                    result.add(
                        GeneratedCodeFile(
                            path = rel,
                            content = file.readText(),
                            language = detectLanguageForPath(rel)
                        )
                    )
                }
            }
        return result.sortedBy { it.path }
    }

    fun exportDirectoryAsZip(projectDir: File): File {
        val safe = sanitizeProjectName(projectDir.name, "yasmin_project")
        val zipFile = File(exportsDir, "$safe.zip")
        val rootPath = projectDir.canonicalPath
        ZipOutputStream(FileOutputStream(zipFile)).use { zos ->
            projectDir.walkTopDown()
                .filter { it.isFile }
                .forEach { file ->
                    val rel = file.canonicalPath.removePrefix(rootPath)
                        .trimStart(File.separatorChar)
                        .replace(File.separatorChar, '/')
                    if (rel.isNotEmpty()) {
                        zos.putNextEntry(ZipEntry(rel))
                        zos.write(file.readBytes())
                        zos.closeEntry()
                    }
                }
        }
        return zipFile
    }

    fun importAnyProjectZip(uri: Uri, targetProjectName: String? = null): Pair<String, List<GeneratedCodeFile>>? {
        return try {
            val loaded = mutableListOf<GeneratedCodeFile>()
            context.contentResolver.openInputStream(uri)?.use { stream ->
                ZipInputStream(stream).use { zis ->
                    var entry = zis.nextEntry
                    val buf = ByteArray(8192)
                    while (entry != null) {
                        val rel = sanitizeRelativePath(entry.name)
                        if (!entry.isDirectory && rel != null) {
                            val out = ByteArrayOutputStream()
                            var totalRead = 0
                            var count: Int
                            while (zis.read(buf).also { count = it } != -1) {
                                totalRead += count
                                if (totalRead > 1_000_000) break
                                out.write(buf, 0, count)
                            }
                            loaded.add(
                                GeneratedCodeFile(
                                    path = rel,
                                    content = out.toString("UTF-8"),
                                    language = detectLanguageForPath(rel)
                                )
                            )
                        }
                        zis.closeEntry()
                        entry = zis.nextEntry
                    }
                }
            }
            if (loaded.isEmpty()) return null
            val projectName = sanitizeProjectName(targetProjectName ?: "imported_project", "imported_project")
            saveMultiFileProject(projectName, loaded)
            Pair(projectName, loaded.sortedBy { it.path })
        } catch (_: Exception) {
            null
        }
    }

    fun syncProjectToSafTree(projectDir: File, treeUri: Uri): Result<Int> {
        return try {
            val rootDoc = DocumentFile.fromTreeUri(context, treeUri)
                ?: return Result.failure(IllegalArgumentException("Invalid folder access URI."))
            if (!rootDoc.canWrite()) {
                return Result.failure(SecurityException("Write permission to selected folder expired. Pick folder again."))
            }
            val projectSubDir = rootDoc.findFile(projectDir.name)?.takeIf { it.isDirectory }
                ?: rootDoc.createDirectory(projectDir.name)
                ?: return Result.failure(IllegalStateException("Could not create folder ${projectDir.name}."))

            var writtenCount = 0
            val files = loadMultiFileProject(projectDir)
            for (file in files) {
                val segments = file.path.split('/').filter { it.isNotBlank() }
                if (segments.isEmpty()) continue
                var currentDir: DocumentFile = projectSubDir
                for (i in 0 until segments.size - 1) {
                    val dirName = segments[i]
                    currentDir = currentDir.findFile(dirName)?.takeIf { it.isDirectory }
                        ?: currentDir.createDirectory(dirName)
                        ?: continue
                }
                val fileName = segments.last()
                val existing = currentDir.findFile(fileName)
                val targetDoc = existing ?: currentDir.createFile(guessMimeTypeForPath(fileName), fileName)
                if (targetDoc != null) {
                    context.contentResolver.openOutputStream(targetDoc.uri, "wt")?.use { os ->
                        os.write(file.content.toByteArray(Charsets.UTF_8))
                    }
                    writtenCount++
                }
            }
            Result.success(writtenCount)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun importProjectFromSafTree(treeUri: Uri): Result<Pair<String, List<GeneratedCodeFile>>> {
        return try {
            val rootDoc = DocumentFile.fromTreeUri(context, treeUri)
                ?: return Result.failure(IllegalArgumentException("Selected folder could not be read."))
            val projectName = sanitizeProjectName(rootDoc.name ?: "external_project", "external_project")
            val collected = mutableListOf<GeneratedCodeFile>()
            collectSafFiles(rootDoc, "", collected)
            if (collected.isEmpty()) {
                return Result.failure(IllegalStateException("No readable source files found in selected folder."))
            }
            saveMultiFileProject(projectName, collected)
            Result.success(Pair(projectName, collected.sortedBy { it.path }))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun collectSafFiles(dir: DocumentFile, prefix: String, out: MutableList<GeneratedCodeFile>) {
        if (out.size >= 150) return
        for (child in dir.listFiles()) {
            if (out.size >= 150) break
            val name = child.name ?: continue
            if (name.startsWith(".") || name == "node_modules" || name == "build" || name == ".git") continue
            val rel = if (prefix.isEmpty()) name else "$prefix/$name"
            if (child.isDirectory) {
                collectSafFiles(child, rel, out)
            } else if (child.isFile && child.length() <= 512_000) {
                val text = importTextFromUri(child.uri) ?: continue
                out.add(GeneratedCodeFile(path = rel, content = text, language = detectLanguageForPath(rel)))
            }
        }
    }

    fun importTextFromUri(uri: Uri): String? {
        return try {
            context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
        } catch (_: Exception) {
            null
        }
    }

    fun importWebProjectZip(uri: Uri): Triple<String, String, String>? {
        return try {
            var html = ""
            var css = ""
            var js = ""
            context.contentResolver.openInputStream(uri)?.use { stream ->
                ZipInputStream(stream).use { zis ->
                    var entry = zis.nextEntry
                    val buf = ByteArray(8192)
                    while (entry != null) {
                        val name = entry.name.lowercase(Locale.US)
                        val isTargetExt = name.endsWith(".html") || name.endsWith(".htm") ||
                            name.endsWith(".css") || name.endsWith(".js")
                        if (!entry.isDirectory && !name.contains("..") && isTargetExt) {
                            val out = ByteArrayOutputStream()
                            var totalRead = 0
                            var count: Int
                            while (zis.read(buf).also { count = it } != -1) {
                                totalRead += count
                                if (totalRead > 2_000_000) break
                                out.write(buf, 0, count)
                            }
                            val body = out.toString("UTF-8")
                            when {
                                name.endsWith(".html") || name.endsWith(".htm") -> html = body
                                name.endsWith(".css") -> css = body
                                name.endsWith(".js") -> js = body
                            }
                        }
                        zis.closeEntry()
                        entry = zis.nextEntry
                    }
                }
            }
            if (html.isBlank() && css.isBlank() && js.isBlank()) null else Triple(html, css, js)
        } catch (_: Exception) {
            null
        }
    }

    private fun writeZipEntry(zos: ZipOutputStream, name: String, content: String) {
        zos.putNextEntry(ZipEntry(name))
        zos.write(content.toByteArray(Charsets.UTF_8))
        zos.closeEntry()
    }

    fun createShareFileIntent(file: File, mimeType: String = "text/plain"): Intent {
        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )
        return Intent(Intent.ACTION_SEND).apply {
            type = mimeType
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
    }

    private fun sanitizeFileName(raw: String, requiredExt: String): String {
        val cleaned = raw.trim().replace("[^a-zA-Z0-9._-]".toRegex(), "_")
            .ifBlank { "script$requiredExt" }
        return if (cleaned.endsWith(requiredExt)) cleaned else "$cleaned$requiredExt"
    }

    companion object {
        fun sanitizeProjectName(raw: String, fallback: String = "yasmin_project"): String {
            return raw.trim()
                .replace("[^a-zA-Z0-9_-]".toRegex(), "_")
                .trim('_')
                .ifBlank { fallback }
        }

        fun sanitizeRelativePath(rawPath: String): String? {
            val normalized = rawPath.trim()
                .replace('\\', '/')
                .trimStart('/')
            if (normalized.isEmpty() || normalized.contains("..")) return null
            val cleanSegments = normalized.split('/').filter { it.isNotBlank() && it != "." }
            if (cleanSegments.isEmpty()) return null
            return cleanSegments.joinToString("/")
        }

        fun detectLanguageForPath(path: String): String {
            val ext = path.substringAfterLast('.', "").lowercase(Locale.US)
            return when (ext) {
                "kt", "kts" -> "Kotlin"
                "java" -> "Java"
                "py" -> "Python"
                "html", "htm" -> "HTML"
                "css" -> "CSS"
                "js", "mjs" -> "JavaScript"
                "ts", "tsx" -> "TypeScript"
                "json" -> "JSON"
                "xml" -> "XML"
                "php" -> "PHP"
                "c" -> "C"
                "cpp", "cc", "hpp", "h" -> "C++"
                "md" -> "Markdown"
                else -> "Text"
            }
        }

        fun guessMimeTypeForPath(path: String): String {
            val ext = path.substringAfterLast('.', "").lowercase(Locale.US)
            return when (ext) {
                "html", "htm" -> "text/html"
                "css" -> "text/css"
                "js", "mjs" -> "application/javascript"
                "json" -> "application/json"
                "xml" -> "application/xml"
                "md" -> "text/markdown"
                else -> "text/plain"
            }
        }
    }
}
