package com.yasmin.ai.coding

import android.content.Context
import android.text.Editable
import android.text.Spannable
import android.text.style.ForegroundColorSpan
import androidx.core.content.ContextCompat
import com.yasmin.ai.R
import java.util.regex.Pattern

object SyntaxHighlighter {

    private const val MAX_HIGHLIGHT_CHARS = 18000

    private val PYTHON_KEYWORDS = Pattern.compile(
        "\\b(def|class|return|if|elif|else|for|while|break|continue|import|from|as|try|except|finally|with|lambda|pass|raise|yield|True|False|None|and|or|not|in|is|print|len|range|enumerate|zip|sorted|sum|min|max)\\b"
    )
    private val JS_CSS_KEYWORDS = Pattern.compile(
        "\\b(const|let|var|function|return|if|else|for|while|switch|case|break|async|await|try|catch|document|window|console|display|flex|grid|color|background|border|padding|margin|font-family|border-radius)\\b"
    )
    private val HTML_TAGS = Pattern.compile("</?[a-zA-Z0-9-]+[^>]*>")
    private val STRINGS = Pattern.compile("(\"[^\"]*\"|'[^']*'|`[^`]*`)")
    private val COMMENTS = Pattern.compile("(#.*|//.*|/\\*[\\s\\S]*?\\*/)")
    private val NUMBERS = Pattern.compile("\\b\\d+(\\.\\d+)?\\b")

    fun highlight(context: Context, editable: Editable, mode: String) {
        if (editable.length > MAX_HIGHLIGHT_CHARS) return

        val existingSpans = editable.getSpans(0, editable.length, ForegroundColorSpan::class.java)
        for (span in existingSpans) {
            editable.removeSpan(span)
        }

        val text = editable.toString()
        if (text.isEmpty()) return

        val keywordColor = ContextCompat.getColor(context, R.color.syntax_keyword)
        val stringColor = ContextCompat.getColor(context, R.color.syntax_string)
        val commentColor = ContextCompat.getColor(context, R.color.syntax_comment)
        val numberColor = ContextCompat.getColor(context, R.color.syntax_number)
        val tagColor = ContextCompat.getColor(context, R.color.syntax_tag)

        applyPattern(editable, text, NUMBERS, numberColor)
        if (mode == "python") {
            applyPattern(editable, text, PYTHON_KEYWORDS, keywordColor)
        } else {
            applyPattern(editable, text, JS_CSS_KEYWORDS, keywordColor)
            applyPattern(editable, text, HTML_TAGS, tagColor)
        }
        applyPattern(editable, text, STRINGS, stringColor)
        applyPattern(editable, text, COMMENTS, commentColor)
    }

    private fun applyPattern(editable: Editable, text: String, pattern: Pattern, color: Int) {
        val matcher = pattern.matcher(text)
        while (matcher.find()) {
            editable.setSpan(
                ForegroundColorSpan(color),
                matcher.start(),
                matcher.end(),
                Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
            )
        }
    }
}
