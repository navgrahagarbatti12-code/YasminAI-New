package com.yasmin.ai.coding

import android.Manifest
import android.annotation.SuppressLint
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.work.CoroutineWorker
import androidx.work.ExistingWorkPolicy
import androidx.work.ForegroundInfo
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkInfo
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.yasmin.ai.MainActivity
import com.yasmin.ai.R
import com.yasmin.ai.YasminApplication
import com.yasmin.ai.ai.AiResult
import com.yasmin.ai.ai.GeneratedCodeFile
import com.yasmin.ai.ai.MultiFileCodeRequest
import com.yasmin.ai.data.local.CodingJobEntity
import com.yasmin.ai.repository.YasminRepository
import kotlinx.coroutines.CancellationException

class BackgroundCodingWorker(
    appContext: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(appContext, workerParams) {

    private val gson = Gson()

    override suspend fun doWork(): Result {
        val app = applicationContext as YasminApplication
        val repository = app.repository
        val fileManager = ProjectFileManager(applicationContext)

        val jobId = inputData.getString(KEY_JOB_ID) ?: return Result.failure()
        val projectName = inputData.getString(KEY_PROJECT_NAME) ?: "yasmin_project"
        val language = inputData.getString(KEY_LANGUAGE) ?: "Kotlin"
        val prompt = inputData.getString(KEY_PROMPT) ?: return Result.failure()
        val mode = inputData.getString(KEY_MODE) ?: "generate"
        val includeDocs = inputData.getBoolean(KEY_INCLUDE_DOCS, true)
        val syncSafUri = inputData.getString(KEY_SAF_URI).orEmpty()

        val notifId = jobId.hashCode() and 0x7FFFFFFF

        try {
            setForeground(createForegroundInfo(notifId, projectName, 15, "Preparing workspace…"))
            repository.updateCodingJobProgress(jobId, STATUS_RUNNING, 15, "Preparing workspace & context…")

            val existingJob = repository.getCodingJob(jobId)
            val existingFiles: List<GeneratedCodeFile> = if (existingJob != null && existingJob.filesJson.isNotBlank()) {
                try {
                    val listType = object : TypeToken<List<GeneratedCodeFile>>() {}.type
                    gson.fromJson(existingJob.filesJson, listType) ?: emptyList()
                } catch (_: Exception) {
                    emptyList()
                }
            } else {
                val dir = fileManager.getProjectDirectory(projectName)
                fileManager.loadMultiFileProject(dir)
            }

            setForeground(createForegroundInfo(notifId, projectName, 40, "Generating $language code with Yasmin AI…"))
            repository.updateCodingJobProgress(jobId, STATUS_RUNNING, 40, "Generating $language code with Yasmin AI…")

            val aiResult = repository.generateMultiFileProject(
                MultiFileCodeRequest(
                    prompt = prompt,
                    projectName = projectName,
                    targetLanguage = language,
                    existingFiles = existingFiles,
                    mode = mode,
                    includeDocs = includeDocs
                )
            )

            when (aiResult) {
                is AiResult.Error -> {
                    val existing = repository.getCodingJob(jobId)
                    repository.upsertCodingJob(
                        (existing ?: CodingJobEntity(
                            jobId = jobId,
                            projectName = projectName,
                            language = language,
                            prompt = prompt,
                            status = STATUS_FAILED,
                            progress = 0,
                            statusMessage = aiResult.message,
                            projectPath = "",
                            summaryText = "",
                            filesJson = "[]",
                            errorMessage = aiResult.message
                        )).copy(
                            status = STATUS_FAILED,
                            statusMessage = "Failed: ${aiResult.message}",
                            errorMessage = aiResult.message,
                            updatedAt = System.currentTimeMillis()
                        )
                    )
                    postCompletionNotification(notifId + 1, "Coding Job Failed: $projectName", aiResult.message)
                    return Result.failure(workDataOf(KEY_ERROR to aiResult.message))
                }

                is AiResult.Success -> {
                    val response = aiResult.data
                    val resolvedProjectName = ProjectFileManager.sanitizeProjectName(
                        response.projectName.ifBlank { projectName },
                        projectName
                    )

                    setForeground(createForegroundInfo(notifId, resolvedProjectName, 75, "Saving files & README.md…"))
                    repository.updateCodingJobProgress(jobId, STATUS_RUNNING, 75, "Saving generated project files…")

                    val mergedFiles = mergeProjectFiles(existingFiles, response.files, mode)
                    val projectDir = fileManager.saveMultiFileProject(
                        projectName = resolvedProjectName,
                        files = mergedFiles,
                        readmeMarkdown = if (includeDocs) response.readmeMarkdown else ""
                    )

                    var safNote = ""
                    if (syncSafUri.isNotBlank()) {
                        val synced = fileManager.syncProjectToSafTree(projectDir, Uri.parse(syncSafUri))
                        safNote = synced.fold(
                            onSuccess = { count -> " · Synced $count files to folder" },
                            onFailure = { err -> " · Folder sync skipped (${err.localizedMessage})" }
                        )
                    }

                    val finalFiles = fileManager.loadMultiFileProject(projectDir)
                    val filesJson = gson.toJson(finalFiles)
                    val doneMsg = "Completed ${finalFiles.size} file(s)$safNote"

                    val prev = repository.getCodingJob(jobId)
                    repository.upsertCodingJob(
                        (prev ?: CodingJobEntity(
                            jobId = jobId,
                            projectName = resolvedProjectName,
                            language = language,
                            prompt = prompt,
                            status = STATUS_COMPLETED,
                            progress = 100,
                            statusMessage = doneMsg,
                            projectPath = projectDir.absolutePath,
                            summaryText = response.summary,
                            filesJson = filesJson,
                            errorMessage = ""
                        )).copy(
                            projectName = resolvedProjectName,
                            status = STATUS_COMPLETED,
                            progress = 100,
                            statusMessage = doneMsg,
                            projectPath = projectDir.absolutePath,
                            summaryText = response.summary,
                            filesJson = filesJson,
                            errorMessage = "",
                            updatedAt = System.currentTimeMillis()
                        )
                    )
                    postCompletionNotification(
                        notifId + 1,
                        "Project Ready: $resolvedProjectName",
                        "${finalFiles.size} file(s) saved. Tap to open in Yasmin Coding Agent."
                    )
                    return Result.success()
                }
            }
        } catch (cancel: CancellationException) {
            val prev = repository.getCodingJob(jobId)
            if (prev != null) {
                repository.upsertCodingJob(
                    prev.copy(
                        status = STATUS_CANCELLED,
                        statusMessage = "Cancelled by user.",
                        updatedAt = System.currentTimeMillis()
                    )
                )
            }
            throw cancel
        } catch (e: Exception) {
            val errMsg = e.localizedMessage ?: "Background coding task interrupted."
            val prev = repository.getCodingJob(jobId)
            if (prev != null) {
                repository.upsertCodingJob(
                    prev.copy(
                        status = STATUS_FAILED,
                        statusMessage = "Failed: $errMsg",
                        errorMessage = errMsg,
                        updatedAt = System.currentTimeMillis()
                    )
                )
            }
            postCompletionNotification(notifId + 1, "Coding Job Failed: $projectName", errMsg)
            return Result.failure(workDataOf(KEY_ERROR to errMsg))
        }
    }

    private fun mergeProjectFiles(
        existing: List<GeneratedCodeFile>,
        incoming: List<GeneratedCodeFile>,
        mode: String
    ): List<GeneratedCodeFile> {
        if (mode == "generate" || existing.isEmpty()) return incoming
        val map = existing.associateBy { it.path }.toMutableMap()
        incoming.forEach { file -> map[file.path] = file }
        return map.values.toList()
    }

    private fun createForegroundInfo(
        notifId: Int,
        projectName: String,
        progress: Int,
        statusText: String
    ): ForegroundInfo {
        val launchIntent = Intent(applicationContext, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val pi = PendingIntent.getActivity(
            applicationContext,
            notifId,
            launchIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val cancelIntent = WorkManager.getInstance(applicationContext).createCancelPendingIntent(id)

        val notification = NotificationCompat.Builder(applicationContext, YasminApplication.CHANNEL_CODING_JOBS)
            .setSmallIcon(R.drawable.ic_code)
            .setContentTitle("Yasmin Coding: $projectName")
            .setContentText(statusText)
            .setProgress(100, progress, false)
            .setOngoing(true)
            .setContentIntent(pi)
            .addAction(R.drawable.ic_stop, "Cancel", cancelIntent)
            .build()

        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ForegroundInfo(notifId, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            ForegroundInfo(notifId, notification)
        }
    }

    @SuppressLint("MissingPermission")
    private fun postCompletionNotification(notifId: Int, title: String, text: String) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(applicationContext, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            return
        }
        val launchIntent = Intent(applicationContext, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val pi = PendingIntent.getActivity(
            applicationContext,
            notifId,
            launchIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = NotificationCompat.Builder(applicationContext, YasminApplication.CHANNEL_CODING_JOBS)
            .setSmallIcon(R.drawable.ic_code)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()
        NotificationManagerCompat.from(applicationContext).notify(notifId, notification)
    }

    companion object {
        const val KEY_JOB_ID = "job_id"
        const val KEY_PROJECT_NAME = "project_name"
        const val KEY_LANGUAGE = "language"
        const val KEY_PROMPT = "prompt"
        const val KEY_MODE = "mode"
        const val KEY_INCLUDE_DOCS = "include_docs"
        const val KEY_SAF_URI = "saf_uri"
        const val KEY_ERROR = "error"

        const val STATUS_QUEUED = "QUEUED"
        const val STATUS_RUNNING = "RUNNING"
        const val STATUS_COMPLETED = "COMPLETED"
        const val STATUS_FAILED = "FAILED"
        const val STATUS_CANCELLED = "CANCELLED"
        const val STATUS_INTERRUPTED = "INTERRUPTED"

        suspend fun enqueue(
            context: Context,
            repository: YasminRepository,
            projectName: String,
            language: String,
            prompt: String,
            mode: String = "generate",
            includeDocs: Boolean = true,
            safUri: String = "",
            initialFilesJson: String = "[]"
        ): String {
            val cleanName = ProjectFileManager.sanitizeProjectName(projectName, "yasmin_project")
            val uniqueKey = "coding_${cleanName}_${prompt.trim().lowercase().hashCode()}"

            val wm = WorkManager.getInstance(context.applicationContext)
            val alreadyActive = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                val existingInfos = wm.getWorkInfosForUniqueWork(uniqueKey).get()
                existingInfos.any {
                    it.state == WorkInfo.State.RUNNING || it.state == WorkInfo.State.ENQUEUED
                }
            }
            if (alreadyActive) {
                return uniqueKey
            }

            val jobId = uniqueKey
            repository.upsertCodingJob(
                CodingJobEntity(
                    jobId = jobId,
                    projectName = cleanName,
                    language = language,
                    prompt = prompt,
                    status = STATUS_QUEUED,
                    progress = 5,
                    statusMessage = "Queued for background generation…",
                    projectPath = "",
                    summaryText = "",
                    filesJson = initialFilesJson,
                    errorMessage = ""
                )
            )

            val request = OneTimeWorkRequestBuilder<BackgroundCodingWorker>()
                .setInputData(
                    workDataOf(
                        KEY_JOB_ID to jobId,
                        KEY_PROJECT_NAME to cleanName,
                        KEY_LANGUAGE to language,
                        KEY_PROMPT to prompt,
                        KEY_MODE to mode,
                        KEY_INCLUDE_DOCS to includeDocs,
                        KEY_SAF_URI to safUri
                    )
                )
                .addTag(jobId)
                .build()

            wm.enqueueUniqueWork(uniqueKey, ExistingWorkPolicy.KEEP, request)
            return jobId
        }

        fun cancelJob(context: Context, jobId: String) {
            WorkManager.getInstance(context.applicationContext).cancelUniqueWork(jobId)
        }

        suspend fun reconcileInterruptedJobs(context: Context, repository: YasminRepository) {
            val wm = WorkManager.getInstance(context.applicationContext)
            val staleCandidates = repository.getNonTerminalCodingJobs()
            for (job in staleCandidates) {
                val isActuallyActive = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                    val infos = try {
                        wm.getWorkInfosForUniqueWork(job.jobId).get()
                    } catch (_: Exception) {
                        emptyList()
                    }
                    infos.any {
                        it.state == WorkInfo.State.RUNNING || it.state == WorkInfo.State.ENQUEUED
                    }
                }
                if (!isActuallyActive) {
                    repository.upsertCodingJob(
                        job.copy(
                            status = STATUS_INTERRUPTED,
                            statusMessage = "Interrupted when system killed app. Tap Retry to resume.",
                            updatedAt = System.currentTimeMillis()
                        )
                    )
                }
            }
        }
    }
}
