package com.yasmin.ai.youtube

import android.content.Context
import android.media.AudioManager
import android.view.KeyEvent
import com.yasmin.ai.accessibility.YasminAccessibilityService
import com.yasmin.ai.automation.DeviceControlManager
import java.util.Locale

/**
 * Parses Hindi, English, and Hinglish YouTube voice commands and executes them via supported
 * Android Intents, AudioManager media key events, and user-authorized AccessibilityService actions.
 * Always verifies actual action outcomes and never reports unsupported actions as successful.
 */
class YouTubeVoiceController(
    private val context: Context,
    private val deviceControl: DeviceControlManager
) {

    fun executeVoiceIntent(intent: YouTubeVoiceIntent): YouTubeActionVerification {
        return when (intent) {
            is YouTubeVoiceIntent.OpenYouTube -> {
                val msg = deviceControl.openYouTubeHome()
                YouTubeActionVerification(verified = true, actionName = "Open YouTube", methodUsed = "Android Intent", message = msg)
            }
            is YouTubeVoiceIntent.OpenYouTubeAgent -> {
                YouTubeActionVerification(verified = true, actionName = "Open YouTube AI Agent", methodUsed = "In-App Navigation", message = "Opening Yasmin YouTube AI Agent.")
            }
            is YouTubeVoiceIntent.SearchVideos -> {
                val msg = deviceControl.searchYouTube(YouTubeDataService.buildFilteredQuery(intent.query, intent.filter))
                YouTubeActionVerification(verified = true, actionName = "Search YouTube", methodUsed = "Android Intent", message = msg)
            }
            is YouTubeVoiceIntent.VolumeUp -> {
                val msg = deviceControl.adjustVolume(AudioManager.ADJUST_RAISE)
                YouTubeActionVerification(verified = true, actionName = "Volume Up", methodUsed = "AudioManager", message = msg)
            }
            is YouTubeVoiceIntent.VolumeDown -> {
                val msg = deviceControl.adjustVolume(AudioManager.ADJUST_LOWER)
                YouTubeActionVerification(verified = true, actionName = "Volume Down", methodUsed = "AudioManager", message = msg)
            }
            is YouTubeVoiceIntent.PlayOrResume -> performPlayPause(wantPlay = true)
            is YouTubeVoiceIntent.Pause -> performPlayPause(wantPlay = false)
            is YouTubeVoiceIntent.SeekForward -> performSeek(forward = true, seconds = intent.seconds)
            is YouTubeVoiceIntent.SeekBackward -> performSeek(forward = false, seconds = intent.seconds)
            is YouTubeVoiceIntent.NextVideo -> performTrackSkip(next = true)
            is YouTubeVoiceIntent.PreviousVideo -> performTrackSkip(next = false)
            is YouTubeVoiceIntent.Fullscreen -> performFullscreenToggle(enter = intent.enter)
            is YouTubeVoiceIntent.CloseVideo -> performCloseVideo()
            is YouTubeVoiceIntent.OpenChannel -> {
                val msg = deviceControl.openYouTubeChannel(intent.query)
                YouTubeActionVerification(verified = true, actionName = "Open Channel", methodUsed = "YouTube Intent / Web URL", message = msg)
            }
            is YouTubeVoiceIntent.OpenPlaylist -> {
                if (intent.isWatchLater) {
                    val msg = deviceControl.openWatchLater()
                    YouTubeActionVerification(
                        verified = true,
                        partial = true,
                        actionName = "Open Watch Later",
                        methodUsed = "YouTube Intent (Account Session Required)",
                        message = msg
                    )
                } else {
                    val msg = deviceControl.openYouTubePlaylist(intent.query)
                    YouTubeActionVerification(verified = true, actionName = "Open Playlist", methodUsed = "YouTube Intent / Web URL", message = msg)
                }
            }
            is YouTubeVoiceIntent.ReadYouTubeScreen -> {
                val svc = YasminAccessibilityService.instance
                    ?: return YouTubeActionVerification(
                        verified = false,
                        actionName = "Read YouTube Screen",
                        methodUsed = "AccessibilityService",
                        message = "Enable Yasmin AI Accessibility Service in Permission Setup to read the YouTube screen.",
                        requiresAccessibilitySetup = true
                    )
                val ytCtx = svc.parseYouTubeScreen()
                if (ytCtx.rawSnapshot.isBlank()) {
                    YouTubeActionVerification(
                        verified = false,
                        actionName = "Read YouTube Screen",
                        methodUsed = "AccessibilityService",
                        message = "No readable text found on the active screen. Make sure a YouTube screen is open."
                    )
                } else {
                    val summary = buildString {
                        if (ytCtx.videoTitle.isNotBlank()) append("Title: ${ytCtx.videoTitle}. ")
                        if (ytCtx.channelName.isNotBlank()) append("Channel: ${ytCtx.channelName}. ")
                        if (ytCtx.visibleControls.isNotEmpty()) append("Controls: ${ytCtx.visibleControls.take(5).joinToString(", ")}.")
                    }.ifBlank { "Captured ${ytCtx.rawSnapshot.lines().size} visible elements." }
                    YouTubeActionVerification(verified = true, actionName = "Read YouTube Screen", methodUsed = "AccessibilityService", message = summary)
                }
            }
            is YouTubeVoiceIntent.SummarizeCurrent,
            is YouTubeVoiceIntent.AskAboutVideo,
            is YouTubeVoiceIntent.GenerateNotes,
            is YouTubeVoiceIntent.StartLearningOrQuiz -> {
                YouTubeActionVerification(
                    verified = true,
                    actionName = "YouTube AI Agent Action",
                    methodUsed = "In-App Agent",
                    message = "Routing request into YouTube AI Agent."
                )
            }
        }
    }

    private fun performPlayPause(wantPlay: Boolean): YouTubeActionVerification {
        val label = if (wantPlay) "Play/Resume Video" else "Pause Video"
        val svc = YasminAccessibilityService.instance
        if (svc != null && svc.isYouTubeActive()) {
            val targetKey = if (wantPlay) "Play" else "Pause"
            when (val res = svc.performYouTubeControlAction(targetKey)) {
                is YasminAccessibilityService.ActionOutcome.Done -> {
                    return YouTubeActionVerification(verified = true, actionName = label, methodUsed = "Accessibility Control", message = res.message)
                }
                else -> Unit
            }
        }
        val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val beforeActive = audioManager.isMusicActive
        val keyCode = if (wantPlay) KeyEvent.KEYCODE_MEDIA_PLAY else KeyEvent.KEYCODE_MEDIA_PAUSE
        val dispatched = dispatchMediaKey(audioManager, keyCode) || dispatchMediaKey(audioManager, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE)
        if (!dispatched) {
            return YouTubeActionVerification(
                verified = false,
                actionName = label,
                methodUsed = "AudioManager MediaKey",
                message = "Could not dispatch media control. Enable Accessibility Service or ensure a video player is active.",
                requiresAccessibilitySetup = svc == null
            )
        }
        Thread.sleep(220L)
        val afterActive = audioManager.isMusicActive
        val changed = afterActive != beforeActive || afterActive == wantPlay
        return if (changed) {
            YouTubeActionVerification(
                verified = true,
                actionName = label,
                methodUsed = "AudioManager MediaKey",
                message = if (wantPlay) "Verified: media playback active." else "Verified: media playback paused."
            )
        } else {
            YouTubeActionVerification(
                verified = false,
                partial = true,
                actionName = label,
                methodUsed = "AudioManager MediaKey",
                message = if (svc == null) {
                    "Media key sent, but Android did not confirm a playback state change (YouTube may be in background or paused without MediaSession focus). Enable Accessibility Service for on-screen YouTube control."
                } else {
                    "Media key sent, but YouTube playback state did not confirm a change. Open the YouTube player overlay and retry."
                },
                requiresAccessibilitySetup = svc == null
            )
        }
    }

    private fun performSeek(forward: Boolean, seconds: Int): YouTubeActionVerification {
        val label = if (forward) "Seek Forward ${seconds}s" else "Seek Backward ${seconds}s"
        val svc = YasminAccessibilityService.instance
        if (svc != null && svc.isYouTubeActive()) {
            val outcome = svc.seekYouTubeRelative(forward = forward, seconds = seconds)
            return when (outcome) {
                is YasminAccessibilityService.ActionOutcome.Done ->
                    YouTubeActionVerification(verified = true, actionName = label, methodUsed = "YouTube Accessibility Gesture", message = outcome.message)
                is YasminAccessibilityService.ActionOutcome.Failed ->
                    YouTubeActionVerification(verified = false, actionName = label, methodUsed = "YouTube Accessibility Gesture", message = outcome.reason)
                is YasminAccessibilityService.ActionOutcome.Ambiguous ->
                    YouTubeActionVerification(verified = false, actionName = label, methodUsed = "YouTube Accessibility Gesture", message = "Multiple player areas matched.")
            }
        }
        val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val keyCode = if (forward) KeyEvent.KEYCODE_MEDIA_FAST_FORWARD else KeyEvent.KEYCODE_MEDIA_REWIND
        val dispatched = audioManager.isMusicActive && dispatchMediaKey(audioManager, keyCode)
        return if (dispatched) {
            YouTubeActionVerification(
                verified = true,
                partial = true,
                actionName = label,
                methodUsed = "AudioManager Fast-Forward/Rewind Key",
                message = "Sent seek media key event to active player (exact +10s/-10s precision requires YouTube Accessibility player gesture)."
            )
        } else {
            YouTubeActionVerification(
                verified = false,
                actionName = label,
                methodUsed = "AccessibilityService",
                message = "Exact 10-second seek requires YouTube open on screen with Yasmin Accessibility Service enabled.",
                requiresAccessibilitySetup = svc == null
            )
        }
    }

    private fun performTrackSkip(next: Boolean): YouTubeActionVerification {
        val label = if (next) "Next Video" else "Previous Video"
        val svc = YasminAccessibilityService.instance
        if (svc != null && svc.isYouTubeActive()) {
            val target = if (next) "Next video" else "Previous video"
            when (val res = svc.performYouTubeControlAction(target)) {
                is YasminAccessibilityService.ActionOutcome.Done ->
                    return YouTubeActionVerification(verified = true, actionName = label, methodUsed = "Accessibility Control", message = res.message)
                else -> Unit
            }
        }
        val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        if (!audioManager.isMusicActive) {
            return YouTubeActionVerification(
                verified = false,
                actionName = label,
                methodUsed = "Media / Accessibility",
                message = "No active playback session detected. Open YouTube and enable Accessibility Service for on-screen Next/Previous controls.",
                requiresAccessibilitySetup = svc == null
            )
        }
        val sent = dispatchMediaKey(audioManager, if (next) KeyEvent.KEYCODE_MEDIA_NEXT else KeyEvent.KEYCODE_MEDIA_PREVIOUS)
        return YouTubeActionVerification(
            verified = sent,
            partial = sent && svc == null,
            actionName = label,
            methodUsed = "AudioManager MediaKey",
            message = if (sent) "Dispatched $label command to active media session." else "Failed to dispatch $label command."
        )
    }

    private fun performFullscreenToggle(enter: Boolean): YouTubeActionVerification {
        val label = if (enter) "Enter Fullscreen" else "Exit Fullscreen"
        val svc = YasminAccessibilityService.instance
            ?: return YouTubeActionVerification(
                verified = false,
                actionName = label,
                methodUsed = "AccessibilityService",
                message = "Fullscreen control requires Yasmin Accessibility Service enabled.",
                requiresAccessibilitySetup = true
            )
        if (!svc.isYouTubeActive()) {
            return YouTubeActionVerification(
                verified = false,
                actionName = label,
                methodUsed = "AccessibilityService",
                message = "YouTube is not the active foreground window right now."
            )
        }
        val key = if (enter) "Enter fullscreen" else "Exit fullscreen"
        return when (val r = svc.performYouTubeControlAction(key)) {
            is YasminAccessibilityService.ActionOutcome.Done ->
                YouTubeActionVerification(verified = true, actionName = label, methodUsed = "Accessibility Control", message = r.message)
            is YasminAccessibilityService.ActionOutcome.Failed ->
                YouTubeActionVerification(verified = false, actionName = label, methodUsed = "Accessibility Control", message = r.reason)
            is YasminAccessibilityService.ActionOutcome.Ambiguous ->
                YouTubeActionVerification(verified = false, actionName = label, methodUsed = "Accessibility Control", message = "Multiple fullscreen buttons detected.")
        }
    }

    private fun performCloseVideo(): YouTubeActionVerification {
        val svc = YasminAccessibilityService.instance
            ?: return YouTubeActionVerification(
                verified = false,
                actionName = "Close Video",
                methodUsed = "AccessibilityService",
                message = "Closing or minimizing the active YouTube player requires Accessibility Service.",
                requiresAccessibilitySetup = true
            )
        if (!svc.isYouTubeActive()) {
            return YouTubeActionVerification(
                verified = false,
                actionName = "Close Video",
                methodUsed = "AccessibilityService",
                message = "YouTube is not currently on screen to close a video."
            )
        }
        val closeOutcome = svc.performYouTubeControlAction("Close player")
        if (closeOutcome is YasminAccessibilityService.ActionOutcome.Done) {
            return YouTubeActionVerification(verified = true, actionName = "Close Video", methodUsed = "Accessibility Control", message = closeOutcome.message)
        }
        val minOutcome = svc.performYouTubeControlAction("Minimize")
        if (minOutcome is YasminAccessibilityService.ActionOutcome.Done) {
            return YouTubeActionVerification(verified = true, actionName = "Close Video", methodUsed = "Accessibility Minimize", message = minOutcome.message)
        }
        val backed = svc.performBackNavigation()
        return YouTubeActionVerification(
            verified = backed,
            partial = backed,
            actionName = "Close Video",
            methodUsed = "Accessibility Back Navigation",
            message = if (backed) "Sent Back navigation on active YouTube screen." else "Could not find Close/Minimize control in YouTube."
        )
    }

    private fun dispatchMediaKey(audioManager: AudioManager, keyCode: Int): Boolean {
        return try {
            audioManager.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, keyCode))
            audioManager.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, keyCode))
            true
        } catch (_: Exception) {
            false
        }
    }

    companion object {
        /**
         * Pure multilingual EN / HI (Devanagari) / Hinglish voice command parser.
         * Returns null when the utterance is not a YouTube command so standard CommandRouter flows handle it.
         */
        fun parseCommand(rawInput: String): YouTubeVoiceIntent? {
            val cleaned = rawInput.trim()
            if (cleaned.isEmpty()) return null
            val lower = cleaned.lowercase(Locale.ROOT)
                .removePrefix("hey yasmin")
                .removePrefix("ok yasmin")
                .trim()

            // Open YouTube AI Agent in-app workspace
            if (lower.contains("youtube agent") || lower.contains("youtube ai") ||
                lower.contains("youtube assistant") || lower.contains("यूट्यूब एजेंट")
            ) {
                return YouTubeVoiceIntent.OpenYouTubeAgent
            }

            // Read YouTube screen / identify current video
            if (lower.contains("read youtube screen") || lower.contains("youtube screen padho") ||
                lower.contains("identify current video") || lower.contains("what video is playing") ||
                lower.contains("kaunsa video chal raha") || lower.contains("कौन सा वीडियो चल रहा") ||
                lower.contains("youtube par kya chal raha") || lower.contains("youtube pe kya chal raha")
            ) {
                return YouTubeVoiceIntent.ReadYouTubeScreen
            }

            // Summarize video (Hindi / Hinglish / English)
            if (lower.contains("summarize this video") || lower.contains("summarize video") ||
                lower.contains("video summary") || lower.contains("is video ka summary") ||
                lower.contains("video summarize karo") || lower.contains("वीडियो का सारांश") ||
                lower.contains("इस वीडियो को समझाओ") || lower.contains("explain this video")
            ) {
                val lang = when {
                    lower.contains("hindi") || lower.contains("हिंदी") || lower.contains("हिन्दी") -> SummaryLanguage.HINDI
                    lower.contains("hinglish") || lower.contains("karo") || lower.contains("batao") -> SummaryLanguage.HINGLISH
                    else -> null
                }
                return YouTubeVoiceIntent.SummarizeCurrent(lang)
            }

            // Notes generation
            if (lower.contains("video notes") || lower.contains("notes of this video") ||
                lower.contains("video ke notes") || lower.contains("make notes for video") ||
                lower.contains("generate notes") && lower.contains("video") ||
                lower.contains("नोट्स बनाओ")
            ) {
                return YouTubeVoiceIntent.GenerateNotes
            }

            // Video Q&A grounded in current video
            if (lower.contains("what is this video about") || lower.contains("what this video is about") ||
                lower.contains("what is the speaker saying") || lower.contains("explain the second chapter") ||
                lower.contains("explain second chapter") || lower.contains("important points of this video") ||
                lower.contains("what are the important points") || lower.contains("what can i learn from this video") ||
                lower.contains("is video mein kya") || lower.contains("speaker kya bol raha") ||
                lower.contains("यह वीडियो किस बारे में") || lower.contains("इस वीडियो से क्या सीख")
            ) {
                return YouTubeVoiceIntent.AskAboutVideo(cleaned)
            }

            // Learning / Quiz mode
            if (lower.contains("youtube learning") || lower.contains("teach me this video") ||
                lower.contains("quiz me on this video") || lower.contains("video quiz") ||
                lower.contains("is video ka quiz") || lower.contains("वीडियो क्विज़")
            ) {
                return YouTubeVoiceIntent.StartLearningOrQuiz
            }

            // Seek forward / backward (flexible word order: "forward 10 seconds", "10 seconds forward", "fast forward", etc.)
            if (lower.contains("seek forward") || lower.contains("forward 10") || lower.contains("fast forward") ||
                lower.contains("skip ahead") || Regex("\\d{1,3}\\s*(?:sec|second|seconds|s)\\s+forward").containsMatchIn(lower) ||
                lower.contains("10 second aage") || lower.contains("10 seconds aage") ||
                lower.contains("aage badhao") || lower.contains("skip 10") ||
                lower.contains("10 सेकंड आगे") || lower.contains("आगे बढ़ाओ")
            ) {
                return YouTubeVoiceIntent.SeekForward(extractSeconds(lower, 10))
            }
            if (lower.contains("seek backward") || lower.contains("backward 10") || lower.contains("rewind") ||
                Regex("\\d{1,3}\\s*(?:sec|second|seconds|s)\\s+(?:back|backward)").containsMatchIn(lower) ||
                lower.contains("10 second peeche") || lower.contains("10 seconds peeche") ||
                lower.contains("peeche karo") || lower.contains("10 सेकंड पीछे") || lower.contains("पीछे करो")
            ) {
                return YouTubeVoiceIntent.SeekBackward(extractSeconds(lower, 10))
            }

            // Fullscreen / Exit Fullscreen
            if (lower.contains("exit fullscreen") || lower.contains("exit full screen") ||
                lower.contains("fullscreen band") || lower.contains("फुल स्क्रीन बंद")
            ) {
                return YouTubeVoiceIntent.Fullscreen(enter = false)
            }
            if (lower == "fullscreen" || lower.contains("full screen") || lower.contains("fullscreen mode") ||
                lower.contains("badi screen") || lower.contains("फुल स्क्रीन")
            ) {
                return YouTubeVoiceIntent.Fullscreen(enter = true)
            }

            // Close video
            if (lower.contains("close video") || lower.contains("close the video") || lower.contains("video band karo") ||
                lower.contains("minimize video") || lower.contains("वीडियो बंद करो")
            ) {
                return YouTubeVoiceIntent.CloseVideo
            }

            // Next / Previous video
            if (lower == "next video" || lower.contains("play next video") ||
                lower.contains("agla video") || lower.contains("अगला वीडियो") || lower.contains("next track")
            ) {
                return YouTubeVoiceIntent.NextVideo
            }
            if (lower == "previous video" || lower.contains("play previous video") ||
                lower.contains("pichla video") || lower.contains("पिछला वीडियो") || lower.contains("previous track")
            ) {
                return YouTubeVoiceIntent.PreviousVideo
            }

            // Play / Pause / Resume video
            if (lower == "pause video" || lower == "pause" || lower == "pause the video" || lower.contains("video pause") ||
                lower.contains("video roko") || lower.contains("वीडियो रोको")
            ) {
                return YouTubeVoiceIntent.Pause
            }
            if (lower == "play video" || lower == "play" || lower == "resume" || lower == "resume video" ||
                lower == "resume the video" || lower.contains("video resume") ||
                lower.contains("video chalao") || lower.contains("वीडियो चलाओ")
            ) {
                return YouTubeVoiceIntent.PlayOrResume
            }

            // Volume
            if (lower.contains("increase volume") || lower.contains("volume up") ||
                lower.contains("awaaz badhao") || lower.contains("आवाज़ बढ़ाओ")
            ) {
                return YouTubeVoiceIntent.VolumeUp
            }
            if (lower.contains("decrease volume") || lower.contains("volume down") ||
                lower.contains("awaaz kam") || lower.contains("आवाज़ कम")
            ) {
                return YouTubeVoiceIntent.VolumeDown
            }

            // Watch Later / Playlists
            if (lower.contains("watch later") || lower.contains("वॉच लेटर")) {
                return YouTubeVoiceIntent.OpenPlaylist("WL", isWatchLater = true)
            }
            val playlistMatch = Regex("(?:open|play|search)\\s+(?:youtube\\s+)?playlist\\s+(.+)$").find(lower)
            if (playlistMatch != null) {
                return YouTubeVoiceIntent.OpenPlaylist(playlistMatch.groupValues[1].trim())
            }
            if (lower.endsWith("playlist kholo") || lower.contains("playlist खोलो")) {
                val q = cleaned.replace(Regex("(?i)playlist\\s*(kholo|खोलो)"), "").trim()
                return YouTubeVoiceIntent.OpenPlaylist(q.ifBlank { "playlist" })
            }

            // Open Channel
            val channelMatch = Regex("(?:open|show|search)\\s+(?:youtube\\s+)?channel\\s+(.+)$").find(lower)
            if (channelMatch != null) {
                return YouTubeVoiceIntent.OpenChannel(channelMatch.groupValues[1].trim())
            }
            if (lower.endsWith("channel kholo") || lower.contains("चैनल खोलो")) {
                val q = cleaned.replace(Regex("(?i)(?:channel\\s*kholo|चैनल\\s*खोलो)"), "").trim()
                if (q.isNotEmpty()) return YouTubeVoiceIntent.OpenChannel(q)
            }

            // Search YouTube (EN / HI / Hinglish)
            val ytSearchPatterns = listOf(
                Regex("(?i)^(?:hey yasmin|ok yasmin)?\\s*search youtube(?:\\s+for)?\\s+(.+)$"),
                Regex("(?i)^(?:hey yasmin|ok yasmin)?\\s*youtube\\s+(?:pe|par|mein|per)\\s+(.+?)\\s*(?:search karo|dhundo|dikhao|chalaao|chalao)?$"),
                Regex("(?i)^(?:hey yasmin|ok yasmin)?\\s*(?:search|play|find|show)\\s+(.+?)\\s+on youtube$"),
                Regex("(?i)^(?:यूट्यूब\\s+(?:पर|पे|में))\\s+(.+?)\\s*(?:खोजो|सर्च करो|दिखाओ|चलाओ)?$")
            )
            for (pattern in ytSearchPatterns) {
                val m = pattern.find(cleaned)
                if (m != null) {
                    val q = m.groupValues[1].trim()
                    if (q.isNotEmpty()) {
                        val filter = when {
                            q.contains("shorts", ignoreCase = true) -> YouTubeSearchFilter.SHORTS
                            q.contains("tutorial", ignoreCase = true) -> YouTubeSearchFilter.TUTORIAL
                            q.contains("latest", ignoreCase = true) -> YouTubeSearchFilter.LATEST
                            else -> YouTubeSearchFilter.VIDEO
                        }
                        return YouTubeVoiceIntent.SearchVideos(q, filter)
                    }
                }
            }

            // Open YouTube home
            if (lower == "open youtube" || lower == "launch youtube" || lower == "youtube kholo" ||
                lower == "यूट्यूब खोलो" || lower == "youtube"
            ) {
                return YouTubeVoiceIntent.OpenYouTube
            }

            return null
        }

        private fun extractSeconds(lower: String, defaultSec: Int): Int {
            val m = Regex("(\\d{1,3})\\s*(?:sec|second|seconds|s|सेकंड)").find(lower)
            return m?.groupValues?.get(1)?.toIntOrNull()?.coerceIn(5, 120) ?: defaultSec
        }
    }
}
