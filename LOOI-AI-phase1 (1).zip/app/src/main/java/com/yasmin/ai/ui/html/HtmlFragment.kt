package com.yasmin.ai.ui.html

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.provider.OpenableColumns
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.webkit.ConsoleMessage
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.fragment.app.viewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.yasmin.ai.R
import com.yasmin.ai.coding.CodeIntelligenceHelper
import com.yasmin.ai.coding.ProjectFileManager
import com.yasmin.ai.coding.SyntaxHighlighter
import com.yasmin.ai.databinding.FragmentHtmlBinding
import com.yasmin.ai.ui.home.YasminSharedViewModel
import kotlinx.coroutines.launch
import java.io.File

class HtmlFragment : Fragment() {

    private var _binding: FragmentHtmlBinding? = null
    private val binding get() = _binding!!
    private val viewModel: HtmlViewModel by viewModels()
    private val sharedViewModel: YasminSharedViewModel by activityViewModels()
    private lateinit var fileManager: ProjectFileManager
    private var currentProjectName = "web_project"
    private var isProgrammaticEdit = false
    private var isMobilePreview = false

    private val importZipLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri == null) return@registerForActivityResult
        val loaded = fileManager.importWebProjectZip(uri)
        if (loaded == null) {
            Toast.makeText(
                requireContext(),
                "Selected ZIP did not contain HTML, CSS, or JS files.",
                Toast.LENGTH_SHORT
            ).show()
            return@registerForActivityResult
        }
        val zipName = resolveDisplayName(uri)
            ?.removeSuffix(".zip")
            ?.replace("[^a-zA-Z0-9_-]".toRegex(), "_")
            ?.ifBlank { "imported_web" }
            ?: "imported_web"

        currentProjectName = zipName
        binding.tvHtmlProjectName.text = currentProjectName
        viewModel.loadProject(loaded.first, loaded.second, loaded.third)
        viewModel.selectTab(WebEditorTab.HTML)
        viewModel.appendConsoleLog("Imported ZIP project '$currentProjectName'.")
        Toast.makeText(requireContext(), "Imported $currentProjectName", Toast.LENGTH_SHORT).show()
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentHtmlBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        fileManager = ProjectFileManager(requireContext())

        setupSafeWebView()
        setupEditor()
        setupButtons()
        observeState()

        val incomingPrompt = sharedViewModel.consumePendingCodingPrompt()
        if (incomingPrompt.isNotBlank()) {
            binding.etHtmlPrompt.setText(incomingPrompt)
            viewModel.generateWebsiteWithGemini(incomingPrompt)
        }
    }

    private fun refreshSnippetChips(tab: WebEditorTab) {
        binding.webSnippetsRow.removeAllViews()
        val list = when (tab) {
            WebEditorTab.HTML -> CodeIntelligenceHelper.htmlSnippets
            WebEditorTab.CSS -> CodeIntelligenceHelper.cssSnippets
            WebEditorTab.JS -> CodeIntelligenceHelper.jsSnippets
            WebEditorTab.PREVIEW -> emptyList()
        }
        val marginPx = (6 * resources.displayMetrics.density).toInt()
        list.forEach { snippet ->
            val btn = Button(requireContext()).apply {
                text = snippet.label
                isAllCaps = false
                textSize = 11f
                setTextColor(ContextCompat.getColor(requireContext(), R.color.jarvis_cyan))
                setBackgroundResource(R.drawable.bg_status_chip)
                setPadding(18, 4, 18, 4)
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    (32 * resources.displayMetrics.density).toInt()
                ).apply { marginEnd = marginPx }
                setOnClickListener {
                    val cursor = binding.etHtmlCodeEditor.selectionStart.coerceAtLeast(0)
                    binding.etHtmlCodeEditor.text?.insert(cursor, snippet.insertText)
                }
            }
            binding.webSnippetsRow.addView(btn)
        }
    }

    private fun resolveDisplayName(uri: android.net.Uri): String? {
        return try {
            requireContext().contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (idx >= 0 && cursor.moveToFirst()) cursor.getString(idx) else null
            }
        } catch (_: Exception) {
            null
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupSafeWebView() {
        binding.webPreview.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = false
            allowFileAccess = false
            allowContentAccess = false
            @Suppress("DEPRECATION")
            allowFileAccessFromFileURLs = false
            @Suppress("DEPRECATION")
            allowUniversalAccessFromFileURLs = false
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
        }

        binding.webPreview.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(
                view: WebView?,
                request: WebResourceRequest?
            ): Boolean {
                val url = request?.url?.toString().orEmpty()
                if (url.startsWith("about:") || url.startsWith("data:")) {
                    return false
                }
                viewModel.appendConsoleLog("Blocked external navigation to $url for sandbox safety.")
                return true
            }
        }

        binding.webPreview.webChromeClient = object : WebChromeClient() {
            override fun onConsoleMessage(consoleMessage: ConsoleMessage?): Boolean {
                if (consoleMessage != null) {
                    viewModel.appendConsoleLog(
                        "[${consoleMessage.messageLevel()}] ${consoleMessage.message()} (line ${consoleMessage.lineNumber()})"
                    )
                }
                return true
            }
        }
    }

    private fun setupEditor() {
        binding.etHtmlCodeEditor.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                if (s == null) return
                SyntaxHighlighter.highlight(requireContext(), s, "web")
                if (!isProgrammaticEdit) {
                    viewModel.updateCurrentTabCode(s.toString())
                }
            }
        })
    }

    private fun setupButtons() {
        binding.btnTabHtml.setOnClickListener { viewModel.selectTab(WebEditorTab.HTML) }
        binding.btnTabCss.setOnClickListener { viewModel.selectTab(WebEditorTab.CSS) }
        binding.btnTabJs.setOnClickListener { viewModel.selectTab(WebEditorTab.JS) }
        binding.btnTabPreview.setOnClickListener {
            viewModel.selectTab(WebEditorTab.PREVIEW)
            renderPreview()
        }

        binding.btnHtmlRefresh.setOnClickListener {
            viewModel.selectTab(WebEditorTab.PREVIEW)
            renderPreview()
        }

        binding.btnHtmlAiGenerate.setOnClickListener {
            val prompt = binding.etHtmlPrompt.text?.toString()?.trim().orEmpty()
            if (prompt.isEmpty()) {
                Toast.makeText(requireContext(), "Describe the website or edit first.", Toast.LENGTH_SHORT).show()
            } else {
                viewModel.generateWebsiteWithGemini(prompt)
            }
        }

        binding.btnHtmlExplain.setOnClickListener { viewModel.explainWithGemini() }
        binding.btnHtmlFormat.setOnClickListener { viewModel.formatCurrentTab() }

        binding.btnHtmlLint.setOnClickListener {
            val issues = CodeIntelligenceHelper.checkWebIssues(
                viewModel.htmlCode.value,
                viewModel.cssCode.value,
                viewModel.jsCode.value
            )
            if (issues.isEmpty()) {
                viewModel.appendConsoleLog("Static Web Lint Passed: HTML, CSS, and JS look balanced.")
            } else {
                viewModel.appendConsoleLog("Lint warnings:\n" + issues.joinToString("\n"))
            }
        }

        binding.btnHtmlImportZip.setOnClickListener {
            importZipLauncher.launch(arrayOf("application/zip", "application/x-zip-compressed", "*/*"))
        }

        binding.btnResponsiveToggle.setOnClickListener {
            isMobilePreview = !isMobilePreview
            val params = binding.webPreview.layoutParams
            if (isMobilePreview) {
                val widthPx = (360 * resources.displayMetrics.density).toInt()
                params.width = widthPx.coerceAtMost(binding.previewContainer.width.takeIf { it > 0 } ?: widthPx)
                binding.btnResponsiveToggle.text = "Full Width"
            } else {
                params.width = ViewGroup.LayoutParams.MATCH_PARENT
                binding.btnResponsiveToggle.text = "Mobile Width"
            }
            binding.webPreview.layoutParams = params
        }

        binding.btnHtmlSave.setOnClickListener {
            val input = EditText(requireContext()).apply { setText(currentProjectName) }
            MaterialAlertDialogBuilder(requireContext())
                .setTitle("Save Web Project")
                .setView(input)
                .setPositiveButton("Save") { _, _ ->
                    val name = input.text?.toString()?.trim().orEmpty().ifBlank { "web_project" }
                    val dir = fileManager.saveWebProject(
                        name,
                        viewModel.htmlCode.value,
                        viewModel.cssCode.value,
                        viewModel.jsCode.value
                    )
                    currentProjectName = dir.name
                    binding.tvHtmlProjectName.text = dir.name
                    Toast.makeText(requireContext(), "Saved project '${dir.name}'", Toast.LENGTH_SHORT).show()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }

        binding.btnHtmlOpen.setOnClickListener {
            val projects = fileManager.listWebProjects()
            if (projects.isEmpty()) {
                Toast.makeText(requireContext(), "No saved web projects yet.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val names = projects.map { it.name }.toTypedArray()
            MaterialAlertDialogBuilder(requireContext())
                .setTitle("Open Web Project")
                .setItems(names) { _, which ->
                    val dir = projects[which]
                    val (html, css, js) = fileManager.loadWebProject(dir)
                    currentProjectName = dir.name
                    binding.tvHtmlProjectName.text = dir.name
                    viewModel.loadProject(html, css, js)
                    viewModel.selectTab(WebEditorTab.HTML)
                }
                .show()
        }

        binding.btnHtmlExport.setOnClickListener {
            val choices = arrayOf(
                "Open Current File in External Editor",
                "Export ZIP Project (index.html, styles.css, app.js)",
                "Export Single Combined HTML File",
                "Copy Bundle & Export to GitHub Gist",
                "Open Multi-Language AI Coding Agent"
            )
            MaterialAlertDialogBuilder(requireContext())
                .setTitle("External Editor & Export")
                .setItems(choices) { _, which ->
                    when (which) {
                        0 -> {
                            val dir = fileManager.saveWebProject(
                                currentProjectName,
                                viewModel.htmlCode.value,
                                viewModel.cssCode.value,
                                viewModel.jsCode.value
                            )
                            val targetName = when (viewModel.activeTab.value) {
                                WebEditorTab.CSS -> "styles.css"
                                WebEditorTab.JS -> "app.js"
                                else -> "index.html"
                            }
                            val file = File(dir, targetName)
                            val preferred = sharedViewModel.preferences.value.externalEditorPackage
                            when (val res = com.yasmin.ai.coding.ExternalEditorHelper.openFileInExternalEditor(requireContext(), file, preferred)) {
                                is com.yasmin.ai.coding.OpenEditorResult.Launched -> {
                                    Toast.makeText(requireContext(), "Opened $targetName in ${res.targetLabel}", Toast.LENGTH_SHORT).show()
                                }
                                is com.yasmin.ai.coding.OpenEditorResult.NoEditorInstalled -> {
                                    MaterialAlertDialogBuilder(requireContext())
                                        .setTitle("No External Code Editor Installed")
                                        .setMessage("No compatible Android text/code editor was detected. Export your project as a ZIP instead?")
                                        .setPositiveButton("Export ZIP") { _, _ ->
                                            val zipFile = fileManager.exportWebProjectZip(
                                                currentProjectName,
                                                viewModel.htmlCode.value,
                                                viewModel.cssCode.value,
                                                viewModel.jsCode.value
                                            )
                                            startActivity(Intent.createChooser(fileManager.createShareFileIntent(zipFile, "application/zip"), "Share $currentProjectName.zip"))
                                        }
                                        .setNegativeButton("Close", null)
                                        .show()
                                }
                                is com.yasmin.ai.coding.OpenEditorResult.Failed -> {
                                    Toast.makeText(requireContext(), res.message, Toast.LENGTH_SHORT).show()
                                }
                            }
                        }
                        1 -> {
                            val zipFile = fileManager.exportWebProjectZip(
                                currentProjectName,
                                viewModel.htmlCode.value,
                                viewModel.cssCode.value,
                                viewModel.jsCode.value
                            )
                            val intent = fileManager.createShareFileIntent(zipFile, "application/zip")
                            startActivity(Intent.createChooser(intent, "Share $currentProjectName.zip"))
                        }
                        2 -> {
                            val exportDir = File(requireContext().cacheDir, "exports").apply { mkdirs() }
                            val bundleFile = File(exportDir, "${currentProjectName}_bundle.html")
                            bundleFile.writeText(viewModel.buildCombinedDocument())
                            val intent = fileManager.createShareFileIntent(bundleFile, "text/html")
                            startActivity(Intent.createChooser(intent, "Export $currentProjectName"))
                        }
                        3 -> {
                            CodeIntelligenceHelper.openGitHubGistExport(
                                requireContext(),
                                "$currentProjectName.html",
                                viewModel.buildCombinedDocument()
                            )
                        }
                        else -> androidx.navigation.fragment.NavHostFragment.findNavController(this@HtmlFragment).navigate(R.id.codingAgentFragment)
                    }
                }
                .show()
        }
    }

    private fun renderPreview() {
        val doc = viewModel.buildCombinedDocument()
        binding.webPreview.loadDataWithBaseURL(null, doc, "text/html", "UTF-8", null)
    }

    private fun refreshActiveEditorText(tab: WebEditorTab) {
        val textToShow = when (tab) {
            WebEditorTab.HTML -> viewModel.htmlCode.value
            WebEditorTab.CSS -> viewModel.cssCode.value
            WebEditorTab.JS -> viewModel.jsCode.value
            WebEditorTab.PREVIEW -> null
        }
        if (textToShow != null && binding.etHtmlCodeEditor.text?.toString() != textToShow) {
            isProgrammaticEdit = true
            binding.etHtmlCodeEditor.setText(textToShow)
            isProgrammaticEdit = false
        }
    }

    private fun observeState() {
        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch {
                    viewModel.activeTab.collect { tab ->
                        updateTabUi(tab)
                        refreshSnippetChips(tab)
                        if (tab != WebEditorTab.PREVIEW) {
                            binding.etHtmlCodeEditor.visibility = View.VISIBLE
                            binding.previewContainer.visibility = View.GONE
                            refreshActiveEditorText(tab)
                        } else {
                            binding.etHtmlCodeEditor.visibility = View.GONE
                            binding.previewContainer.visibility = View.VISIBLE
                            renderPreview()
                        }
                    }
                }
                launch {
                    viewModel.htmlCode.collect {
                        if (viewModel.activeTab.value == WebEditorTab.HTML) {
                            refreshActiveEditorText(WebEditorTab.HTML)
                        }
                    }
                }
                launch {
                    viewModel.cssCode.collect {
                        if (viewModel.activeTab.value == WebEditorTab.CSS) {
                            refreshActiveEditorText(WebEditorTab.CSS)
                        }
                    }
                }
                launch {
                    viewModel.jsCode.collect {
                        if (viewModel.activeTab.value == WebEditorTab.JS) {
                            refreshActiveEditorText(WebEditorTab.JS)
                        }
                    }
                }
                launch {
                    viewModel.statusLog.collect { log ->
                        binding.tvWebConsole.text = log
                    }
                }
                launch {
                    viewModel.isLoading.collect { loading ->
                        binding.btnHtmlAiGenerate.isEnabled = !loading
                        binding.btnHtmlExplain.isEnabled = !loading
                    }
                }
                launch {
                    viewModel.explanationDialogText.collect { explanation ->
                        if (!explanation.isNullOrBlank()) {
                            MaterialAlertDialogBuilder(requireContext())
                                .setTitle("Web Project Explanation")
                                .setMessage(explanation)
                                .setPositiveButton("Close") { _, _ -> viewModel.clearExplanation() }
                                .setOnDismissListener { viewModel.clearExplanation() }
                                .show()
                        }
                    }
                }
            }
        }
    }

    private fun updateTabUi(active: WebEditorTab) {
        val buttons = mapOf(
            WebEditorTab.HTML to binding.btnTabHtml,
            WebEditorTab.CSS to binding.btnTabCss,
            WebEditorTab.JS to binding.btnTabJs,
            WebEditorTab.PREVIEW to binding.btnTabPreview
        )
        buttons.forEach { (tab, btn) ->
            if (tab == active) {
                btn.setBackgroundResource(R.drawable.bg_jarvis_button_primary)
                btn.setTextColor(ContextCompat.getColor(requireContext(), R.color.jarvis_bg_deep))
            } else {
                btn.setBackgroundResource(R.drawable.bg_jarvis_panel)
                btn.setTextColor(ContextCompat.getColor(requireContext(), R.color.jarvis_text_primary))
            }
        }
    }

    override fun onDestroyView() {
        binding.webPreview.destroy()
        super.onDestroyView()
        _binding = null
    }
}
