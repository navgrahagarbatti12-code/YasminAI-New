package com.yasmin.ai.youtube

enum class YouTubeItemType {
    VIDEO,
    CHANNEL,
    PLAYLIST
}

enum class YouTubeSearchFilter(val label: String) {
    VIDEO("Videos"),
    SHORTS("Shorts"),
    TUTORIAL("Tutorials"),
    EDUCATION("Educational"),
    LATEST("Latest"),
    CREATOR("Creator"),
    CHANNEL("Channels"),
    PLAYLIST("Playlists")
}

data class VideoChapter(
    val startSeconds: Int,
    val timestampLabel: String,
    val title: String
)

data class YouTubeVideoInfo(
    val videoId: String,
    val title: String,
    val channelId: String = "",
    val channelTitle: String = "",
    val description: String = "",
    val durationSeconds: Int = 0,
    val durationFormatted: String = "",
    val publishedAt: String = "",
    val thumbnailUrl: String = "",
    val viewCount: String = "",
    val isShort: Boolean = false,
    val itemType: YouTubeItemType = YouTubeItemType.VIDEO,
    val playlistId: String = "",
    val sourceUrl: String = "",
    val chapters: List<VideoChapter> = emptyList()
)

enum class TranscriptStatus(val badgeLabel: String) {
    NOT_CHECKED("NOT CHECKED"),
    LOADING("FETCHING CAPTIONS"),
    AVAILABLE("TRANSCRIPT READY"),
    UNAVAILABLE("NO CAPTIONS"),
    RESTRICTED("RESTRICTED"),
    FROM_SCREEN_CONTEXT("SCREEN TEXT ONLY"),
    ERROR("TRANSCRIPT ERROR")
}

data class TranscriptSegment(
    val startSeconds: Double,
    val durationSeconds: Double,
    val timestampLabel: String,
    val text: String
)

data class TranscriptResult(
    val videoId: String,
    val status: TranscriptStatus,
    val languageCode: String = "",
    val availableLanguages: List<String> = emptyList(),
    val segments: List<TranscriptSegment> = emptyList(),
    val rawTextWithTimestamps: String = "",
    val statusReason: String = "",
    val isChunked: Boolean = false,
    val chunkCount: Int = 1
)

enum class SummaryStyle(val label: String) {
    SHORT("Short Summary"),
    DETAILED("Detailed Summary"),
    COMPLETE_TRANSCRIPT("Complete Transcript Summary"),
    TOPIC_WISE("Topic-Wise Explanation"),
    STEP_BY_STEP("Step-by-Step Explanation"),
    IMPORTANT_POINTS("Important Points"),
    PRACTICAL_EXAMPLES("Practical Examples"),
    CHAPTER_WISE("Chapter-Wise Summary")
}

enum class SummaryLanguage(val code: String, val label: String) {
    ENGLISH("en", "English"),
    HINDI("hi", "Hindi (हिन्दी)"),
    HINGLISH("hinglish", "Hinglish")
}

enum class LearningDepth(val label: String) {
    BASIC("Basic Explanation"),
    ADVANCED("Advanced Deep Dive"),
    PRACTICAL("Practical Examples"),
    INTERACTIVE("Interactive Teaching")
}

data class YouTubeChatMessage(
    val id: Long = System.currentTimeMillis(),
    val role: String,
    val content: String,
    val groundedInTranscript: Boolean = false,
    val timestampMs: Long = System.currentTimeMillis()
)

data class GeneratedNotesBundle(
    val topic: String,
    val definitions: String,
    val bulletPoints: String,
    val stepByStep: String,
    val importantTimestamps: String,
    val fullMarkdown: String
)

data class QuizQuestion(
    val index: Int,
    val question: String,
    val options: List<String>,
    val correctIndex: Int,
    val explanation: String,
    val topicTag: String = ""
)

data class QuizQuestionFeedback(
    val index: Int,
    val selectedIndex: Int,
    val correctIndex: Int,
    val isCorrect: Boolean,
    val explanation: String
)

data class QuizEvaluation(
    val totalQuestions: Int,
    val correctCount: Int,
    val scorePercent: Int,
    val summaryMessage: String,
    val feedback: List<QuizQuestionFeedback>
)

data class YouTubeScreenContext(
    val isYouTubeForeground: Boolean,
    val videoTitle: String = "",
    val channelName: String = "",
    val playbackControlVisible: String = "",
    val isFullscreenLikely: Boolean = false,
    val visibleControls: List<String> = emptyList(),
    val searchResults: List<String> = emptyList(),
    val descriptionOrComments: List<String> = emptyList(),
    val rawSnapshot: String = ""
)

sealed class YouTubeVoiceIntent {
    data object OpenYouTube : YouTubeVoiceIntent()
    data object OpenYouTubeAgent : YouTubeVoiceIntent()
    data class SearchVideos(val query: String, val filter: YouTubeSearchFilter = YouTubeSearchFilter.VIDEO) : YouTubeVoiceIntent()
    data object PlayOrResume : YouTubeVoiceIntent()
    data object Pause : YouTubeVoiceIntent()
    data class SeekForward(val seconds: Int = 10) : YouTubeVoiceIntent()
    data class SeekBackward(val seconds: Int = 10) : YouTubeVoiceIntent()
    data object NextVideo : YouTubeVoiceIntent()
    data object PreviousVideo : YouTubeVoiceIntent()
    data object VolumeUp : YouTubeVoiceIntent()
    data object VolumeDown : YouTubeVoiceIntent()
    data class Fullscreen(val enter: Boolean = true) : YouTubeVoiceIntent()
    data object CloseVideo : YouTubeVoiceIntent()
    data class OpenChannel(val query: String) : YouTubeVoiceIntent()
    data class OpenPlaylist(val query: String, val isWatchLater: Boolean = false) : YouTubeVoiceIntent()
    data class SummarizeCurrent(val language: SummaryLanguage? = null) : YouTubeVoiceIntent()
    data class AskAboutVideo(val question: String) : YouTubeVoiceIntent()
    data object GenerateNotes : YouTubeVoiceIntent()
    data object StartLearningOrQuiz : YouTubeVoiceIntent()
    data object ReadYouTubeScreen : YouTubeVoiceIntent()
}

data class YouTubeActionVerification(
    val verified: Boolean,
    val partial: Boolean = false,
    val actionName: String,
    val methodUsed: String,
    val message: String,
    val requiresAccessibilitySetup: Boolean = false,
    val requiresConfirmation: Boolean = false
)
