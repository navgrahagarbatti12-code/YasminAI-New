import express, { Request, Response, NextFunction } from "express";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import crypto from "node:crypto";
import { spawn } from "node:child_process";
import dotenv from "dotenv";
import { GoogleGenAI, Type } from "@google/genai";

dotenv.config();

const GEMINI_MODEL = process.env.GEMINI_MODEL?.trim() || "gemini-2.5-flash";

function getGeminiClient(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY?.trim();
  if (!apiKey || apiKey === "YOUR_GEMINI_API_KEY" || apiKey === "MY_GEMINI_API_KEY") {
    return null;
  }
  return new GoogleGenAI({ apiKey });
}

const rateBucket = new Map<string, { count: number; resetAt: number }>();
function rateLimitMiddleware(req: Request, res: Response, next: NextFunction) {
  const ip = req.ip || req.socket.remoteAddress || "unknown";
  const now = Date.now();
  if (rateBucket.size > 500) {
    for (const [k, v] of rateBucket.entries()) {
      if (now > v.resetAt) rateBucket.delete(k);
    }
  }
  const entry = rateBucket.get(ip);
  if (!entry || now > entry.resetAt) {
    rateBucket.set(ip, { count: 1, resetAt: now + 60_000 });
    return next();
  }
  if (entry.count >= 60) {
    return res.status(429).json({
      error: "Rate limit exceeded (60 requests/minute). Please retry shortly.",
    });
  }
  entry.count += 1;
  return next();
}

function optionalAuthMiddleware(req: Request, res: Response, next: NextFunction) {
  const expectedToken = process.env.YASMIN_PROXY_TOKEN?.trim();
  if (!expectedToken) return next();
  const authHeader = req.headers.authorization || "";
  const expectedHeader = `Bearer ${expectedToken}`;
  const actualBuf = Buffer.from(authHeader, "utf8");
  const expectedBuf = Buffer.from(expectedHeader, "utf8");
  if (
    actualBuf.length === expectedBuf.length &&
    crypto.timingSafeEqual(actualBuf, expectedBuf)
  ) {
    return next();
  }
  return res.status(401).json({
    error: "Unauthorized: Invalid or missing Bearer token.",
  });
}

function buildLanguageDirective(language: string): string {
  if (language === "hi") {
    return "Respond naturally in Hindi (Devanagari script) unless code is requested.";
  }
  if (language === "en") {
    return "Respond in clear, concise, intelligent English.";
  }
  return "Respond in natural Hinglish (friendly mix of conversational Hindi in Roman script and English technical terms) when appropriate, or match the user's language.";
}

function buildPersonalityDirective(personality: string): string {
  switch (personality) {
    case "concise_tactical":
      return "Adopt a crisp, tactical, zero-fluff JARVIS operational tone. Keep replies short and action-focused.";
    case "friendly_companion":
      return "Adopt a warm, polite, encouraging personal companion tone while staying sharp and accurate.";
    case "coding_mentor":
      return "Adopt a senior software architect tone: explain clearly with clean code and edge-case awareness.";
    default:
      return "Adopt a polite, poised, intelligent JARVIS-inspired butler-engineer tone.";
  }
}

function runIsolatedPythonSubprocess(code: string): Promise<{
  success: boolean;
  stdout: string;
  stderr: string;
  error: string;
  elapsedMs: number;
  isolation: string;
}> {
  return new Promise((resolve) => {
    const startMs = Date.now();
    const sandboxDir = fs.mkdtempSync(path.join(os.tmpdir(), "yasmin_py_"));
    const runnerPath = path.join(sandboxDir, "_sandbox_harness.py");

    const harness = `
import ast, contextlib, io, json, resource, socket, sys, time, traceback

MAX_OUTPUT_CHARS = 32768
MAX_EXEC_SECONDS = 4.0
MAX_TRACE_STEPS = 400000
ALLOWED_MODULES = frozenset({
    "math","cmath","random","statistics","json","datetime","re",
    "itertools","functools","collections","decimal","fractions",
    "string","hashlib","base64","time"
})
BLOCKED_ATTRS = frozenset({
    "__subclasses__","__globals__","__builtins__","__class__","__bases__",
    "__mro__","__import__","__code__","__closure__","__dict__","__getattribute__",
    "gi_frame","f_globals","f_locals","f_back","format","format_map"
})
BLOCKED_CALLS = frozenset({
    "open","eval","exec","compile","__import__","input","breakpoint",
    "globals","locals","vars","dir","getattr","setattr","delattr",
    "format","format_map","object"
})

class SecurityError(Exception):
    pass

class SandboxAstValidator(ast.NodeVisitor):
    def visit_Import(self, node):
        for alias in node.names:
            if alias.name.split(".")[0] not in ALLOWED_MODULES:
                raise SecurityError(f"Import blocked: '{alias.name}'")
        self.generic_visit(node)
    def visit_ImportFrom(self, node):
        mod = (node.module or "").split(".")[0]
        if mod not in ALLOWED_MODULES:
            raise SecurityError(f"Import blocked: '{node.module}'")
        self.generic_visit(node)
    def visit_Attribute(self, node):
        if node.attr in BLOCKED_ATTRS or node.attr.startswith("_"):
            raise SecurityError(f"Attribute blocked: '{node.attr}'")
        self.generic_visit(node)
    def visit_Name(self, node):
        if node.id in BLOCKED_CALLS or node.id.startswith("__"):
            raise SecurityError(f"Builtin blocked: '{node.id}'")
        self.generic_visit(node)
    def visit_Call(self, node):
        if isinstance(node.func, ast.Attribute) and node.func.attr in ("format", "format_map"):
            raise SecurityError("str.format/format_map is blocked in sandbox; use f-strings instead.")
        self.generic_visit(node)

for lim, val in [
    (resource.RLIMIT_CPU, (4, 4)),
    (resource.RLIMIT_FSIZE, (0, 0)),
    (resource.RLIMIT_NOFILE, (16, 16)),
]:
    try:
        resource.setrlimit(lim, val)
    except Exception:
        pass
try:
    resource.setrlimit(resource.RLIMIT_AS, (128 * 1024 * 1024, 128 * 1024 * 1024))
except Exception:
    pass

def _blocked_net(*args, **kwargs):
    raise SecurityError("Network access blocked inside Yasmin sandbox")
socket.socket = _blocked_net
socket.create_connection = _blocked_net

def _safe_import(name, globals=None, locals=None, fromlist=(), level=0):
    if str(name).split(".")[0] not in ALLOWED_MODULES:
        raise ImportError(f"Module '{name}' is not permitted.")
    return __import__(name, globals, locals, fromlist, level)

SAFE_BUILTINS = {
    "print": print, "len": len, "range": range, "enumerate": enumerate, "zip": zip,
    "map": map, "filter": filter, "sum": sum, "min": min, "max": max, "abs": abs,
    "round": round, "pow": pow, "divmod": divmod, "sorted": sorted, "reversed": reversed,
    "any": any, "all": all, "int": int, "float": float, "str": str, "bool": bool,
    "list": list, "dict": dict, "set": set, "tuple": tuple, "frozenset": frozenset,
    "chr": chr, "ord": ord, "hex": hex, "bin": bin, "oct": oct, "repr": repr,
    "isinstance": isinstance, "issubclass": issubclass, "type": type,
    "Exception": Exception, "ValueError": ValueError, "TypeError": TypeError,
    "KeyError": KeyError, "IndexError": IndexError, "ZeroDivisionError": ZeroDivisionError,
    "RuntimeError": RuntimeError, "__import__": _safe_import,
}

user_code = sys.stdin.read()
out_buf, err_buf = io.StringIO(), io.StringIO()
success, error_msg, steps = True, "", 0
t0 = time.monotonic()

def watchdog(frame, event, arg):
    global steps
    steps += 1
    if steps > MAX_TRACE_STEPS:
        raise TimeoutError(f"Exceeded {MAX_TRACE_STEPS} bytecode steps.")
    if (steps & 1023) == 0 and (time.monotonic() - t0) > MAX_EXEC_SECONDS:
        raise TimeoutError(f"Exceeded {MAX_EXEC_SECONDS}s execution timeout.")
    return watchdog

try:
    tree = ast.parse(user_code, filename="<isolated.py>", mode="exec")
    SandboxAstValidator().visit(tree)
    compiled = compile(tree, "<isolated.py>", "exec")
    ns = {"__builtins__": SAFE_BUILTINS, "__name__": "__main__"}
    sys.settrace(watchdog)
    try:
        with contextlib.redirect_stdout(out_buf), contextlib.redirect_stderr(err_buf):
            exec(compiled, ns, ns)
    finally:
        sys.settrace(None)
except SecurityError as se:
    success = False
    error_msg = f"Sandbox Security Policy Violation: {se}"
except TimeoutError as te:
    success = False
    error_msg = f"Sandbox Resource Limit: {te}"
except SyntaxError as sy:
    success = False
    error_msg = f"SyntaxError at line {sy.lineno}: {sy.msg}"
except Exception:
    success = False
    error_msg = traceback.format_exc()

stdout_v = out_buf.getvalue()[:MAX_OUTPUT_CHARS]
if len(out_buf.getvalue()) > MAX_OUTPUT_CHARS:
    stdout_v += "\\n... [Output truncated at 32 KB limit]"
stderr_v = err_buf.getvalue()[:MAX_OUTPUT_CHARS]

print(json.dumps({
    "success": success,
    "stdout": stdout_v,
    "stderr": stderr_v,
    "error": error_msg,
    "elapsedMs": int((time.monotonic() - t0) * 1000),
    "isolation": "subprocess-rlimit-ast"
}))
`;

    fs.writeFileSync(runnerPath, harness, "utf8");

    const child = spawn("python3", ["-I", "-B", runnerPath], {
      cwd: sandboxDir,
      env: { PATH: "/usr/local/bin:/usr/bin:/bin", PYTHONDONTWRITEBYTECODE: "1" },
      stdio: ["pipe", "pipe", "pipe"],
    });

    let rawStdout = "";
    let rawStderr = "";
    let killedByTimeout = false;

    const killTimer = setTimeout(() => {
      killedByTimeout = true;
      child.kill("SIGKILL");
    }, 4500);

    child.stdout.on("data", (chunk) => {
      if (rawStdout.length < 48000) rawStdout += chunk.toString("utf8");
    });
    child.stderr.on("data", (chunk) => {
      if (rawStderr.length < 16000) rawStderr += chunk.toString("utf8");
    });

    child.on("close", () => {
      clearTimeout(killTimer);
      try {
        fs.rmSync(sandboxDir, { recursive: true, force: true });
      } catch {
        // Ignore cleanup failure
      }
      if (killedByTimeout) {
        return resolve({
          success: false,
          stdout: "",
          stderr: "",
          error: "Process terminated (SIGKILL): exceeded 4.5s subprocess execution timeout.",
          elapsedMs: Date.now() - startMs,
          isolation: "subprocess-rlimit-ast",
        });
      }
      try {
        return resolve(JSON.parse(rawStdout.trim()));
      } catch {
        return resolve({
          success: false,
          stdout: rawStdout.slice(0, 8000),
          stderr: rawStderr.slice(0, 8000),
          error: rawStderr || "Subprocess exited without JSON payload.",
          elapsedMs: Date.now() - startMs,
          isolation: "subprocess-rlimit-ast",
        });
      }
    });

    child.on("error", (err) => {
      clearTimeout(killTimer);
      try {
        fs.rmSync(sandboxDir, { recursive: true, force: true });
      } catch {
        // Ignore
      }
      resolve({
        success: false,
        stdout: "",
        stderr: "",
        error: `Failed to spawn python3 subprocess: ${err.message}`,
        elapsedMs: Date.now() - startMs,
        isolation: "subprocess-rlimit-ast",
      });
    });

    child.stdin.write(code);
    child.stdin.end();
  });
}

const app = express();
const PORT = Number(process.env.PORT || 3000);
app.use(express.json({ limit: "10mb" }));

app.get("/api/health", (_req, res) => {
  res.json({
    ok: true,
    service: "yasmin-ai-backend-v3",
    geminiConfigured: Boolean(getGeminiClient()),
    authRequired: Boolean(process.env.YASMIN_PROXY_TOKEN?.trim()),
    sandboxIsolation: "subprocess-rlimit-ast",
    timestamp: new Date().toISOString(),
  });
});

app.post("/api/sandbox/python", rateLimitMiddleware, optionalAuthMiddleware, async (req, res) => {
  const { code } = req.body ?? {};
  if (typeof code !== "string" || code.trim().length === 0 || code.length > 32000) {
    return res.status(400).json({ error: "Field 'code' must be a non-empty string under 32,000 chars." });
  }
  return res.json(await runIsolatedPythonSubprocess(code));
});

app.post("/api/gemini/chat", rateLimitMiddleware, optionalAuthMiddleware, async (req, res) => {
  const ai = getGeminiClient();
  if (!ai) return res.status(503).json({ error: "GEMINI_API_KEY is not configured." });

  const {
    message,
    language = "hinglish",
    personality = "jarvis_formal",
    history = [],
    memories = [],
    userName = "Commander",
    enableWebSearch = true,
  } = req.body ?? {};

  if (!message || typeof message !== "string" || message.length > 12000) {
    return res.status(400).json({ error: "Field 'message' must be a non-empty string under 12,000 chars." });
  }

  const memoryBlock =
    Array.isArray(memories) && memories.length > 0
      ? `User-approved personal context:\n${memories
          .slice(0, 12)
          .map((m: { keyTitle?: string; content?: string }) => `- ${m.keyTitle ?? "Note"}: ${m.content ?? ""}`)
          .join("\n")}\n\n`
      : "";
  const historyText = Array.isArray(history)
    ? history
        .slice(-10)
        .map((t: { role?: string; content?: string }) => `${t.role === "user" ? "User" : "Yasmin"}: ${t.content ?? ""}`)
        .join("\n")
    : "";
  const prompt = `${memoryBlock}${historyText ? `Recent conversation:\n${historyText}\n\n` : ""}Current message from ${userName}:\n${message}`;

  try {
    const response = await ai.models.generateContent({
      model: GEMINI_MODEL,
      contents: prompt,
      config: {
        systemInstruction: `You are Yasmin AI 3.0, a JARVIS-inspired personal AI assistant for ${userName}. ${buildPersonalityDirective(
          personality
        )} ${buildLanguageDirective(language)}`,
        tools: enableWebSearch ? [{ googleSearch: {} }] : undefined,
      },
    });
    const chunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks ?? [];
    const sources = chunks
      .filter((c: { web?: { uri?: string; title?: string } }) => c.web?.uri)
      .slice(0, 4)
      .map((c: { web?: { uri?: string; title?: string } }) => ({
        title: c.web?.title || c.web?.uri || "Source",
        uri: c.web?.uri || "",
      }));
    return res.json({ reply: response.text ?? "", sources });
  } catch (error: unknown) {
    return res.status(502).json({ error: error instanceof Error ? error.message : "Gemini chat failed." });
  }
});

app.post("/api/gemini/stream", rateLimitMiddleware, optionalAuthMiddleware, async (req, res) => {
  const ai = getGeminiClient();
  if (!ai) return res.status(503).json({ error: "GEMINI_API_KEY is not configured." });

  const {
    message,
    language = "hinglish",
    personality = "jarvis_formal",
    history = [],
    memories = [],
    userName = "Commander",
  } = req.body ?? {};
  if (!message || typeof message !== "string") {
    return res.status(400).json({ error: "Field 'message' is required." });
  }

  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache");
  res.setHeader("Connection", "keep-alive");

  const memoryBlock =
    Array.isArray(memories) && memories.length > 0
      ? `Personal context:\n${memories
          .slice(0, 10)
          .map((m: { keyTitle?: string; content?: string }) => `- ${m.keyTitle ?? "Note"}: ${m.content ?? ""}`)
          .join("\n")}\n\n`
      : "";
  const historyText = Array.isArray(history)
    ? history
        .slice(-8)
        .map((t: { role?: string; content?: string }) => `${t.role === "user" ? "User" : "Yasmin"}: ${t.content ?? ""}`)
        .join("\n")
    : "";
  const prompt = `${memoryBlock}${historyText ? `Recent conversation:\n${historyText}\n\n` : ""}User (${userName}):\n${message}`;

  try {
    const stream = await ai.models.generateContentStream({
      model: GEMINI_MODEL,
      contents: prompt,
      config: {
        systemInstruction: `You are Yasmin AI 3.0 for ${userName}. ${buildPersonalityDirective(
          personality
        )} ${buildLanguageDirective(language)}`,
      },
    });
    for await (const chunk of stream) {
      const text = chunk.text ?? "";
      if (text) res.write(`data: ${JSON.stringify({ delta: text })}\n\n`);
    }
    res.write(`data: ${JSON.stringify({ done: true })}\n\n`);
    return res.end();
  } catch (error: unknown) {
    res.write(`data: ${JSON.stringify({ error: error instanceof Error ? error.message : "Streaming error." })}\n\n`);
    return res.end();
  }
});

app.post("/api/gemini/agent", rateLimitMiddleware, optionalAuthMiddleware, async (req, res) => {
  const ai = getGeminiClient();
  if (!ai) return res.status(503).json({ error: "GEMINI_API_KEY is not configured." });

  const {
    message,
    language = "hinglish",
    personality = "jarvis_formal",
    memories = [],
    pendingTasks = [],
    userName = "Commander",
  } = req.body ?? {};
  if (!message || typeof message !== "string") {
    return res.status(400).json({ error: "Field 'message' is required." });
  }

  try {
    const response = await ai.models.generateContent({
      model: GEMINI_MODEL,
      contents: `User (${userName}): ${message}\nKnown memories: ${JSON.stringify(
        memories.slice(0, 8)
      )}\nPending tasks: ${JSON.stringify(pendingTasks.slice(0, 8))}`,
      config: {
        systemInstruction: `Analyze natural language and map to safe Android tool actions when applicable. ${buildPersonalityDirective(
          personality
        )} ${buildLanguageDirective(language)}`,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            reply: { type: Type.STRING },
            actions: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  tool: { type: Type.STRING },
                  arg1: { type: Type.STRING },
                  arg2: { type: Type.STRING },
                  arg3: { type: Type.STRING },
                },
                required: ["tool"],
              },
            },
          },
          required: ["reply", "actions"],
        },
      },
    });
    return res.json(JSON.parse((response.text ?? "{}").trim()));
  } catch (error: unknown) {
    return res.status(502).json({ error: error instanceof Error ? error.message : "Agent planning failed." });
  }
});

app.post("/api/assistant/briefing", rateLimitMiddleware, optionalAuthMiddleware, async (req, res) => {
  const ai = getGeminiClient();
  if (!ai) return res.status(503).json({ error: "GEMINI_API_KEY is not configured." });

  const {
    cityOrContext = "",
    pendingTasks = [],
    upcomingEvents = [],
    language = "hinglish",
    personality = "jarvis_formal",
    userName = "Commander",
  } = req.body ?? {};

  try {
    const response = await ai.models.generateContent({
      model: GEMINI_MODEL,
      contents: `Prepare a crisp JARVIS daily briefing for ${userName}. Context: ${cityOrContext || "General"}. Tasks: ${JSON.stringify(
        pendingTasks.slice(0, 6)
      )}. Events: ${JSON.stringify(upcomingEvents.slice(0, 5))}`,
      config: {
        systemInstruction: `You are Yasmin AI 3.0. ${buildPersonalityDirective(personality)} ${buildLanguageDirective(
          language
        )}`,
        tools: [{ googleSearch: {} }],
      },
    });
    const chunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks ?? [];
    const sources = chunks
      .filter((c: { web?: { uri?: string; title?: string } }) => c.web?.uri)
      .slice(0, 4)
      .map((c: { web?: { uri?: string; title?: string } }) => ({
        title: c.web?.title || c.web?.uri || "Source",
        uri: c.web?.uri || "",
      }));
    return res.json({ reply: response.text ?? "", sources });
  } catch (error: unknown) {
    return res.status(502).json({ error: error instanceof Error ? error.message : "Briefing request failed." });
  }
});

app.post("/api/gemini/code", rateLimitMiddleware, optionalAuthMiddleware, async (req, res) => {
  const ai = getGeminiClient();
  if (!ai) return res.status(503).json({ error: "GEMINI_API_KEY is not configured." });

  const { prompt, target = "python", existingCode = "", errorOutput = "" } = req.body ?? {};
  if (!prompt || typeof prompt !== "string") {
    return res.status(400).json({ error: "Field 'prompt' is required." });
  }

  try {
    if (target === "web") {
      const response = await ai.models.generateContent({
        model: GEMINI_MODEL,
        contents: `User request: ${prompt}\n\nExisting code:\n${existingCode}`,
        config: {
          systemInstruction: "Return clean, responsive HTML, CSS, and vanilla JavaScript.",
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              html: { type: Type.STRING },
              css: { type: Type.STRING },
              js: { type: Type.STRING },
              explanation: { type: Type.STRING },
            },
            required: ["html", "css", "js", "explanation"],
          },
        },
      });
      return res.json(JSON.parse((response.text ?? "{}").trim()));
    }

    const response = await ai.models.generateContent({
      model: GEMINI_MODEL,
      contents: `Target: ${target}\nRequest: ${prompt}\n\nExisting code:\n${existingCode}\n\nError output:\n${errorOutput}`,
      config: {
        systemInstruction:
          "Produce runnable Python compatible with Yasmin sandbox (allowed modules: math, random, statistics, json, datetime, re, itertools, functools, collections, decimal, fractions, string, hashlib, base64, time — no os/sys/open/socket, and use f-strings instead of .format()).",
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            code: { type: Type.STRING },
            explanation: { type: Type.STRING },
          },
          required: ["code", "explanation"],
        },
      },
    });
    return res.json(JSON.parse((response.text ?? "{}").trim()));
  } catch (error: unknown) {
    return res.status(502).json({ error: error instanceof Error ? error.message : "Code generation failed." });
  }
});

app.post("/api/gemini/vision", rateLimitMiddleware, optionalAuthMiddleware, async (req, res) => {
  const ai = getGeminiClient();
  if (!ai) return res.status(503).json({ error: "GEMINI_API_KEY is not configured." });

  const {
    prompt = "Analyze this image clearly.",
    imageBase64,
    mimeType = "image/jpeg",
    language = "hinglish",
    mode = "general",
  } = req.body ?? {};

  if (!imageBase64 || typeof imageBase64 !== "string" || imageBase64.length > 8_000_000) {
    return res.status(400).json({ error: "Field 'imageBase64' is required and must be under 8 MB." });
  }
  const allowedMime = new Set(["image/jpeg", "image/png", "image/webp"]);
  if (!allowedMime.has(mimeType)) {
    return res.status(400).json({ error: "Unsupported mimeType." });
  }

  try {
    const response = await ai.models.generateContent({
      model: GEMINI_MODEL,
      contents: {
        parts: [
          { inlineData: { mimeType, data: imageBase64 } },
          { text: `Mode: ${mode}\nQuestion: ${prompt}\n${buildLanguageDirective(language)}` },
        ],
      },
    });
    return res.json({ reply: response.text ?? "" });
  } catch (error: unknown) {
    return res.status(502).json({ error: error instanceof Error ? error.message : "Vision analysis failed." });
  }
});

app.listen(PORT, "0.0.0.0", () => {
  console.log(`Yasmin AI 3.0 Standalone Backend running on http://0.0.0.0:${PORT}`);
});
