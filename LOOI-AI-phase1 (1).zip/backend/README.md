# Yasmin AI 3.0 Standalone Backend Proxy

This directory contains the standalone Node.js + Express + Gemini AI proxy server and OS-isolated Python 3 sandbox used by the Yasmin AI Android app.

## Endpoints

- `GET /api/health` — Readiness check (`geminiConfigured`, `authRequired`, `sandboxIsolation`)
- `POST /api/gemini/chat` — Conversational AI with memories, history & Google Search Grounding
- `POST /api/gemini/stream` — Server-Sent Events (SSE) token streaming
- `POST /api/gemini/agent` — Natural-language intent & Android tool planner (JSON schema)
- `POST /api/gemini/code` — Python & Web HTML/CSS/JS code generation / explanation / repair
- `POST /api/gemini/vision` — Multimodal image, OCR, document & UI screenshot analysis
- `POST /api/assistant/briefing` — Weather, news & daily task/calendar briefing
- `POST /api/sandbox/python` — OS-isolated Python 3 subprocess sandbox (`-I -B`, `RLIMIT_*`, scrubbed env, `4.5s` `SIGKILL`)

## Quick Deploy

```bash
cp .env.example .env
# Set GEMINI_API_KEY and optional YASMIN_PROXY_TOKEN in .env
npm install
npm start
```

Or deploy directly to Google Cloud Run / Railway / Render using the included `Dockerfile`. Then paste your HTTPS service URL and optional `YASMIN_PROXY_TOKEN` into **Yasmin AI → Settings**.
