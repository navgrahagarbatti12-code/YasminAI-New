# Yasmin AI – Part 3: Universal Screen Reading, ChatGPT Reading, AI Vision Repair

Real Accessibility-based screen reading plus a consent-gated screenshot fallback. No fake screen reader.

## Honest status

| Item | Status |
|---|---|
| Pure logic (command parser, ChatGPT parser, model selection) | Compiled with kotlinc 1.9.24 and 15 unit tests passed (in a JUnit stand-in) |
| Android code (service, reader, capture, ViewModel, UI) | **Written but NOT compiled here** (no Android SDK in my environment). First GitHub Actions run is the real compile check. |
| On-device behaviour in ChatGPT / YouTube / Chrome / Settings | **NOT TESTED** – see `docs/TEST_MATRIX.md` |

This zip is a standalone project built because your existing source files were not attached.
Files that replace/merge into yours are listed in `docs/INTEGRATION.md`.

## Build on GitHub

1. Create a repo, upload the *contents* of this folder (keep `.github/`).
2. Push. Actions → "Build Yasmin Part 3" runs unit tests and builds a debug APK (artifact: `yasmin-part3-debug-apk`).
3. No Gradle wrapper is committed; the workflow installs Gradle 8.7. Locally: `gradle wrapper --gradle-version 8.7`.

If the build fails, send me the log and I will fix it.

## Use

1. Install APK → "Open Accessibility settings" → enable **Yasmin AI – Screen Reading**.
2. Enter a Gemini and/or Groq API key (memory only, never saved).
3. Open ChatGPT (or any app), then say/type a command. Use **Read after 5 s** to give yourself time to switch apps.

Commands: Read my screen · Screen padho · ChatGPT screen read karo · What is on my screen? · Read the text · Explain this page · Read YouTube screen · Read Chrome screen · Summarize visible content · Read the current app · ChatGPT ne kya answer diya? · ChatGPT ka text Yasmin ko dikhao · Is answer ko Hindi mein samjhao · ChatGPT ke answer ka summary banao · Analyze my screenshot

## Flow

- **Read commands**: read via Accessibility → show text/controls → speak locally. **Nothing goes to the cloud.**
- **Explain / Summarize / Hindi**: read → show extracted text → **consent dialog showing the exact text** → Gemini or Groq → show + speak actual response.
- **Screenshot** (offered when Accessibility returns empty/partial, or by command): Gemini key + vision-capable model check → Android screen-capture consent → one capture → **privacy review dialog with the image** → send → extracted text + description with `[unreadable]`/`[uncertain]` markers. Runs automatically after approval; **Analyze (manual)** remains optional.

## Privacy and safety design

- Event handler stores only a timestamp. No monitoring; reading happens only on a user request.
- Password inputs, password-type input variations, and fields whose id/hint/description says OTP/PIN/CVV/etc. are never read (reported as "hidden").
- Invisible nodes are skipped; `flagIncludeNotImportantViews` is NOT used, so apps' own exposure choices are respected.
- FLAG_SECURE / DRM: black frame is detected and reported; no bypass attempted.
- Screen text is wrapped as untrusted data in prompts (prompt-injection mitigation).
- Screenshot bitmap is recycled after analysis. Keys are in memory only.

## Known limitations (not hidden)

- ChatGPT roles are assigned **only** from explicit evidence (text prefix, content description, view id). Alignment is not used. If the UI exposes none, blocks are shown as "Unlabelled".
- Reading order = the app's accessibility tree order; some apps expose it imperfectly.
- Only the currently visible/exposed part of a scrolling list is read; the tool does not auto-scroll.
- "Gemini vision-capable" is a name-family heuristic over the live model list (the API has no vision flag); API rejection is surfaced as an error.
- Groq is text-only here (vision support not verified per model).
- Android shows its capture consent every time; on Android 14+ users may pick one app instead of the whole screen. Returning to Yasmin after capture may need the "Screenshot captured" notification (background activity launches are restricted).
- Voice input is not included; `ScreenCommandParser.parse()` takes the text from your existing recognizer.
