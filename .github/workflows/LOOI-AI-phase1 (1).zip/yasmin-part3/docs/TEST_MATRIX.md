# Test matrix

Statuses: SUCCESS / PARTIAL / FAILED / PERMISSION REQUIRED / NOT TESTED.
**Every device row is NOT TESTED**: no device or emulator was available. Fill these in after running the APK.
"Expectation" is a hypothesis to check, not a result.

| Target | Command | Status | Expectation to verify |
|---|---|---|---|
| ChatGPT app | ChatGPT screen read karo | NOT TESTED | Text exposed; roles may be Unlabelled |
| ChatGPT app | ChatGPT ne kya answer diya? | NOT TESTED | Same, shows conversation order |
| ChatGPT app | Is answer ko Hindi mein samjhao | NOT TESTED | Consent dialog appears, Hindi reply spoken |
| ChatGPT app | ChatGPT ke answer ka summary banao | NOT TESTED | Consent dialog, summary shown/spoken |
| YouTube | Read YouTube screen | NOT TESTED | Titles/buttons likely; video frame not readable |
| Chrome | Read Chrome screen | NOT TESTED | Page text/links likely; some content may be missing |
| Settings | Read the current app | NOT TESTED | Rows and toggle states with on/off |
| Another app | Read my screen | NOT TESTED | App-dependent |
| Custom-drawn/game screen | Read my screen | NOT TESTED | Empty → fallback offered |
| Screenshot fallback | Analyze my screenshot | NOT TESTED | Needs Gemini key, capture consent, privacy review |
| FLAG_SECURE app | Analyze my screenshot | NOT TESTED | Black frame detected and reported, no bypass |
| Login screen | Read my screen | NOT TESTED | Password/OTP fields reported as hidden |
| Accessibility disabled | Read my screen | PERMISSION REQUIRED (by design) | Clear message + settings button |
| Capture dialog denied | Analyze my screenshot | PERMISSION REQUIRED (by design) | "Nothing was captured" |

Automated (JVM, via a JUnit stand-in in my environment): command parsing, ChatGPT role/merge rules, model selection — 15/15 passed.
