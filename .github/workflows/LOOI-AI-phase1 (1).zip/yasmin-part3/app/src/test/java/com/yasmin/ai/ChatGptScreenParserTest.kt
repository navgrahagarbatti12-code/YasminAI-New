package com.yasmin.ai

import com.yasmin.ai.screen.*
import org.junit.Assert.*
import org.junit.Test

class ChatGptScreenParserTest {
    private fun el(order: Int, text: String, desc: String? = null, id: String? = null,
                   clickable: Boolean = false, heading: Boolean = false, kind: ElementKind = ElementKind.TEXT) =
        ScreenElement(order, kind, text, desc, id, null, clickable, heading)

    private fun snap(vararg e: ScreenElement) =
        ScreenSnapshot("com.openai.chatgpt", "ChatGPT", null, e.toList(), emptyList(), emptyList())

    @Test fun detection() {
        assertTrue(ChatGptScreenParser.isChatGpt("com.openai.chatgpt", null))
        assertTrue(ChatGptScreenParser.isChatGpt("some.other.pkg", "ChatGPT"))
        assertFalse(ChatGptScreenParser.isChatGpt("com.android.chrome", "Chrome"))
    }

    @Test fun rolesOnlyFromEvidence() {
        val r = ChatGptScreenParser.parse(snap(
            el(0, "ChatGPT", heading = true),
            el(1, "What is photosynthesis in simple words please", desc = "You said: What is photosynthesis in simple words please"),
            el(2, "Plants turn sunlight into food.", id = "com.openai.chatgpt:id/assistant_message"),
            el(3, "Copy", clickable = true),
            el(4, "Message ChatGPT", kind = ElementKind.INPUT)
        ))
        assertEquals(2, r.messages.size)
        assertEquals(MessageRole.USER, r.messages[0].role)
        assertEquals(MessageRole.ASSISTANT, r.messages[1].role)
        assertTrue(r.rolesIdentified)
    }

    @Test fun noEvidenceMeansUnknown() {
        val r = ChatGptScreenParser.parse(snap(
            el(0, "Tell me a long story about a dragon who loves tea"),
            el(1, "Once upon a time there was a dragon that loved tea more than gold.")
        ))
        assertEquals(2, r.messages.size)
        assertTrue(r.messages.all { it.role == MessageRole.UNKNOWN })
        assertFalse(r.rolesIdentified)
    }

    @Test fun mergesOnlySameExplicitRole() {
        val a = "com.openai.chatgpt:id/assistant_text"
        val r = ChatGptScreenParser.parse(snap(el(0, "Paragraph one is here.", id = a), el(1, "Paragraph two is here.", id = a)))
        assertEquals(1, r.messages.size)
        assertTrue(r.messages[0].text.contains("two"))
    }
}
