package com.yasmin.ai

import com.yasmin.ai.ai.GeminiModel
import com.yasmin.ai.ai.ModelSelection
import org.junit.Assert.*
import org.junit.Test

class ModelSelectionTest {
    private val models = listOf(
        GeminiModel("gemini-embedding-001", true),
        GeminiModel("gemini-2.5-flash-preview-tts", true),
        GeminiModel("gemini-x-pro", true),
        GeminiModel("gemini-x-flash-preview", true),
        GeminiModel("gemini-x-flash-lite", true),
        GeminiModel("gemini-x-flash", true),
        GeminiModel("gemini-x-flash-nogen", false),
        GeminiModel("text-bison", true)
    )

    @Test fun prefersStableFlash() = assertEquals("gemini-x-flash", ModelSelection.pickGemini(models, true)?.id)

    @Test fun excludesNonVisionAndNonGenerate() {
        assertFalse(GeminiModel("gemini-embedding-001", true).visionLikely)
        assertFalse(GeminiModel("gemini-2.5-flash-preview-tts", true).visionLikely)
        assertFalse(GeminiModel("gemini-x-flash", false).visionLikely)
        assertFalse(GeminiModel("text-bison", true).visionLikely)
    }

    @Test fun noVisionModelMeansNull() =
        assertNull(ModelSelection.pickGemini(listOf(GeminiModel("gemini-embedding-001", true)), true))

    @Test fun groqSkipsAudioAndGuard() {
        assertEquals("llama-x-versatile",
            ModelSelection.pickGroqText(listOf("whisper-large-v3", "llama-guard-x", "llama-x-versatile", "playai-tts")))
        assertNull(ModelSelection.pickGroqText(listOf("whisper-large-v3")))
    }
}
