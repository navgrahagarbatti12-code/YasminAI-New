package com.yasmin.ai.ai

import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

internal data class HttpResult(val code: Int, val body: String)

internal object Http {
    suspend fun send(method: String, url: String, headers: Map<String, String>, body: String? = null): HttpResult =
        withContext(Dispatchers.IO) {
            val c = URL(url).openConnection() as HttpURLConnection
            try {
                c.requestMethod = method
                c.connectTimeout = 15_000
                c.readTimeout = 90_000
                headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
                if (body != null) {
                    c.doOutput = true
                    c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
                }
                val code = c.responseCode
                val stream = if (code in 200..299) c.inputStream else c.errorStream
                HttpResult(code, stream?.bufferedReader()?.use { it.readText() }.orEmpty())
            } finally {
                c.disconnect()
            }
        }

    fun explain(code: Int, body: String, provider: String): AiException {
        val apiMsg = try { JSONObject(body).optJSONObject("error")?.optString("message") } catch (_: Exception) { null }
        val base = when (code) {
            400 -> "$provider rejected the request"
            401, 403 -> "$provider rejected the API key (or access is not allowed)"
            404 -> "$provider model not found"
            429 -> "$provider rate limit or quota reached"
            in 500..599 -> "$provider server error"
            else -> "$provider returned HTTP $code"
        }
        return AiException(if (apiMsg.isNullOrBlank()) base else "$base: ${apiMsg.take(300)}")
    }
}

class GeminiClient(private val apiKey: String) {
    private val base = "https://generativelanguage.googleapis.com/v1beta"
    private var cached: List<GeminiModel>? = null

    private fun headers() = mapOf("x-goog-api-key" to apiKey, "Content-Type" to "application/json")

    suspend fun listModels(): List<GeminiModel> {
        cached?.let { return it }
        val out = ArrayList<GeminiModel>()
        var token: String? = null
        try {
            var pages = 0
            do {
                val url = "$base/models?pageSize=100" + (token?.let { "&pageToken=$it" } ?: "")
                val r = Http.send("GET", url, headers())
                if (r.code !in 200..299) throw Http.explain(r.code, r.body, "Gemini")
                val j = JSONObject(r.body)
                val arr = j.optJSONArray("models") ?: JSONArray()
                for (i in 0 until arr.length()) {
                    val m = arr.getJSONObject(i)
                    val methods = m.optJSONArray("supportedGenerationMethods")
                    val gen = (0 until (methods?.length() ?: 0)).any { methods!!.getString(it) == "generateContent" }
                    out += GeminiModel(m.optString("name").removePrefix("models/"), gen)
                }
                token = j.optString("nextPageToken").takeIf { it.isNotEmpty() }
                pages++
            } while (token != null && pages < 5)
        } catch (e: IOException) {
            throw AiException("Could not reach Gemini. Check your internet connection.", e)
        }
        cached = out
        return out
    }

    /** Throws AiException if no suitable model is available. */
    suspend fun resolveModel(requireVision: Boolean): String {
        val models = listModels()
        return ModelSelection.pickGemini(models, requireVision)?.id
            ?: throw AiException(
                if (requireVision) "No vision-capable Gemini model is available for this API key."
                else "No Gemini text model is available for this API key."
            )
    }

    suspend fun generateText(prompt: String): String =
        generate(resolveModel(false), prompt, null)

    suspend fun generate(model: String, prompt: String, jpeg: ByteArray?): String {
        val parts = JSONArray().put(JSONObject().put("text", prompt))
        if (jpeg != null) {
            parts.put(
                JSONObject().put(
                    "inline_data",
                    JSONObject().put("mime_type", "image/jpeg")
                        .put("data", Base64.encodeToString(jpeg, Base64.NO_WRAP))
                )
            )
        }
        val body = JSONObject().put("contents", JSONArray().put(JSONObject().put("parts", parts))).toString()
        val r = try {
            Http.send("POST", "$base/models/$model:generateContent", headers(), body)
        } catch (e: IOException) {
            throw AiException("Could not reach Gemini. Check your internet connection.", e)
        }
        if (r.code !in 200..299) throw Http.explain(r.code, r.body, "Gemini ($model)")
        val j = JSONObject(r.body)
        val cand = j.optJSONArray("candidates")?.optJSONObject(0)
        if (cand == null) {
            val block = j.optJSONObject("promptFeedback")?.optString("blockReason").orEmpty()
            throw AiException("Gemini returned no answer" + if (block.isNotEmpty()) " (blocked: $block)." else ".")
        }
        val partsOut = cand.optJSONObject("content")?.optJSONArray("parts")
        val sb = StringBuilder()
        for (i in 0 until (partsOut?.length() ?: 0)) sb.append(partsOut!!.getJSONObject(i).optString("text"))
        val text = sb.toString().trim()
        if (text.isEmpty()) throw AiException("Gemini returned an empty answer (finish reason: ${cand.optString("finishReason")}).")
        return text
    }
}

/** Text only. Vision is deliberately not offered for Groq: support varies by model and is not verified here. */
class GroqClient(private val apiKey: String) {
    private val base = "https://api.groq.com/openai/v1"
    private var model: String? = null

    private fun headers() = mapOf("Authorization" to "Bearer $apiKey", "Content-Type" to "application/json")

    private suspend fun resolveModel(): String {
        model?.let { return it }
        val r = try { Http.send("GET", "$base/models", headers()) }
        catch (e: IOException) { throw AiException("Could not reach Groq. Check your internet connection.", e) }
        if (r.code !in 200..299) throw Http.explain(r.code, r.body, "Groq")
        val data = JSONObject(r.body).optJSONArray("data") ?: JSONArray()
        val ids = (0 until data.length()).map { data.getJSONObject(it) }
            .filter { it.optBoolean("active", true) }.map { it.getString("id") }
        val chosen = ModelSelection.pickGroqText(ids) ?: throw AiException("No Groq chat model is available for this API key.")
        model = chosen
        return chosen
    }

    suspend fun generate(prompt: String): String {
        val m = resolveModel()
        val body = JSONObject()
            .put("model", m)
            .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", prompt)))
            .put("max_tokens", 1500)
            .toString()
        val r = try { Http.send("POST", "$base/chat/completions", headers(), body) }
        catch (e: IOException) { throw AiException("Could not reach Groq. Check your internet connection.", e) }
        if (r.code !in 200..299) throw Http.explain(r.code, r.body, "Groq ($m)")
        val text = JSONObject(r.body).optJSONArray("choices")?.optJSONObject(0)
            ?.optJSONObject("message")?.optString("content")?.trim().orEmpty()
        if (text.isEmpty()) throw AiException("Groq returned an empty answer.")
        return text
    }
}
