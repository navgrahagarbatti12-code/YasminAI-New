package com.yasmin.ai.screen

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.view.WindowManager
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull

data class CaptureOutcome(val bitmap: Bitmap?, val blankSuspected: Boolean, val error: String?)

/**
 * One-shot screenshot via MediaProjection. A new system consent is required for every capture
 * (Android 14+ makes the token single-use). FLAG_SECURE / DRM content arrives as a black frame;
 * we detect and REPORT that — we never try to bypass it.
 */
object ScreenCaptureManager {
    @Volatile private var pending: CompletableDeferred<CaptureOutcome>? = null

    fun createConsentIntent(context: Context): Intent =
        context.getSystemService(MediaProjectionManager::class.java).createScreenCaptureIntent()

    fun prepare(): CompletableDeferred<CaptureOutcome> {
        pending?.cancel()
        return CompletableDeferred<CaptureOutcome>().also { pending = it }
    }

    fun deliver(outcome: CaptureOutcome) { pending?.complete(outcome) }

    suspend fun captureFrame(context: Context, projection: MediaProjection): CaptureOutcome =
        withContext(Dispatchers.Default) {
            val thread = HandlerThread("yasmin-capture").also { it.start() }
            val handler = Handler(thread.looper)
            var reader: ImageReader? = null
            var display: android.hardware.display.VirtualDisplay? = null
            try {
                val wm = context.getSystemService(WindowManager::class.java)
                val (rw, rh) = if (Build.VERSION.SDK_INT >= 30) {
                    val b = wm.currentWindowMetrics.bounds; b.width() to b.height()
                } else {
                    @Suppress("DEPRECATION")
                    val m = android.util.DisplayMetrics().also { wm.defaultDisplay.getRealMetrics(it) }
                    m.widthPixels to m.heightPixels
                }
                val dpi = context.resources.displayMetrics.densityDpi
                val scale = minOf(1f, 1600f / maxOf(rw, rh))
                val w = (rw * scale).toInt().coerceAtLeast(2) and 1.inv()
                val h = (rh * scale).toInt().coerceAtLeast(2) and 1.inv()

                reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
                val frame = CompletableDeferred<Unit>()
                reader.setOnImageAvailableListener({ frame.complete(Unit) }, handler)
                // Required on Android 14+: register a callback BEFORE creating the virtual display.
                projection.registerCallback(object : MediaProjection.Callback() {}, handler)
                display = projection.createVirtualDisplay(
                    "yasmin-screen", w, h, dpi,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader.surface, null, handler
                )

                if (withTimeoutOrNull(4000) { frame.await() } == null) {
                    return@withContext CaptureOutcome(null, false, "Timed out waiting for a screen frame.")
                }
                delay(350)   // let the first frame be replaced by a settled one
                val image = reader.acquireLatestImage()
                    ?: return@withContext CaptureOutcome(null, false, "No frame was available.")
                try {
                    val plane = image.planes[0]
                    val pixelStride = plane.pixelStride
                    val rowPadding = plane.rowStride - pixelStride * w
                    val full = Bitmap.createBitmap(w + rowPadding / pixelStride, h, Bitmap.Config.ARGB_8888)
                    full.copyPixelsFromBuffer(plane.buffer)
                    val bmp = Bitmap.createBitmap(full, 0, 0, w, h)
                    if (bmp !== full) full.recycle()
                    CaptureOutcome(bmp, isMostlyBlack(bmp), null)
                } finally {
                    image.close()
                }
            } catch (e: Exception) {
                CaptureOutcome(null, false, "Screen capture failed: ${e.javaClass.simpleName}")
            } finally {
                try { display?.release() } catch (_: Exception) {}
                try { reader?.close() } catch (_: Exception) {}
                try { projection.stop() } catch (_: Exception) {}
                thread.quitSafely()
            }
        }

    /** True when >99% of sampled pixels are (near) black: FLAG_SECURE, DRM video, or a secure system screen. */
    private fun isMostlyBlack(b: Bitmap): Boolean {
        var dark = 0; var total = 0
        val sx = maxOf(1, b.width / 40); val sy = maxOf(1, b.height / 40)
        var y = 0
        while (y < b.height) {
            var x = 0
            while (x < b.width) {
                val p = b.getPixel(x, y)
                val r = (p shr 16) and 0xFF; val g = (p shr 8) and 0xFF; val bl = p and 0xFF
                if (r < 8 && g < 8 && bl < 8) dark++
                total++
                x += sx
            }
            y += sy
        }
        return total > 0 && dark * 100 / total >= 99
    }
}
