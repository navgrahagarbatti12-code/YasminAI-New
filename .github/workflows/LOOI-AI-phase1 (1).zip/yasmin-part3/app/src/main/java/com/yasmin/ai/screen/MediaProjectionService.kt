package com.yasmin.ai.screen

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import androidx.core.content.IntentCompat
import com.yasmin.ai.MainActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** Foreground service (type mediaProjection) that takes exactly ONE screenshot, delivers it, then stops. */
class MediaProjectionService : Service() {

    companion object {
        private const val EXTRA_RESULT_CODE = "result_code"
        private const val EXTRA_DATA = "data"
        private const val EXTRA_DELAY_MS = "delay_ms"
        private const val CHANNEL = "yasmin_capture"
        private const val NOTIF_ID = 4101
        private const val DONE_NOTIF_ID = 4102

        fun start(context: Context, resultCode: Int, data: Intent, delayMs: Long) {
            val i = Intent(context, MediaProjectionService::class.java)
                .putExtra(EXTRA_RESULT_CODE, resultCode)
                .putExtra(EXTRA_DATA, data)
                .putExtra(EXTRA_DELAY_MS, delayMs)
            context.startForegroundService(i)
        }
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Screen capture", NotificationManager.IMPORTANCE_LOW))
        val n: Notification = Notification.Builder(this, CHANNEL)
            .setContentTitle("Yasmin is capturing your screen once")
            .setContentText("Nothing is sent until you approve it.")
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else startForeground(NOTIF_ID, n)

        val code = intent?.getIntExtra(EXTRA_RESULT_CODE, 0) ?: 0
        val data = intent?.let { IntentCompat.getParcelableExtra(it, EXTRA_DATA, Intent::class.java) }
        val delayMs = intent?.getLongExtra(EXTRA_DELAY_MS, 0L) ?: 0L

        scope.launch {
            val outcome = try {
                if (data == null) CaptureOutcome(null, false, "Missing screen-capture permission data.")
                else {
                    delay(delayMs)   // gives the user's target app time to come to the foreground
                    val mgr = getSystemService(MediaProjectionManager::class.java)
                    val projection = mgr.getMediaProjection(code, data)
                    ScreenCaptureManager.captureFrame(this@MediaProjectionService, projection)
                }
            } catch (e: Exception) {
                CaptureOutcome(null, false, "Could not start screen capture: ${e.javaClass.simpleName}")
            }
            ScreenCaptureManager.deliver(outcome)
            notifyDone(nm)
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
        return START_NOT_STICKY
    }

    /** Background activity starts are restricted on Android 10+, so we notify instead of forcing the app forward. */
    private fun notifyDone(nm: NotificationManager) {
        val open = Intent(this, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
        val pi = PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        try { startActivity(open) } catch (_: Exception) { /* blocked: the notification below is the fallback */ }
        nm.notify(
            DONE_NOTIF_ID,
            Notification.Builder(this, CHANNEL)
                .setContentTitle("Screenshot captured")
                .setContentText("Tap to review it before anything is sent.")
                .setSmallIcon(android.R.drawable.ic_menu_camera)
                .setContentIntent(pi)
                .setAutoCancel(true)
                .build()
        )
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }
}
