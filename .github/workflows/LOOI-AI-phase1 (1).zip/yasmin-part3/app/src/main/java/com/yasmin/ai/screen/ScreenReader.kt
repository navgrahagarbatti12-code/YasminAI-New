package com.yasmin.ai.screen

import android.graphics.Rect
import android.os.Build
import android.text.InputType
import android.text.Spanned
import android.text.style.URLSpan
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Walks an AccessibilityNodeInfo tree and produces a [ScreenSnapshot].
 * Only reads what the foreground app exposes. Never reads password/OTP-type inputs.
 * The CALLER owns [root] and must recycle it; this class recycles every child it obtains.
 */
class ScreenReader(
    private val maxNodes: Int = 3000,
    private val maxDepth: Int = 45
) {
    private class Ctx {
        var order = 0
        var visited = 0
        var hiddenSensitive = 0
        var unlabeled = 0
        var truncated = false
        val elements = ArrayList<ScreenElement>()
        val actions = ArrayList<ScreenAction>()
        val scrollables = ArrayList<ScrollableInfo>()
        val seenElements = HashSet<String>()
        val seenActions = HashSet<String>()
    }

    fun read(root: AccessibilityNodeInfo, appLabel: String?): ScreenSnapshot {
        val ctx = Ctx()
        try { root.refresh() } catch (_: Exception) { /* stale root: continue with what we have */ }
        traverse(root, 0, false, ctx)
        return ScreenSnapshot(
            packageName = root.packageName?.toString().orEmpty(),
            appLabel = appLabel,
            windowTitle = windowTitle(root),
            elements = ctx.elements,
            actions = ctx.actions,
            scrollables = ctx.scrollables,
            sensitiveFieldsHidden = ctx.hiddenSensitive,
            unlabeledControls = ctx.unlabeled,
            truncated = ctx.truncated,
            nodesVisited = ctx.visited
        )
    }

    /** Returns the texts emitted by this subtree (used to label clickable containers). */
    private fun traverse(node: AccessibilityNodeInfo, depth: Int, inListItem: Boolean, ctx: Ctx): List<String> {
        if (ctx.visited >= maxNodes || depth > maxDepth) { ctx.truncated = true; return emptyList() }
        ctx.visited++
        try {
            if (!node.isVisibleToUser) return emptyList()        // hidden content is not read
            val bounds = Rect().also { node.getBoundsInScreen(it) }
            if (bounds.width() <= 0 || bounds.height() <= 0) return emptyList()

            val className = node.className?.toString()
            val viewId = node.viewIdResourceName
            val text = node.text?.toString()?.trim()?.takeIf { it.isNotEmpty() }
            val desc = node.contentDescription?.toString()?.trim()?.takeIf { it.isNotEmpty() }
            val hint = hintOf(node)

            // ── Sensitive inputs: never read the value ──────────────────────────────
            if (isSensitive(node, hint, desc)) {
                ctx.hiddenSensitive++
                addElement(ctx, ElementKind.INPUT, "[sensitive field hidden]", hint ?: desc, viewId, className,
                    false, false, false, inListItem, bounds)
                return emptyList()
            }

            val inItem = inListItem || node.collectionItemInfo != null
            val actionsBefore = ctx.actions.size
            val emitted = ArrayList<String>()

            // ── Editable fields (search box / input) ────────────────────────────────
            if (node.isEditable) {
                val search = looksLikeSearch(node, hint, desc, className, viewId)
                val shown = text ?: "(empty${(hint ?: desc)?.let { ": $it" }.orEmpty()})"
                addElement(ctx, if (search) ElementKind.SEARCH_FIELD else ElementKind.INPUT,
                    shown, hint ?: desc, viewId, className, node.isClickable, false, false, inItem, bounds)
                if (text != null) emitted.add(text)
                addAction(ctx, (hint ?: desc ?: text ?: "text field"), listOf("edit"), viewId, className, null)
                collectScrollable(node, className, viewId, ctx)
                return emitted
            }

            val isLink = isLink(node)
            val heading = isHeading(node)

            // ── Own text ─────────────────────────────────────────────────────────────
            if (text != null) {
                addElement(ctx, ElementKind.TEXT, text, desc.takeIf { it != text }, viewId, className,
                    node.isClickable, heading, isLink, inItem, bounds)
                emitted.add(text)
            } else if (desc != null && node.childCount == 0) {
                // Leaf with only a content description (icons, image buttons)
                addElement(ctx, ElementKind.TEXT, desc, null, viewId, className,
                    node.isClickable, heading, isLink, inItem, bounds)
                emitted.add(desc)
            }

            // ── Children ─────────────────────────────────────────────────────────────
            val childTexts = ArrayList<String>()
            val count = try { node.childCount } catch (_: Exception) { 0 }
            for (i in 0 until count) {
                val child = try { node.getChild(i) } catch (_: Exception) { null } ?: continue   // null/stale child
                try {
                    childTexts += traverse(child, depth + 1, inItem, ctx)
                } finally {
                    recycle(child)
                }
            }

            // Container with only a description and no readable children
            if (text == null && desc != null && node.childCount > 0 && childTexts.isEmpty()) {
                addElement(ctx, ElementKind.TEXT, desc, null, viewId, className,
                    node.isClickable, heading, isLink, inItem, bounds)
                emitted.add(desc)
            }
            emitted.addAll(childTexts)

            // ── Controls ─────────────────────────────────────────────────────────────
            val types = ArrayList<String>()
            if (node.isClickable) types.add("click")
            if (node.isLongClickable) types.add("long-click")
            if (node.isCheckable) types.add("toggle")
            if (types.isNotEmpty()) {
                val ownLabel = text ?: desc
                val derived = ownLabel == null
                // Nested clickables: if a label-less parent already has labelled clickable children, the children are the real controls.
                if (!(derived && ctx.actions.size > actionsBefore)) {
                    val label = ownLabel
                        ?: childTexts.joinToString(" ").trim().take(80).takeIf { it.isNotEmpty() }
                    val state = when {
                        node.isCheckable -> if (node.isChecked) "on" else "off"
                        !node.isEnabled -> "disabled"
                        else -> null
                    }
                    if (label != null) {
                        addAction(ctx, label, types, viewId, className, state, bounds)
                    } else {
                        ctx.unlabeled++
                    }
                }
            }

            collectScrollable(node, className, viewId, ctx)
            return emitted
        } catch (_: IllegalStateException) {
            return emptyList()    // node became stale mid-read
        } catch (_: SecurityException) {
            return emptyList()
        }
    }

    // ── helpers ─────────────────────────────────────────────────────────────────────

    private fun addElement(
        ctx: Ctx, kind: ElementKind, text: String, description: String?, viewId: String?, className: String?,
        clickable: Boolean, heading: Boolean, link: Boolean, inList: Boolean, b: Rect
    ) {
        val clean = text.take(4000)
        // De-dup: same text at the same place (parent/child both exposing the same string)
        val key = "$clean|${b.left},${b.top},${b.right},${b.bottom}"
        if (!ctx.seenElements.add(key)) return
        ctx.elements.add(
            ScreenElement(ctx.order++, kind, clean, description, viewId, className, clickable, heading, link, inList,
                b.left, b.top, b.right, b.bottom)
        )
    }

    private fun addAction(
        ctx: Ctx, label: String, types: List<String>, viewId: String?, className: String?, state: String?,
        b: Rect? = null
    ) {
        val key = "$label|${b?.left},${b?.top},${b?.right},${b?.bottom}|${types.joinToString()}"
        if (!ctx.seenActions.add(key)) return
        ctx.actions.add(ScreenAction(label.take(120), types, viewId, className, state))
    }

    private fun collectScrollable(node: AccessibilityNodeInfo, className: String?, viewId: String?, ctx: Ctx) {
        if (!node.isScrollable) return
        val ids = node.actionList.map { it.id }.toSet()
        val rows = node.collectionInfo?.rowCount?.takeIf { it >= 0 }
        ctx.scrollables.add(
            ScrollableInfo(className, viewId,
                AccessibilityNodeInfo.ACTION_SCROLL_FORWARD in ids,
                AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD in ids, rows)
        )
    }

    private fun hintOf(node: AccessibilityNodeInfo): String? =
        if (Build.VERSION.SDK_INT >= 26) node.hintText?.toString()?.trim()?.takeIf { it.isNotEmpty() } else null

    private val sensitiveRegex = Regex(
        """(password|passcode|passwd|\botp\b|one.?time|\bpin\b|\bmpin\b|upi.?pin|cvv|cvc|card.?number|security.?code|verification.?code|aadhaar|\bssn\b)""",
        RegexOption.IGNORE_CASE
    )

    private fun isSensitive(node: AccessibilityNodeInfo, hint: String?, desc: String?): Boolean {
        if (node.isPassword) return true
        if (!node.isEditable) return false
        val it = node.inputType
        val variation = it and InputType.TYPE_MASK_VARIATION
        val cls = it and InputType.TYPE_MASK_CLASS
        if (cls == InputType.TYPE_CLASS_TEXT && (variation == InputType.TYPE_TEXT_VARIATION_PASSWORD ||
                variation == InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD ||
                variation == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD)) return true
        if (cls == InputType.TYPE_CLASS_NUMBER && variation == InputType.TYPE_NUMBER_VARIATION_PASSWORD) return true
        return listOf(node.viewIdResourceName, hint, desc).any { s -> s != null && sensitiveRegex.containsMatchIn(s) }
    }

    private fun looksLikeSearch(
        node: AccessibilityNodeInfo, hint: String?, desc: String?, className: String?, viewId: String?
    ): Boolean {
        val probe = listOfNotNull(hint, desc, viewId, className).joinToString(" ").lowercase()
        return "search" in probe || "खोज" in probe || "find" in probe || "query" in probe
    }

    private fun roleDescription(node: AccessibilityNodeInfo): String? =
        try { node.extras?.getCharSequence("AccessibilityNodeInfo.roleDescription")?.toString()?.lowercase() }
        catch (_: Exception) { null }

    private fun isLink(node: AccessibilityNodeInfo): Boolean {
        val t = node.text
        if (t is Spanned && t.getSpans(0, t.length, URLSpan::class.java).isNotEmpty()) return true
        return roleDescription(node)?.contains("link") == true
    }

    @Suppress("DEPRECATION")
    private fun isHeading(node: AccessibilityNodeInfo): Boolean {
        if (Build.VERSION.SDK_INT >= 28 && node.isHeading) return true
        if (node.collectionItemInfo?.isHeading == true) return true
        return roleDescription(node)?.contains("heading") == true
    }

    @Suppress("DEPRECATION")
    private fun windowTitle(root: AccessibilityNodeInfo): String? {
        val w = try { root.window } catch (_: Exception) { null } ?: return null
        return try {
            if (Build.VERSION.SDK_INT >= 24) w.title?.toString() else null
        } catch (_: Exception) { null } finally {
            try { w.recycle() } catch (_: Exception) {}
        }
    }

    @Suppress("DEPRECATION")
    private fun recycle(n: AccessibilityNodeInfo) {
        try { n.recycle() } catch (_: Exception) {}
    }
}
