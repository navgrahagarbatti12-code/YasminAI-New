package com.yasmin.ai.screen

// Pure Kotlin (no android.* imports) so it can be unit-tested on the JVM.

enum class ReadingMethod { ACCESSIBILITY, VISION, NONE }
enum class AccessibilityStatus { NOT_ENABLED, ENABLED_NOT_CONNECTED, CONNECTED }
enum class ProjectionStatus { NOT_REQUESTED, CONSENT_REQUIRED, GRANTED_FOR_THIS_CAPTURE, DENIED, UNAVAILABLE }
enum class AnalysisStatus { NOT_STARTED, AWAITING_CONSENT, IN_PROGRESS, DONE, CANCELLED, FAILED }

/** FULL = complete relative to what the app exposes to Accessibility. It never means "the whole screen". */
enum class ReadQuality { FULL, PARTIAL, EMPTY }

enum class ElementKind { TEXT, INPUT, SEARCH_FIELD }

data class ScreenElement(
    val order: Int,
    val kind: ElementKind,
    val text: String,
    val description: String? = null,
    val viewId: String? = null,
    val className: String? = null,
    val clickable: Boolean = false,
    val isHeading: Boolean = false,
    val isLink: Boolean = false,
    val inListItem: Boolean = false,
    val left: Int = 0, val top: Int = 0, val right: Int = 0, val bottom: Int = 0
)

data class ScreenAction(
    val label: String,
    val types: List<String>,          // click, long-click, toggle, edit
    val viewId: String? = null,
    val className: String? = null,
    val state: String? = null         // on / off / disabled
)

data class ScrollableInfo(
    val className: String?,
    val viewId: String?,
    val canScrollForward: Boolean,
    val canScrollBackward: Boolean,
    val totalItems: Int?
)

data class ScreenSnapshot(
    val packageName: String,
    val appLabel: String?,
    val windowTitle: String?,
    val elements: List<ScreenElement>,
    val actions: List<ScreenAction>,
    val scrollables: List<ScrollableInfo>,
    val sensitiveFieldsHidden: Int = 0,
    val unlabeledControls: Int = 0,
    val truncated: Boolean = false,
    val nodesVisited: Int = 0
) {
    val displayName: String get() = appLabel?.takeIf { it.isNotBlank() } ?: packageName

    val quality: ReadQuality
        get() = when {
            elements.isEmpty() -> ReadQuality.EMPTY
            truncated || sensitiveFieldsHidden > 0 || unlabeledControls > 0 || elements.size < 3 -> ReadQuality.PARTIAL
            else -> ReadQuality.FULL
        }

    /** Plain reading-order text, used for speech and (after consent) for cloud analysis. */
    fun plainText(): String = elements
        .filter { !(it.kind != ElementKind.TEXT && it.text.startsWith("[sensitive")) }
        .joinToString("\n") { it.text }

    /** Annotated text for on-screen review. */
    fun annotatedText(): String = elements.joinToString("\n") { e ->
        val tag = buildString {
            if (e.isHeading) append("[Heading] ")
            if (e.isLink) append("[Link] ")
            when (e.kind) {
                ElementKind.SEARCH_FIELD -> append("[Search field] ")
                ElementKind.INPUT -> append("[Input] ")
                else -> {}
            }
            if (e.inListItem && !e.isHeading) append("• ")
        }
        tag + e.text
    }
}

data class ScreenReadResult(
    val activeApp: String = "—",
    val packageName: String? = null,
    val accessibilityStatus: AccessibilityStatus = AccessibilityStatus.NOT_ENABLED,
    val projectionStatus: ProjectionStatus = ProjectionStatus.NOT_REQUESTED,
    val method: ReadingMethod = ReadingMethod.NONE,
    val analysisStatus: AnalysisStatus = AnalysisStatus.NOT_STARTED,
    val quality: ReadQuality? = null,
    val extractedText: String = "",
    val actions: List<ScreenAction> = emptyList(),
    val scrollables: List<ScrollableInfo> = emptyList(),
    val analysisText: String? = null,
    val errorReason: String? = null,
    val notes: List<String> = emptyList()
) {
    fun toDisplayText(): String = buildString {
        appendLine("Active app: $activeApp" + (packageName?.let { " ($it)" } ?: ""))
        appendLine("Accessibility: ${accessibilityStatus.name}")
        appendLine("Screenshot permission: ${projectionStatus.name}")
        appendLine("Reading method: ${method.name}" + (quality?.let { " — $it" } ?: ""))
        appendLine("Analysis: ${analysisStatus.name}")
        errorReason?.let { appendLine("Error / reason: $it") }
        notes.forEach { appendLine("Note: $it") }
        if (extractedText.isNotBlank()) {
            appendLine()
            appendLine("── Extracted text ──")
            appendLine(extractedText)
        }
        if (actions.isNotEmpty()) {
            appendLine()
            appendLine("── Available controls (${actions.size}) ──")
            actions.take(40).forEach { a ->
                appendLine("• ${a.label}" + (a.state?.let { " [$it]" } ?: "") + "  (${a.types.joinToString("/")})")
            }
            if (actions.size > 40) appendLine("… and ${actions.size - 40} more")
        }
        if (scrollables.isNotEmpty()) {
            appendLine()
            appendLine("── Scrollable areas ──")
            scrollables.forEach { s ->
                appendLine("• ${s.className?.substringAfterLast('.') ?: "view"}" +
                    " fwd=${s.canScrollForward} back=${s.canScrollBackward}" +
                    (s.totalItems?.let { " items≈$it" } ?: ""))
            }
        }
        analysisText?.let {
            appendLine()
            appendLine("── Analysis ──")
            appendLine(it)
        }
    }
}
