package com.yasmin.ai.vision

import android.app.AlertDialog
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.yasmin.ai.screen.ScreenCaptureManager
import com.yasmin.ai.voice.YasminVoiceRuntime
import kotlinx.coroutines.launch

/** Programmatic UI so the module has no layout-file dependencies. */
class VisionFragment : Fragment() {

    private val vm: VisionViewModel by activityViewModels()
    private lateinit var voice: YasminVoiceRuntime

    private lateinit var status: TextView
    private lateinit var resultView: TextView
    private lateinit var commandInput: EditText
    private lateinit var geminiKey: EditText
    private lateinit var groqKey: EditText
    private lateinit var btnFallback: Button
    private lateinit var btnAnalyze: Button
    private lateinit var progress: ProgressBar
    private var shownConsentId = -1L
    private var dialog: AlertDialog? = null

    private val projectionLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        vm.onProjectionResult(it.resultCode, it.data)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun button(label: String, onClick: () -> Unit) = Button(requireContext()).apply {
        text = label; isAllCaps = false; setOnClickListener { onClick() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        voice = YasminVoiceRuntime(requireContext().applicationContext)
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        val ctx = requireContext()
        val root = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(16), dp(16), dp(16)) }
        val title = TextView(ctx).apply { text = "Yasmin – Screen Reading"; textSize = 20f; setTypeface(null, Typeface.BOLD) }
        status = TextView(ctx).apply { setPadding(0, dp(8), 0, dp(8)) }
        progress = ProgressBar(ctx, null, android.R.attr.progressBarStyleHorizontal).apply { isIndeterminate = true; visibility = View.GONE }

        commandInput = EditText(ctx).apply { hint = "e.g. ChatGPT screen read karo"; setSingleLine(true) }
        val run = button("Run command") { runTypedCommand(0) }
        val delayed = button("Read after 5 s (switch app now)") { runTypedCommand(5000) }
        btnFallback = button("Analyze screenshot instead") { applyKeys(); vm.runCommand(com.yasmin.ai.screen.ScreenCommand(com.yasmin.ai.screen.ScreenIntent.VISION_ANALYZE)) }
        btnAnalyze = button("Analyze (manual, optional)") { applyKeys(); vm.manualAnalyze() }
        val a11y = button("Open Accessibility settings") { vm.requestAccessibilitySettings() }

        val providerGroup = RadioGroup(ctx).apply { orientation = RadioGroup.HORIZONTAL }
        val rbGemini = RadioButton(ctx).apply { text = "Gemini"; id = View.generateViewId(); isChecked = true }
        val rbGroq = RadioButton(ctx).apply { text = "Groq (text only)"; id = View.generateViewId() }
        providerGroup.addView(rbGemini); providerGroup.addView(rbGroq)
        providerGroup.setOnCheckedChangeListener { _, id ->
            vm.setProvider(if (id == rbGroq.id) VisionViewModel.Provider.GROQ else VisionViewModel.Provider.GEMINI)
        }
        geminiKey = EditText(ctx).apply { hint = "Gemini API key (kept in memory only)"; inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD }
        groqKey = EditText(ctx).apply { hint = "Groq API key (kept in memory only)"; inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD }

        resultView = TextView(ctx).apply { setTextIsSelectable(true); setPadding(0, dp(12), 0, 0) }

        listOf(title, status, progress, commandInput, run, delayed, btnFallback, btnAnalyze, a11y,
            providerGroup, geminiKey, groqKey, resultView).forEach { root.addView(it) }
        return ScrollView(ctx).apply { addView(root) }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch { vm.state.collect { render(it) } }
                launch { vm.events.collect { handle(it) } }
            }
        }
    }

    private fun applyKeys() = vm.setKeys(geminiKey.text.toString(), groqKey.text.toString())

    private fun runTypedCommand(delayMs: Long) {
        applyKeys()
        val text = commandInput.text.toString().ifBlank { "read my screen" }
        vm.handleCommandText(text, delayMs)
    }

    private fun handle(e: VisionViewModel.Event) {
        when (e) {
            is VisionViewModel.Event.RequestProjection ->
                projectionLauncher.launch(ScreenCaptureManager.createConsentIntent(requireContext()))
            is VisionViewModel.Event.SendAppToBackground -> requireActivity().moveTaskToBack(true)
            is VisionViewModel.Event.OpenAccessibilitySettings ->
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            is VisionViewModel.Event.Speak -> voice.speak(e.text, e.languageTag)
        }
    }

    private fun render(s: VisionViewModel.UiState) {
        status.text = s.statusLine
        progress.visibility = if (s.busy) View.VISIBLE else View.GONE
        resultView.text = s.result.toDisplayText()
        btnFallback.alpha = if (s.offerScreenshotFallback) 1f else 0.7f

        val c = s.pendingConsent
        if (c != null && c.id != shownConsentId) {
            shownConsentId = c.id
            showConsent(c)
        }
    }

    private fun showConsent(c: VisionViewModel.PendingConsent) {
        dialog?.dismiss()
        val ctx = requireContext()
        val box = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0) }
        val builder = AlertDialog.Builder(ctx).setCancelable(false)
        when (c) {
            is VisionViewModel.PendingConsent.Text -> {
                box.addView(TextView(ctx).apply {
                    text = "App: ${c.appName}\nSent to: ${c.provider.label} (cloud service)\nCharacters: ${c.text.length}\n\n" +
                        "This exact text will leave your device. It may contain private messages:"
                })
                val body = TextView(ctx).apply { text = c.text; setTextIsSelectable(true); setPadding(0, dp(8), 0, 0) }
                box.addView(ScrollView(ctx).apply {
                    addView(body)
                    layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(320))
                })
                builder.setTitle("Send this text to ${c.provider.label}?")
                    .setView(box)
                    .setPositiveButton("Send") { _, _ -> applyKeys(); vm.onTextConsent(c.id, true) }
                    .setNegativeButton("Cancel") { _, _ -> vm.onTextConsent(c.id, false) }
            }
            is VisionViewModel.PendingConsent.Image -> {
                box.addView(TextView(ctx).apply {
                    text = "Sent to: Google Gemini (${c.model})\nThe screenshot below may show private information. " +
                        "Nothing is sent unless you approve."
                })
                box.addView(ImageView(ctx).apply {
                    setImageBitmap(c.bitmap); adjustViewBounds = true
                    layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(360)).apply { gravity = Gravity.CENTER }
                    scaleType = ImageView.ScaleType.FIT_CENTER
                })
                builder.setTitle("Send this screenshot to Gemini?")
                    .setView(box)
                    .setPositiveButton("Send screenshot") { _, _ -> vm.onImageConsent(c.id, true) }
                    .setNegativeButton("Discard") { _, _ -> vm.onImageConsent(c.id, false) }
            }
        }
        dialog = builder.show()
    }

    override fun onDestroyView() {
        dialog?.dismiss(); dialog = null
        super.onDestroyView()
    }

    override fun onDestroy() {
        voice.shutdown()
        super.onDestroy()
    }
}
