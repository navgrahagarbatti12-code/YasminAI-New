package com.yasmin.ai.vision

import android.app.Activity
import android.app.Application
import android.content.Intent
import android.graphics.Bitmap
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.yasmin.ai.ai.AiException
import com.yasmin.ai.ai.GeminiClient
import com.yasmin.ai.ai.GroqClient
import com.yasmin.ai.ai.PromptBuilder
import com.yasmin.ai.screen.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.io.ByteArrayOutputStream

/**
 * Workflow: command -> read (Accessibility) -> review -> consent -> analyse -> display + speak.
 * Screenshot fallback: provider/model check -> projection consent -> capture -> privacy review -> consent -> analyse.
 * Nothing leaves the device without an explicit approval in [PendingConsent].
 */
class VisionViewModel(app: Application) : AndroidViewModel(app) {

    enum class Provider(val label: String) { GEMINI("Gemini"), GROQ("Groq") }

    sealed class PendingConsent {
        abstract val id: Long
        data class Text(
            override val id: Long, val provider: Provider, val appName: String,
            val text: String, val command: ScreenCommand
        ) : PendingConsent()

        data class Image(
            override val id: Long, val provider: Provider, val model: String,
            val bitmap: Bitmap, val command: ScreenCommand
        ) : PendingConsent()
    }

    data class UiState(
        val busy: Boolean = false,
        val statusLine: String = "Ready. Type a screen command, or use the buttons.",
        val result: ScreenReadResult = ScreenReadResult(),
        val pendingConsent: PendingConsent? = null,
        val offerScreenshotFallback: Boolean = false,
        val provider: Provider = Provider.GEMINI
    )

    sealed class Event {
        object RequestProjection : Event()
        object SendAppToBackground : Event()
        object OpenAccessibilitySettings : Event()
        data class Speak(val text: String, val languageTag: String?) : Event()
    }

    private val _state = MutableStateFlow(UiState())
    val state: StateFlow<UiState> = _state.asStateFlow()
    private val _events = MutableSharedFlow<Event>(extraBufferCapacity = 16)
    val events: SharedFlow<Event> = _events.asSharedFlow()

    // Keys live in memory only. They are never logged or written to disk.
    private var geminiKey = ""
    private var groqKey = ""
    private var job: Job? = null
    private var nextId = 1L
    private var lastSnapshot: ScreenSnapshot? = null
    private var lastCommand: ScreenCommand? = null
    private var visionModel: String? = null

    fun setProvider(p: Provider) = _state.update { it.copy(provider = p) }
    fun setKeys(gemini: String, groq: String) { geminiKey = gemini.trim(); groqKey = groq.trim() }
    fun requestAccessibilitySettings() { _events.tryEmit(Event.OpenAccessibilitySettings) }

    // ── Entry points ────────────────────────────────────────────────────────────────

    /** Returns false if the text is not a screen command (so CommandRouter can try something else). */
    fun handleCommandText(text: String, delayMs: Long = 0): Boolean {
        val cmd = ScreenCommandParser.parse(text)
        if (cmd == null) {
            _state.update { it.copy(statusLine = "That is not a screen-reading command.") }
            return false
        }
        runCommand(cmd, delayMs)
        return true
    }

    fun runCommand(cmd: ScreenCommand, delayMs: Long = 0) {
        job?.cancel()
        job = viewModelScope.launch {
            lastCommand = cmd
            if (cmd.intent == ScreenIntent.VISION_ANALYZE) beginVision(cmd) else readViaAccessibility(cmd, delayMs)
        }
    }

    /** Optional manual control: re-run analysis of what is currently held (still asks for consent again). */
    fun manualAnalyze() {
        val cmd = lastCommand?.takeIf { it.intent == ScreenIntent.EXPLAIN || it.intent == ScreenIntent.SUMMARIZE }
            ?: ScreenCommand(ScreenIntent.EXPLAIN)
        val snap = lastSnapshot
        job?.cancel()
        job = viewModelScope.launch {
            if (snap != null) prepareTextConsent(cmd, snap) else beginVision(cmd.copy(intent = ScreenIntent.VISION_ANALYZE))
        }
    }

    // ── Accessibility path ──────────────────────────────────────────────────────────

    private suspend fun readViaAccessibility(cmd: ScreenCommand, delayMs: Long) {
        val ctx = getApplication<Application>()
        _state.update { it.copy(busy = true, offerScreenshotFallback = false, pendingConsent = null,
            statusLine = "Reading screen…") }

        if (cmd.referencesPrevious && lastSnapshot != null) {
            afterRead(cmd, lastSnapshot!!)
            return
        }
        if (delayMs > 0) {
            _state.update { it.copy(statusLine = "Switch to the app you want me to read. Reading in ${delayMs / 1000}s…") }
            delay(delayMs)
        }

        val a11y = YasminAccessibilityService.status(ctx)
        val service = YasminAccessibilityService.instance
        if (service == null) {
            publish(
                ScreenReadResult(
                    accessibilityStatus = a11y, method = ReadingMethod.NONE,
                    errorReason = if (a11y == AccessibilityStatus.NOT_ENABLED)
                        "Yasmin's Accessibility service is not enabled. Enable it in Settings → Accessibility."
                    else "Accessibility service is enabled but not connected yet. Toggle it off and on, then retry."
                ),
                "Cannot read the screen yet.", offerFallback = true
            )
            return
        }

        val outcome = service.readActiveScreen(ownPackage = ctx.packageName)
        when (outcome.status) {
            ReadStatus.OWN_APP -> publish(
                ScreenReadResult(accessibilityStatus = a11y, errorReason =
                "Yasmin is in the foreground, so there is nothing else to read. Open the app you want, or use 'Read in 5 s' and switch apps."),
                "Open the app you want me to read first."
            )
            ReadStatus.NO_ACTIVE_WINDOW -> publish(
                ScreenReadResult(accessibilityStatus = a11y, errorReason = outcome.reason),
                "No readable window.", offerFallback = true
            )
            ReadStatus.OK_EMPTY -> {
                val s = outcome.snapshot!!
                publish(
                    ScreenReadResult(
                        activeApp = s.displayName, packageName = s.packageName, accessibilityStatus = a11y,
                        method = ReadingMethod.ACCESSIBILITY, quality = ReadQuality.EMPTY,
                        errorReason = "This screen exposes no text to Accessibility (custom drawing, game, video, WebView, or protected content). Text extraction is incomplete."
                    ),
                    "Accessibility could not read this screen. A screenshot analysis is available.", offerFallback = true
                )
            }
            ReadStatus.OK -> {
                val s = outcome.snapshot!!
                val t = cmd.target
                if (t != null && !t.matches(s.packageName, s.appLabel)) {
                    publish(
                        ScreenReadResult(
                            activeApp = s.displayName, packageName = s.packageName, accessibilityStatus = a11y,
                            errorReason = "You asked for ${t.displayName}, but the active app is ${s.displayName}. Open ${t.displayName} and try again."
                        ),
                        "Wrong app in the foreground."
                    )
                } else {
                    lastSnapshot = s
                    afterRead(cmd, s)
                }
            }
        }
    }

    private fun afterRead(cmd: ScreenCommand, s: ScreenSnapshot) {
        val ctx = getApplication<Application>()
        val a11y = YasminAccessibilityService.status(ctx)
        val chat = ChatGptScreenParser.isChatGpt(s.packageName, s.appLabel)
        val parsed = if (chat) ChatGptScreenParser.parse(s) else null
        val shownText = parsed?.toReviewText() ?: s.annotatedText()
        val notes = buildList {
            parsed?.let { add(it.note) }
            if (s.sensitiveFieldsHidden > 0) add("${s.sensitiveFieldsHidden} sensitive field(s) were hidden and not read.")
            if (s.truncated) add("The screen was very large; reading was cut off.")
            if (s.unlabeledControls > 0) add("${s.unlabeledControls} control(s) have no label exposed to Accessibility.")
            if (s.quality != ReadQuality.FULL) add("Text extraction may be incomplete: only content the app exposes to Accessibility can be read.")
        }
        val result = ScreenReadResult(
            activeApp = s.displayName, packageName = s.packageName, accessibilityStatus = a11y,
            method = ReadingMethod.ACCESSIBILITY, quality = s.quality,
            extractedText = shownText, actions = s.actions, scrollables = s.scrollables, notes = notes
        )
        val incomplete = s.quality != ReadQuality.FULL

        when (cmd.intent) {
            ScreenIntent.READ -> {
                publish(result, "Read locally on your device. Nothing was sent anywhere.", offerFallback = incomplete)
                val spoken = (parsed?.toReviewText() ?: s.plainText()).take(6000)
                _events.tryEmit(Event.Speak("${s.displayName}. $spoken", languageTagFor(spoken)))
            }
            else -> {
                publish(result, "Review the extracted text. Approve before anything is sent.", offerFallback = incomplete)
                viewModelScope.launch { prepareTextConsent(cmd, s) }
            }
        }
    }

    private fun prepareTextConsent(cmd: ScreenCommand, s: ScreenSnapshot) {
        val provider = _state.value.provider
        if (keyFor(provider).isBlank()) {
            fail("Enter a ${provider.label} API key first.", "Missing API key.")
            return
        }
        val chat = ChatGptScreenParser.isChatGpt(s.packageName, s.appLabel)
        val text = if (chat) ChatGptScreenParser.parse(s).toPromptText() else s.plainText()
        if (text.isBlank()) { fail("There is no text to analyse.", "Nothing to send."); return }
        _state.update {
            it.copy(
                busy = false, statusLine = "Waiting for your approval…",
                result = it.result.copy(analysisStatus = AnalysisStatus.AWAITING_CONSENT, errorReason = null),
                pendingConsent = PendingConsent.Text(nextId++, provider, s.displayName, text, cmd)
            )
        }
    }

    // ── Consent callbacks ───────────────────────────────────────────────────────────

    fun onTextConsent(id: Long, approved: Boolean) {
        val p = _state.value.pendingConsent as? PendingConsent.Text ?: return
        if (p.id != id) return
        _state.update { it.copy(pendingConsent = null) }
        if (!approved) {
            _state.update {
                it.copy(statusLine = "Cancelled. Nothing was sent.",
                    result = it.result.copy(analysisStatus = AnalysisStatus.CANCELLED))
            }
            return
        }
        job = viewModelScope.launch { analyzeText(p) }
    }

    fun onImageConsent(id: Long, approved: Boolean) {
        val p = _state.value.pendingConsent as? PendingConsent.Image ?: return
        if (p.id != id) return
        _state.update { it.copy(pendingConsent = null) }
        if (!approved) {
            p.bitmap.recycle()
            _state.update {
                it.copy(statusLine = "Screenshot discarded. Nothing was sent.",
                    result = it.result.copy(analysisStatus = AnalysisStatus.CANCELLED))
            }
            return
        }
        job = viewModelScope.launch { analyzeImage(p) }
    }

    // ── Cloud analysis ──────────────────────────────────────────────────────────────

    private suspend fun analyzeText(p: PendingConsent.Text) {
        _state.update {
            it.copy(busy = true, statusLine = "Asking ${p.provider.label}…",
                result = it.result.copy(analysisStatus = AnalysisStatus.IN_PROGRESS))
        }
        try {
            val prompt = PromptBuilder.forScreenText(p.command.intent.name, p.command.responseLanguage, p.appName, p.text)
            val answer = when (p.provider) {
                Provider.GEMINI -> GeminiClient(geminiKey).generateText(prompt)
                Provider.GROQ -> GroqClient(groqKey).generate(prompt)
            }
            finishAnalysis(answer, p.command.responseLanguage)
        } catch (e: AiException) {
            fail(e.userMessage, "Analysis failed.")
        } catch (e: Exception) {
            fail("Unexpected error: ${e.javaClass.simpleName}", "Analysis failed.")
        }
    }

    private suspend fun analyzeImage(p: PendingConsent.Image) {
        _state.update {
            it.copy(busy = true, statusLine = "Asking Gemini (${p.model}) to read the screenshot…",
                result = it.result.copy(analysisStatus = AnalysisStatus.IN_PROGRESS))
        }
        try {
            val jpeg = withContext(Dispatchers.Default) { encodeJpeg(p.bitmap) }
            val answer = GeminiClient(geminiKey).generate(p.model, PromptBuilder.forScreenshot(p.command.responseLanguage), jpeg)
            finishAnalysis(answer, p.command.responseLanguage, vision = true)
        } catch (e: AiException) {
            fail(e.userMessage, "Screenshot analysis failed.")
        } catch (e: Exception) {
            fail("Unexpected error: ${e.javaClass.simpleName}", "Screenshot analysis failed.")
        } finally {
            p.bitmap.recycle()     // the screenshot is not kept after analysis
        }
    }

    private fun finishAnalysis(answer: String, lang: String?, vision: Boolean = false) {
        _state.update {
            it.copy(
                busy = false, statusLine = "Done.",
                result = it.result.copy(
                    analysisStatus = AnalysisStatus.DONE, analysisText = answer, errorReason = null,
                    method = if (vision) ReadingMethod.VISION else it.result.method,
                    extractedText = if (vision) answer else it.result.extractedText
                )
            )
        }
        _events.tryEmit(Event.Speak(answer.take(6000), if (lang == "hi") "hi-IN" else languageTagFor(answer)))
    }

    // ── Screenshot path ─────────────────────────────────────────────────────────────

    private suspend fun beginVision(cmd: ScreenCommand) {
        val ctx = getApplication<Application>()
        _state.update { it.copy(busy = true, pendingConsent = null, statusLine = "Checking screenshot analysis availability…") }
        val a11y = YasminAccessibilityService.status(ctx)
        val base = ScreenReadResult(accessibilityStatus = a11y, method = ReadingMethod.VISION)

        if (_state.value.provider != Provider.GEMINI) {
            publish(base.copy(errorReason =
            "Screenshot analysis uses a Gemini vision model. Groq is used for text only here because image support depends on the specific Groq model and is not verified. Switch the provider to Gemini."),
                "Screenshot analysis needs Gemini.")
            return
        }
        if (geminiKey.isBlank()) { publish(base.copy(errorReason = "Enter a Gemini API key first."), "Missing API key."); return }
        try {
            visionModel = GeminiClient(geminiKey).resolveModel(requireVision = true)
        } catch (e: AiException) {
            publish(base.copy(errorReason = e.userMessage), "No vision model available."); return
        }
        publish(
            base.copy(projectionStatus = ProjectionStatus.CONSENT_REQUIRED,
                notes = listOf("Android will ask for screen-capture permission each time. Choose a single app or the entire screen.")),
            "Android needs your permission to capture the screen."
        )
        _events.emit(Event.RequestProjection)
    }

    fun onProjectionResult(resultCode: Int, data: Intent?) {
        val cmd = lastCommand ?: ScreenCommand(ScreenIntent.VISION_ANALYZE)
        if (resultCode != Activity.RESULT_OK || data == null) {
            _state.update {
                it.copy(busy = false, statusLine = "Screen-capture permission was not granted. Nothing was captured.",
                    result = it.result.copy(projectionStatus = ProjectionStatus.DENIED,
                        errorReason = "Screen-capture permission denied."))
            }
            return
        }
        job = viewModelScope.launch {
            val deferred = ScreenCaptureManager.prepare()
            _state.update {
                it.copy(busy = true, statusLine = "Capturing the screen…",
                    result = it.result.copy(projectionStatus = ProjectionStatus.GRANTED_FOR_THIS_CAPTURE))
            }
            MediaProjectionService.start(getApplication(), resultCode, data, delayMs = 1500)
            _events.emit(Event.SendAppToBackground)
            val outcome = withTimeoutOrNull(20_000) { deferred.await() }
            when {
                outcome == null -> fail("The capture timed out.", "Capture failed.")
                outcome.error != null -> fail(outcome.error, "Capture failed.")
                outcome.bitmap == null -> fail("No image was captured.", "Capture failed.")
                outcome.blankSuspected -> {
                    outcome.bitmap.recycle()
                    fail(
                        "The captured frame is black. This screen is probably protected (FLAG_SECURE, DRM video, or a secure system screen). Yasmin does not bypass these protections.",
                        "Protected or blank screen."
                    )
                }
                else -> {
                    val model = visionModel ?: "gemini"
                    _state.update {
                        it.copy(busy = false, statusLine = "Review the screenshot. Approve before it is sent.",
                            result = it.result.copy(analysisStatus = AnalysisStatus.AWAITING_CONSENT, errorReason = null),
                            pendingConsent = PendingConsent.Image(nextId++, Provider.GEMINI, model, outcome.bitmap, cmd))
                    }
                }
            }
        }
    }

    // ── helpers ─────────────────────────────────────────────────────────────────────

    private fun keyFor(p: Provider) = if (p == Provider.GEMINI) geminiKey else groqKey

    private fun publish(r: ScreenReadResult, status: String, offerFallback: Boolean = false) {
        _state.update { it.copy(busy = false, statusLine = status, result = r, offerScreenshotFallback = offerFallback) }
    }

    private fun fail(reason: String, status: String) {
        _state.update {
            it.copy(busy = false, statusLine = status,
                result = it.result.copy(analysisStatus = AnalysisStatus.FAILED, errorReason = reason))
        }
    }

    private fun encodeJpeg(src: Bitmap): ByteArray {
        val maxSide = 1280
        val scale = minOf(1f, maxSide.toFloat() / maxOf(src.width, src.height))
        val bmp = if (scale < 1f)
            Bitmap.createScaledBitmap(src, (src.width * scale).toInt(), (src.height * scale).toInt(), true) else src
        val out = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.JPEG, 85, out)
        if (bmp !== src) bmp.recycle()
        return out.toByteArray()
    }

    private fun languageTagFor(text: String): String? =
        if (text.any { it in '\u0900'..'\u097F' }) "hi-IN" else null
}
